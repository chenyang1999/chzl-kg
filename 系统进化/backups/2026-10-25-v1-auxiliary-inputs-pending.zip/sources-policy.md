# B3 七类既有辅助输入：一次签来源政策，程序每日列文件

**状态：仅草案、未批准、未部署。** `B2/pending-approval.patch` 的限制性 A 不构成本表授权。本次选择器/提示词/技能三文件差异及下列 SOUL 两处必要读取差异须同一次明确批准；缺任何一项就不应上线辅助读取。

一次签核内容：政策 `d1_existing_auxiliary_v1` 只对下列七类来源、业务日期规则与确切差异生效。以后程序每日自动按政策选择，写入既有 `research_summary.json.input_manifest.auxiliary_candidates`；**不要求用户每天签文件，不新增配置/来源/定时任务/输出目录**。路径清单是政策执行结果，不是授权主体。不得以 JSON `authorized=true`、模型自报或改 JSON 的 hash 自授权。

| 类别 | 允许（唯一入口） | 日期 / 来源时点规则 | 不允许 |
|---|---|---|---|
| 近期错题 | `data/corrections/YYYY-Www/error_case_*.md` 单层、选择后逐文件列出 | 沿 E1 现有 ISO 周目录，将“最近3周”明确为业务日所在周和前两 ISO 周（含当前未结束周）；带 `YYYYMMDD` 的文件名不得晚于业务日且须属于该周；无日期旧文件仅能说明所在周，精确生成时间未知 | 全历史 glob；`CORR_*.json`；嵌套目录、备份；直接运行会扩读全历史的 `get_all_corrections`；为了本次审查扫真实错题正文 |
| 股性 | `data/cache/stock_character.json` | 缓存生产者只写 `source/rows`，没有 `generated_at`；保留 `source`，可识别的来源文件名日期单列，缺时点记 null，不伪称每日更新 | `stock_character.source`、来源 XLSX、其它 cache；调用会重新构建缓存的 `load_character/build_cache`；把来源字段当路径继续打开 |
| 题材锚 | `data/rules/theme_anchors/latest.json` | 保留 `trade_date/generated_at/stock_xlsx`；latest 是共享内容文件而非当然同日产物，日期可早于业务日；缺字段显式保留，不加新陈旧天数阈值 | glob 任意日期快照；追读 stock_xlsx、概念原始材料；现场重建或恢复旧来源 |
| 宏观 | `data/runtime/hermes_macro_YYYYMMDD.json` | 文件名与内部 `trade_date` 精确匹配调用方业务日，保留生产者 `as_of`（可能无时区，不擅自补时区） | runtime 大目录权限；latest/邻日回退；私人账户、持仓、账本或诊断材料；重跑宏观抓取 |
| 预测 | `data/research/YYYYMMDD/node_prediction.json` | 名称已由 `src/research/node_predict.py::write_prediction` 及消费者核实，不是臆造；内部 `trade_date` 精确一致，保留 `generated_at`；生产者提供 tomorrow/two-step 分布但没有日期化目标字段，不擅自推断下一交易日 | 猜 `node_predict.json` 或其他别名；找最近有文件日补位；现场跑预测；把相对标签冒作明确目标日 |
| 情绪 | `data/research/YYYYMMDD/emotion_cycle.json` | 内部 `trade_date` 精确一致；保留 `generated_at` 和 `metrics.metrics_date/intraday_fallback/_data_complete`，业务日和数据观察日不混用 | 用 `emotion_cycle_closed.json` 或其它日文件补位；现场算法、MCP 或行情回填；mtime 当数据日 |
| 热度 | `data/research/YYYYMMDD/attention_signals.json` | 内部 `trade_date` 精确一致，保留 `generated_at`；生成日与业务日可不同，不能改写成业务日刚生成 | 其它热榜、跨日目录、累积缓存/账文件、原始群聊；现场重算或调用数据源 |

## 所有类别共同限制

- 业务日只使用现有流水线传入的 `trade_date`，严格 `YYYYMMDD`；选择器不擅自解析今日/最近交易日，不新增交易日历来源。调用方给出的日期是否真实开市日不由本草案另证。
- 六个固定 JSON 精确路径；错题只枚举三个精确周目录中的单层合法 basename。所有输入和父目录拒绝 symlink / `..` / 绝对路径逃逸。A3 的 R7 同日别名兼容不能扩大这些辅助路径。
- 对选中的具体文件记录 SHA-256、字节数、mtime_ns 作为版本指纹；**mtime_ns 只表示文件交付版本，不是来源日期**。缓存/最新文件的来源生成时点与缺失独立记录。不追读 JSON 中的引用路径。
- 缺失、非法路径/日期/JSON、不完整来源时点如实列出；缺失文件不在 inputs，不新增交易门禁或 R6 否决。合法缺失不是“已经读过/覆盖”。不为凑交付拉数据或造文件。
- 每次 D1 尝试前，现有 shell 预检由代码政策重新派生路径与 hash 集合，和 summary 逐项比较：文件改稿、消失、新错题加入、注入路径/类别/authorized 字段均拒绝旧清单，须原汇总方重建。D1 的提示词/技能要求仅按 inputs 精确路径 pull。
- 这不是防恶意写者的签名系统，也不是模型 file-tool 强制沙箱；有权同时改源与 summary 的主体可重建一致版本。预检至模型工具读之间仍有 TOCTOU；不声称模型已读、理解或采纳。若要求逐次 LLM 工具层强制 hash，需要另批工具读取集成，不夹带进本次三文件范围。

## 明确不变

不改变 R6、预算/零预算、禁新仓、交易资格、live 授权、输出白名单、角色工具集或永久任务；不修改任何真实实现/技能/profile/SOUL。现有技能中超出角色权限的其它输入/输出矛盾不是本次顺带解禁项。
