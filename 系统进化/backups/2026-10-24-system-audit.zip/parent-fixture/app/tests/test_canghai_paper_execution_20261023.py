"""Isolated synthetic paper exchange acceptance. No real account/quotes/config reads."""
from __future__ import annotations

import builtins
import copy
import importlib.util
import io
import json
import socket
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from trading.paper import PaperError, PaperLedger
from scripts.execute.run_paper_trading import main

SCRATCH = Path('/Users/chenyang/.hermes/cache/scratch')
NOW = '2026-10-23T10:00:01+08:00'
NEXT = '2026-10-26T10:00:01+08:00'
AUTH = 'fixture-user-paper-permission-20261023'
SYMBOL = '600000.SH'


def fixture(now=NOW):
    today = now[:10]
    units = ['R1','R2','R3','R4','R5','R6','R7']
    summary = {'trade_date': today, 'generated_at': today+'T08:40:00+08:00',
               'orchestrator_status': 'complete', 'contract_checks_passed': True,
               'contract_failures': {}, 'timeouts': [], 'fetch_global_severity': 0, 'hard_rejects': [],
               'units': {u:{'status':'complete'} for u in units},
               'artifacts': {u:'SYNTHETIC_TEST_ONLY/'+u+'.json' for u in units},
               'contract_results': {u:{'status':'passed','research_status':'complete'} for u in units}}
    r6 = {'trade_date': today, 'generated_at': today+'T08:30:00+08:00', 'status':'complete',
          'candidates_evaluated':1, 'upstream_usable':{u:True for u in units if u!='R6'},
          'hard_rejects':[], 'counter_arguments':[]}
    plan = {'schema_version': '1.0', 'trade_date': today.replace('-', ''), 'generated_at': today+'T09:00:00+08:00',
            'mode': 'dry_run', 'autonomous_trading_enabled': False, 'requires_user_confirmation': True,
            'status': 'ok', 'no_trade': False, 'no_trade_conditions': [],
            'meta': {'paper_trading_authorized': True, 'paper_authorization_id': AUTH,
                     'production_ready': True, 'research_completion_passed': True,
                     'research_summary': summary, 'r6_devil_advocate': r6},
            'risk_limits': {'target_total_position_pct': 1, 'max_positions': 3, 'max_buy_orders_per_day': 20,
                            'max_orders_per_symbol_per_day': 20, 'block_prefixes': [], 'block_st': True},
            'execution_pool': [{'ts_code': SYMBOL, 'name': 'SYNTHETIC_NOT_REAL_PRICE', 'is_st': False,
                                'max_position_pct': 1, 'buy_eligibility': {'status':'eligible','source':'synthetic_external_fixture'},
                                'stop_loss':9.75, 'take_profit':10.5,
                                'entry_rules': [{'type': 'low_absorption_intraday', 'trigger_price': 10.10, 'position_pct': 1}],
                                'exit_rules': [{'type': 'take_profit_hit', 'trigger_price': 10.50, 'quantity_pct': 1},
                                               {'type': 'stop_loss_break', 'trigger_price': 9.75, 'quantity_pct': 1}]}], 'watch_pool': []}
    quotes = {'quotes': [{'symbol': SYMBOL, 'source': 'synthetic_fixture_not_market', 'trade_date': today,
                         'observed_at': today+'T10:00:00+08:00', 'received_at': today+'T10:00:00.500000+08:00',
                         'board': 'main', 'security_type': 'common_stock', 'is_st': False,
                         'quantity_unit': 'shares', 'lot_size': 100, 'tick_size': '0.01',
                         'bid_price': '9.99', 'bid_size': 1000, 'ask_price': '10.00', 'ask_size': 1000,
                         'last_price': '10.00', 'lower_limit': '9.00', 'upper_limit': '11.00',
                         'suspended': False, 'at_upper_limit': False, 'at_lower_limit': False}]}
    calendar = {'source': 'synthetic_calendar_fixture', 'reliable': True, 'published_at': '2026-10-22T20:00:00+08:00',
                'coverage_start': '2026-10-22', 'coverage_end': '2026-10-30',
                'trading_days': ['2026-10-22', '2026-10-23', '2026-10-26', '2026-10-27', '2026-10-28', '2026-10-29', '2026-10-30']}
    intent = {'order_id': 'buy-1', 'symbol': SYMBOL, 'side': 'buy', 'quantity': 100, 'limit_price': '10.00', 'rule_index': 0}
    return plan, quotes, calendar, intent


class PaperAcceptance(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='paper_unit_', dir=SCRATCH)
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'paper_fixture.sqlite3'
        self.l = PaperLedger(self.path, fixture=True)
        self.guards = ExitStack()
        self.addCleanup(self.guards.close)
        for target in ['socket.socket', 'socket.create_connection', 'subprocess.Popen']:
            self.guards.enter_context(patch(target, side_effect=AssertionError('NETWORK_OR_PROCESS_FORBIDDEN')))
        original_open, original_io_open = builtins.open, io.open
        def guard(original):
            def checked(path, *args, **kwargs):
                if not isinstance(path, int):
                    resolved = Path(path).resolve()
                    if resolved.name == '.env' or resolved.is_relative_to(ROOT / 'data'):
                        raise AssertionError('REAL_CONFIG_OR_PRODUCTION_DATA_FORBIDDEN:' + str(resolved))
                return original(path, *args, **kwargs)
            return checked
        self.guards.enter_context(patch('builtins.open', side_effect=guard(original_open)))
        self.guards.enter_context(patch('io.open', side_effect=guard(original_io_open)))
        self.seed()

    def seed(self, cash='10000', fee=None, account='fixture'):
        return self.l.initialize(account_id=account, init_cash=cash, authorization_id=AUTH,
                                 seed_source='synthetic_test_only_not_user_production_seed',
                                 fee_model=fee or {'model': 'zero_fee_assumption'}, now=NOW)

    def run_order(self, data=None, now=NOW, ledger=None, age: str | None = '5'):
        p, q, c, i = data or fixture(now)
        return (ledger or self.l).execute(account_id='fixture', authorization_id=AUTH, intent=i,
                                        plan=p, quotes=q, calendar=c, quote_max_age=age, now=now)

    def snapshot(self, now=NOW):
        return self.l.snapshot('fixture', now=now)

    def assert_no_fill(self, data, reason, *, now=NOW, age='5'):
        result = self.run_order(data, now=now, age=age)
        self.assertEqual(result['fill_quantity'], 0, result)
        self.assertIn(reason, result.get('reason', ''), result)
        state = self.snapshot(now)
        self.assertEqual(state['cash_cents'], 1000000)
        self.assertEqual(state['positions'], {})
        self.assertEqual(state['fills'], [])

    def test_buy_t1_next_session_sell_restart_replay(self):
        self.assertEqual(self.run_order()['event'], 'paper_filled')
        self.assertEqual(self.snapshot()['cash_cents'], 900000)
        self.assertEqual(self.snapshot()['positions'][SYMBOL]['sellable_quantity'], 0)
        p,q,c,i = fixture()
        q['quotes'][0].update(last_price='10.60', bid_price='10.59', ask_price='10.60')
        q['quotes'][0].update(observed_at='2026-10-23T10:00:00.100000+08:00', received_at='2026-10-23T10:00:00.600000+08:00')
        i.update(order_id='same-day-sell', side='sell', limit_price='10.50')
        self.assertIn('t_plus_one', self.run_order((p,q,c,i))['reason'])
        p,q,c,i = fixture(NEXT)
        p['no_trade'] = True
        p['meta']['production_ready'] = False
        p['execution_pool'][0]['buy_eligibility'] = {'eligible': False, 'reasons': ['RR_FAIL']}
        q['quotes'][0].update(last_price='10.60', bid_price='10.59', ask_price='10.60')
        i.update(order_id='next-day-sell', side='sell', limit_price='10.50')
        result = self.run_order((p,q,c,i), now=NEXT)
        self.assertEqual(result['status'], 'filled', result)
        state = self.snapshot(NEXT)
        self.assertEqual(state['cash_cents'], 1005900)
        self.assertEqual(state['positions'], {})
        restarted = PaperLedger(self.path, fixture=True)
        result = self.run_order((p,q,c,i), now=NEXT, ledger=restarted)
        self.assertTrue(result['idempotent_replay'])
        self.assertEqual(len(self.snapshot(NEXT)['fills']), 2)

    def test_missing_seed_does_not_create_database(self):
        path = Path(self.temp.name)/'absent.sqlite3'
        with self.assertRaisesRegex(PaperError, 'paper_uninitialized'):
            self.run_order(ledger=PaperLedger(path, fixture=True))
        self.assertFalse(path.exists())

    def test_reinitialization_and_idempotency_conflict(self):
        with self.assertRaisesRegex(PaperError, 'already_initialized'):
            self.seed(cash='1000000')
        self.run_order()
        p,q,c,i = fixture()
        i['quantity'] = 200
        with self.assertRaisesRegex(PaperError, 'idempotency_key_conflict'):
            self.run_order((p,q,c,i))
        self.assertEqual(len(self.snapshot()['fills']), 1)

    def test_partial_and_displayed_liquidity_not_reused(self):
        p,q,c,i = fixture()
        i['quantity'] = 300
        q['quotes'][0]['ask_size'] = 150
        first = self.run_order((p,q,c,i))
        self.assertEqual((first['status'],first['fill_quantity']), ('partial',100))
        second = self.run_order((p,q,c,i))
        self.assertEqual(second['fill_quantity'], 0)
        i['order_id'] = 'different-order-same-book'
        self.assertEqual(self.run_order((p,q,c,i))['fill_quantity'], 0)
        i['order_id'] = 'buy-1'
        q['quotes'][0].update(observed_at='2026-10-23T10:00:00.100000+08:00', received_at='2026-10-23T10:00:00.600000+08:00', ask_size=200)
        final = self.run_order((p,q,c,i))
        self.assertEqual((final['status'], final['filled_quantity']), ('filled',300))
        self.assertEqual(self.snapshot()['cash_cents'],700000)

    def test_concurrent_duplicate_only_fills_once(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: self.run_order(ledger=PaperLedger(self.path, fixture=True)), range(16)))
        self.assertEqual(sum(not r['idempotent_replay'] for r in results),1)
        self.assertEqual(len(self.snapshot()['fills']),1)
        self.assertEqual(self.snapshot()['cash_cents'],900000)

    def test_transaction_rollback_on_failure_after_cash_mutation(self):
        with self.l.transaction() as db:
            db.execute("CREATE TRIGGER synthetic_failure BEFORE INSERT ON fills BEGIN SELECT RAISE(ABORT,'fixture_fill_failure'); END")
        with self.assertRaisesRegex(sqlite3.IntegrityError, 'fixture_fill_failure'):
            self.run_order()
        s = self.snapshot()
        self.assertEqual((s['cash_cents'],s['positions'],s['fills'],s['orders']), (1000000,{},[],[]))
        with self.l.transaction() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM liquidity').fetchone()[0],0)

    def test_fee_inclusive_cash_and_explicit_zero_label(self):
        fee = {'model':'flat_per_fill','buy':'1.25','sell':'2.50'}
        self.seed(cash='1000', fee=fee, account='small')
        p,q,c,i = fixture()
        r = self.l.execute(account_id='small',authorization_id=AUTH,intent=i,plan=p,quotes=q,calendar=c,quote_max_age='5',now=NOW)
        self.assertEqual(r['status'],'rejected')
        self.seed(cash='10000', fee=fee, account='fees')
        args = dict(account_id='fees',authorization_id=AUTH,intent=i,plan=p,quotes=q,calendar=c,quote_max_age='5')
        self.l.execute(**args,now=NOW)
        p,q,c,i = fixture(NEXT)
        q['quotes'][0].update(last_price='10.60',bid_price='10.59',ask_price='10.60')
        i.update(order_id='sell-fees',side='sell',limit_price='10.50')
        args.update(intent=i,plan=p,quotes=q,calendar=c)
        self.l.execute(**args,now=NEXT)
        s = self.l.snapshot('fees',now=NEXT)
        self.assertEqual((s['cash_cents'],s['fees_cents']), (1005525,375))
        self.assertEqual(self.snapshot()['fee_model']['model'],'zero_fee_assumption')

    def test_cash_single_total_rule_and_holdings_budget(self):
        for key, value in [('cash',None),('single',0),('total',0),('rule',0),('positions',1)]:
            with self.subTest(key=key):
                p,q,c,i = fixture()
                i['order_id'] = 'budget-'+key
                if key == 'cash': i['limit_price'] = '10000'; q['quotes'][0].update(last_price='10000',ask_price='10000',bid_price='9999',upper_limit='11000',lower_limit='9000'); p['execution_pool'][0]['entry_rules'][0]['trigger_price']='10001'
                if key == 'single': p['execution_pool'][0]['max_position_pct']=value
                if key == 'total': p['risk_limits']['target_total_position_pct']=value
                if key == 'rule': p['execution_pool'][0]['entry_rules'][0]['position_pct']=value
                if key == 'positions': p['risk_limits']['max_positions']=0
                self.assertEqual(self.run_order((p,q,c,i))['status'],'rejected')
        self.assertEqual(self.snapshot()['fills'],[])

    def test_global_conditions_r6_eligibility_and_authorization(self):
        mutations = [
            ('no_trade',lambda p:p.update(no_trade=True)),
            ('no_trade_condition',lambda p:p.update(no_trade_conditions=[{'code':'MAIN_DOWN','active':True}])),
            ('kill',lambda p:p['risk_limits'].update(kill_switch_active=True)),
            ('kill_file_unverified',lambda p:p['risk_limits'].update(kill_switch_file='data/runtime/KILL_SWITCH')),
            ('decision',lambda p:p.update(decision_status='no_trade')),
            ('unready',lambda p:p['meta'].update(production_ready=False)),
            ('reassessment',lambda p:p.update(reassessment_required=True)),
            ('stub',lambda p:p.update(status='stub')),
            ('paper_auth',lambda p:p['meta'].update(paper_trading_authorized=False)),
            ('auth_id',lambda p:p['meta'].update(paper_authorization_id='wrong')),
            ('live',lambda p:p.update(mode='live')),
            ('live_auth',lambda p:p.update(autonomous_trading_enabled=True)),
            ('r6',lambda p:p['execution_pool'][0].update(r6_hard_reject=True)),
            ('hard_list',lambda p:p.update(hard_rejects=[{'ts_code':SYMBOL}])),
            ('eligibility',lambda p:p['execution_pool'][0].update(buy_eligibility={'eligible':False})),
            ('missing_rr_price',lambda p:p['execution_pool'][0].update(take_profit=None)),
            ('watch_only',lambda p:p.update(watch_pool=p.pop('execution_pool'))),
            ('rebalance',lambda p:p.update(portfolio_rebalance={'max_new_buys_before_trim_done':0})),
        ]
        for label, mutate in mutations:
            with self.subTest(label=label):
                p,q,c,i = fixture(); i['order_id']=label; mutate(p)
                result=self.run_order((p,q,c,i))
                self.assertEqual(result['status'],'rejected',result)
        self.assertEqual(self.snapshot()['fills'],[])

    def test_missing_quote_fields_and_bad_metadata(self):
        required = ['source','symbol','trade_date','observed_at','received_at','bid_price','bid_size','ask_price','ask_size','last_price',
                    'lower_limit','upper_limit','suspended','at_upper_limit','at_lower_limit','tick_size','lot_size','quantity_unit','board','security_type','is_st']
        for key in required:
            with self.subTest(field=key):
                p,q,c,i=fixture(); i['order_id']='missing-'+key; q['quotes'][0].pop(key)
                r=self.run_order((p,q,c,i)); self.assertEqual(r['status'],'rejected',r)
        self.assertEqual(self.snapshot()['fills'],[])

    def test_future_stale_inverted_wrong_date_and_timezone(self):
        mutations=[('future',{'observed_at':'2026-10-23T10:00:03+08:00'}),
                   ('stale',{'observed_at':'2026-10-23T09:59:00+08:00'}),
                   ('received_future',{'received_at':'2026-10-23T10:00:03+08:00'}),
                   ('wrong_date',{'trade_date':'2026-10-22'}),
                   ('naive',{'observed_at':'2026-10-23T10:00:00'}),
                   ('tick',{'ask_price':'10.001'}),('suspended',{'suspended':True}),
                   ('crossed',{'bid_price':'10.01'}),('negative_depth',{'ask_size':-1}),
                   ('wrong_unit',{'quantity_unit':'lots'}),('nan',{'last_price':'NaN'}),('st',{'is_st':True})]
        for label, fields in mutations:
            with self.subTest(label=label):
                p,q,c,i=fixture();i['order_id']=label;q['quotes'][0].update(fields)
                self.assertEqual(self.run_order((p,q,c,i))['status'],'rejected')
        self.assertEqual(self.snapshot()['fills'],[])

    def test_lunch_close_weekend_and_calendar_fail_closed(self):
        for label, now in [('lunch','2026-10-23T12:32:00+08:00'),('close','2026-10-23T15:00:00+08:00'),('weekend','2026-10-24T10:00:01+08:00')]:
            with self.subTest(label=label):
                p,q,c,i=fixture(now);i['order_id']=label
                self.assert_no_fill((p,q,c,i),'session' if label!='weekend' else 'trading_day',now=now)
        # Independent accounts avoid any clock rewind for calendar variants.
        for label, change in [('unreliable',{'reliable':False}),('missing_next',{'trading_days':['2026-10-23']}),('coverage',{'coverage_end':'2026-10-22'})]:
            p,q,c,i=fixture('2026-10-26T10:00:01+08:00');i['order_id']=label;c.update(change)
            self.assertEqual(self.run_order((p,q,c,i),now=NEXT)['status'],'rejected')

    def test_limit_price_trigger_and_unsupported_rule(self):
        for label, mutate in [('limit',lambda p,q,i:i.update(limit_price='9.99')),
                               ('trigger',lambda p,q,i:p['execution_pool'][0]['entry_rules'][0].update(trigger_price='9.90')),
                               ('unsupported',lambda p,q,i:p['execution_pool'][0]['entry_rules'][0].update(type='daban_confirm')),
                               ('extra_signal',lambda p,q,i:p['execution_pool'][0]['entry_rules'][0].update(sealed_bid_threshold=20000)),
                               ('lot',lambda p,q,i:i.update(quantity=101)),
                               ('smallcap',lambda p,q,i:i.update(symbol='300001.SZ'))]:
            with self.subTest(label=label):
                p,q,c,i=fixture();i['order_id']=label;mutate(p,q,i)
                self.assertEqual(self.run_order((p,q,c,i))['status'],'rejected')
        self.assertEqual(self.snapshot()['fills'],[])

    def test_limit_up_no_ask_pending_not_fill(self):
        p,q,c,i=fixture();q['quotes'][0].update(last_price='11.00',bid_price='11.00',at_upper_limit=True,ask_price=None,ask_size=0)
        i['limit_price']='11.00'
        r=self.run_order((p,q,c,i))
        self.assertEqual((r['status'],r['event']),('pending','paper_no_fill'))
        self.assertEqual(self.snapshot()['positions'],{})

    def test_stop_loss_bypasses_buy_gates_but_cannot_short(self):
        self.run_order()
        p,q,c,i=fixture(NEXT)
        p.update(no_trade=True,no_trade_conditions=[{'active':True,'code':'MAIN_DOWN'}])
        p['execution_pool'][0].update(r6_hard_reject=True,buy_eligibility={'eligible':False})
        q['quotes'][0].update(last_price='9.40',bid_price='9.39',ask_price='9.40')
        i.update(order_id='stop',side='sell',quantity=200,rule_index=1,limit_price='9.30')
        r=self.run_order((p,q,c,i),now=NEXT)
        self.assertEqual((r['status'],r['fill_quantity']),('partial',100))
        self.assertEqual(self.snapshot(NEXT)['positions'],{})
        self.assertEqual(self.snapshot(NEXT)['cash_cents'],993900)
        i['order_id']='cannot-short'
        self.assertEqual(self.run_order((p,q,c,i),now=NEXT)['status'],'rejected')

    def test_clock_rollback_and_real_mode_no_now(self):
        self.run_order(now='2026-10-23T10:01:00+08:00',age='120')
        with self.assertRaisesRegex(PaperError,'clock_rollback'):
            self.run_order()
        real = PaperLedger(self.path,fixture=False)
        with self.assertRaisesRegex(PaperError,'historical_clock_forbidden'):
            real.clock(NOW)
        with self.assertRaisesRegex(PaperError,'fixture_requires_explicit_now'):
            self.l.clock()
        with self.assertRaisesRegex(PaperError,'path_not_allowed'):
            PaperLedger(ROOT/'data'/'runtime'/'oops.sqlite3',fixture=True)

    def test_quote_change_same_observation_not_new_depth(self):
        self.run_order()
        p,q,c,i=fixture();i['order_id']='changed-book';q['quotes'][0]['ask_size']=2000
        r=self.run_order((p,q,c,i))
        self.assertIn('conflicting_quote_observation',r['reason'])
        self.assertEqual(len(self.snapshot()['fills']),1)

    def test_quote_age_is_mandatory_positive(self):
        for idx,age in enumerate([None,'0','-1','NaN']):
            p,q,c,i=fixture();i['order_id']='age-'+str(idx)
            self.assertEqual(self.run_order((p,q,c,i),age=age)['status'],'rejected')

    def test_bad_plan_and_calendar_fields(self):
        for key in ['schema_version','trade_date','generated_at','mode','autonomous_trading_enabled','status','no_trade']:
            p,q,c,i=fixture();i['order_id']='plan-'+key;p.pop(key)
            self.assertEqual(self.run_order((p,q,c,i))['status'],'rejected')
        for key in ['reliable','source','published_at','coverage_start','coverage_end','trading_days']:
            p,q,c,i=fixture();i['order_id']='calendar-'+key;c.pop(key)
            self.assertEqual(self.run_order((p,q,c,i))['status'],'rejected')

    def test_daily_order_limit_and_valuation_required(self):
        self.run_order()
        p,q,c,i=fixture();i['order_id']='daily';p['risk_limits']['max_buy_orders_per_day']=1
        self.assertIn('daily_order_budget',self.run_order((p,q,c,i))['reason'])
        p,q,c,i=fixture();i['order_id']='valuation';i['symbol']='600001.SH'
        p['execution_pool'][0]['ts_code']='600001.SH';q['quotes'][0]['symbol']='600001.SH'
        self.assertIn('quote_missing',self.run_order((p,q,c,i))['reason'])
        p['risk_limits']['max_positions']=1;i['order_id']='holdings'
        self.assertIn('max_positions',self.run_order((p,q,c,i))['reason'])

    def test_breakout_requires_actual_trigger_and_ask_cap(self):
        p,q,c,i=fixture();p['execution_pool'][0]['entry_rules'][0].update(type='leader_breakout',trigger_price=10.10,max_acceptable_ask=10.20)
        p['execution_pool'][0]['take_profit']=11.5
        p['execution_pool'][0]['exit_rules'][0]['trigger_price']=11.5
        self.assert_no_fill((p,q,c,i),'entry_trigger_not_met')
        i['order_id']='breakout-triggered';q['quotes'][0].update(last_price='10.10',bid_price='10.09',ask_price='10.10');i['limit_price']='10.10'
        self.assertEqual(self.run_order((p,q,c,i))['status'],'filled')

    def test_selling_uses_bid_not_last(self):
        self.run_order()
        p,q,c,i=fixture(NEXT);q['quotes'][0].update(last_price='10.60',bid_price='10.40',ask_price='10.60')
        i.update(order_id='sell-not-marketable',side='sell',limit_price='10.50')
        r=self.run_order((p,q,c,i),now=NEXT)
        self.assertIn('limit_price_not_marketable',r['reason'])
        self.assertEqual(self.snapshot(NEXT)['positions'][SYMBOL]['quantity'],100)

    def test_cli_actual_dispatch_no_legacy_imports(self):
        p,q,c,i=fixture()
        for label,value in [('plan',p),('quotes',q),('calendar',c),('order',i)]:
            (Path(self.temp.name)/(label+'.json')).write_text(json.dumps(value))
        args=['execute','--database',str(self.path),'--account-id','fixture','--authorization-id',AUTH,'--fixture','--now',NOW,'--quote-max-age','5']
        for label in ['plan','quotes','calendar','order']:
            args += ['--'+label,str(Path(self.temp.name)/(label+'.json'))]
        output=io.StringIO()
        with redirect_stdout(output): code=main(args)
        self.assertEqual(code,0)
        self.assertEqual(json.loads(output.getvalue())['event'],'paper_filled')
        self.assertNotIn('src.settings',sys.modules)
        self.assertFalse(any('qmt' in module.lower() or module.startswith('ib_insync') for module in sys.modules))

    def test_new_rr_status_contract_recomputes_cached_ask(self):
        p,q,c,i=fixture()
        s=p['execution_pool'][0]
        s['engine_levels']={'ok':True,'trigger_price':10.1,'stop_loss':9.75,'take_profit':10.5}
        s['buy_eligibility']={'source':'price_levels_engine','status':'eligible','buy_price':9.90,'review_required':False}
        result=self.run_order((p,q,c,i))
        self.assertEqual(result['status'],'filled',result)
        self.assertEqual(result['buy_eligibility']['buy_price'],10.)
        self.assertEqual(s['buy_eligibility']['buy_price'],9.90)
        i['order_id']='cached-pass-but-bad-actual-rr'
        s['take_profit']=10.2;s['exit_rules'][0]['trigger_price']=10.2
        result=self.run_order((p,q,c,i))
        self.assertEqual(result['status'],'rejected',result)
        self.assertIn('RR_FAIL',result['reason'])

    def test_stock_conditions_and_r6_rejected_pool(self):
        for label,mutate in [('stock_condition',lambda p:p['execution_pool'][0].update(no_trade_conditions=[{'active':True,'code':'RR_FAIL'}])),
                             ('r6_rejected',lambda p:p.update(rejected=[{'ts_code':SYMBOL,'source_agent':'R6'}])),
                             ('unknown_rr',lambda p:p['execution_pool'][0].update(buy_eligibility={'status':'unknown'})),
                             ('review',lambda p:p['execution_pool'][0].update(buy_eligibility={'status':'eligible','review_required':True}))]:
            p,q,c,i=fixture();i['order_id']=label;mutate(p)
            self.assertEqual(self.run_order((p,q,c,i))['status'],'rejected')
        p,q,c,i=fixture();i['order_id']='other-stock-not-global'
        p['no_trade_conditions']=[{'active':True,'code':'RR_FAIL','scope':'stock','ts_code':'600001.SH'}]
        self.assertEqual(self.run_order((p,q,c,i))['status'],'filled')

    def test_explicit_zero_meta_and_derivation_caps(self):
        for label,change in [('meta',lambda p:p['meta'].update(position_cap_pct=0)),
                             ('derivation',lambda p:p.update(position_cap_derivation={'final_position_cap_pct':0}))]:
            p,q,c,i=fixture();i['order_id']=label;change(p)
            self.assert_no_fill((p,q,c,i),'global_no_new_buy')

    def test_multiple_buy_batches_t1_sell_only_older_batch(self):
        self.run_order()
        p,q,c,i=fixture(NEXT);i['order_id']='monday-buy'
        self.assertEqual(self.run_order((p,q,c,i),now=NEXT)['status'],'filled')
        state=self.snapshot(NEXT)['positions'][SYMBOL]
        self.assertEqual((state['quantity'],state['sellable_quantity']),(200,100))
        i.update(order_id='monday-sell',side='sell',quantity=200,limit_price='10.50')
        q['quotes'][0].update(observed_at='2026-10-26T10:00:00.100000+08:00',received_at='2026-10-26T10:00:00.600000+08:00',last_price='10.60',bid_price='10.59',ask_price='10.60')
        r=self.run_order((p,q,c,i),now=NEXT)
        self.assertEqual((r['status'],r['fill_quantity']),('partial',100))
        state=self.snapshot(NEXT)['positions'][SYMBOL]
        self.assertEqual((state['quantity'],state['sellable_quantity']),(100,0))

    def test_transport_timestamp_refresh_cannot_replenish_depth(self):
        p,q,c,i=fixture();q['quotes'][0]['ask_size']=100
        self.run_order((p,q,c,i))
        i['order_id']='received-again';q['quotes'][0]['received_at']='2026-10-23T10:00:00.900000+08:00'
        r=self.run_order((p,q,c,i))
        self.assertEqual(r['fill_quantity'],0)
        self.assertIn('depth_exhausted',r['reason'])

    def test_cli_requires_seed_and_age_no_hidden_defaults(self):
        absent=Path(self.temp.name)/'never-created.sqlite3'
        output=io.StringIO()
        with redirect_stdout(output):
            code=main(['init','--database',str(absent),'--account-id','empty','--fixture','--now',NOW])
        self.assertEqual(code,2);self.assertFalse(absent.exists())
        output=io.StringIO()
        with redirect_stdout(output):
            code=main(['execute','--database',str(self.path),'--account-id','fixture','--fixture','--now',NOW])
        self.assertEqual(code,2)
        self.assertIn('quote_max_age',output.getvalue())

    def test_import_is_inert_under_io_network_and_process_guards(self):
        original_import=builtins.__import__
        def imports(name,*args,**kwargs):
            if name.startswith('src') or 'qmt' in name.lower() or name.startswith('ib_insync'):
                raise AssertionError('FORBIDDEN_DEPENDENCY:'+name)
            return original_import(name,*args,**kwargs)
        with patch('builtins.__import__',side_effect=imports), \
             patch('pathlib.Path.read_text',side_effect=AssertionError('IMPORT_FILE_READ_FORBIDDEN')), \
             patch('sqlite3.connect',side_effect=AssertionError('IMPORT_DATABASE_CONNECTION_FORBIDDEN')):
            spec=importlib.util.spec_from_file_location('isolated_paper_import',ROOT/'trading/paper/ledger.py')
            assert spec is not None and spec.loader is not None
            spec.loader.exec_module(importlib.util.module_from_spec(spec))


if __name__ == '__main__':
    unittest.main()
