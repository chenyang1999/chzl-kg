"""Synthetic offline consumer integration, real schema and SQLite, never a real account."""
from __future__ import annotations

import builtins
import copy
import importlib.util
import io
import json
import socket
import sqlite3
import sys
import tempfile
from contextlib import ExitStack, redirect_stdout
from pathlib import Path
from unittest.mock import patch

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRATCH = Path('/Users/chenyang/.hermes/cache/scratch')
sys.path.insert(0, str(ROOT))
from trading.paper import PaperLedger
from scripts.execute.run_paper_trading import main

# Import ONLY this schema file; importing trading.schema also imports settings.
spec = importlib.util.spec_from_file_location('synthetic_paper_schema', ROOT/'trading/schema/watchlist_plan.py')
assert spec is not None and spec.loader is not None
schema = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = schema
spec.loader.exec_module(schema)
from src.plan.buy_eligibility import evaluate_stock_buy_eligibility, evaluate_plan_buy_gate

NOW = '2026-10-23T10:00:01+08:00'
NEXT = '2026-10-26T10:00:01+08:00'
AUTH = 'SYNTHETIC_paper_review_not_production'
SYMBOL = '600000.SH'
UNITS = ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7']


def research(today):
    summary = dict(trade_date=today.replace('-', ''), generated_at=today+'T08:40:00+08:00',
                   orchestrator_status='complete', contract_checks_passed=True, contract_failures={}, timeouts=[],
                   fetch_global_severity=0,
                   artifacts={u:f'SYNTHETIC/{today}/{u}.json' for u in UNITS},
                   units={u:{'status':'complete'} for u in UNITS},
                   contract_results={u:{'status':'passed', 'research_status':'complete'} for u in UNITS}, hard_rejects=[])
    r6 = dict(trade_date=today.replace('-', ''), generated_at=today+'T08:30:00+08:00', status='complete',
              candidates_evaluated=1, upstream_usable={u:True for u in UNITS if u!='R6'},
              hard_rejects=[], counter_arguments=[], source='SYNTHETIC_R6_NOT_RESEARCH')
    return summary, r6


def fixture(now=NOW):
    today = now[:10]
    summary, r6 = research(today)
    stock = schema.StockEntry(ts_code=SYMBOL, name='SYNTHETIC_NOT_REAL_PRICES', score=90,
        role='leader', plan_status='execution_pool_hold', max_position_pct=1,
        stop_loss=9.5, take_profit=11.5,
        entry_rules=[dict(type='trend_pullback_buy', trigger_price=10.1, buy_zone=[9.9,10.1], position_pct=1,
                          execution_logic='SYNTHETIC numeric price-only setup', price_src='D1',
                          engine_formula={'buy':'synthetic derivation, not a signal'})],
        exit_rules=[dict(type='take_profit_hit', trigger_price=11.5, quantity_pct=1),
                    dict(type='stop_loss_break', trigger_price=9.5, quantity_pct=1)],
        buy_eligibility={'status':'eligible', 'source':'synthetic_external_research'})
    # Full serialized defaults and explicit, mutually consistent RR/exit prices.
    plan = schema.WatchlistPlan(trade_date=today, generated_at=today+'T09:00:00+08:00',
        no_trade=False, execution_pool=[stock],
        meta=dict(paper_trading_authorized=True, paper_authorization_id=AUTH, production_ready=True,
                  research_completion_passed=True, research_summary=summary, r6_devil_advocate=r6),
        risk_limits=dict(target_total_position_pct=1, max_positions=3, max_buy_orders_per_day=20,
                         max_orders_per_symbol_per_day=20, block_prefixes=[], kill_switch_active=False)).model_dump_plan()
    quotes = {'quotes':[dict(symbol=SYMBOL, source='synthetic_fixture_not_market', trade_date=today,
        observed_at=today+'T10:00:00+08:00', received_at=today+'T10:00:00.500000+08:00',
        board='main', security_type='common_stock', is_st=False, quantity_unit='shares', lot_size=100,
        tick_size=.01, bid_price=9.99, bid_size=1000, ask_price=10., ask_size=1000, last_price=10.,
        lower_limit=9., upper_limit=12., suspended=False, at_upper_limit=False, at_lower_limit=False)]}
    calendar = dict(source='synthetic_calendar', reliable=True, published_at='2026-10-22T20:00:00+08:00',
        coverage_start='2026-10-22', coverage_end='2026-10-30',
        trading_days=['2026-10-23','2026-10-26','2026-10-27','2026-10-28','2026-10-29','2026-10-30'])
    intent = dict(order_id='buy-1', symbol=SYMBOL, side='buy', quantity=100, limit_price=10., rule_index=0)
    return plan, quotes, calendar, intent


@pytest.fixture
def env():
    with tempfile.TemporaryDirectory(prefix='paper_parent_synthetic_', dir=SCRATCH) as d, ExitStack() as guards:
        directory = Path(d)
        # No network, subprocess, config/credentials, production artifacts or writes outside scratch.
        for target in ['socket.socket', 'socket.create_connection', 'subprocess.Popen']:
            guards.enter_context(patch(target, side_effect=AssertionError('NETWORK_PROCESS_FORBIDDEN')))
        original_import = builtins.__import__
        def imports(name, *args, **kwargs):
            if name=='src.settings' or 'qmt' in name.lower() or name.startswith(('ib_insync','dotenv')):
                raise AssertionError('BROKER_SETTINGS_CREDENTIAL_IMPORT_FORBIDDEN:'+name)
            return original_import(name, *args, **kwargs)
        guards.enter_context(patch('builtins.__import__', side_effect=imports))
        def guard(original):
            def checked(path,*args,**kwargs):
                if not isinstance(path,int):
                    resolved=Path(path).resolve()
                    mode=args[0] if args else kwargs.get('mode','r')
                    if resolved.name=='.env' or resolved.is_relative_to(ROOT/'data'):
                        raise AssertionError('PRODUCTION_CREDENTIAL_ACCESS_FORBIDDEN:'+str(resolved))
                    if any(m in mode for m in 'wax+') and not resolved.is_relative_to(SCRATCH):
                        raise AssertionError('WRITE_OUTSIDE_SCRATCH_FORBIDDEN:'+str(resolved))
                return original(path,*args,**kwargs)
            return checked
        guards.enter_context(patch('builtins.open',side_effect=guard(builtins.open)))
        guards.enter_context(patch('io.open',side_effect=guard(io.open)))
        original_connect=sqlite3.connect
        def connect(path,*args,**kwargs):
            assert str(path).startswith((str(SCRATCH), SCRATCH.as_uri())), path
            return original_connect(path,*args,**kwargs)
        guards.enter_context(patch('sqlite3.connect',side_effect=connect))
        ledger=PaperLedger(directory/'fixture.sqlite3',fixture=True)
        ledger.initialize(account_id='synthetic',init_cash='1000000',authorization_id=AUTH,
            seed_source='SYNTHETIC_OFFLINE_ONLY',fee_model={'model':'zero_fee_assumption'},now=NOW)
        yield ledger, directory


def execute(env, data=None, now=NOW, **kwargs):
    p,q,c,i=data or fixture(now)
    return env[0].execute(account_id='synthetic',authorization_id=AUTH,intent=i,plan=p,quotes=q,
                          calendar=c,quote_max_age='5',now=now,**kwargs)


def assert_reject(env, data, reason=None):
    result=execute(env,data)
    assert result['status']=='rejected', result
    assert result['fill_quantity']==0, result
    if reason:
        assert reason in result.get('reason',''), result
    snap=env[0].snapshot('synthetic',now=NOW)
    assert snap['fills']==[] and snap['positions']=={} and snap['cash_cents']==100000000
    return result


def test_real_schema_shared_helpers_cli_saved_json_fill_snapshot(env):
    p,q,c,i=fixture()
    assert p['execution_pool'][0]['entry_rules'][0]['sealed_bid_threshold'] is None
    assert evaluate_stock_buy_eligibility(p['execution_pool'][0],10.,entry_rule=p['execution_pool'][0]['entry_rules'][0])['status']=='eligible'
    assert evaluate_plan_buy_gate(p)['status']=='eligible'
    before=copy.deepcopy(p)
    args=['execute','--database',str(env[0].path),'--account-id','synthetic','--authorization-id',AUTH,
          '--fixture','--now',NOW,'--quote-max-age','5']
    for label,obj in [('plan',p),('quotes',q),('calendar',c),('order',i)]:
        path=env[1]/(label+'.json');path.write_text(json.dumps(obj));args += ['--'+label,str(path)]
    output=io.StringIO()
    with redirect_stdout(output):
        code=main(args)
    result=json.loads(output.getvalue())
    assert code==0 and result['event']=='paper_filled',result
    assert p==before and json.loads((env[1]/'plan.json').read_text())==p
    assert result['buy_eligibility']['buy_price']==10. and result['buy_eligibility']['risk_reward_ratio']==3.
    assert result['global_buy_gate']['status']=='eligible'
    with env[0].transaction() as db:
        evidence=json.loads(db.execute('SELECT evidence_json FROM fills').fetchone()[0])
        saved_result=json.loads(db.execute('SELECT result_json FROM orders').fetchone()[0])
    assert evidence['buy_eligibility']==result['buy_eligibility']==saved_result['buy_eligibility']
    assert evidence['stock_snapshot']['exit_rules']==p['execution_pool'][0]['exit_rules']
    assert evidence['accounting']=='gross_zero_fee_assumption'
    snap=env[0].snapshot('synthetic',now=NOW)
    assert snap['cash_cents']==99900000 and snap['positions'][SYMBOL]['quantity']==100
    assert len(snap['fills'])==1 and SYMBOL in snap['managed_exit_plans']
    assert 'src.settings' not in sys.modules
    assert not any('qmt' in m.lower() for m in sys.modules)


def test_actual_ask_recomputed_not_cached_price(env):
    p,q,c,i=fixture(); s=p['execution_pool'][0]
    s['engine_levels']=dict(ok=True,buy_zone=[9.9,10.1],trigger_price=10.1,stop_loss=9.5,take_profit=11.5)
    s['buy_eligibility']=dict(source='price_levels_engine',status='eligible',buy_price=9.91,review_required=False)
    result=execute(env,(p,q,c,i))
    assert result['event']=='paper_filled',result
    assert result['buy_eligibility']['buy_price']==10.
    assert s['buy_eligibility']['buy_price']==9.91


@pytest.mark.parametrize('missing', ['stop_loss','take_profit','bad_rr','bad_order'])
def test_forged_eligible_cannot_bypass_actual_rr(env,missing):
    p,q,c,i=fixture();s=p['execution_pool'][0]
    s['buy_eligibility']={'status':'eligible','eligible':True,'source':'forged_test'}
    if missing in ['stop_loss','take_profit']: s[missing]=None
    if missing=='bad_rr': s['take_profit']=10.4
    if missing=='bad_order': s['stop_loss']=10.01
    result=assert_reject(env,(p,q,c,i),'stock_buy_ineligible')
    assert result['buy_eligibility']['status']!='eligible'


def test_selected_rule_controls_rr_and_trigger(env):
    p,q,c,i=fixture();s=p['execution_pool'][0]
    s['entry_rules'].insert(0,dict(type='trend_pullback_buy',trigger_price=8.,position_pct=1))
    i['rule_index']=1
    result=execute(env,(p,q,c,i))
    assert result['event']=='paper_filled',result
    assert result['buy_eligibility']['buy_price']==10.


def test_only_owned_stale_stock_rr_state_can_be_replaced(env):
    p,q,c,i=fixture();s=p['execution_pool'][0]
    s['engine_levels']=dict(ok=True,buy_zone=[9.9,10.1],trigger_price=10.1,stop_loss=9.5,take_profit=11.5)
    s['buy_eligibility']=dict(source='price_levels_engine',status='blocked',buy_price=10.9,review_required=False)
    s['no_trade_conditions']=[dict(source='price_levels_engine',code='RR_FAIL',active=True)]
    result=execute(env,(p,q,c,i));assert result['event']=='paper_filled',result


@pytest.mark.parametrize('qualification', [
    dict(status='blocked'),dict(status='unknown'),dict(status='eligible',eligible=False),
    dict(status='eligible',review_required=True),
    dict(source='price_levels_engine',status='eligible',review_required=True),
    dict(source='price_levels_engine',status='eligible',external_qualification=dict(status='blocked')),
    dict(source='price_levels_engine',status='eligible',external_qualification=dict(status='eligible',review_required=True)),
])
def test_external_veto_and_explicit_review_preserved(env,qualification):
    p,q,c,i=fixture();p['execution_pool'][0]['buy_eligibility']=qualification
    assert_reject(env,(p,q,c,i))


@pytest.mark.parametrize('field,value', [('auction_confirm',True),('volume_ratio',2),('board_confirm',False),
    ('sealed_bid_threshold',10000),('only_first_seal',False),('max_break_count_today',1),
    ('trigger_condition','volume > yesterday'),('max_premium_pct',.03),('t_round_limit',1)])
def test_nonprice_signal_never_silently_ignored(env,field,value):
    p,q,c,i=fixture();p['execution_pool'][0]['entry_rules'][0][field]=value
    assert_reject(env,(p,q,c,i),'unsupported')


@pytest.mark.parametrize('ask,ok', [(9.89,False),(9.9,True),(10.,True),(10.1,True),(10.11,False)])
def test_numeric_buy_zone_both_bounds(env,ask,ok):
    p,q,c,i=fixture();q['quotes'][0].update(ask_price=ask,last_price=ask,bid_price=round(ask-.01,2));i['limit_price']=ask
    result=execute(env,(p,q,c,i))
    assert (result['event']=='paper_filled') is ok,result


def test_target_only_and_confirm_price_predicates(env):
    p,q,c,i=fixture();r=p['execution_pool'][0]['entry_rules'][0]
    r.update(trigger_price=None,buy_zone=None,entry_target_price=10.1)
    assert execute(env,(p,q,c,i))['event']=='paper_filled'
    i['order_id']='unconfirmed';r['confirm_price']=10.2
    result=execute(env,(p,q,c,i));assert result['status']=='rejected' and 'trigger' in result['reason'],result


@pytest.mark.parametrize('location,rows', [('root',[SYMBOL]),('meta',[{'ts_code':SYMBOL}]),
    ('applied',[SYMBOL]),('applied',[{'target_ts_code':SYMBOL}]),('applied',['R6_M6_01']),
    ('applied',['UNRESOLVED_REJECT_ID']),('raw',[{'ts_code':SYMBOL}]),('summary',[{'ts_code':SYMBOL}])])
def test_r6_hard_reject_sources_and_aliases(env,location,rows):
    p,q,c,i=fixture();meta=p['meta'];raw=meta['r6_devil_advocate']
    raw['counter_arguments']=[dict(reject_id='R6_M6_01',target_ts_code=SYMBOL,severity='soft_suggest')]
    if location=='root':p['hard_rejects']=rows
    if location=='meta':meta['r6_devil_advocate']={**raw,'hard_rejects':rows}
    if location=='applied':meta['r6_devil_advocate']['hard_rejects_applied']=rows
    if location=='raw':raw['hard_rejects']=rows
    if location=='summary':meta['research_summary']['hard_rejects']=rows
    assert_reject(env,(p,q,c,i),'r6_')


@pytest.mark.parametrize('case', ['missing_ready','missing_completion','missing_summary','missing_unit','bad_unit',
    'missing_contract','failed_contract','missing_r6','zero_r6','degraded_r6','missing_r6_upstream',
    'unusable_r6_upstream','old_summary','future_summary','no_summary_source','no_trade','zero_total',
    'unknown_total','missing_total','zero_meta','unknown_cap','stock_foreign_condition','global_foreign_condition'])
def test_missing_or_unready_research_global_and_budget_fail_closed(env,case):
    p,q,c,i=fixture();m=p['meta'];s=p['execution_pool'][0];summary=m['research_summary'];r6=m['r6_devil_advocate']
    if case=='missing_ready':m.pop('production_ready')
    if case=='missing_completion':m.pop('research_completion_passed')
    if case=='missing_summary':m.pop('research_summary')
    if case=='missing_unit':summary['units'].pop('R5')
    if case=='bad_unit':summary['units']['R5']['status']='skipped'
    if case=='missing_contract':summary['contract_results'].pop('R4')
    if case=='failed_contract':summary['contract_checks_passed']=False
    if case=='missing_r6':m.pop('r6_devil_advocate')
    if case=='zero_r6':r6['candidates_evaluated']=0
    if case=='degraded_r6':r6['status']='degraded'
    if case=='missing_r6_upstream':r6['upstream_usable'].pop('R5')
    if case=='unusable_r6_upstream':r6['upstream_usable']['R5']=False
    if case=='old_summary':summary['trade_date']='20261022'
    if case=='future_summary':summary['generated_at']='2026-10-23T11:00:00+08:00'
    if case=='no_summary_source':summary['artifacts']['R5']=''
    if case=='no_trade':p['no_trade']=True
    if case=='zero_total':p['risk_limits']['target_total_position_pct']=0
    if case=='unknown_total':p['risk_limits']['target_total_position_pct']=None
    if case=='missing_total':p['risk_limits'].pop('target_total_position_pct')
    if case=='zero_meta':m['position_cap_pct']=0
    if case=='unknown_cap':p['position_cap_derivation']={'final_position_cap_pct':None}
    if case=='stock_foreign_condition':s['no_trade_conditions']=[dict(source='manual',code='RR_FAIL',active=True)]
    if case=='global_foreign_condition':p['no_trade_conditions']=[dict(source='price_levels_engine',code='RR_FAIL',active=True)]
    assert_reject(env,(p,q,c,i))


def test_stock_scoped_condition_for_other_symbol_is_not_global(env):
    p,q,c,i=fixture();p['no_trade_conditions']=[dict(scope='stock',ts_code='600001.SH',code='OTHER',active=True)]
    result=execute(env,(p,q,c,i));assert result['event']=='paper_filled',result


def test_missing_cache_is_recomputed_from_real_fields(env):
    p,q,c,i=fixture();p['execution_pool'][0].pop('buy_eligibility')
    result=execute(env,(p,q,c,i));assert result['event']=='paper_filled',result


def test_saved_exit_survives_new_pool_absence_and_buy_gates(env):
    p,q,c,i=fixture();buy=execute(env,(p,q,c,i));assert buy['event']=='paper_filled',buy
    source_hash=buy['plan_sha256']
    p,q,c,i=fixture(NEXT);p['execution_pool']=[];p['meta'].pop('research_summary');p['meta']['production_ready']=False
    p['no_trade']=True;p['risk_limits']['target_total_position_pct']=0
    q['quotes'][0].update(last_price=11.6,bid_price=11.59,ask_price=11.6)
    i.update(order_id='saved-exit',side='sell',limit_price=11.5)
    result=execute(env,(p,q,c,i),now=NEXT);assert result['event']=='paper_filled',result
    assert result['exit_source']['plan_sha256']==source_hash
    snap=env[0].snapshot('synthetic',now=NEXT)
    assert snap['positions']=={} and snap['cash_cents']==100015900


def test_new_explicit_exit_source_updates_and_persists(env):
    assert execute(env)['event']=='paper_filled'
    p,q,c,i=fixture(NEXT);p['execution_pool'][0]['exit_rules'][0]['trigger_price']=11.8
    i.update(order_id='update-exit-not-hit',side='sell',limit_price=11.5)
    q['quotes'][0].update(last_price=11.6,bid_price=11.59,ask_price=11.6)
    result=execute(env,(p,q,c,i),now=NEXT)
    assert result['status']=='rejected' and 'exit_trigger_not_met' in result['reason'],result
    snap=env[0].snapshot('synthetic',now=NEXT)
    saved=snap['managed_exit_plans'][SYMBOL]
    assert saved['stock']['exit_rules'][0]['trigger_price']==11.8
    p['execution_pool']=[];i['order_id']='saved-new-exit';q['quotes'][0].update(last_price=11.9,bid_price=11.89,ask_price=11.9)
    result=execute(env,(p,q,c,i),now=NEXT);assert result['event']=='paper_filled',result
    assert result['exit_source']['plan_sha256']==saved['plan_sha256']


def test_missing_exit_source_cannot_invent_sell_or_force_liquidation(env):
    assert execute(env)['event']=='paper_filled'
    with env[0].transaction() as db:db.execute('DELETE FROM exit_plans')
    p,q,c,i=fixture(NEXT);p['execution_pool']=[]
    i.update(order_id='missing-source',side='sell',limit_price=9.)
    result=execute(env,(p,q,c,i),now=NEXT)
    assert result['status']=='rejected' and 'exit_source' in result['reason'],result
    assert env[0].snapshot('synthetic',now=NEXT)['positions'][SYMBOL]['quantity']==100


def test_separate_local_research_inputs_without_editing_formal_plan(env):
    p,q,c,i=fixture();summary=p['meta'].pop('research_summary');r6=p['meta'].pop('r6_devil_advocate')
    result=execute(env,(p,q,c,i),research_summary=summary,r6_research=r6)
    assert result['event']=='paper_filled',result
    assert result['research_proof']['summary_sha256'] and result['research_proof']['r6_sha256']


def test_both_real_shared_helpers_run_inside_transaction_on_selected_ask(env):
    p,q,c,i=fixture();captured={}
    original=env[0]._account
    def account(db,*args,**kwargs):
        captured['db']=db
        return original(db,*args,**kwargs)
    def stock_helper(stock,quote_or_buy_price=None,*,entry_rule=None):
        assert captured['db'].in_transaction
        assert quote_or_buy_price=={'ask':10.}
        assert entry_rule==stock['entry_rules'][0]
        return evaluate_stock_buy_eligibility(stock,quote_or_buy_price,entry_rule=entry_rule)
    def global_helper(plan):
        assert captured['db'].in_transaction
        return evaluate_plan_buy_gate(plan)
    with patch.object(env[0],'_account',side_effect=account), \
         patch('src.plan.buy_eligibility.evaluate_stock_buy_eligibility',side_effect=stock_helper) as a, \
         patch('src.plan.buy_eligibility.evaluate_plan_buy_gate',side_effect=global_helper) as b:
        result=execute(env,(p,q,c,i))
    assert result['event']=='paper_filled',result
    assert a.call_count==b.call_count==1


def test_real_engine_rule_zone_lower_anchor_is_not_an_upper_cap(env):
    p,q,c,i=fixture();s=p['execution_pool'][0];r=s['entry_rules'][0]
    r.update(price_src='engine',trigger_price=9.9,max_acceptable_ask=10.3)
    s['engine_levels']=dict(ok=True,buy_zone=[9.9,10.1],trigger_price=9.9,stop_loss=9.5,take_profit=11.5)
    result=execute(env,(p,q,c,i));assert result['event']=='paper_filled',result
    assert result['buy_eligibility']['price_source']=='engine'


@pytest.mark.parametrize('identity', ['watch_pool','watch_status','watch_role','exit_status','candidate'])
def test_engine_or_external_eligible_never_promotes_observation_identity(env,identity):
    p,q,c,i=fixture();s=p['execution_pool'][0]
    if identity=='watch_pool':p['watch_pool']=p.pop('execution_pool')
    if identity=='watch_status':s['plan_status']='watch_pool_only'
    if identity=='watch_role':s['role']='watch'
    if identity=='exit_status':s['plan_status']='execution_pool_exit_at_open'
    if identity=='candidate':s['plan_status']='agent_candidate_pool'
    assert_reject(env,(p,q,c,i))


def test_r6_counter_argument_hard_severity_cannot_be_omitted_from_derived_list(env):
    p,q,c,i=fixture()
    p['meta']['r6_devil_advocate']['counter_arguments']=[dict(severity='hard_reject',target_ts_code=SYMBOL)]
    assert_reject(env,(p,q,c,i),'r6_hard_reject')


def test_resolved_other_symbol_r6_alias_does_not_block_all_buys(env):
    p,q,c,i=fixture();r6=p['meta']['r6_devil_advocate']
    r6['hard_rejects_applied']=['R6_OTHER']
    r6['counter_arguments']=[dict(reject_id='R6_OTHER',severity='hard_reject',target_ts_code='600001.SH')]
    result=execute(env,(p,q,c,i));assert result['event']=='paper_filled',result


@pytest.mark.parametrize('field,value', [('exit_rules',None),('no_trade_conditions',None),('exit_rules',['invalid'])])
def test_malformed_stock_containers_reject_without_exception_or_fill(env,field,value):
    p,q,c,i=fixture();p['execution_pool'][0][field]=value
    assert_reject(env,(p,q,c,i),'invalid_stock_')


@pytest.mark.parametrize('value', [None,True])
def test_account_stop_needs_explicit_snapshot_not_price_inference(env,value):
    p,q,c,i=fixture();p['risk_limits']['account_hard_stop_loss_pct']=.05
    if value is not None:p['risk_limits']['account_hard_stop_loss_active']=value
    assert_reject(env,(p,q,c,i))


def test_saved_exit_does_not_force_clear_when_symbol_leaves_today_pool(env):
    assert execute(env)['event']=='paper_filled'
    p,q,c,i=fixture(NEXT);p['execution_pool']=[]
    i.update(order_id='not-hit-saved-exit',side='sell',limit_price=9.)
    result=execute(env,(p,q,c,i),now=NEXT)
    assert result['status']=='rejected' and result['reason']=='exit_trigger_not_met',result
    snap=env[0].snapshot('synthetic',now=NEXT)
    assert snap['positions'][SYMBOL]['quantity']==100 and len(snap['fills'])==1


def test_partial_retry_recomputes_rr_and_preserves_prior_fill(env):
    p,q,c,i=fixture();i['quantity']=200;q['quotes'][0]['ask_size']=100
    first=execute(env,(p,q,c,i));assert first['status']=='partial',first
    q['quotes'][0].update(observed_at='2026-10-23T10:00:00.100000+08:00',received_at='2026-10-23T10:00:00.600000+08:00',ask_size=100)
    p['execution_pool'][0]['take_profit']=10.1
    p['execution_pool'][0]['exit_rules'][0]['trigger_price']=10.1
    result=execute(env,(p,q,c,i))
    assert result['status']=='partial' and result['fill_quantity']==0,result
    assert result['buy_eligibility']['status']=='blocked' and 'RR_FAIL' in result['reason']
    snap=env[0].snapshot('synthetic',now=NOW)
    assert snap['positions'][SYMBOL]['quantity']==100 and len(snap['fills'])==1


def test_engine_owned_stale_derived_review_is_recomputed_not_a_permanent_latch(env):
    p,q,c,i=fixture();s=p['execution_pool'][0]
    s['engine_levels']=dict(ok=True,buy_zone=[9.9,10.1],trigger_price=9.9,stop_loss=9.5,take_profit=11.5)
    s['buy_eligibility']=dict(source='price_levels_engine',status='unknown',review_required=True,
        reasons=['D1_ENGINE_PRICE_REVIEW_REQUIRED'],review_reasons=['CONFLICTING_EXIT_PRICE_EVIDENCE'])
    result=execute(env,(p,q,c,i));assert result['event']=='paper_filled',result
    assert result['buy_eligibility']['review_required'] is False


@pytest.mark.parametrize('review', ['EXPLICIT_ENTRY_REVIEW_REQUIRED','HUMAN_REVIEW_REQUIRED'])
def test_explicit_cached_review_never_cleared_by_engine_owned_status(env,review):
    p,q,c,i=fixture();s=p['execution_pool'][0]
    s['engine_levels']=dict(ok=True,buy_zone=[9.9,10.1],trigger_price=9.9,stop_loss=9.5,take_profit=11.5)
    s['buy_eligibility']=dict(source='price_levels_engine',status='unknown',review_required=True,
        reasons=['D1_ENGINE_PRICE_REVIEW_REQUIRED'],review_reasons=[review])
    assert_reject(env,(p,q,c,i),'stock_review_required')


def test_rr_pass_without_original_legal_exit_rules_cannot_seed_unmanaged_position(env):
    p,q,c,i=fixture();p['execution_pool'][0]['exit_rules']=[]
    assert_reject(env,(p,q,c,i),'legal_exit_source_required')


def test_stock_scoped_unknown_target_does_not_disappear_from_global_gate(env):
    p,q,c,i=fixture();p['no_trade_conditions']=[dict(scope='stock',code='UNKNOWN_TARGET',active=True)]
    assert_reject(env,(p,q,c,i),'invalid_condition_target')


def test_stale_add_buy_cannot_replace_newer_saved_exit_source(env):
    assert execute(env)['event']=='paper_filled'
    p,q,c,i=fixture(NEXT);p['generated_at']='2026-10-26T09:30:00+08:00'
    p['execution_pool'][0]['exit_rules'][0]['trigger_price']=11.8
    i.update(order_id='newer-exit-plan',side='sell',limit_price=9.)
    result=execute(env,(p,q,c,i),now=NEXT)
    assert result['reason']=='exit_trigger_not_met',result
    p,q,c,i=fixture(NEXT);i['order_id']='stale-add'
    result=execute(env,(p,q,c,i),now=NEXT)
    assert result['status']=='rejected' and result['reason']=='stale_replacement_exit_source',result
    snap=env[0].snapshot('synthetic',now=NEXT)
    assert snap['positions'][SYMBOL]['quantity']==100 and len(snap['fills'])==1
    assert snap['managed_exit_plans'][SYMBOL]['stock']['exit_rules'][0]['trigger_price']==11.8
