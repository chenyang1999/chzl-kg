#!/usr/bin/env python3
"""Independent local paper ledger. Never imports the legacy execution stack."""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path

# This package's parent __init__ is inert; do not import src.settings/load_plan.
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from trading.paper import PaperError, PaperLedger


def load(path):
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise PaperError('duplicate_json_key:' + key)
            out[key] = value
        return out
    def nonfinite(value):
        raise PaperError('nonfinite_json_number:' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=nonfinite)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['init', 'execute', 'snapshot'])
    p.add_argument('--database', required=True, help='scratch DB or data/execution/paper_<id>.sqlite3; no default')
    p.add_argument('--account-id', required=True)
    p.add_argument('--authorization-id', help='explicit user paper authorization, required for init/execute')
    p.add_argument('--fixture', action='store_true', help='synthetic rehearsal only; forces scratch database')
    p.add_argument('--now', help='timezone-aware fixture clock; forbidden without --fixture')
    p.add_argument('--init-cash', help='explicit virtual CNY; never defaults or migrates real/dry_run holdings')
    p.add_argument('--seed-source', help='explicit provenance for this paper seed')
    p.add_argument('--fee-model', choices=['zero_fee_assumption', 'flat_per_fill'])
    p.add_argument('--buy-fee', help='CNY flat charge per actual fill; not a claimed broker rate')
    p.add_argument('--sell-fee', help='CNY flat charge per actual fill; not a claimed broker rate')
    p.add_argument('--plan')
    p.add_argument('--research-summary', help='local research_summary.json snapshot for buy proof; no implicit filesystem discovery')
    p.add_argument('--r6-research', help='local R6 primary snapshot for buy proof / reject-id resolution')
    p.add_argument('--quotes', help='local JSON only, no HTTP or broker fallback')
    p.add_argument('--calendar', help='local reliable calendar with declared coverage and published_at')
    p.add_argument('--order', help='local explicit order intent JSON; rule_index refers to plan rule')
    p.add_argument('--quote-max-age', help='explicit positive maximum observed quote age in seconds')
    a = p.parse_args(argv)
    try:
        ledger = PaperLedger(a.database, fixture=a.fixture)
        if a.action == 'init':
            if not all([a.init_cash, a.authorization_id, a.seed_source, a.fee_model]):
                raise PaperError('init_requires_cash_authorization_provenance_and_fee_model')
            if a.fee_model == 'zero_fee_assumption':
                if a.buy_fee is not None or a.sell_fee is not None:
                    raise PaperError('zero_fee_model_cannot_accept_fee_parameters')
                fee = {'model': a.fee_model}
            else:
                if a.buy_fee is None or a.sell_fee is None:
                    raise PaperError('explicit_buy_and_sell_fees_required')
                fee = {'model': a.fee_model, 'buy': a.buy_fee, 'sell': a.sell_fee}
            result = ledger.initialize(account_id=a.account_id, init_cash=a.init_cash, authorization_id=a.authorization_id,
                                       seed_source=a.seed_source, fee_model=fee, now=a.now)
        elif a.action == 'execute':
            if any(v is None for v in [a.authorization_id, a.plan, a.quotes, a.calendar, a.order, a.quote_max_age]):
                raise PaperError('execute_requires_authorization_plan_quotes_calendar_order_and_quote_max_age')
            result = ledger.execute(account_id=a.account_id, authorization_id=a.authorization_id, intent=load(a.order),
                                    plan=load(a.plan), quotes=load(a.quotes), calendar=load(a.calendar),
                                    quote_max_age=a.quote_max_age, now=a.now,
                                    research_summary=load(a.research_summary) if a.research_summary else None,
                                    r6_research=load(a.r6_research) if a.r6_research else None)
        else:
            result = ledger.snapshot(a.account_id, now=a.now)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, allow_nan=False))
        return 2 if result.get('status') == 'rejected' else 0
    except (PaperError, OSError, ValueError, sqlite3.Error) as exc:
        print(json.dumps({'environment': 'paper', 'status': 'rejected', 'reason': str(exc)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
