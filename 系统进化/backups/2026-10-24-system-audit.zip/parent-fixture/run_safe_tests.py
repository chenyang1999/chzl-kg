"""Audit-only guarded runner. Never run production entrypoints or account data."""
from __future__ import annotations
import os
import sys
from pathlib import Path
import json
import traceback

BASE = Path(__file__).resolve().parent
APP = BASE / 'app'
FIXTURES = BASE / 'fixtures'
PRODUCTION = Path('/Users/chenyang/Downloads/demo/沧海巨浪')
FIXTURES.mkdir(exist_ok=True)
sys.dont_write_bytecode = True
sys.path[:] = [str(APP)] + [p for p in sys.path if p and not Path(p).resolve().is_relative_to(PRODUCTION)]
# Installed dependencies are interpreter-owned; keep only explicit site-packages.
VENV_SITE = PRODUCTION / '.venv/lib/python3.11/site-packages'
if VENV_SITE.is_dir():
    sys.path.append(str(VENV_SITE))
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['TMPDIR'] = str(FIXTURES)
os.environ['TMP'] = str(FIXTURES)
os.environ['TEMP'] = str(FIXTURES)
os.chdir(APP)
violations = []

def inside(path, root):
    return path == root or path.is_relative_to(root)

def check_path(value, write=False):
    if value is None or isinstance(value, int):
        return
    if isinstance(value, bytes):
        value = os.fsdecode(value)
    if not isinstance(value, (str, os.PathLike)):
        return
    token = str(value)
    if token == ':memory:':
        raise AssertionError('unexpected_memory_database')
    if token.startswith('file:'):
        from urllib.parse import urlsplit, unquote
        token = unquote(urlsplit(token).path)
    path = Path(token).resolve()
    if path.name == '.env' or path.name.startswith('.env.') or 'credential' in str(path).lower():
        raise AssertionError('credential_read_or_write_forbidden')
    if inside(path, PRODUCTION) and not inside(path, VENV_SITE):
        raise AssertionError('production_repository_access_forbidden:' + str(path))
    if write and not inside(path, BASE) and str(path) != '/dev/null':
        raise AssertionError('write_outside_audit_fixture:' + str(path))
    if not write and str(path).endswith(('.sqlite', '.sqlite3', '.db')) and not inside(path, BASE):
        raise AssertionError('private_database_forbidden')

def audit(event, args):
    try:
        if event == 'open':
            path, mode, flags = args
            write = (isinstance(mode, str) and any(c in mode for c in 'wax+')) or bool((flags or 0) & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            check_path(path, write)
        elif event == 'sqlite3.connect':
            check_path(args[0], True)
        elif event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.utime', 'os.truncate'}:
            check_path(args[0], True)
        elif event in {'os.rename', 'os.link', 'os.symlink'}:
            check_path(args[0], True)
            check_path(args[1], True)
        elif event in {'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.exec', 'os.fork', 'socket.connect', 'socket.connect_ex', 'socket.bind', 'socket.getaddrinfo'}:
            raise AssertionError('external_effect_forbidden:' + event)
        elif event == 'import':
            name = args[0]
            if name == 'src.settings' or 'qmt' in name.lower() or name.startswith(('dotenv', 'ib_insync', 'ibapi')):
                raise AssertionError('broker_or_settings_import_forbidden:' + name)
    except AssertionError as exc:
        violations.append({'event': event, 'reason': str(exc)})
        raise

sys.addaudithook(audit)
import pytest

class AuditPlugin:
    def pytest_collection_modifyitems(self, items):
        # Do not rewrite business assertions; redirect only their fixture root.
        for item in items:
            mod = item.module
            if hasattr(mod, 'SCRATCH'):
                mod.SCRATCH = BASE if mod.__name__.endswith('paper_plan_driver_20261023') else FIXTURES
        # Code-copy test fixtures deliberately test an exists-only kill file
        # and a scratch report target under APP, both inside this audit root.

CASESET = 'diagnostic' if '--diagnostic' in sys.argv else 'paper'
TESTS = ([
 'tests/test_canghai_paper_execution_20261023.py',
 'tests/test_canghai_paper_parent_review_20261023.py',
 'tests/test_canghai_paper_plan_driver_20261023.py',
] if CASESET == 'paper' else ['tests/test_audit_d_diagnostics.py'])
argv = TESTS + ['-q', '--noconftest', '-p', 'no:cacheprovider', '--basetemp', str(FIXTURES/('pytest-'+CASESET)), '--junitxml', str(BASE/(CASESET+'-junit.xml'))]
rc = 99
try:
    rc = pytest.main(argv, plugins=[AuditPlugin()])
finally:
    payload = {'command': [sys.executable, '-B', str(Path(__file__).resolve()), *sys.argv[1:]], 'pytest_argv': argv,
               'cwd': str(APP), 'exit_code': int(rc), 'violations': violations,
               'fixture_rebinding_only': str(FIXTURES), 'production_accounts_initialized': False,
               'market_quotes': 'synthetic', 'calendar': 'synthetic'}
    (BASE/(CASESET+'-run.json')).write_text(json.dumps(payload, ensure_ascii=False, indent=2)+'\n')
raise SystemExit(98 if violations else rc)
