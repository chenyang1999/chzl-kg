# H｜七份系统审计独立交叉复核

**结论：纠正D11“E1未消费paper”和B03“当前keepalive存活仍另跑一次”；G07主SOUL两句降为歧义待澄清，不能机械判矛盾。竞价时间与代码量需收窄口径。执行缺陷没有因此消失，但没有一项能据现有证据写成已发生实盘事故。**

- 基线截至：2026-10-24T15:38:40+08:00；H读取：2026-10-24T15:57:59+08:00—2026-10-24T16:09:59.736348+08:00。没有全系统事务冻结；本报告不冒充截止时点统一部署快照。
- 七份MD已通读，挑选8个关键主题核原路径；JSON中每项含原文行号、hash、最小反例、建议措辞与非事故边界。不是七份全部发现的端到端验收。
- 项目只读；未读凭据、私有账户/持仓/成交库，未跑生产、交易、cron、网络、pytest；未改Git/技能/记忆。独立paper仅读已生成的复盘汇总，未开账本。

## H01｜纠正：paper已有Agent消费者，确定性接线仍不完整

D11的“E1未消费”不能保留为整体断言。实际 `data/reports/20261023/E1_data.json:6534–6550` 包含paper来源、18:22:13核对时刻及0订单/0成交/0存量；人读 `E1_daily_review.md:328–334` 也明确分离纸上账与价格场景。独立证据在 `evidence/paper_ledger_review.json:1–4,12–16`。E2 `weekly_summary.json:74` 已带14:40:53单点paper快照。

但 `scripts/review/run_daily_review_prep.py:2–5` 自称骨架，`src/review/daily_review_prep.py:369–378,403–407` 只列旧events与空收益。E2 prep `weekly_evolution_prep.py:44–49` 可整包透传E1 JSON，并不等于有独立paper核算adapter。E2在17:02采集且明确缺周五E1（周报:5–12），早先paper快照不能补齐该依赖。

**采用措辞：**“10/23 Agent复盘已纳入独立paper证据；统一只读核算、常驻paper→日周对账及有效成交序列未验证。”B最终MD:27已接受E1/E2快照，因此应修D的概括，不应再指B/F全面矛盾。反例就是现存paper字段；它证明有消费者，不证明实际账户空仓/收益为零。H未再次核底层SQL或会话工具记录。

## H02｜确认：六个安全反例仍在，不是六起事故

复核D原生JUnit：**6 case/6 failure/0 error/0 skip**；另有**156 testcase通过＋65子测试**。当前16份源码/测试hash均与D冻结清单一致。H只解析原证据，**没有重跑**；历史416项不纳入。证据 `D-fixture/diagnostic-pytest.log:102–109`、`paper-pytest.log:1–4`、诊断源码:1–4,20–30。

|D项|当前可达边界与最小反例|不能推导的结论|
|---|---|---|
|D01|paper driver pending先reserved，比例止盈5000后阻止剩余5000新止损；driver:278–307、ledger:717–757|不是已发生真实止损事故；需已有paper仓与partial|
|D02|低层CLI直进ledger，省略kill路径时仍撮合100；CLI:65–72、ledger:377–383|新driver:108–126已补默认kill，不能说它也没修|
|D04|真实schema＋AST合并：计划0→账户0.75；loader:156–164|不是10/23多门禁被解禁；与C06同根|
|D06|AST缺available但total1000，返回1000；QMTContext:229–234，sell_common:114|不是券商已接受T+1违规单；真实字段覆盖未读|
|D07|AST以报价池最高100元算10元目标，100股而非1000；base:92–104、buy_common:105|不是实际买量/损失；前后风控仍可能拦截|
|D08|AST trigger10/last9.8/ask9.9也true；base:59–62|正常scan可另拦截；缺票才与C05形成联合缺口|

两项paper链测试＋四项AST局部测试应分列。D03不是这六个动态诊断之一。保持问题优先级，但把“可达、隔离复现、当日触发、真实成交/损失”四层分开。

补充回执：主控在独立parent-fixture于16:04:52/16:04:54再次得到156用例＋65子测试通过、6诊断失败，16份hash匹配、hook违规0；见`parent-verification.json:85–155`。这是截至点后的独立复核，不是H重跑，也不与D重复case相加。

## H03｜确认：mode旁路是另一入口的许可缺口，不是当前cron在live

`trading/watcher/run_once.py:27–49,103–109` 默认不reload，以调用mode覆盖plan；正常loader `295–300` 则拒绝缺双重live同意。退出先于买入auto/no_trade门禁（dispatch:89–115）是需要保留的买卖分层，不能把它单独当错；真正缺失的是最终执行环境同意不能被CLI提升。

静态反例：loaded=dry_run，直接传live并有合法持仓退出，且触发/可卖量、kill、Amygdala全部通过，就可到QMT提交边界。H未执行。`qmt_context.py:148–183` 仍有kill/硬风控，`:185–203` dry_run直接返回；实际外部启动脚本:28明确`--mode dry_run`。

**采用措辞：**“独立旧watcher存在潜在实盘授权升级路径，应统一订单边界；当前所核cron wrapper为dry_run，未证明越权实盘或成交。”不读私有订单就不能证明有事故，也不能保证所有手工入口安全。

## H04｜归并：C05突破/扫描子项＋D08

`entry_selector.py:132–146` 抓数错跳过该票；`session_context.py:45–63` 缺票默认True，而正常watch/无突破会拒绝；`base.py:59–62` 只核ask上限。`_buy_common.py:76–89` 异常也pass-through。D的未突破反例与C的缺票反例可组成局部放行链。

**采用措辞：**“突破谓词不完整＋缺扫描证据默认允许，合并一组执行风险。”仍须经过全局禁新、单票身份/预算、RR、kill等；10/23又为空执行池，不能说已误买。A01首轮缺新scan会扩大暴露，但双分派是另一根因，归H06；C05低吸分支不因本归并被抹去。

## H05｜归并：C06＋D04，保留权限交集修复

`load_plan.py:156–164` 权限AND/OR是正确收紧，但risk字典由账户覆盖计划。C用0.8、D用0.75只是fixture不同。若零约束只在target_total_position_pct，该阻断可消失；若no_trade=True或meta cap仍0，`buy_eligibility.py:221–250` 仍拒绝。

**采用措辞：**“同一风险合并缺陷，限制只能收紧且保留有效零。”实际10/23计划:4–20,1792–1824仍有dry_run、no_trade、三项禁令、空池及自主false/确认true，不能说已解禁。独立paper直读canonical，不经过此overlay。

## H06｜确认双dispatch；撤回当前keepalive额外轮次的部署断言

`watcher_daemon.py:167–170` → `load_plan.py:333–336`已分派 → `run_once.py:59–70`再分派，A01/D05应合并。两轮simulate/scan条件不同，不可直接等同两笔相同订单。

**新纠正：** B03引用的是仓库 `scripts/execute/canghai_execute_watcher_keepalive.sh:7–12`（alive仍`--once`）。但已注册default任务的相对script经 `~/.hermes/hermes-agent/cron/scheduler_script.py:323–346` 解析到 `~/.hermes/scripts/`，该实际wrapper:29–35是alive即exit 0。其SHA256与B JSON:494–497完全一致，不是H晚读发生漂移。

**采用措辞：**“daemon成功轮次双分派仍在；仓库另一keepalive有额外轮次风险，但未证明已注册任务调用它。”B旧日期/无日历风险并未被这个纠正推翻；当前dry_run与未核进程加载状态也不能证明重复实盘成交。

## H07｜保留0/5，但明确时间、分母和保护结果

分母=10/19—23五个应运行日，不是池中股票/非空天数。技能要求快照09:28:00前落盘（fetch skill:61,145），P1 09:29:00前（P1 skill:42–45）。

|日期|snapshot captured_at|P1 generated_at|P1状态|
|---|---|---|---|
|20261019|09:28:16|09:29:58|timeout_no_amendment|
|20261020|09:28:19|09:29:33|timeout_no_amendment|
|20261021|09:28:07|09:29:54|timeout_no_amendment|
|20261022|09:28:07|09:29:52|timeout_no_amendment|
|20261023|09:28:07|09:31:08|timeout_no_amendment|

原文均为 `data/raw/<日>/auction_snapshot.json:4`、`data/plans/<日>/auction_amendment.json:5,12–16`。当前采集实现 `run_auction_snapshot.py:448–454` 在市场请求(:502)前写captured_at，最终写盘在:559：它是**构建起点**，不是交易所观察时刻或提交完成时间。

五个起点均已越09:28，故现存构建不能满足该落盘期限；P1明确timeout且晚于09:29，现存有效按时交付0/5成立。mtime只辅助，不能排除曾有早版；0/5也不是报价覆盖率、策略准确率或亏损率。fetch的47—63秒是整个Agent执行时长，不是纯API耗时。晚于09:28不必然使P1超09:29，因果不能只归于快照。超时不追补、observe-only不reload是正常保护。

## H08｜规模与别名只支持治理候选，不支持整删

重聚合A原清单：646文件/113411物理行，去tests为583/102120；不是H重新全仓扫描。A_inventory.py:5–18规定排除路径/扩展名，近似代码行仍含docstring。独立读取四个 `r1_compute_{20261012,20261013,20261014,20261019}.py:21–214`，main AST相同；582是额外函数跨度，不是保证可删行数。

`src/mcp/research_server.py:1–2`及两个MCP入口:11均指sise同一对象；5个独特业务工具不是两套策略。生成器 `setup_hermes_doubao.py:164–169,192–205` 已不新增别名但保留旧键；A记录三处并挂仅复用其脱敏投影，H未重读配置凭据。注册、实际调用、token消耗分开，不能编节省比例。

反例：新QMT仍导入旧models/journal/client（qmt_context:8–12），macro仍用daily_pipeline公共函数（hermes_macro_daily:15），API仍用旧agent（agent_ops:9）。**采用措辞：**“别名迁移、日期CLI参数化、入口隔离候选；消费者迁移＋替代验收＋签核后才能退休。”A原文多已如此限定，不要在整合时改成可删目录/冗余总行数。G的同名技能副本是另一清单。

**按主控补充裁决G07：** `~/.hermes/SOUL.md:33`不预设固定“节点→打法”，`:38`阶段决定打法/仓位上限，并非必然相反：阶段可约束资格和上限，允许集合内仍按资金确认择法。列“语义歧义待澄清”，不计确定规则冲突。只保留具体旧条款：`short_line_thinking_v1:200`半路禁止、`main_decision_v1:218`零置信度默认正仓、`analyze_capital_flow_v1:247–252,269–272`北向缺口全局归零/默认仓位，与当前R7:18,35–38的optional语义不一致。旧文字存在不证明本次实际采用，更不能借澄清放松零预算。

## 不确定项与最终使用规则

1. 独立paper常驻、报价来源、前瞻成交序列与统一对账未认证；Agent有快照不补足这些证据。
2. 所有诊断/静态旁路均非事故证明；未读私有订单也不证明绝无事故。不要用修门禁为由抬零预算或拦合法退出。
3. 现存文件不是不可变历史，未确认驻留进程加载版本。历史已修的权限交集、逐票RR、新driver默认kill、E1语义分离不能再列新增同一缺陷。
4. 10/26记忆完成说法未核；H只查两处正式目录均未见，不读记忆、不猜其他位置。10/26晚于当前10/24，不把缺件记逾期失败。
5. 本轮唯一写入是授权scratch中的H报告及生成脚本；没有生产整改，也未重跑D/C测试。超长JSON首次读取截断已改为只读字段投影，不计产品失败。

详证：`H-reconciliation.json`（confirmed/corrected/unresolved、逐项原文与hash、六诊断可达性矩阵、去重映射、全部时间行、读取清单）。
