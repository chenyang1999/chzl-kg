# C｜研究与交易决策质量审计

截止 **2026-10-24 15:38:40 +08:00**。只读项目；无策略数值修改、联网抓数、下单或外发。逐项机器证据及完整路径见同目录 `C-decision.json`。以下路径相对项目根目录，L为实际文件行号。

## 实际链路与样本

`run_research_shell.sh` 并行R1/R4/R7 → R3 → R2 → 图表预渲染 → R5 → R6 → `build_research_summary` → **canghai-plan身份LLM D1** → runtime交接（`scripts/research/run_research_shell.sh:L157–246`）。`d1_algorithm.py`仅规则对照，不能拿它代表主路径。买入消费者为 `run_once→scan_entry_opportunities→dispatch_plan→_buy_common→buy_eligibility`；不是研究JSON直接授权。

|现存版本|summary|R5画像|执行/观察/研究锚|R6正式评估|
|---|---|---:|---|---:|
|10/21|complete|10|2/22/3|18|
|10/22|skeleton|0（skipped）|0/0/0|0|
|10/23 14:22恢复版|partial|4|**0/4/9**|0；另诊断4|
|10/26|正式research/plans目录未检得|—|—|—|

不能用记忆中“26日R4/R7已完成”替代文件；也不能断言其他位置从未生成。10/21、22 R7数据归属T-1，23恢复版归属当日；**未来trade_date、同日文件与生成时间均不是数据新鲜度证明**。10/21 summary自报07:43:24早于R6自报07:52，无法据现存文件证明当时版本一致。

## 八项结论与可证伪验收

### C01｜正常保护：研究与交易已实质分层
10/23有3条研究方向、4份画像、9个研究锚，而非“市场没机会”；有效零预算、R1_FAIL与研究未就绪独立挡新仓。R2已有辨识度顺序、流通<20亿不看；真实观察票未清关，不伪造买点。

证据：`skills/analyze_main_sectors_v1/SKILL.md:L146–173`；`data/plans/20261023/watchlist_plan.json:L1792–1859`。
验收：同组非空候选切换为零预算后，研究仍留、执行不升；真空池须给覆盖/剔除/缺口。

### C02｜保护已修，生产重评闭环尚未证明
10/23明确三旗标为false/false/true；health的completed是交付完成，不是研究或许可通过。安全网只接受晚于临时版的新R1–R7/summary，核路径与run，缺批次或重评未成返回非零；不替研究owner刷新、不用规则覆盖LLM。**生产刷新时窗及触发尚待签核**，不能称已完成自动重评。

证据：`scripts/research/pipeline_state.py:L171–197`；`scripts/plan/ensure_watchlist_plan.py:L143–176,L340–360`。
验收：旧批次不能消待办；新证据触发owner重评仍不自动解禁或抬预算。

### C03｜现存冲突：新铁律与旧prompt并存
D1旧文仍有极恐抬仓、confidence=0回退0.50、正仓位clamp；旧短线skill仍“半路禁止”，与动态通道冲突，**本审计不遵从旧禁令**。研究SOUL的RR<2、计划SOUL的1/2/3分仓档、执行资格1.8需明确作用域；分仓档本身不必与资格阈值冲突。R1置信度0.245来自降级因子相乘，不应当作校准胜率。当前D1实际保留零预算，不能说已被旧文放开。

证据：`skills/main_decision_v1/SKILL.md:L188,L218,L1112–1118`；`skills/short_line_thinking_v1/SKILL.md:L200`；两profile SOUL研究L57/计划L39；`src/plan/buy_eligibility.py:L17`。
验收：签核唯一规则注册表；0/null/低置信度跨身份不转成默认授权。不在本次选定新数值。

### C04｜已修：单票RR不再外溢全局
10/21遗留全局RR_FAIL是历史证据。现代码逐票计算，只清本引擎所属旧全局RR；按实际拟提交限价重算，买入门禁不挡合法卖出。旧skill仍称写全局no_trade，应另签清理文字，**不是再报现行代码同一缺陷**。

证据：`scripts/plan/apply_price_levels.py:L159–175`；`trading/executors/_buy_common.py:L59–69`；`trading/watcher/dispatch.py:L97–113`。
验收已做内存回归：坏票不传染好票、缺ask未知、补价不晋升/解禁/抬预算。

### C05｜高优先：右侧门禁有实现但缺证据时放行
正常扫描检查突破与SISE；然而抓数异常会跳过单票，session缺票返回pass-through，基础breakout又只查ask上限。反例已复现“未突破+扫描缺票也过此局部链”。低吸扫描可因低于价位先标buy，再也到不了阴跌分支；价格引擎仍产昨收回撤/MA50回踩区，不能据此证明“预判当日涨停”。板块合力/辨识度/市值须成为可核验资格，不能只在文字中出现。

证据：`trading/entry_selector.py:L93–106,L132–146`；`trading/watcher/session_context.py:L45–63`；`trading/executors/base.py:L49–61`；`src/plan/price_levels.py:L124–149`。
验收：抓数错/缺扫描禁新买但不挡卖；无突破、无合力、无涨停假设不能仅凭便宜获买。**未证明真实误成交。**

### C06｜高优先条件反例：账户可覆盖有效零预算
授权旗标取交集，但risk_limits用账户字典覆盖计划。仅以target_total_position_pct=0表达约束的合成计划会被较宽账户cap抬高，随后全局gate不再拦截。10/23另有no_trade、禁令、空执行池，不能称该样本已解禁。

证据：`trading/load_plan.py:L156–164,L282–306`；`src/plan/buy_eligibility.py:L244–251`。
验收：各类风险限制组合只能收紧，零值保持零；未读真实账户，未做交易端到端测试。

### C07｜有效修订尚未交付，observe-only保护正常
现存P1三份全超时；P2两份均无实质修订，11:42的timeout_no_amendment实际是缺数据fallback，不是过12:05。23日两修订仍引用06:51预案，不能套到14:22新版。skill默认observe-only，未发现当前加载入口应用amendment，不能据此称自动闭环。

证据：`data/plans/20261023/{auction_amendment,midday_amendment}.json:L1–18`；`skills/auction_amendment_v1/SKILL.md:L22`；P2同L22。
验收：先保证窗口内快照/版本绑定；stub零、跨日、旧引用不得promote；超窗不可补写有效修订。自动reload另签。

### C08｜优化：共享证据，不合并独立裁决
R1/R3宜共用采集与基线，保留市场温度和叙事增量两个视角，不能把同一基线算两票。R4事件/R7资金独立价值高。R5快变日更、慢变财务业务按事件或失效更新，复用现有图表快照。**R6保留独立反证与完整性门槛**，不可因正式评估0就砍掉；4份负面诊断仍有价值。

10/23恢复批次87.87分钟，R5占30.88分钟；R1完成后R3额外等5.70分钟。只是单次实测，非长期性能结论。
证据：`data/health/research_pipeline_20261023.json:L22–82`；`scripts/research/run_research_shell.sh:L157–174`；`data/research/20261023/R6_devil_advocate.json:L189–192`。
验收：同批数据消融比较增量证据、漏警/误警和延迟；慢变量缓存须能被公告/财报/候选变化失效。调整单元与生产触发均需批准。

## 验证边界与优先顺序
已做**16条原函数/纯模块内存断言：11条保护回归、5条缺陷/条件反例复现**；不是“16项系统安全测试全绿”。未导入settings，未读凭据/个人持仓，未运行生产或完整回测。66个登记证据文件mtime均不晚于截止点，但mtime不证明历史内容不可变。

建议先签核处理C05/C06，再清C03契约冲突和C02重评收据；最后做C08消融提效。只有scratch中的本MD及JSON被写入，代码、配置、skills、SOUL、cron、git及项目产物均未修改。
