# A｜架构与冗余审计

**证据截止：2026-10-24 15:38:40 +08:00；HEAD：03c1d25caf94e8c8576765442b55cbf4538559f1。**
审查对象是当前脏工作树，不把HEAD或旧报告当现况。本轮只读项目；没有交易、启动服务、补跑生产、改调度或技能。详细证据、调用关系、审批条件见同名JSON；以下路径相对项目根。

## 实际统计与口径

Python枚举 `src/scripts/trading/web/tests/cron/config` 的源码，排除环境、依赖、数据、缓存、历史归档，不跟随符号链接。

|范围|文件|物理行|去空白及注释前缀行|
|---|---:|---:|---:|
|全部|646|113411|96025|
|不含tests|583|102120|86729|
|src|207|41635|35270|
|scripts|272|49774|41934|
|trading|46|4438|3827|

近似代码行包含docstring，不能冒称严格SLOC。跨文件、至少二十物理行的函数AST克隆：1组、4处、额外跨度582行；非微小整文件完全重复0组。带日期名源码109个，不等于无用文件。AST解析错误0个。实际命令为scratch内 `A_inventory.py/A_external.py/A_query.py/A_probe.py`，均退出成功；输出保存在同目录JSON，不以人工心算填数。

## 当前真实链路

- 已注册研究任务 `24f4119fab82` → 外部 `canghai_research_daily.sh:2-6` → 仓库shell wrapper → `run_research_shell.sh:151-246`。生产者顺序为R1/R4/R7并行，随后R3、R2、R5、R6；`build_research_summary.py`只读汇总，D1写 `data/plans/日期/watchlist_plan.json`。
- 交接 `pipeline_artifacts.py:157-173` → `trading/load_plan.py:122-154` → runtime副本；账户及合规投影另写loaded，再交执行器。API仍读loaded/runtime（`src/api/routers/trading_agent.py:21-44`）。canonical、staged、loaded不是应当直接删成一个文件的冗余。
- `src/orchestrator/pipeline.py:18-84` 是赛道、公司、数据库研究；`src/agents`有macro/company/API消费者，并非日研究R1-R7的同义实现。显式Python fallback、旧morning/intraday CLI和独立paper则另有入口，不能混报为同时运行的生产链。

## 四类清单

### 核心必须加强

**A01｜高：执行循环仍两次分派。** `src/execute/watcher_daemon.py:167-170` 先load再intraday；前者在 `trading/load_plan.py:336` 已dispatch，后者在 `trading/watcher/run_once.py:70` 再dispatch。`reload=False`只去掉额外重载，没有把load变成纯准备。首轮和次轮scan时序不同，应拆纯prepare与唯一dispatch，并测试幂等。现注册wrapper明确dry_run；本审计未读取订单、更没有证明重复实盘成交。

**A02｜高：fallback命名空间未隔离。** CLI已有显式开关（`scripts/research/run_research_orchestrator.py:35-60`），不是默认主路；但开启后 `src/research/orchestrator.py:237-285,417` 仍写正式R产物和summary。建议保留可回滚能力、改为隔离run目录，禁止占位覆盖LLM研究。

**A04｜保留已修保护。** 单向原子交接、坏canonical拒绝及限制版禁止自动晋升已在当前代码实现。抽样20261022、20261023正式/runtime哈希一致；20261023是partial研究、安全degraded计划，production_ready=false、执行池为空，不能把它说成已经完成研究。20261021哈希不同是旧快照证据，不证明新修复失效。后续加强run_id、source_hash、版本和界面来源披露，而不是撤掉安全闸门。

**A10｜入口登记。** 已读Hermes库共37项均enabled/scheduled；外部watcher脚本还写“已暂停”，与配置不符。配置证明注册，不证明进程活着。安装脚本、旧注释和真实调度必须分别记录。

### 可合并

**A03｜MCP别名注册。** `src/mcp/research_server.py:1-2` 直接导出SISE同一对象；default配置及项目、Cursor共3处仍并挂历史名与正式名，共享5个业务工具。`setup_hermes_doubao.py:153-205`已不新增旧名，但保留已有键；canghai profiles已无此别名。应审批迁移注册，而非删后端或假称全环境都未修。

**A06｜日期计算脚本。** `scripts/research/r1_compute_20261012.py`、`scripts/research/r1_compute_20261013.py`、`scripts/research/r1_compute_20261014.py`、`scripts/research/r1_compute_20261019.py`各 `21-214` 函数AST相同。保留薄wrapper，抽参数化CLI；日期说明仍有引用，克隆统计不是自动删除许可。

**A08｜契约重复。** `pipeline_artifacts.py:10-24`、`src/research/orchestrator.py:79-89`、`src/plan/main_decision.py:439-447`各列产物目录；`trading/load_plan.py:76`反向依赖scripts，publisher又导入loader。宜抽无副作用contract/catalog，保持正式与fallback语义不同；不宣称已出现循环导入崩溃。

### 停用待签

**A05：** `src/research/d1_python_fallback.py:90-114`使用旧schema直写runtime；当前查询只命中自身usage。旧 `scripts/trading_agent_daily_pipeline.py:681-694`把最近计划换日期后直写，`976-1006`另起两类watcher。建议先封存这些业务入口。外部 `trading_agent_intraday_once.sh:5`仍有live调用，所读Hermes库未匹配不等于从未使用；必须补查系统调度与人工流程、用户签字后才停用。

### 证据不足不得删除

**A07/A09：** 不整删agents/orchestrator/trading_agent或daily_pipeline：新QMTContext仍导入旧models/journal/client（`trading/order/qmt_context.py:8-12`）；API仍用旧模型；macro脚本仍导入daily_pipeline辅助函数。旧ResearchPipeline还有MCP模块导入及legacy CLI。旧API job中缺失脚本路径是残留，未找到调用者，不能夸大成线上接口故障。`daily_spine.sh`与runtime intel是派生视图，不等同research_summary；独立paper账本不得与dry_run/QMT合并。日期名、legacy名、零文本引用均不足以判死。

## 判定边界与验收重点

首先，旧入场监控已收敛成兼容壳：`scripts/trading_agent_intraday_watcher.py:20-59`最终调用新单次监控模块，不能继续画成另一套完整入场引擎。但旧日流水线仍会额外启动持仓监控，故迁移重点是入口授权、持仓动作责任和共享状态，而不是按文件名统计“执行引擎数量”。单次命令、守护循环和独立模拟账本也不能简单相加为同时在跑的生产系统。

其次，业务完成与文件存在必须分开。当前研究汇总部分完成、正式计划安全降级、调度记录成功可以同时出现；这不自动构成数据造假，也不表示业务验收通过。应分别显示研究完成、计划就绪、交接完成与执行授权，保留未就绪版本的重新评估义务。安全网作为重试和占位设施应加强，不能因它也生成计划就删除，也不能用它掩盖上游未完成。

引用核查覆盖源码、当前技能与外部脚本，最终排除了历史技能归档。实际查询：ResearchPipeline为4文件/7命中；daily_pipeline为10文件/15命中；旧D1直写仅自身说明；旧runtime直接引用仅测试。这些数字说明应把删除单位收缩到分支或入口，不能从某个搜索词为零推导整个模块无人使用。共享函数先搬到稳定包，调用者全部替换之后再移除兼容层。

建议验收时至少覆盖：同一天旧计划不得回灌正式版本；失败研究不得被占位标成完成；限制版本不得自动升级权限；每轮仅分派一次；重复意图不得重复产生执行动作；买入门禁不得误伤合法退出；界面显示的计划应能追溯到正式版本。以上都是待批准实施时的验收标准，本次没有伪造通过结果，也没有执行这些生产路径。停止旧入口前还需确认系统级调度、外部机器和人工应急命令；无法确认的项目继续列为证据不足。

## 最小目标架构与低风险顺序

目标：入口登记 → run隔离研究 → 统一契约/publisher → 唯一canonical D1 → 原子staged → loaded执行投影 → 唯一dispatch/幂等intent → 明确选定的执行适配器。paper保持独立域；API/KG只读带来源版本的视图；每后端一个正式MCP名。无需为了整洁推倒已有安全边界，也不把所有CLI都升格为生产任务。

迁移顺序：先冻结入口/消费者与回滚基线；审批后优先拆prepare/dispatch并在隔离fixture验收；再提纯契约、隔离fallback写入；随后迁移别名和日期脚本；最后抽走macro/review公共功能，再逐项签字停用。每步都需输出等价、异常fail-closed和消费者回归，不能以源码行数下降替代验收。

限制：未查OS crontab/launchd、远程QMT、人工操作历史；未运行项目测试或生产调用。审计脚本真实执行成功只是静态/文件证据，不是服务部署验收。配置只摘非秘密字段；未读账户或凭据。全部源码mtime未晚于截止时间，产物只抽样所列日期。本轮没有任何项目整改。
