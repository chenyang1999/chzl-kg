# D｜执行安全与独立模拟交易审计

**证据截止：2026-10-24 15:38:40（UTC+08:00）。仅审计，未整改、未下单、未初始化生产账户。** 隔离测试在15:44及15:46运行；所测16份源码/测试文件均早于截止时点，复核无漂移。main及既有dirty/untracked不作改写。

## 结论

**保留独立paper账本作为模拟核心，但不应据此给整个执行系统放行。** 当前有三种不同结果：旧`dry_run`只记意图；paper持久化虚拟现金/批次/订单/成交；QMT路径提交券商委托。它们不能共用“成交/收益”口径。

本次重跑指定闭包为**156项通过＋65项子测试通过，0失败/错误/跳过**。另加6项安全诊断，**6项均失败、0错误/跳过**，证明现存边界缺陷；没有改断言或生产代码求绿。10/23的416＋65是历史验收，本次没有重跑416项，也没有读取真实账户、私有持仓库或凭据。

## 实际调用边界

- 正式`data/plans/<日>/watchlist_plan.json` → `stage_plan`校验、原子刷新runtime → `run_load_plan`叠加账户/合规、写`.loaded`，**同时已经dispatch** → watcher再次dispatch → QMT意图/委托JSONL。
- 独立`run_paper_plan_once --once`直接消费当日正式计划，不经过旧loader或QMT；显式授权ID须匹配独立账本。逐票实际ask重算RR及研究证明，卖出优先，SQLite事务更新现金/批次/fills/盘口消耗。
- 复盘的`position_lifecycle`是计划可成交性推演，不是paper账本；`observation_tracking`比较候选池日涨跌，不是账户损益。

## 发现与建议（均未应用）

| ID/级别 | 证据、影响与最小建议 |
|---|---|
| **D01 P1** | **paper半仓止盈会卡住后续止损。** driver给比例卖出传全可卖基数，成交一半仍记partial；随后先将该票加入reserved，旧止盈不触发也不再评估其他退出。合成复现：剩余5000股可卖，后续价格触发优先级更高止损，却0成交。`run_paper_plan_once.py:278–307,348–350`、`ledger.py:717–757`。应持久化原始目标数量，并允许保护性退出接管未完成订单。 |
| **D02 P1** | **默认杀开关只在新driver补齐，低层入口仍可绕过。** `run_paper_trading.py:65–72`直接调用ledger；`ledger.py:377–383`只检查传入标志。合成停止文件存在、裸计划省略路径时，低层仍买入100股。统一授权/杀开关验证入口，不能把研究JSON中的false当执行者已验证的快照。 |
| **D03 P0（潜在实盘入口）** | `watcher/run_once.py:41–49`用CLI mode覆盖计划mode，不经过loader的双重授权验证；出口不检查股票auto开关。可进入live发送路径，**不等于已证实真实成交**。账户配置白名单元数据为live/自主true/确认false；现行cron传dry_run，故不是当前cron正在实盘的结论。所有调用入口必须共享不可升级的授权门。 |
| **D04 P1** | `load_plan.py:156–164`虽然收紧mode/自主权限，却以字典覆盖风险配置。隔离纯函数验证正式总仓预算0被账户0.75覆盖。风控合并应取更严格值、禁区并集，保留有效零及缺失语义。 |
| **D05 P1** | `watcher_daemon.py:169–170`先loader后watcher；loader自身`333–336`已dispatch，实际每轮两遍。QMTContext无持久订单幂等/占用事务；`PositionsStateStore.save:93–99`无原子替换/锁，loader每轮又reset日内T状态。另daemon日期启动时固定、窗口包含午休且无日历核验。拆分“纯装载”和“唯一dispatch”，统一日历、订单状态机与进程锁。 |
| **D06 P1** | 旧QMT报价异常可把持仓last伪作bid/ask（`qmt_context.py:86–116`），Quote模型不带观察时点或盘口量；`available_qty:229–234`缺值退到total。合成未知可卖量返回1000，破坏本地T+1防线。缺价格时间/量/可卖量应拒绝，不靠券商最后兜底。 |
| **D07 P2** | `executors/base.py:92–104`以整个quotes集合最高价计算本票数量，并硬保底一手。合成10元标的因另一票100元只买100股而非1000股。数量必须绑定本票实际限价、现金与预算，低于一手明确不下单。 |
| **D08 P1** | 旧突破判断只检查ask上限，不检查达到突破价；合成last9.8/ask9.9、触发10返回true。`base.py:55–62`；打板wrapper也没有封单量等完整谓词。部分退出条件直接true（74–88）。应复用明确谓词契约，不支持的确认条件显式拒绝。 |
| **D09 P1** | 旧dispatcher只对execution_pool运行退出，watch_pool只日志；compliance还从两池剔除受限票（`dispatch.py:89–147`、`load_plan.py:176–199`）。移池持仓可能失管。paper虽保留退出来源，但driver在读到账本前必须取得今日正式计划（172–201）；当日计划缺失仍不能单独保护持仓。应将已有持仓管理与新仓研究就绪分离，缺新计划时只使用有效、已授权的退出来源。 |
| **D10 P1** | QMTContext提交后直接标submitted且不查委托；另一OrderManager虽查列表，却不匹配目标订单或成交（`order_manager.py:64–74`）。position_executor把submitted卖单当接回前置（196–229），并非成交回报；其独立watcher/执行链未见杀开关检查。统一区分intent/submitted/confirmed/fill，按真实成交量驱动接回及账本；保留合法卖出但不能绕过统一执行门。 |
| **D11 P1／接线待核实** | 最新一次性paper入口及其测试确实存在，不能重复说“未实现”；但本次核到default实际启用的两条execute cron仍解析至`~/.hermes/scripts/`旧watcher，E1技能、prep及生命周期复盘未消费paper账本。`test_canghai_paper_parent_review`是父审测试，不是E1接线。上下文所称“后续review已补接线”未在这些真实消费者得到印证，需主控提供并核对具体新入口/生效配置；不能用历史报告或调度status=ok替代。 |

## 应保留、合并、隔离/退休候选

**保留：** `trading/paper/ledger.py`的整数分记账、BEGIN IMMEDIATE、回滚、批次T+1、观察时点幂等及盘口消耗；`run_paper_plan_once`的canonical哈希/不改正式计划/卖出优先；纯`buy_eligibility`；loader的日期/显式布尔/原子交接与禁止扩大live授权。

**合并：** 两套Plan/Quote模型、模式许可、价格及数量校验、kill路径、订单状态、持仓退出来源、复盘账本适配。只保留一个执行者；研究只能给候选/规则，不能写执行许可或账户状态。

**隔离后再决定退休：** 旧`trading.watcher`＋`src.execute.watcher_daemon`；`scripts/trading_agent_position_watcher`旁路；`src.trading_agent.runtime`旧执行栈；已deprecated的`trading_agent_intraday_watcher`及历史启动脚本；`trading_agent_daily_pipeline`中自动写自主true/确认false的旧overlay。**活跃cron不是死代码，不得直接删除；先确认消费者和替代链验收。** 生命周期推演可保留作反事实研究，必须与paper账户收益分栏。

## 验证边界与审批

测试只复制审阅过的13文件闭包及3份AST诊断源码到`D-fixture`，禁插件自动加载和全仓collection；审计钩子阻断网络、子进程、生产数据/凭据访问及sandbox外写入，两轮违规记录均0。原生JUnit、命令、退出码、源码hash和失败详情均留在该目录。

已测正向买卖/重启/回滚/并发重复、完整schema序列化、坏行情/年龄/单位、零预算、缺研究及硬否决、移池合法退出。**未认证：**真实报价来源与盘口量口径、真实日历、实盘可成交性、驻留进程重载、跨进程压力、真实账户盈亏及新复盘闭环。paper接受的source/reliable/研究文件哈希是调用者证据，不是独立来源认证；零费用只能称毛额模拟。

优先建议：先获授权封住D03旁路，再修D01/D02及D05，最后做单执行者→账本→复盘端到端验收。实现修复、账户/模式/cron变更、行情年龄/费率规则、退休或迁移均需另行明确批准；本次不提供任何交易放行结论。
