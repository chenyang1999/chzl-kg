---
name: analyze_main_sectors_v1
description: R2 主线板块 — 从全市场挑 1-3 条主线，每条 3-5 只候选龙头；5 维打分
agent_owner: R2
version: v1.4
status: active
category: research/R2
created: 2026-07-03
updated: 2026-11-01
spec: docs/agents/R2-主线板块Agent.md
---

# analyze_main_sectors_v1 · R2 主线板块 Agent

**跑动时点**: 07:45（**R1 / R3 / R4 / R7 完成后**）  
**权威规格**: `docs/agents/R2-主线板块Agent.md`  
**产出路径**: `data/research/YYYYMMDD/R2_main_sectors.json`  
**后续步骤**: 本 skill 完成后由 **`filter_leader_v1`** 做龙头硬过滤（同文件原地更新）

---

## 唯一职责

从全市场板块中挑选今日 **1–3 条主线**，每条给出 **3–5 只候选龙头**（龙一/龙二/候补）。  
**禁止**: 风格判断(R1)、买卖点(D1)、个股深度画像(R5)、技术形态。

## 因子面板选票器(v1.2 · 2026-07-07 新增 · 参考 vibe-trading `factor-research`)

**问题背景**: R2 当前用"tushare 板块涨跌 + R3 共振 + R4 催化 + R7 资金"四维定性排序,板块内个股排序缺乏**量化因子层**验证,易受当日噪音干扰。

**周日夜跑离线任务**: `scripts/factor/weekly_ir_scan.py --lookback 60 --top 5`
- 输入: A 股全池 · tushare `stock_factor`(动量/成交量/换手/波动 30+ 因子)
- 调用: `mcp_vibe_trading_factor_analysis(factor_csv, return_csv, output_dir, n_groups=5)`
- 输出: `data/factor_snapshot/YYYY-MM-DD/top_ir_factors.json`,含过去 60 日 **IR>0.5 且 IC>0.03** 的 top 5 因子及其符号

**R2 消费方式**: Step 3 板块内个股排序时,读取本周 `top_ir_factors.json`,对候选池按 top-5 因子的加权(IC 加权)计算 `factor_composite_score`,与原定性打分**并列**作为龙一/龙二裁决依据;两者冲突时以定性为主,但**必须在 notes 里显式标注 factor_score 排位**(供 R6 反证消费)。

**降级**: `top_ir_factors.json` 缺失或过期 >7 日 → R2 跳过因子层 · notes 记 `factor_layer_degraded=true`。

---

## 横切 skill（`@` 引用，禁止重写查询逻辑）

| Skill | 路径 | 用途 |
|-------|------|------|
| `@hithink-sector-selector` | `skills/_shared/hithink-sector-selector/` | 多条件板块筛选（热度/资金/涨幅组合） |
| `@hithink-industry-query` | `skills/_shared/hithink-industry-query/` | 行业结构、板块成分概览 |
| `@hithink-market-query` | `skills/_shared/hithink-market-query/` | 板块/个股行情快照、主力资金 |
| `@iwencai-query` | `skills/_shared/iwencai-query/` | NL 验证「某概念涨停家数/连板高度 top」 |

调用方式：读取对应 `SKILL.md` 并按其 CLI/API 执行；**不得**在本 prompt 内复述 hithink/iwencai 的实现细节。

---

## 输入

### 上游 research artifact（必需，先 `read_file`）

| 路径 | 字段 |
|------|------|
| `data/research/YYYYMMDD/R1_style.json` | `style`, `main_lines_count`, `position_cap_suggestion` |
| `data/research/YYYYMMDD/R3_sentiment.json` | `resonance_top_themes`, `hotlist_signals` |
| `data/research/YYYYMMDD/R4_news.json` | `sectors_catalyzed`, `top_events` |
| `data/research/YYYYMMDD/R7_capital_flow.json` | `main_force.top_inflow_sectors`（若 07:30 批次已产出） |

若某上游 `status != complete`，按 spec §6 降级并在 `notes` 标注；R7 缺失时资金维用 T-1 或 Tushare 直拉。

### 本地 raw（`data/raw/YYYYMMDD/`）

| 文件 | 用途 |
|------|------|
| `manifest.json` | severity |
| `wechat_official_20.jsonl` / `wechat_cli_5groups.jsonl` | 叙事维度补充 |
| `weflow_snapshot.json` | 可选，共振维度 |
| `hotlist_signals.json` | 若存在则读；否则自行用 Tushare `ths_hot`/`dc_hot` + 昨日 diff 计算 |

### 用户 context（只读）

- `data/user_preferences.yaml` → `sector_blacklist`, `sector_whitelist_priority`
- `data/human_thesis/active/*.md` → 长期主线笔记；得分 40–70 可进 `secondary_lines` 并标注「长期主线继承」
- `chzl_kg/主线/*.md`（若存在）

### MCP（按需，Tushare 为主）

`ths_hot`, `dc_hot`, `ths_member`, `dc_concept_cons`, `moneyflow_ind_ths`, `moneyflow_ind_dc`, `kpl_concept`, `limit_cpt_list`, `limit_list_d`, `limit_step`, `top_list`

### vibe-trading MCP 补充（2026-08-06 新增 · 核心增强）

**目的**：R2 板块内个股排序缺乏量化因子层，vibe-trading 提供快速问财 + 资金流 + 研报验证。

| 工具 | 调用方式 | 典型问句 | 返回字段 |
|------|---------|---------|---------|
| `vibe_trading__iwencai_search` | NL 问句 | `{板块名称}概念成分股，按市值倒序，取前20只` | 成分股列表 |
| `vibe_trading__iwencai_search` | NL 问句 | `{板块名称}近30日涨幅前10，验证资金共识` | 涨幅排行 |
| `vibe_trading__iwencai_search` | NL 问句 | `{概念} AND 市值>50亿 AND 股东户数连续2季减少` | 筹码集中度 |
| `vibe_trading__get_fund_flow` | ts_code | R2 候选池每只票，查主力净流入占比 | 主力净流入/占比 |
| `vibe_trading__get_research_reports` | ts_code | R2 候选池每只票，查近30日研报 | 研报标题/评级/目标价 |
| `vibe_trading__factor_analysis` | ts_code | 对候选池 top 10 做动量/换手率因子排名 | 因子综合分 |

**调用时序**：Step 2（候选板块初筛）→ `iwencai_search` 查成分股 → Step 3（个股排序）→ `factor_analysis` 综合打分。  
**节流**：候选板块 ≤ 5 个，每板块 iwencai 调用 ≤ 2 次，全 skill ≤ 10 次。  
**降级**：`vibe_trading__iwencai_search` 失败 → `@iwencai-query` CLI 替代。

---

## 执行步骤

### Step 1 · 读上游 + 大势优先、区分研究与计划身份

先比较当下市场奖励、板块合力/扩散、延续与核心辨识度，再核必要风险。辅助资料缺项/质量分只说明证据局限，不全局禁买；真实用户/账户硬预算与停买仍交最终权限层执行。旧市场性no_trade/零仓建议标来源、事实时点、适用窗口及重评条件，本次按有效证据重评，不把旧计划的0预算固化为研究政策。

本轮 D1 首次成案之前，候选 `in_today_plan` 为未知（省略或null），不得写false、附`plan_outside_scan`或据旧计划缺席认定本批不能研究。后续确有同版D1计划时才引用其明确身份与版本；计划外身份不是 R2 在成案前能创造的执行禁令。`gate_status`须区分真实硬限制、必要缺证和待本次D1裁决的市场意见，不以泛化“拦截”把三者合并。

- 读 R1：`main_lines_count` 与 `style` 作为市场温度和交易约束输入；不能据此停止研究或预先清空研究观察对象。分别记录已确认可交易主线与待资金确认的研究方向；真实无合格对象允许空，不用研究方向冒充已确认主线。
- 读 R3：`resonance_top_themes` 与热榜覆盖、时点及缺口，作为观察输入，不单凭热度判定方向。
- 读 R4：对照 `sectors_catalyzed` 的事件原文、时点和反证，不单凭消息强度断定资金方向。
- 读 R7：资金净流入前十板块

### Step 1.5 · 市场横截面与梯队观察
观察广度、主线梯队、最高标与容量核心、主要指数和板块扩散，注明数据时间、覆盖和口径。消息、个股反应和板块传导需独立核验；仅以前日相对强弱或热度不得否决方向。未确认主线与有来源的研究方向分开，允许无合格主线，禁新不停止研究。

### 四季度情绪题材与10cm妖股研究（从2026-11-04起采用，逐日按市场证据验证）

- 先实际阅读 `chzl_kg/投研交易/游资风格/A股短线黑话词典.md` 的市场风格/名字梗定义、`新生代游资核心观点整理.md` 的92科比股性/人气/换手/补涨切换段及`新生代游资交易纪律.md`的市场地位与指数情绪段。它们是历史方法材料，不是当日行情或现行监管规则；与当前用户指令和既有硬边界冲突时按后者，不继承历史“只做深市”等说法。
- 四季度/跨年是待每日验证的研究窗口，不自动推导妖股行情或固定打法。按资金交易的预期年份理解题材，而不是只按当前年份匹配：2026年四季度提前研究2027年羊年叙事，不能因为当前是马年就将羊年线索判为日期错误或排除。研究生肖、字辈、谐音、名字梗、社会话题及监管消息之后的叙事切换；不要求这些方向有产业政策、业绩兑现或现成官方概念标签才可研究。将市场实际传播、用户提出线索和模型联想分别标明，不能先编梗再拿上涨作证。
- 妖股通道优先研究沪深普通10cm股票，两交易所同等对待；这是该通道的研究优先级，不是全系统20cm禁令，不把大容量权重修复票替代为妖股候选。低价、流通盘与换手是比较项，不新造硬阈值；流通市值<20亿元剔除，20—50亿元注明风险但不刻意回避，ST/风险警示及既有保护不变。
- 顺序为市场奖励/指数与情绪关系 → 叙事共识与人气辨识度 → 龙头/补涨/切换地位 → 历史涨停连板股性及真实换手承接。允许纯情绪题材，但必须核资金选择与实际市场地位；不以单项均价、净流入、板数、日期或固定评分替代判断，不因指数下跌就否定所有独立情绪机会。
- 监管警告、关注/异动公告、停复牌与交易限制逐项按官方来源、公告日期和实际对象核对；“监管后资金会换名字炒”只是竞争性假设，不当作已发生事实或规避监管的交易依据。题材叙事可灵活，不解除真实风险或必要审核。
- 2026-11-04单日核验线索：用户点名七匹狼，并提出“羊/狼、谐音与监管后叙事切换”的观察。保留为用户待核线索，核实际传播、梯队、股性、资金与监管来源；不得预设成妖、强行入选或把未知写成已验证。明确“当前2026年马年、预期2027年羊年”的跨年时钟，羊年线索是提前交易预期，不是用户混淆日历；日历正确不等于该线已有市场合力，仍核当日证据。此单日点名不成为长期固定股票名单。
- 沿用现有 `main_lines`/`secondary_lines`/`leaders`/`notes`与逐票 `selection_basis`/`stock_type`/`t1_game`承载真实结果，不扩schema或另造分数。情绪线未成立、候选不合格或必要证据缺失，明确覆盖与未纳入原因，不静默漏研究、不为凑数造票；仍由R5/R6和D1完成必要画像、审核与买点。

### 候选形成前：消息催化、产业趋势与纯情绪并行比较

- 在 Step 2 初筛及 Step 4 候选排序之前，将 R4 `top_events` / `stocks_impact` / 已有 `first_board_candidates` 中有直接催化映射的对象，与有证据的产业趋势、纯情绪方向并行纳入研究比较；不先锁定旧名单，再只为旧票补故事。三类可重叠，不设配额、默认赢家或新评分，不要求每只票都有新公告，也不因缺产业逻辑一概禁纯情绪。
- 事件/产业对象仍核真实受益关系、资金选择、核心地位与当前所处位置；消息真实或趋势成立不等于可买。纯情绪仍核传播、人气、梯队和承接，10cm优先只适用于原妖股通道。
- 已出现一致扩散后，次日须独立核旧核心兑现、梯队分化与承接；有证据的高潮/兑现不能靠继续找同字、谐音或低位后排维持旧叙事。比较旧核心分歧后的真实承接、新事件/产业方向与独立情绪切换；不因单一高位/一致标签否决龙头，也不因后排低位而递补，沿用原生命周期及硬否决。
- 在现有 `notes` / `selection_basis` 说明实际覆盖、采用与未纳入理由；上游未覆盖或候选缺必要画像时保留缺口并交相应研究owner，不据此断言全市场无机会，不产生交易许可。

### Step 2 · 板块筛选

1. `@hithink-sector-selector`：按「概念涨幅前 N + 主力净流入 + 涨停家数」筛一批候选  
2. Tushare `limit_cpt_list`：按涨停家数/连板统计取 top 20  
3. 合并去重；剔除 `sector_blacklist`；`sector_whitelist_priority` 得分 ×1.2

### Step 3 · 五维研究比较（每维 0–20，总分 100）
沿用热度、资金、涨停、叙事、共振五个维度及现有输出格式；分数是研究排序辅助，不是验证过的胜率。记录证据来源、时间、缺失和反证，不把热度直接等同拥挤或派发；不以单一相对强度、最高标或消息条数直接一票否决。已有独立交易风控与权限保持不变。

### 辨识度优先选股(v1.3 · 2026-10-19 用户钦定)

**原则(用户原话)**: 龙头风险 < 补涨杂毛——杂毛失去板块β无人接;题材一旦启动先做全市场"一听就知道"的票。
辨识度两层: ①跨平台热榜持续度(同花顺/开盘啦/东财) ②题材心智锚("一提福建板块就想到平潭发展"式的历史记忆)。

**必读数据**:
- `data/rules/theme_anchors/latest.json`(由 `scripts/research/build_theme_anchors.py` 每周/股性表更新后生成): 每题材锚定分 TOP8(妖性型/容量型标注)
- R3 `hotlist_signals`: 多平台在榜持续度;**高位赖榜+主力净卖出=霸榜出货,锚降级但不删除**

**Step 4 龙头候选排序改为**:
1. 题材被判定为主线后,该题材心智锚 TOP3 **默认入候选**(除非 ST/流通市值<20亿/霸榜出货hard_reject),不受当日截面资金排名影响
2. 辨识度裁决: 身位(连板板数/首封时序) > 热榜持续度 > 心智锚定分 > 当日资金流入
3. **龙一必须是当日板块内身位/封板时序/人气最强者**;补涨票(低位、未涨停、靠资金流入排名上位)只能标 `role: B计划补涨`,不得占执行池主位
4. 主跌→修复期: 聚焦**新题材首板/二板接力**(身位新、位置低),高位老龙不接;主升期才允许高度龙
5. 三通道(打板/半路/低吸)按当日赚钱效应选,不因情绪周期静态禁用某通道——通道选择写 `channel` 字段,主跌段是降低开仓数量/可整池为空,不是禁用龙头买点
6. **允许 execution_pool 为空**: 无合格龙一时输出空池+理由,禁止拿弹性核心/杂毛充数

**红线补充**: 禁止因"高位/一致"单独否决龙一后用低位票替补;龙头被否的合法出口只有空仓或等分歧(买点标注,不换票)。

---

## Step 4 · 龙头候选（每条 3–5 只）

筛选顺序（spec §3.3）：

1. 板块内今日/昨日涨停共振  
2. `@hithink-market-query` / Tushare moneyflow：主力资金流入 top5  
3. 近 5 日龙虎榜频次（`top_list`）  
4. 连板高度（`limit_step`）  
5. 流通市值 <20 亿不看；20–50 亿警惕但不刻意回避，逐票注明风险与依据；排除 ST/退市/风险警示，缺市值不伪造合格  
6. `@iwencai-query` 可选验证：「{板块名} 涨停 连板高度 流通市值不低于20亿」；返回字段及单位须核验  

**板块前缀规则**：常规主线研究中，300（创业板）/ 688（科创板）与主板同权参与龙一/龙二/中军竞争，不因前缀自动判为不合格或添加“需过滤”。四季度情绪/妖股通道按本节用户要求优先研究沪深普通10cm，不将此偏好扩大为全系统20cm禁令。仅920（北交所）沿用既有执行限制；20cm可标弹性角色，是否参与仍按实际地位、买点、风险与授权判断。

输出 `leaders[]`：`role` = 龙一/龙二/候补，`ts_code`, `name`, `pct_chg`, `limit_times`, `selection_basis`。

**本步产出的是研究候选池**；`filter_leader_v1` 仅标龙头层级与执行前置资格，不是最终交易许可。禁新仓/零预算时保留有证据的研究观察对象并标仅研究；R5 仍可画像，R6 完整性门槛不变。最终开仓须由 D1 与执行侧逐票通过既有门禁及授权，无对象不凑数。

### Step 4.4 · 主线生命周期判定（2026-09-04 新增 · `@mainline_lifecycle_v1`）

**在选龙头之前**，先判定每条主线的生命周期阶段——因为「一条退潮期的主线，龙头再强也不该做」。

调 `@mainline_lifecycle_v1`（`src/research/mainline_lifecycle.py::locate_mainline_lifecycle`），对每条候选主线算：

| 指标 | 含义 | 数据源 |
|------|------|--------|
| `age_days` | 主线已运行交易日数（从首次涨停潮起） | `limit_cpt_list` 回看 N 日 |
| `leader_height` | 龙头连板高度 | `limit_step` |
| `money_persist_days` | 板块主力资金连续净流入天数 | `moneyflow_ind_dc` 近 N 日 |
| `break_rate` | 今日炸板率 | `limit_list_d` |

写入每条主线的 `stage` / `stage_name` / `stage_action` 字段（`formation`/`early_up`/`mid_up`/`climax`/`fade`）。

**联动规则（治"一日游"）**：
- `early_up`（主升早期）→ 优先研究龙头/龙二；进入 execution_pool 仍须 D1 独立核验全部交易门禁，阶段不能自动授权
- `mid_up` → 可做，龙头分歧低吸或后排补涨，控仓
- `climax`（高潮分歧）→ **只做龙头或空仓等分歧**，禁追高缩量一字
- `fade`（退潮反抽）→ **降级次线**，不进主线主推；除非情绪周期=主升（超跌反弹博反抽）
- **禁止**：把已运行 ≥5 天 + 资金转出的主线当"新主线"推荐（这是"一日游陷阱"）

### Step 4.5 · 个股属性分类 + T+1 博弈推演（2026-09-04 用户方法论）

对每条主线的每个候选，除 role（龙一/龙二/候补）外，**必须**标注：

**1. 个股四分类**（`stock_type`）——不同属性对应不同操作节奏：
- `抱团型妖股`：高辨识度人气票，资金抱团，波动大，看情绪不看基本面
- `波段型趋势股`：沿均线/趋势上行，量能配合，可拿波段
- `连板妖股`：高度连板，T+1 博弈最激烈，隔日溢价/炸板风险双高
- `稳健防守股`：低波动、有资金防守逻辑的票（**不是**"死水高股息"）

**2. 板块攻守属性**（`sector_offensive`）：进攻（资金进攻主线）或 防守（防御避险/低位修复）——**不是静态标签**，随资金切换。农业/创新药等可从前防守转进攻。

**3. 龙头结构**（`leader_structure`）：谁是打高度的龙头（`height_leader`）、谁是容量的中军（`capacity_core`）——与流通市值相关；量能充沛时大盘股优先，量能萎缩时小盘股更受青睐。

**4. T+1 博弈推演**（`t1_game`）——A股 T+1 下每笔买入=押注次日有人接力，必须推演：
- **消息双面解读**：利好→高开低走（先手兑现）or 平开高走？利空→洗盘吸筹（低吸机会）or 真利空瀑布杀？
- **预期差/超预期**：赚钱效应来自预期差，不是消息本身
- **买点推演**（`buy_point_check`）：集合竞价/开盘是否已被先手资金兑现？有无好的进场节点（低吸/半路/打板）？追高是否接盘？
- **短线结构词汇**：用"卡位/弱转强/分离/联动/助攻/补涨"等描述资金博弈位置（详见 R2 横切短线方法论）

写入每个 leader 的 `stock_type`, `sector_offensive`, `leader_structure`, `t1_game` 字段。

---

### Step 5 · 风险 bullet

每条主线 `risks[]`：引用 R3 `distribution_alert`、R6 尚未跑时的待验证项等。

### Step 6 · 写盘 + 触发 filter_leader_v1

1. 写入 `R2_main_sectors.json`（见下 schema）  
2. **立即执行** `@filter_leader_v1` 对同一文件做龙头硬过滤

---

## 产出 JSON 契约

`data/research/YYYYMMDD/R2_main_sectors.json`：

```json
{
  "schema_version": "research_unit_v1",
  "agent": "R2",
  "trade_date": "20260704",
  "generated_at": "2026-07-04T07:50:00+08:00",
  "status": "complete",
  "confidence": 0.80,
  "fetch_global_severity": 0,
  "inputs": {
    "fetch_manifest": "data/raw/20260704/manifest.json",
    "upstream_artifacts": {
      "R1": "data/research/20260704/R1_style.json",
      "R3": "data/research/20260704/R3_sentiment.json",
      "R4": "data/research/20260704/R4_news.json",
      "R7": "data/research/20260704/R7_capital_flow.json"
    }
  },
  "main_lines_count": 2,
  "main_lines": [
    {
      "name": "机器人",
      "score": 82.0,
      "score_dims": {"热度": 18, "资金": 17, "涨停": 19, "叙事": 16, "共振": 12},
      "logic": ["R4: 特斯拉产线催化 high", "资金: 东财概念净流入第1"],
      "leaders": [
        {"role": "龙一", "ts_code": "002050.SZ", "name": "三花智控", "pct_chg": 10.0, "limit_times": 4, "selection_basis": "...", "stock_type": "波段型趋势股", "sector_offensive": "进攻", "leader_structure": {"height_leader": "002050.SZ", "capacity_core": "300750.SZ"}, "t1_game": {"消息解读": "...", "预期差判断": "...", "买点结论": "低吸", "短线结构标签": "卡位"}}
      ],
      "leaders_degraded": false,
      "leaders_degrade_reason": "",
      "risks": ["R3 distribution_alert 待 R6 验证"]
    }
  ],
  "secondary_lines": [{"name": "商业航天", "score": 62, "reason": "长期主线继承"}],
  "notes": "",
  "method": "llm_v1",
  "confidence_rationale": "..."
}
```

---

## 红线

1. ❌ 主线 **最多 3 条**  
2. ❌ 每条主线龙头 **最多 5 只**  
3. ❌ 不出买卖点、止损、仓位（D1 处理）  
4. ❌ 不做估值（R5 处理）  
5. ✅ 分数只作研究比较；不得仅以score或资料质量分硬禁主线/全市场交易。核心认定须给市场奖励、合力、地位与必要风险证据。

---

## 降级路径（spec §6）

| 失效源 | 处理 |
|--------|------|
| moneyflow 死 | DataPro 或仅热度+涨停 |
| R3/R4 死 | 叙事/共振维留null并说明缺口，不把未知填0；已核维度继续研究，不自动禁全市场 |
| 全死 | `chzl_kg/主线/` 长期继承 + 涨停，`severity=3` |

---

## chzl_kg 人读 md 落盘（必需 · @render_kg_md_v1）

**契约来源**: `skills/_shared/render_kg_md_v1/SKILL.md`

除机读 JSON 落盘之外，本 skill 必须**同时**渲染一份人读 md 到 chzl_kg 供用户当日审阅。

### 落盘路径

```
chzl_kg/投研交易/主线研判/{trade_date}.md
```

（目录若不存在，`mkdir -p` 创建。）

### frontmatter（必填，UTF-8 · Unix 换行）

```yaml
---
date: {trade_date YYYY-MM-DD}
agent: R2-main-sectors
skill_version: analyze_main_sectors_v1@1.0
generated_at: {ISO 8601 · 落盘时刻 · 含时区}
confidence: {从本 skill JSON artifact 读；缺则 null}
degraded: {true|false}
data_sources:
  - name: {源标识}
    path: {data/raw/... 或 MCP 名}
    status: {ok|error|timeout|stale}
    captured_at: {ISO 8601 或 null}
    record_count: {整数或 null}
    error: {可选 · 简短错误串}
input_freshness: {ok|partial|stale}
input_freshness_note: {任一源非 ok 时必填的说明}
---
```

### 正文（Markdown）

```markdown
# {trade_date 中文日期} · **主线研判**

> **数据源新鲜度**: {input_freshness}
> **降级状态**: {degraded}
> **置信度**: {confidence}

## 一句话结论
{≤ 60 字核心判断}

## 详细分析
{3-5 段主体}

## 关键证据
- 证据 1: {内容} · 来源 {data_source}
- 证据 2: ...
- 证据 3: ...

## 数据源审计
| 源 | 状态 | 抓取时间 | 记录数 | 备注 |
|---|---|---|---|---|
...

## 不确定性 / 反证
{自我批判段}

## 与其他 R/D/E 的关系
- 依赖: {上游 artifact 列表}
- 被消费: {下游 skill 列表}

## Sub-Agent 元数据
- skill: analyze_main_sectors_v1
- artifact: data/.../{...}.json
- 生成耗时: N 秒
- model: {model 名}
```

### 落盘规则

1. **atomic write**: 先写 `.tmp` → `mv` 到目标（避免 Obsidian 抓半写）
2. **overwrite**: 同日重跑覆盖；若目标已存在先备份为 `.md.bak`
3. **失败不阻塞**: md 渲染失败**不**回滚 JSON artifact 落盘；skill status 写 `partial` 并在汇报中标注

### 验收

盘后 `test -f chzl_kg/投研交易/主线研判/{trade_date}.md` 必须为 true；前 30 行满足 frontmatter schema。

---

## 写作契约(v1 · 2026-07-06 硬约束升级)

本 skill 输出的 md **必须**遵循 `skills/_shared/canghai_writing_contract_v1.md`,该契约定义了:

1. **写作风格锚点** — 对标 `样例/20260630_pre_open_plan.md`,表格化 + emoji + 因果句 · 禁 python dump JSON / 群名裸露 / 时分秒
2. **必含 mermaid 图表**(≥1 张 · 节点 ≥ 8) — 本 skill 推荐类型见契约
3. **推理深度三问** — 每个 top 分析对象显式回答 `**大资金意图**` / `**为什么走强**` / `**逻辑够不够硬**`
4. **每票思维链**(≥4 段) — 首推票必附 `**买入理由**` / `**风险点**` / `**止损条件**` / `**可验证假设**`
5. **数据源审计表** — 三色 emoji · 日期无时分秒 · 群名匿名化 · 主源缺失即 degraded=true

**验收硬门槛**: md 落盘后逐条自检契约第六节六项,任一缺失即 skill 状态 `partial`,视为执行失败须重跑。

## Version History (writing contract)

- v1 (2026-07-06): 加入沧海写作契约 · 覆盖 R1-R7 + D1
- v1.2 (2026-08-07): R2/R3/R4/R7 cross_validation 交叉验证 + consensus_themes 共识主题

---

## v1.2 新增 · R2/R3/R4/R7 交叉验证（P0-3 修复）

**问题根因**: 2026-08-05/06 实盘跑中,R2 main_lines.leaders 输出后,无任何字段告诉 D1/R6 "这条主线 R3 共振了吗?R4 催化支持吗?R7 资金流入吗?"。R2 完全独立判断 → D1 在选 execution_pool 时**再次**人工交叉 R3/R4/R7,浪费时间且易遗漏。

**v1.2 交叉验证契约**(硬约束,新增到 §产出 JSON 契约 之前):

每条 main_line 必须新增字段:

```json
{
  "name": "机器人",
  "score": 82.0,
  "cross_validation": {
    "r3_resonance_match": true,        // R3.resonance_top_themes 包含"机器人"/L1-L3 主题
    "r4_catalyst_match": true,         // R4.sectors_catalyzed 包含"机器人"且 strength>=medium
    "r7_capital_match": null,          // R7未覆盖可比证据，未知而不是阴性
    "cross_validation_score": 1.0,     // 仅已核的2项均支持，不冒充三源完整
    "checked_source_count": 2,
    "r3_evidence": "L1+L2 共振,行业分析师群 3 个独立提及",
    "r4_evidence": "E20260805_002 特斯拉产线催化 high,首推三花智控",
    "r7_evidence": "可比范围未核；不在top10不能据此写无资金支持"
  },
  "consensus_themes": []               // 见下方说明
}
```

**consensus_themes 字段**(顶层):

```json
{
  "consensus_themes": [
    {
      "sector": "存储/HBM",
      "agreement_count": 4,            // 出现在 R2 ∩ R3 ∩ R4 ∩ R7
      "sources": ["R2_main_lines", "R3_resonance_top_themes", "R4_sectors_catalyzed", "R7_top_inflow_sectors"],
      "composite_score": 0.92           // = (r2_score + r3_resonance + r4_strength + r7_rank_score) / 4
    }
  ]
}
```

**计算逻辑**(R2 LLM 在 §Step 5 风险 bullet 之后,§Step 6 写盘前自动算):

先逐来源核本批版本、对象映射、实际已查范围/窗口与证据，再给三态结果：支持为true、实际检查后不支持为false、未查/范围外为null；不能对缺失输入用`any([])==false`，也不能仅因不在R7前十写已证实无资金。每个结果保留`r3_evidence`/`r4_evidence`/`r7_evidence`的真实定位与限定语义，板块排名不冒充个股资金。

仅对已核非null项计算兼容`cross_validation_score`并显式记录`checked_source_count`；全部未知为null，不填0。`agreement_count`只计实际支持来源，底层同稿/同接口不重复计独立性；达到原共识数量条件才列`consensus_themes`，无法比较的综合分为null，不用0占位。该摘要不代替必要风险审核，更不产生交易门槛或买权。

**消费契约**(供 D1 / R6):
- `cross_validation_score`只描述已查跨源支持，不是独立交易门槛；低分或缺辅助源不强制降级到watch_pool。逐项保留支持/冲突/未知，交D1结合市场奖励、核心地位与必要风险裁决，不自动给执行资格
- D1 写入 `meta.cross_validation_summary`,列出当日 consensus_themes 数量
- R6只对已核实的矛盾给反证；分数0、字段缺失或未在top10不等于已证明无资金支持，不据此自动strong_suggest

**降级**:
- R3 缺失或范围未覆盖 → `r3_resonance_match=null`；仅对已核可比项计算兼容摘要`sum(non_null) / len(non_null)`，分母为0时为null，并列实际已核分母，不冒充完整三源支持
- R4/R7 缺失同上
- 任一上游缺失 → JSON 顶层加 `cross_validation_degraded=true` 字段,让 E1 复盘能识别

**验收**:
- 盘后 `tests/check_r2_cross_validation.py` 校验每条 main_line 含 `cross_validation` 字段、`consensus_themes` 字段存在、4 源交集阈值生效
- 缺任一字段 → orchestrator 标 R2 失败

---

## Version History

| 版本 | 日期 | 说明 |
|------|------|------|
| v1 | 2026-07-04 | 骨架建立 |
| v1.1 | 2026-08-06 | vibe-trading MCP 补充(候选板块扩池) |
| v1.2 | 2026-08-07 | P0-3 修复: cross_validation 字段(3 源验证) + consensus_themes(4 源交集) |
| v1.3 | 2026-11-01 | 历史新增相对强度固定权重、拥挤度扣分及一票否决已撤销；市场横截面与梯队观察保留。 |
| v1.3 | 2026-10-19 | 辨识度优先: 题材心智锚+热榜持续度入主排序;龙一独占执行池;允许空仓;通道动态化 |
