---
name: main_decision_v1
description: D1 主决策 Agent 核心 skill — fresh context LLM 消费 research_summary.json，出 pydantic-valid watchlist_plan.json + 盘前预案 md
agent_owner: D1
version: v2.1
status: P0
category: plan/D1
created: 2026-07-04
updated: 2026-11-02
tested_with: ["20260704 (skeleton dry_run)"]
---

# main_decision_v1

**归属 Agent**: D1 主决策 Agent（canghai-plan profile，08:00 fresh context）
**权威 Spec**: `docs/agents/D1-主决策Agent.md`
**契约**: `docs/11-契约-盘前预案.md` · `docs/10-契约-研究汇总.md`
**用户铁律**: `data/user_preferences.yaml`

## Purpose

D1 是全局唯一决策者：**不抓原始数据、不委派子 Agent、不携带 R1–R7 中间推理**。fresh context 只读最终 artifact，综合裁决后写出当日唯一 `watchlist_plan.json`。

> **T1' 执行路径**：本 skill 由 **LLM fresh context 直接决策**（主路径）。
> **禁止**将 `src/plan/d1_algorithm.py` 或 `src/plan/main_decision.py` 当作主路径调用；它们仅为规则版对照/回归，供人工 diff，不得替代本 skill 的推理与落盘。

## 当前决策政策：大势优先，缺项分层

本节为用户批准的现行差异；历史示例不得重新引入“任一缺项全局禁买”。先判断市场奖励什么，再比较板块与核心，最后选择入场和承担风险。T-1指标只描述T-1；盘中已有可核变化时由计划owner重评，不把昨天的阶段、资料质量分或零仓建议冻结成永久禁令。

- **资料质量不是盈利概率。** 保留confidence原值、公式和缺口；不再以`confidence < 0.4`单独触发全局禁新。0.392不是胜率39.2%。说明哪些结论仍成立、哪些降低把握、哪些必要事实确实未核，不调分凑过线。
- **风险按对象与来源生效。** 真实用户/账户停买、已确认全局硬风险、真实逐票硬否决与执行保护分别保留。辅助热度、个别外盘、历史研报或日历覆盖缺口不自动全局禁买；必要价格、成交性、关键合规或出货判断确实缺证时，仅限制相关对象，不将未知写成通过、不牵连必要审核已完成的另一对象。
- **研究覆盖不等于必要决策完成。** summary为partial不能单独证明全部候选不可用；按本轮实际选中执行对象核R6必要覆盖、硬否决、价格与身份。主研究真实性和版本校验仍必需。production_ready/research_completion_passed不得因文件已交付而为true，也不要求无关对象与所有辅助项目全完美；仍缺必要判断的对象保留待核与补证义务。
- **市场仓位建议不同于账户预算。** R1作研究建议，D1按本轮市场、赚钱效应、情绪温度和逐票证据，在已签硬上限内独立决定市场建议，不读取或扣减真实/模拟持仓、余额及未知账户可用额度。账户未知不等于市场建议空仓；不能以ACCOUNT_BUDGET_UNVERIFIED、no_trade或执行额度0推导人的建议仓位0。真实用户/账户禁令及未知来源执行保护仍保留，正建议不授实盘或绕过必要审核；不固定复制历史试探比例。

### 市场建议与执行额度的显式双轨（优先于下文历史公式与示例）

- 正常主路径须单列顶层`market_position_advice`，`sizing_basis="market_only"`，字段为`total_position_cap_pct`（市场建议总仓上限）、`initial_position_pct`（本轮初始试探总仓）、`fact_at`、`valid_until`（含时区ISO时点）、`rationale`、`conditions`。比例是0—1有限数字或null，初始试探不超已给建议上限；保留实际事实日、观察窗口和条件，未形成结论保留null及具体原因，不从账户未知、旧计划或检测器档位补数。
- 执行/观察/B计划逐票条件总仓建议写`StockEntry.suggested_position_pct`，不写入`entry_rules`以免变成未知执行谓词；互斥买点/重复B候选不重复累加。依据与必要缺证、审核、市场触发及失效条件分开说明，正建议不是已取得买入资格，硬否决仍保留。没有本轮逐票判断时保留null，不从`max_position_pct`或`entry_rules.position_pct`借数。
- 建议以账户净资产100%作为概念比例基准，不需读取实际金额；表示建议总风险敞口，不是在未知已有仓位上额外加仓，不计算假想加减仓差额。仓位建议只由本轮市场事实与风险取舍形成，不因真实/模拟持仓、剩余名额或账户读取权限改变。阶段只定温度，不机械映射固定打法或永久仓位表。
- `risk_limits`、`max_position_pct`和`entry_rules.position_pct`仍为原系统执行约束/分配，不能拿新建议字段回填它们；未获授权时仍按原契约为0，保留dry_run、no_trade、禁自主、人工确认、真实账户停买与逐票硬限制。执行端实际下单仍核账户/持仓/资金，这不反向归零市场建议。不能在未读账户时声称用户实际新增为0，只能说系统未授权执行。
- 人读主报告前部并列市场建议总仓、初始试探、逐票条件建议及系统执行限制。缺市场建议显示未知，显式0显示0；不得把执行0标成建议0。共享renderer只展示本轮显式字段，不生成或重评建议；正式判断与JSON仍由计划owner同版交付，不能在渲染或历史回填时造新建议。
- 实现回归覆盖正常/安全网两入口的明确字段义务、严格数字/时点/上限校验、schema与真实loader往返、账户与模拟持仓变化不影响建议、观察/B与互斥场景不借数、正建议且执行额度0时订单仍拒绝。隔离运行先装收集前I/O守卫，复用真实授权链与合成账户/行情；源码回归不冒充正常模型已采用，不重跑正式预案求非零。

- **核心优先，不等待资料完美。** 优先为有辨识度、资金确认的核心完成必要判断；可用已有同版真实证据及可靠替代源交叉，不强求某一provider/某一R字段齐全。明确值得试的原因、条件买点、可承担风险、失效事实；不反复重跑全市场，也不为每天出票凑票。
- **形成计划不同于执行计划外买入。** 研究提名、D1首次形成或合法修订时，不要求对象已在旧计划中；执行仍只认已发布且已授权计划。不得用in_today_plan=false循环阻止首次纳入。

业务取舍归本轮LLM；Python负责事实、日期、几何、作用域与原硬保护，不另造综合分数替代判断。流通市值硬线、T+1、退出、仓位硬上限及实盘/人工确认边界不变。

## 四季度10cm情绪核心与名字梗预案（从2026-11-04起采用，逐日按市场证据验证）

- 在正常主报告原文单列“10cm情绪核心／名字梗”章节，区分情绪投机与权重/容量修复，不用中军防守票替代用户要研究的情绪核心。沪深普通10cm优先仅适用于该通道，不新增全局20cm禁令、不强迫当日采用该风格或填满候选。
- 只消费本轮已授权绑定R2/R3/R4/R5/R6/R7中的实际候选和证据；由R2承担游资风格方法阅读及题材发现，本条不扩D1辅助输入白名单、不让D1旁路打开未绑定原始资料或现场补选票。若上游未研究该方向，明确覆盖缺口并交回研究owner，不假装已经筛过。
- 纯生肖、字辈、谐音和社会话题叙事，不因无产业/业绩逻辑直接排除；按预期交易的年份解释跨年主题，2026年四季度炒2027年羊年不得因当前马年被机械过滤；反过来，名字沾边不等于有市场合力或可买资格。分别解释传播依据、辨识度、梯队/补涨/切换角色、股性换手、指数与情绪联动/分离及次日接力假设，允许LLM灵活比较，不加固定权重、强制同涨或机械加速门槛。
- 监管事实、公告日期、适用对象和交易限制沿用上游真实证据；未核保留未核，不能把规避监管或谐音切换当成解除风险的依据。2026-11-04须明确交代用户提名七匹狼的上游覆盖及本轮纳入/观察/未纳入理由；这不是买入指定或长期硬编码名单。
- 对有来源且有买卖研究价值的对象，沿用现有执行/观察/B计划身份、竞价符合/超预期/不及预期三档、引擎条件价位、最高接受价、买前取消、T+1退出及失效剧本；资格与价位分列，禁止为“妖”而挪价、降门槛、补未知预算或虚构明日涨停。
- 无合格情绪对象时写清市场证据、对照和缺口，允许空仓但不停研究；真实逐票硬否决、流通市值硬线、仓位上限、预算、dry_run/人工确认与下单权限完全不变。原文与同版JSON保持一致，不新增正式产物路径或额外模型轮次。

## 三类机会的综合裁决（沿用本轮已授权研究）

- 消息催化、产业趋势、纯情绪并行比较，三类可重叠，不设固定配额或默认优先通道；情绪/名字梗章节只是其中一部分，不要求所有候选有新公告，不以事件标签替代资金、核心地位和位置判断。
- 对本轮已绑定 R4 有直接催化映射的实际候选，在原文说明“采用／延后／排除”及具体证据；与 R2/R5/R6/R7 的覆盖、角色和反证交叉，不只对旧情绪名单补故事。尚未进入 R2 候选或缺必要画像/审核时，说明覆盖与待补事项并交回相应owner，不由D1现场补选或旁路取数，也不把未画像等同全市场无机会。
- 对一致扩散后的旧情绪线，按本轮证据比较核心兑现、真实分歧承接与新方向，不靠继续挖同名/谐音后排维持旧剧本；不能仅凭高位/一致否决龙头再以低位杂毛递补。沿用原池身份、R6硬否决、必要审核、价位及买权边界，“小仓试试”不能豁免证据或授权。
- 比较与处置理由放本轮模型原文和现有解释文本，不新增schema、评分、固定仓位或预算阈值，不扩大输入白名单，不新增模型轮次或研究任务。

## 必要审核与市场重评的实际接口

- `pipeline_artifacts.decision_review_scope(primary, plan)`先按完整R2/R5研究集合验证原R6模式1/2/6/7，再核`execution_pool`实际带`entry_rules`对象的`selected_review_completed`，保留其余对象的原覆盖及所选对象的`selected_incomplete`。空选中集合不认证研究完成，旧全局布尔或空否决不代替逐票明细。
- R6模式1可使用同版R5真实可比资金/价格与R4独立交叉，不能要求R7特定字段或provider齐全；模式6消费R3明确已查对象、窗口与结果，空alert不是阴性；模式7区分`flagged/checked_negative/not_applicable/unknown`，辅助unknown不冒充合规缺证，必要缺证仍限制相关对象。局部proposal只交原五字段完成明细，实质判断放原markdown，不能为写判断破坏既有接收器。
- `decision_hard_vetoes`与`decision_active_restrictions`只隔离已明确的另一票范围；全局、未知作用域或非法目标继续保护，不按名称/描述猜限制归属。原逐票硬否决、来源、顺序与未完成项保留；完成覆盖不等于无风险。
- 差分/事件重评仅能改调用方`condition_sources`提供的精确来源条件的active；用户/账户/未知来源不改。已有`EFFECTIVE_ZERO_BUDGET`且source精确为`R1/R2/R5/R7`，同日绑定R1研究cap与原推导值一致、三处原市场cap合法一致时，才有`market_budget_source`；它是研究来源，不是账户许可。只有同时存在绑定的`market_policy`，计划owner才可按真实新证据提出一致的新`risk_limits.target_total_position_pct`、`meta.position_cap_pct`、`position_cap_derivation.final_position_cap_pct`，不得超`user_preferences.position_hard_rules.max_total_position_pct`。来源/字段缺失则保持未知，不补默认预算、不按检测器参考档位自动抬仓。
- 本条差分/事件修订不换原池、entry/exit、订单上限、执行环境与人工确认；不因此增加具体对象的仓位或下单权限。必要审核完成标志须owner显式给出，绑定、汇总partial及其他对象缺项不能代替本轮实际裁决。

## When to Run

| 时点 | 前置条件 |
|------|---------|
| 08:00（盘前批次） | 同日 `data/research/YYYYMMDD/research_summary.json` 已存在且 `orchestrator_status` ≠ `failed` |

若 research 主控未完成，告警并保留未完成事实；缺少必需输入/校验失败仍拒绝写 plan，不拼造半成品。若现有安全校验允许发布未就绪 LLM 临时版，必须完整符合安全发布字段与重评契约（见 Step 3.5.8），只能 dry_run/禁新仓，不视为研究完成或最终裁决。

---

## Inputs（全部 pull-based，只读）

### 本轮版本与辅助读取边界（优先于下文路径示例及历史必读条款）

- 主研究版本由实际当前研究 owner 的 run_id、summary 交付回执及其 input_manifest 共同定位；复用 `verify_saved_inputs` / `consume_authorized_inputs` 的原校验，核对 artifacts、run/attempt、receipt 和内容摘要。启动前与交付后必须同版；目录同日、mtime 更新、正文自报“本批”均不能替代绑定。辅助输入不得覆盖主研究版本或混入 artifacts.R1–R7。
- `data/user_preferences.yaml` 是既有只读政策输入，须保留实际读取版本，不借本条改值。技能/契约读取与业务辅助材料读取分开；下列历史路径、工具示例和“必读”义务本身不是本轮授权。
- 已批准的辅助读取为`data/research/{trade_date}/attention_signals.json`、`data/research/{trade_date}/emotion_cycle.json`和真实既有日历`chzl_kg/投研交易/催化剂/{trade_date}.md`三类精确路径。受审调用代码用`approved_d1_auxiliary_paths`固定范围，以`input_manifest.bound_auxiliary_inputs`绑定本批主版本、run/attempt和文件摘要/字节/mtime；D1经`consume_bound_auxiliary_inputs`取得单独返回的实际payload，不混入artifacts.R1–R7。启动/交付复核同一主研究及辅助版本；旧summary无绑定时不得现场重建或补读后来到达的文件。
- 其余错题、观察材料、账户及其他候选没有因此获得许可；不展开通配符、不补抓、不换日期或找替代文件。`auxiliary_candidates`的`pending_approval`/`approved_adapter_only`仍只是适配证据，模型或报告中的authorized=true不能自签。辅助事实日期、观察窗口、生成时间原样保留；人气`use_trade_date`是使用日，`signal_trade_date`和顶层`trade_date`是事实日，不把T-1绑定解释为当日实时人气。
- 未获许可或无版本绑定：不展开 corrections/observation 等通配符，不现场抓数/算新研究，不调用交易账户；在本轮原文和既有 meta 文本留具体缺项及 owner，不能把未读解释成“无错题/无人气/无大事件”。其中必要风险判断无法完成时保留相关对象未就绪、禁止该对象新买与补证义务，辅助缺口不自动扩为全局禁新；不以新增默认结论填空。
- 日历仅经上述精确绑定返回完整Markdown及frontmatter；保留`event_facts_verified=false`的本义：元数据/版本通过不等于事件已核。D1阅读原文中的来源、暂定/已定档、待核结果与具体对象后判断未来三交易日风险；不凭标题造事件，不跟随`previous_report`、外链或历史路径，不假定存在另一个calendar JSON。日历缺失或无效是有责任和影响说明的辅助gap，不默认全市场命中事件，也不解除已核相关事件保护。只读许可和核心JSON/KG主MD写许可分开。

两类快照的实际读取使用已有工作对象`saved`（本轮已核版本的summary）、`date`与项目`ROOT`：

```python
from scripts.research.build_research_summary import (
    approved_d1_auxiliary_paths, consume_bound_auxiliary_inputs,
)
auxiliary = consume_bound_auxiliary_inputs(
    saved, root=ROOT, approved_paths=approved_d1_auxiliary_paths(date),
)
```

逐项使用`available`条目的`payload`并引用实际版本/时点；`unavailable`仅表示绑定时的缺口，没有payload，不补0/false或“无风险”。消费者返回内容和绑定成功不认证模型已理解或采用；正文说明采用/未采用、缺口及影响对象。辅助缺口不独立构成全局禁买；必要风险无法判断时仅限制相关对象。读取成功也不能解除真实R6硬否决、用户/账户禁令或未知来源预算保护。盘中事件差分重评仍按Step 3.5.9的独立输入边界运行，不因这里的正常D1接线新增其前置依赖。


### 必填

| 路径 | 用途 |
|------|------|
| `data/research/YYYYMMDD/research_summary.json` | **主入口**；含 `artifacts` 指针、`hard_rejects`、`confidence`、`fetch_global_severity` |
| `data/user_preferences.yaml` | 仓位铁律、龙一龙二池、合规过滤、观察池规模 |

### 按需 pull（经 `research_summary.artifacts`）

| 键 | 默认路径 | 消费内容 |
|----|---------|---------|
| R1 | `data/research/YYYYMMDD/R1_style.json` | 风格模式 → `position_cap` |
| R2 | `data/research/YYYYMMDD/R2_main_sectors.json` | 主线板块 + 龙头候选 |
| R3 | `data/research/YYYYMMDD/R3_sentiment.json` | 情绪共振（可选维度） |
| R4 | `data/research/YYYYMMDD/R4_news.json` | 消息催化（可选维度） |
| R5 | `data/research/YYYYMMDD/R5_stock_profiles.json` | 六维画像、`alpha_grade`、`risk_grade` |
| R6 | `data/research/YYYYMMDD/R6_devil_advocate.json` | `hard_reject` / `strong_suggest` / `soft_note` |
| R7 | `data/research/YYYYMMDD/R7_capital_flow.json` | 资金面确认 |

### 可选

| 路径 | 用途 |
|------|------|
| `data/human_thesis/active/*.md` | 用户当前视角 |
| `data/reports/YYYY-MM-DD/observation_tracking.json` | 昨日观察票，避免重复否决 |
| QMT 持仓（`user-agentqmt_qmt` MCP 或 REST） | 决定 `plan_status`（持有/加仓/减仓） |

---

## Outputs

| 路径 | 说明 |
|------|------|
| `data/plans/YYYYMMDD/watchlist_plan.json` | **核心契约**；必须通过 pydantic 校验后才写盘 |
| `chzl_kg/投研交易/盘前预案/YYYYMMDD.md` | 唯一人读主报告：本轮模型完整原文 + 同版定稿 JSON 的共享表格 |

**输出边界**：正常 D1 主路径只交付以上核心 JSON 与 KG 主 MD；不写 `plan.md`、`_点位表.md`、`_散文版.md`、`_价位推导.md` 或新的 raw 伴随文件。原文保留在主报告正文内；调用本 skill 不扩大 canghai-plan 的 Ownership 或本轮 prompt 白名单。其他章节中的历史双份 MD 记录不构成当前写入义务。

写盘前确保目录存在：

```bash
mkdir -p data/plans/YYYYMMDD
mkdir -p chzl_kg/投研交易/盘前预案
```

---

## LLM Prompt 结构（fresh context 主路径）

按顺序执行以下 **7 步**，每步只引用 artifact 字段，不复述子 Agent 推理链。

### Step 0 — 契约与健康度门禁

1. 读取 `research_summary.json`，校验：
   - `schema_version == "research_summary_v1"`
   - `trade_date == YYYYMMDD`（当日）
   - `artifacts` 含 R1–R7 且路径文件存在
2. 读取 `data/user_preferences.yaml` 全文
3. 若 `orchestrator_status == "failed"` 或 R2 artifact 缺失 → **中止**，不写 plan
4. 若 `fetch_global_severity >= 3` → 仍可出 plan，但 `mode` 必须为 `dry_run`，`autonomous_trading_enabled=false`

### Step 0.4 — 近期错题本注入（快回路 · 2026-08-31 新增）

开盘决策前，**必须**读近期错题本，把 E1 沉淀的同类错误带进今天判断（防同类错误重犯，这是错题本从「记分牌」变「训练器」的关键）：

1. 读 `data/corrections/20*/error_case_*.md`（最近 3 周，优先同 `category` 的 high/medium 条目；用 `scripts/trading_tools.py --action get_all_corrections` 可直接取结构化版）
2. 对命中本日情景的错题，明确回答「今天的判断是否避开/覆盖了该错题」：
   - **R2 主线遗漏类**（`error_case_001_main_line_rotation` / `error_case_20260831_001`）→ 强制交叉 R1 `sise_sector_ranking` top 共振板块 + 盘初板块涨停潮（≥3 家）即时补线
   - **R6 无差别反证类**（`error_case_002_r6_blanket_bearcase` / `error_case_20260831_002`）→ 情绪回暖日 R6 反证只决定仓位上限、不构成「不参与」依据
   - **P2 午盘强判类**（`error_case_20260831_003`）→ 强主线龙头午盘分歧 ≠ 上攻乏力，留「午后催化」不确定项
3. 采纳/不采纳都要在 plan `meta` 记一行 `corrections_applied`（`case_id` + 是否规避/覆盖理由）

### Step 0.5 — 宏观 + 情绪 + 行为金融 周期定位（v1.3 · 2026-08-06 新增 · 不阻塞）

**触发条件**: R1/R3 完整 + 跨资产数据可用时执行。**任一缺失** → 跳过整段，进入 Step 1。

1. **宏观环境判定**（`@全球宏观分析框架` 3 档）：
   - 软着陆/降息预期：金/铜同涨 + USDCNH 月升值 > 0.5% + Fed 9 月降息概率 > 50%
   - 衰退担忧：金涨 + 油跌 + 股市高位 + 美元强
   - 滞胀：金涨 + 油涨 + 股市横盘 + 美元强

2. **情绪周期定位**（`@行为金融分析` 7 阶段）：
   - 冷静(涨停<50) / 乐观(50-80) / 兴奋(80-100) / **贪婪(涨停 100+ + 5+ 板 100% 晋级)** / 狂热(涨停 150+) / 焦虑(炸板率>25%) / 恐慌(跌停 100+)
   - **2026-08-05 实况**: 涨停 104 + 5+ 板 100% 晋级 = 贪婪阶段

2.5. **情绪周期四阶段定位（硬接入 · v1.7 · 2026-09-04 新增 · `@emotion_cycle_v1`）**：
   - 读 `data/research/YYYYMMDD/emotion_cycle.json`（由 `compute_cycle_metrics.py` 预计算）或调 `@emotion_cycle_v1` 现场算
   - 四阶段：`low_test` 低位试错 / `main_up` 主升 / `high_chop` 高位震荡 / `main_down` 主跌
   - **阶段只定温度，不预设打法**：按真实赚钱效应、龙头身位与资金确认动态选择通道；不因阶段自动停止研究或自动授权交易。以下保留原仓位约束数字，仅列温度，不构成开仓许可：

| 阶段 | 温度 / 研究要求 | execution_pool | 原仓位约束（不因本提案上调） |
|------|------------------|----------------|---------------------------|
| `main_up` 主升 | 研究当前最强核心，不能认为任何位置都可买 | 逐票通过门禁才可入 | 按 R1 cap 上限 |
| `high_chop` 高位震荡 | 核对分歧与承接，不静态锁定打法 | 保留原减量约束 | cap × 0.75 |
| `main_down` 主跌 | 继续研究新题材首板/二板，不能接高位老龙或把抄底冒充低吸 | 保留有来源的执行候选及条件价位；禁新限制实际买入，不据此清候选 | cap × 0.4；禁新决定另写 no_trade |
| `low_test` 低位试错 | 准备右侧确认剧本，不凭阶段给代码授权 | 小仓仍须独立资格 | cap × 0.5 |

   - **优先级**：阶段用于温度与已有仓位约束，不覆盖全局禁令、R6、逐票资格或用户授权；不把描述性的阶段标签当通道白名单。
   - 写入 `meta.emotion_cycle_phase` + `meta.emotion_cycle_action`

3. **跨资产→板块映射**（`@大宗商品分析` commodity→sector）：
   - 黄金 +3% → 黄金股加分（+0.05）
   - 铜 +3% → 铜业/锂电加分（+0.05）
   - 油 -2% → 油服/上游减分（-0.05）

### Step 0.55 — 大事件前夜 · 买点后置硬闸门（2026-09-14 新增 · 用户钦定 · 强制 gate）

**背景（错题本 004 固化）**：2026-09-14 高位光模块（新易盛 -4.99% / 长飞 -3.02%）在"美联储 9/17 凌晨决议前"被 AI 三巨头"呼吁放缓 AI 开发"利空闷杀——R4 把 Amodei 呼吁归类为"Anthropic IPO+盈利"利好（polarity=正面），未识别行业级利空；执行池在加息落地前仍持有高位 AI 硬件。**用户钦定纪律：买点后置——大事件落地前不抢跑，等确定性信号。**

**Step 0.55 Gate（已核事件、实际影响范围与买点后置）**：

1. **事件日历扫描**（消费本批`catalyst_calendar`已绑定完整原文，不现场抓数或自换历史材料）：逐项核未来 **≤3 个交易日内**是否有以下大事件；保留日历实际覆盖、来源及未知，不把“读到了”写成窗口事实全部已核：
   - 美联储利率决议 / CPI / PPI / 非农 / 议息会议
   - 中国重磅宏观数据（金融数据 / 社融 / 经济数据 / LPR / 政治局会议）
   - 地缘重大升级（战争 / 制裁 / 关税 / 科技出口管制）
   - 龙头公司重大事件（发布日 / 财报 / 定增 / 减持 / 监管调查）
   - AI 巨头联合声明 / 行业级监管表态（如 2026-09-14 三巨头呼吁放缓 AI 开发类）

2. **若命中大事件** → 执行**买点后置**硬规则：
   - `execution_pool` 中**高位票**（近 10 日涨幅 > 30% 或连板 ≥ 3）**默认降级 watch**；确需保留的必须逐票写"为什么这次例外"且经用户 sign-off
   - 被已核事件直接影响的新增买入后置到事件落地后：对应 `entry_rules` 标注 `post_event_only: true`，触发条件为"事件落地 + 竞价/开盘确认"。不相关对象不连带禁止；日历覆盖未知不是全市场已命中事件。
   - 高位持仓相关：预案提示"事件落地前高位持仓只减不加，破位即走"
   - 仓位：若事件偏负面（如三巨头呼吁放缓类），`position_cap` 额外 × 0.6

3. **写入 plan**：`meta.event_premarket_gate = {"event": "...", "event_date": "YYYYMMDD", "post_event_only": true/false, "high_pool_reduced": true/false, "rationale": "..."}`

4. **与 Step 0.5 联动**：大事件前夜即使情绪周期判 `main_up`，也以本 Gate 的买点后置优先（防"情绪好就抢跑"）。两者冲突以本 Gate 为准。

**约束**：本Gate限制已核相关事件落地前受影响高位票的抢跑，非全市场禁令。事件落地后由计划owner按新证据重评。日历缺失、未授权或覆盖不完整时保留具体未知与责任，不制造全市场大事件的默认结论；已核事件的必要保护仍有效。

### vibe-trading MCP 补充（2026-08-06 新增 · D1 决策增强）

**目的**：D1 整合 R1-R7 + 用户意图做最终决策，vibe-trading 提供候选池量化验证 + iwencai 概念纯度二次确认。

| 工具 | 调用方式 | 典型问句 | 返回字段 |
|------|---------|---------|---------|
| `vibe_trading__iwencai_search` | NL 问句 | `Execution候选池：{候选代码} 30日换手率>10% AND 近1年无重组` | 候选池过滤表 |
| `vibe_trading__iwencai_search` | NL 问句 | `验证叙事纯度：{概念}成分股中纯正主业占比>80%` | 概念纯度报告 |
| `vibe_trading__get_market_data` | ts_code | D1 候选池每只，查近5日K线（验证近因） | OHLCV |
| `vibe_trading__get_fund_flow` | ts_code | 候选票，查主力净流入占比（与 R7 交叉验证） | 资金流 |
| `vibe_trading__pattern_recognition` | ts_code | 候选票，查"突破"、"回踩"等形态（辅助买点判断） | 形态信号 |
| `vibe_trading__search_symbol` | name | 用户输入"XX科技"→ ts_code（处理用户自然语言输入） | 标准代码 |

**调用时序**：Step 1（R1 风格）→ Step 2（R2 候选过滤）→ **D1 vibe-trading 验证**→ Step 3（风控硬过滤）。  
**关键**：D1 必须在最终 `execution_pool` 每只票上调用至少 1 次 vibe-trading 工具（`iwencai_search` 或 `get_market_data`），确保候选池不只是 R2 的定性判断，而是有独立量化证据。  
**节流**：execution_pool ≤ 15 只，每只 1 次，全 D1 ≤ 15 次调用。  
**降级**：`vibe_trading__iwencai_search` 失败 → 直接用 R2/R7 的判断结果。

4. **position_cap 联动**（`@市场情绪分析` 5 维度法）：
   - 情绪极端值仅为风险与拥挤参考，不能由低分自动推导仓位下限或高分自动决定交易；D1结合当日资金确认、核心地位及真实风险作仓位建议，受原用户/账户硬上限及预算约束。
   - 情绪分处于中间区间也不机械跟随旧R1零仓建议；须核其事实日与来源。

5. **写入 `market_context.emotion_cycle`**:
   ```json
   "market_context": {
     "structure": "...",
     "emotion_cycle": {
       "phase": "贪婪",
       "score_5d": 85.2,
       "r1_sentiment_score": 75,
       "gap": 10.2,
       "commodity_signal": "金+3.4% 铜+3% 油-1.9% 人民币升值",
       "macro_regime": "软着陆+降息预期"
     }
   }
   ```

> D1 红线 7：**Step 0.5 不得**作为 hard_reject 触发器——仅是 position_cap / 加分 / 减分参考，不 override R6 模式六。

### Step 1 — 风格与仓位上限（R1）

从 R1 读取今日风格结论，映射 `position_cap`（写入 `risk_limits.target_total_position_pct` 与 `meta.position_cap_pct`）：

| R1 风格信号 | position_cap |
|------------|--------------|
| 防御观望 / 情绪冰点 | ≤ 0.40 |
| 震荡分化 | ≤ 0.60 |
| 主线进攻 / 情绪扩散 | ≤ 0.75–0.80 |

降级：R1超时或质量低时，核本轮其他已绑定研究中可支持市场温度的真实事实；不以低质量分自动零仓，也不补默认0.50。必要市场事实无法判断时明确未核；有证据的局部机会继续比较，预算和授权仍独立校验。

**v1.3 · 2026-08-06 新增 · Step 0.5 情绪分硬联动**:

```
final_position_cap = MIN(R1_position_cap, 情绪联动上限)
```

| R1 sentiment_score | 情绪分 5 维度 | Step 0.5 联动 | 强制 position_cap 上限 |
|-------------------|--------------|--------------|---------------------|
| ≤ 20 (极恐) | ≤ 20 | 核右侧确认与承接，不自动逆向抬仓 | 无机械仓位下限，真实预算优先 |
| 20-40 | 20-40 | 跟随 R1 | 跟随 R1 |
| 40-60 | 40-60 | 跟随 R1 | 跟随 R1 |
| 60-80 | 60-80 | 跟随 R1 | 跟随 R1 |
| **≥ 80 (贪婪)** | **≥ 80** | **逆向卖出** | **≤ 0.60**（不允许 R1 给的 0.80） |

**2026-08-05 实况**: R1 sentiment_score=75 + 5 维度分 85.2 = Step 0.5 强制 position_cap ≤ 0.60。

写入 `meta.position_cap_pct` 和 `meta.position_cap_source: "R1-style with emotion_5d_override"`。

### Step 2 — R6 硬否决（不可覆盖）

1. 合并 `research_summary.hard_rejects` 与 R6 内 `severity: hard_reject` 条目
2. 对应 `ts_code` **永久剔除** execution_pool 候选；可进入 `watch_pool`（`watch_reason_code=distribution_alert`）或 `rejected`
3. 记录到 `meta.r6_devil_advocate.hard_rejects_applied`

> 红线：D1 **不得** override R6 `hard_reject`，无例外。

### Step 2.5 — 主线第一天参与原则（硬规则 · 2026-08-31 新增，错题本 001/002 固化）

打板/情绪驱动行情下（R1 情绪回暖日 **或** R2 主线 `stage=early` 且当日板块涨停家数 ≥3），**主线第一天的参与优先级高于 R6 反证**：

1. **R6 反证只决定仓位上限，不构成「不参与」依据**：
   - 情绪回暖日（炸板率收敛 + 涨停家数扩张），R6 的出货/退潮类反证置信度整体打折（×0.5）
   - 「基本面亏损 / 资金面弱 / 估值高」→ 只压仓位（如 ≤3%），**禁止**直接把主线龙头降为「只观察不参与」
   - 唯一硬例外：R6 `hard_reject`（模式六霸榜出货等）仍不可覆盖
2. **主线龙一/龙二必须至少进 execution_pool（轻仓）或 watch_pool 最高观察级**：
   - 主线 `stage=early` 且涨停潮启动 → 优先完成龙一研究；仅在当日允许新仓且逐票通过全部门禁后由 D1 定仓，无保底参与额度；否则只观察并保留禁令
   - 龙一一字锁仓买不进 → 顺势切龙二/候补的参与机会，**而不是放弃整条线**
3. 本原则写入 `meta.mainline_participation_applied`，供 E1 复盘核对是否被执行

### Step 2.6 — 板块公共判断的复用与逐票引用（说明性接线）

仅在本轮既有研究输入及当前读取白名单内，复用 R2 已有板块判断；不增加模型轮次、调用、取数或路径。

- 先以 R2 实际 main_lines/secondary_lines 的板块对象及已有行情窗口为准，在现有 sector_core_watchlist 对应条目保留公共判断一次：沿用已有 sector、stage/round、sector_status、core_leaders/leaders、source_evidence、trigger/intraday_low_absorption_rules、invalidation、captured_at/data_date 槽位承载确有依据的内容；不是要求 R2 必有这些同名键。source_evidence 中引用 R2 实际字段位置与支持/风险原文，保留待验证性质；不重算板块分、不从候选强弱另造板块结论。
- 对没有实际证据的本轮窗口、板块效应、共同确认/失效或事实时点，在本轮模型原文明示“未知/未提供”，现有文本槽可原样记录缺口；不补新字段、不把 stage 充 round、不把 generated_at 充观测时间。不同轮行情不能仅凭板块同名合并；区分依据不足就保留该缺口。
- execution_pool、watch_pool 及 B 计划中每票沿用实际 sector/theme 归属（两者已有时核对一致），在现有 reason/alpha_logic 或 entry_note 及本轮原文引用上述公共条目，保留 R2 原角色与 selection_basis/leader_structure/t1_game 中已有关系依据；最终池角色不冒充 R2 原角色。归属或角色未提供时明示未知，不臆配板块，不复制一套逐票公共判断。
- 概念归属、跨源主题命中和阶段标签本身不证明同轮共振；只有已有支持/相反证据才能说明联动或分离，独立/关系未确认不直接改称杂毛、庄股或 anti_rotation。阶段在此仅作上游标签，不另推静态打法；已明确命中的原门禁仍按原规则处理。
- 仍由本轮 D1 综合已有支持、反证与缺口裁决，并在同轮原文说明公共条件与各票既有 entry/exit、观察或 B 剧本的关系；未确认不写成已满足，已有失效不写成仍有效。按现有 Step 5.0/Step 7 核对原文与定稿 JSON；共享表格只展示，不补判断。不新增字段、评分公式/权重、硬否决、通道政策或交易许可。

### Step 3 — 合规 + 龙一龙二筛选（R2 + R5 + user_preferences）

对 R2 候选逐票过滤（顺序从最严到最宽）：

1. **合规**：**自 2026-08-06 起,300/688/920 全部解禁**(用户确认全系统已支持创业板/科创板/北交所)。残留风控:`st_filter`(ST 摘帽期)、停牌、退市警示 → execution 剔除,watch 可保留。**特殊规则**(v1.1):300/688 因涨跌幅 20%,止损/止盈阈值自动按 1.2x 系数调整(可在 `user_preferences.yaml` 里 override)
2. **R6 hard_reject**（Step 2 已剔）
3. **人气维度（2026-09-14 新增 · 用户钦定"人气=潜力核心" · 必读 `attention_signals.json`）**：
   - 读 `data/research/YYYYMMDD/attention_signals.json`：`persistent`（90日持续人气）/ `surge`（今日跳升/首次进榜）/ `cross_platform`（多平台合力）/ `today.dc_renqi_top` + `today.ths_stock_top`
   - **加分**（进 execution 时写入 `attention_score`）：持续人气 `days_on_list ≥ 10` + 今日仍在前排 → 人气分 +1；`surge` 跳升股（首次进榜/排名跳升≥15）→ 标记 `attention_surge=true`（配合弱转强/超预期买点）
   - **警告**：持续无人气（90日从未上榜）却单日大涨/涨停的票 → 标 `attention_cold=true`，**警惕无合力/庄股**，默认降级 watch（需用户 sign-off 才进 execution）
   - **联动**：人气股 ∩ 主线龙头（R2 龙一龙二）→ 最高优先级；人气掉出榜（`L2_dropped` 类）的票 → 检查是否该卖出/降级
4. **龙一龙二池**（`leader_preference`）：
   - 每板块仅龙一、龙二可进 execution_pool
   - 龙一：板块涨停家数 top1 **或** 主力 5 日累计 top1 **或** 连板高度 top1
   - 龙二：板块综合评分 top2
   - 龙三及以下 → watch_pool；龙一被 R6 hard_reject 后不得为数量或低位偏好启用龙二/杂毛递补，保留真实否决与空池理由
   - **杂毛过滤**（满足 ≥2 项即剔除 execution）：主力排名 top3 外、龙虎榜 30 日无机构席位、连板高度 < 龙头-2、换手率 < 板块 median 50%
5. **风险等级**（R5 `alpha_grade` / `risk_grade`与真实证据）：
   - 档位是比较与仓位参考，不是已校准胜率；先看本轮逻辑、资金、地位、反证和成交条件。
   - 不因继承cap=0而自动只准A，制造“旧零预算→无对象→继续零预算”的循环。账户禁止买入不改变研究对象本身的质量。
   - D1在既有硬上限内说明为什么试、承担何种风险；逐票硬否决、必要缺证与用户/账户停买独立有效，不新增默认试仓额度。
   - **档位缺失必须套契约默认值 B**（`_effective_grades`）。缺失档位若按 rank 0 处理，
     会比 C 更差，使 `risk_grade≥B-` 的 AND 分支恒假 → 该类日期执行池被整体清空。
     R5 实际长期未产出 `risk_grade`（2026-09-30 实测 30 日 0/330），故此项为硬要求。
6. **执行候选、可买资格与持仓上限分离**：`execution_pool` 最多列出 **6 个有真实研究来源的优先新机会候选**，不是已获买权或已成交名单。先由 D1 比较候选并明确买卖情景，再逐项给出资格和当前阻塞；全局禁新、零预算或必要审核未完成时，仍列有依据的优先执行候选，显式标为“执行候选·待补证／暂不开仓”，不得把未知改成通过。已明确命中逐票硬否决或禁止项的对象仍按原规则移入观察／否决，不以候选展示绕过。真实机会不足时说明覆盖与缺口，不凑票，也不把空池解释为全市场没有上涨或反弹机会。已有持仓的维护／退出条目完整保留且不占新机会容量；候选数量不改变实际持仓、订单或仓位上限。只有逐票通过全部原门禁并具备有效预算和授权后才可实际新买；禁新时逐票自动交易关闭、需人工确认，新增仓位与入场规则仓位显式为零。
7. **单票/板块/总仓**：`max_position_pct ≤ 0.15`，单板块累计 ≤ 0.40，总仓 ≤ position_cap

降级：R5 缺失 → `alpha_grade` 默认 B，`risk_grade` 默认 B。

### 旧 score 的身份与来源说明（不新增评分方法）

- 现有必填整数 `score` 是兼容字段，不是已验证的个股质量分或胜率；本段不改变其类型、数值处理、候选顺序、扫描范围、交易资格或原有权限，不新增默认分、权重、阈值或 JSON 评分字段。
- 本轮完整模型原文须交代旧分的已知来源与局限：本轮模型给出的数值只作为未校准的解释性判断，说明实际依据；继承上游数值时说明实际字段路径及适用对象，板块分不得冒称个股质量分。不能仅因数值恰为50就推断它来自规则占位；来源无法核实写未核实，不补造。
- 复用本轮已经实际读取的同版 artifacts 中的原始指标、字段定位和数据时点；模型解释与可计算量分开。缺少方法、关键数据或有效时点时写“不可完整评分／未校准”，不得补造公式、样本、胜率或用数据完整度冒充成功概率；不为本段扩大读取权限或增加模型调用。
- 股性已有字段不自动等于无损原始测量；上游可能将缺失转换为0，需核对零值语义，统计窗口、样本量和观测时点未提供时明确缺口。历史涨停溢价／晋级率不等于当前策略胜率。
- 沿用共享表格的未校准提示和原计划顺序。本段只是来源透明义务，不宣称旧分已从扫描／执行消费中隔离；可复算质量分、排序迁移和评分效果验证仍须独立冻结方法与消费者后验收。

### Step 3.5.6 — 入口通道按 regime 选择（2026-09-30 修 · 禁止固定单通道）

**背景（事故）**：执行池原先只认 `trend_pullback_buy`（决策线 MA50 回踩）单通道。
强势打板行情里龙头距 MA50 常差 20-30%，回踩条件数学上永不成立
→ **越是点火行情，执行池越必然为空**（20260930 六只候选全落 watch、exec=0）。
这与用户三通道体系（打板/强势低吸/跟单）直接冲突：打板是其数据中 64% 胜率的正 α 通道，
却在前瞻层被结构性排除。

**规则**：入口通道由当日赚钱效应、龙头结构和资金确认动态选择，不由 R1 阶段或风格机械开关。下表仅保留历史规则实现映射供核对，不再作为 LLM 主路径资格白名单；规则版 `d1_algorithm.step_regime_channels` 尚未在本提案改动，不能据此宣称实现已统一。所有通道仍受当日禁令、预算、买点与授权约束：

| R1 style（历史映射，非许可） | 历史通道示例 | 历史 ignition |
|---|---|---|
| 连板情绪型 / 主升 | `trend_pullback_buy` + `leader_breakout` | ✅ |
| 主线扩散型 | `trend_pullback_buy` + `leader_breakout` | ❌ |
| 震荡分化型 | `trend_pullback_buy` | ❌ |
| 崩溃退潮型 / 退潮 | `trend_pullback_buy` | ❌ |
| 缺失 / 未匹配 | `trend_pullback_buy`（保守回退） | ❌ |

- `leader_breakout` 口径：平开或小幅高开 + 放量突破昨日涨停价/20日前高跟随买入；
  高开 >7% 不追。
- **一字板不得被静默吞掉**：仍入执行池，但 `entry_rule.one_word_no_chase=True`
  且不给竞价挂单价（挂单必然落空，制造"假买点"），语义为"等开板分歧承接"。
- 每份 plan 必须落 `data_sources.entry_channels`（style/channels/ignition/raw_candidates/reason），
  使 exec=0 时能一眼区分"regime 未开放通道"与"候选被过滤"。

### Step 3.5.7 — 候选不得静默消失（2026-09-30 修 · 硬约束）

**事故**：`step3_execution_candidates` 用裸 `continue` 淘汰候选，被淘汰的票
**既不在执行池也不在观察池**，在预案里彻底不可见。R2 明确选出的 6 只龙一/龙二
曾有 4 只这样消失（20260930：新华传媒 6连板龙一、超声电子 PCB人气王龙一、
依顿电子龙二、广汽集团龙二），用户只能看到"票没了"，无法分辨原因。

**规则**：
- 任何淘汰必须写入 `gate_log` → plan `data_sources.grade_gate_drops`，
  含 `ts_code/name/role/stage/reason`（档位闸门 / R6否决 / 禁买前缀 / 非龙一龙二）。
- 被淘汰的**龙一/龙二必须回灌观察池**（`watch_reason_code=grade_gate_dropped`），
  保证"要么在执行池，要么在观察池，要么在否决清单"——不得三处皆无。
- 档位闸门淘汰原因文案必须提示"risk 为缺省补 B，需核 R5 是否漏产出"，
  避免把上游数据缺失误读为"票不够好"。

### Step 3.5.8 — 兜底 plan 的时序陈旧判定（2026-09-30 修）

**事故**：08:30 兜底 plan 生成时 R5(08:33:51)/R6(08:52:36) 尚未落盘 → 空池；
而安全网（`scripts/plan/ensure_watchlist_plan.py`）只按"文件存在"判幂等，
09:20 再跑也不重建 → 全链一整天读陈旧空池。

**规则**：安全网判幂等时，除"文件存在"外还必须校验**兜底 plan 是否早于
关键上游（R5/R6）落盘**；若是则用完整上游重建。完整、已评估的合法 LLM 决策（含 no_trade/空执行池）不得被兜底覆盖，`--force` 也不例外。

**交付完成 ≠ 全研究覆盖完成 ≠ 所选对象必要判断完成 ≠ 可交易**：先按选中对象核必要审核及真实硬风险，不以summary partial或其他对象缺证自动否定全部。所选对象仍缺必要判断时，安全临时版须显式 `production_ready: false`、`research_completion_passed: false`、`reassessment_required: true`，保持dry_run、禁自主、需人工确认；不得把辅助缺项冒充必要缺项，也不得把文件完成当判断完成。所选对象必要判断已齐、其他对象未齐时，保留两者各自状态和限制，不制造全局未就绪。研究刷新归研究 owner，D1 重评归计划 owner；安全网不代跑R1–R7、不切模型、不擅自抬用户/账户预算；已证实来自研究判断的市场性零仓建议不因此冻结。盘前缺项的差分重评须逐项绑定原预案、当前研究owner、汇总及各主产物的run/attempt/receipt/hash：未变化且同版可核的研究允许复用，补证必须有真实更新与相应交付回执，不能只改mtime或汇总文字触发模型。旧版本身份缺失、错批或漂移不作复用；跨批缺完整继承证据时不默认复用。重评入口不再要求无关七份报告全部重新生成，也不把“允许重新判断”写成“必要审核已通过”；仍有必要缺项时由计划owner明确相关对象未就绪、禁止该对象新买及补证义务；辅助缺项保留影响说明，不自动将所有对象预算归零。真实用户/账户零预算和未知来源限制仍保留，不能由Python自动生成正预算覆盖。新计划通过既有交付/发布/消费边界前旧计划继续有效；真实角色补证与模型运行须按已批准的具体范围执行。`production_ready=true` 也不构成 live/开仓授权。生产窗口和刷新触发待用户另签。

### Step 3.5.9 — 盘中事件差分重评（计划 owner，不是检测器放行）

本分支与安全网的原全批刷新分支分开。收到同一交易日、时点及版本可核的盘中事件后，由 `canghai-plan` 复用已绑定的原研究，读取本次明确列出的事件及受影响的新证据，重新判断可重算的当日市场条件；不强制无关的七份研究全部重新生成，不把旧 `no_trade` 当成永久结论。缺失审核或证据只能逐项补齐并说明，不能凭翻多将未审核对象直接视为通过。

逐项保留原禁令及其来源，给出 `retained / superseded / unresolved`、依据和适用窗口；只有来源明确、属于本分支获授权重评范围的当日市场判断可以被新结论替换。用户/账户预算、制度限制、真实逐票硬否决、来源未知的禁令、执行身份和人工确认要求不得因事件信号撤销；检测参考档位不得直接成为仓位预算或买权。仍有阻塞或未审完时，可以继续不交易，但应列出对应对象与下一步所需证据。

新结果通过原 JSON、人读 MD、来源版本及既有发布/消费边界之前，原计划与限制继续有效。事件只触发重新判断，不直接写预算或下单；失败不得覆盖最后有效计划，正常退出管理不能因禁新停止。拒绝重复事件、错误交易日、未来时点、输入版本漂移和旧文件冒充新交付；真实生成时间与原研究事实时点分别标注，不冒充盘前或固定午盘时点。

实现复用现有检测 wrapper、计划角色启动/验收与 canonical→runtime 交接，不新建研究模型、常驻服务或全市场重跑。新事件只增加明确绑定的事件及差分证据读取范围，不开放任意目录；原安全网的幂等、失败处理和全批刷新契约保持不变。此条需用户签核并完成实现验证后生效；不会仅凭本段文字启动生产任务或增加交易权限。

### Step 3.6 — 战术层短线信号(2026-09-04 新增 · 硬闸门 · v1.7)

每只拟取得实际买入资格的 execution 候选，在 Step 3.5 三大闸门通过后，**还必须**经过以下买点级硬约束；明确失败仍降级watch。按Step 3第6项展示的待补证候选不等于已通过这些闸门：未完成逐项标未知／待核，不伪造通过，不因全局禁新跳过其可完成的买卖情景推演。

**关4 · 板型识别**(`@tactical_signal_v1` · `src/research/board_pattern.py::classify_pattern`):
- 输入: limit_list_d 字段(first_time/last_time/open_times/amount/limit_amount/limit_times/sector_limit_up_count)
- 写出 `pattern` / `time_window` / `pattern_action`
- **硬规则**:
  - 板型=`尾盘投机板(14:30+)` → 拒绝(北京炒家 §1.5.4: 几乎不碰)
  - 板型=`回封板(多次开板)`(open_times≥2) → 拒绝(§1.5.2: 不碰)
  - 板型=`秒拉板` AND 板块涨停<3 → 拒绝(§1.5.1: 无板块效应不封)
  - 板型=`秒拉板` AND 板块涨停≥3 → 排板不冲(§1.5.1 排板优于冲)
  - 板型=`换手板(午前)` → 可扫; 时段 10:00-11:30 合适(§1.5.3 半小时级横盘)
  - 板型=`中军板(午前)` → 可做(§1.5.5 行业一提就想到)
  - `time_window ∈ {尾盘封板(14:00-14:30), 尾盘投机(14:30+)}` → 警告(§1.5.4: 少打)

**关5 · 弱转强/强转弱**(同上函数):
- 输入: prev_open_times/prev_pct_chg/today_pct_chg
- `is_weak_to_strong=true`(烂板+今涨停) → 推荐(92科比 §3.3.27: 烂板后买盘凶=弱转强)
- `is_strong_to_weak=true`(昨涨停+今<5%) → 卖点(§3.3.30: 第三天可能强转弱)

**关6 · 总龙开关**(`src/research/dragon_switch.py::judge_dragon_switch`):
- 输入: 当日市场总龙 ts_code + yesterday/today pct_chg/limit + consecutive_halts
- 写出 `dragon_status` / `dragon_action`
- **硬规则**:
  - `status=second_halt`(总龙第二次被关) → D1 总仓上限 cap ×0.5(陈小群 §10)
  - `status=first_yin_crushed`(首阴被按) → cap ×0.6(§8 准备调整)
  - `status=faded`(连续大跌) → cap ×0.3 或空仓(§10 退潮)
  - `status=alive` + `sector_follower≥3` → 维持 cap(§52 合力强)

**关7 · 分阶段纪律检查**(`src/research/forbidden_filter.py::check_forbidden`):
- 研究提名用`phase="research"`，本轮首次/合法修订形成计划用`phase="plan_formation"`；不得借默认execution阶段将旧计划缺席变成本次选股禁令。
- 区分函数实际返回的`hit_rules`必要硬风险和`context_diagnostics`市场上下文诊断：硬失败按对象保留，诊断交LLM结合大势与本轮证据判断，不因情绪阶段、行业名称对立或不同对象模板不同就自动全局禁买。
- 执行阶段仍用`phase="execution"`，核已发布计划身份及独立买权；研究/形成阶段检查通过不取得执行授权。
- 不给缺证补false/零排名制造“杂毛/无地位”结论；真实中位跟风、风险越界及必要未知仍按对象说明和处理。

写入每只票: `tactical_signals.pattern` / `dragon_status` / `forbidden_hits[]` 字段。

### Step 3.5 — 核心判定 + 盈亏比 + 纪律自检（2026-09-04 新增 · 硬闸门）

对通过 Step 3 的每只候选，在取得可买资格前**必须**跑以下三关；任何一关明确拒绝仍移出执行候选，保留观察／否决理由。尚未完成与明确拒绝分开：待补证候选按Step 3第6项展示且保持禁买，不能把空执行池当作审核完成的替代品。

**关1 · 个股核心判定**（`@core_judge` · `src/research/core_judge.py`）：
- 输入：个股/板块/大盘 20 日日收益率（`daily`）+ 连板高度 + 板块内排名 + 主力净流入
- 输出 `is_core` / `core_grade` / `resonance_type`
- 依据真实地位、板块传导和资金证据判断核心；相对强度或anti_rotation标签不独立证明控盘，缺板块收益/排名不能喂空数组制造假拒绝。
- 已核为无辨识度跟风/中位杂毛的对象仍剔除；量化输入未核与明确负面分开，不由缺省core_grade直接生成全局禁买。

**关2 · 盈亏比判断**（`@risk_reward` · `src/plan/risk_reward.py`）：
- 输入：买点（`buy_price`）+ 止盈（`take_price`）+ 止损（`stop_price`）+ 情绪阶段 + 是否核心
- 输出 `risk_reward_ratio` + `position_suggestion_pct` + `grade_check`
- **硬规则**：`risk_reward_ratio < 1` → 拒绝开仓（纪律铁律6: 盈亏比优先于胜率）
- 仓位按 `position_suggestion_pct` 写（主升核心可 15%，主跌只试仓）

**关2.5 · R4 利空 × 候选打击面交叉（2026-09-14 新增 · 错题本 004 固化）**：
- 读 `R4_news.json` 全部 `top_events`，取 `polarity=负面` 且 `bearish_scope=行业级/板块级` 的事件及其 `bearish_impact_sectors[]`
- 对每只候选票：所在板块 ∈ `bearish_impact_sectors` → **降级 watch 或要求竞价反证**；命中行业级 → 默认剔出 execution_pool（除非用户显式 sign-off）
- 输出每只票：`bearish_hit: {event_id, scope, sector, action}`（保留/降级/剔出/竞价反证）
- **若 R4 有行业级利空但 execution_pool 仍保留该板块高位票 → 必须有用户 sign-off 记录**，否则判定违反 Gate

**市场奖励与梯队交叉观察**：在已有授权输入内交叉查看消息、板块扩散、最高标和容量核心；标明事实时点、覆盖缺口及反证。R1 情绪分按其基准日解释，不单独预测方向。消息热度、拥挤猜测、最高标封单或单一相对强弱均不直接生成新禁令或买权。原有 R6 硬否决、用户账户预算、禁新、执行审核和卖出管理不因本条改变。

**关3 · 纪律自检**（`@trade_discipline_v1`）：
- 跑交易铁律、分阶段资格checklist及禁止清单；市场上下文诊断与必要硬失败分别记录。
- 真实必要硬风险命中才按对象写入`rejected`并注明证据；温度/辅助诊断不自动剔出，更不将任一对象失败扩为全局禁新。首次形成计划与实际执行身份分别检查。

写入每只票：`core_judge` / `risk_reward` / `discipline` 三段字段。

### Step 4 — 观察池（板块核心 + 近10日涨停 + R2 余票 + R6 修正 + 昨日观察）

组装 `watch_pool`（`watchlist_policy.min_watch_pool_size`–`max_watch_pool_size`，**20–40 只**），来源优先级（2026-08-31 用户钦定扩容口径）：

1. **板块核心个股**：R2 主线/次线 `sector_core_watchlist` 全部 + 每条主线前 3 核心票（含未入选 execution 的龙三及以下）
2. **近 10 交易日涨停股**：tushare `limit_list_d` 拉最近 10 个交易日涨停/炸板名单，保留其中属于当日主线/次线板块、或有资金关注（龙虎榜/主力净流入）的票——**10 日内有过涨停 = 有人气的观察候选，必须覆盖**
3. R6 `strong_suggest` 降级票（须写 `meta.r6_devil_advocate` 采纳/覆盖理由）
4. 昨日 `observation_tracking` 中未成交观察票 + 长期主线未启动票（`sector_off_line`）

每只须含合法 `role`（`watch` / `watch_elastic`）与 `plan_status`（`watch_pool_only` / `watch_pool_wait_for_entry`）。
**观察池宁多勿漏但不凑数**：原数量范围是覆盖目标，不是硬配额；上限 40 只不变。用于盘中扫描与次日回看，不进 execution、不参与自动交易；有效对象不足时列覆盖、淘汰与数据缺口，允许为空。禁交易时观察及重评义务仍保留。

### Step 4.5 — 买点推演 + T+1 博弈（2026-09-04 用户方法论 · 硬要求）

A股 **T+1** 制度下，当天买入不可卖，每一笔买入=**押注次日有人接力**。因此 execution_pool 每只票在定 entry_rules 前，**必须**先做博弈推演（写入 `t1_game_analysis`，作为 entry_rules 的推导依据）：

**1. 消息双面解读**（对应 R4 催化 + 盘前公告）：
- 利好：高开低走（先手资金兑现）or 平开高走（预期差发酵）？——**若高开幅度已被先手兑现，禁止推荐"竞价追高"**
- 利空：洗盘吸筹（给低吸机会）or 真利空瀑布杀？——上升趋势中的利空洗盘=上车机会

**2. 预期差/超预期**：赚钱效应来自**预期差**，不是消息本身。判断市场对该消息的定价是否已充分。

**3. 买点类型与先手风险**（结合 `trading_time_preference`）：
- 集合竞价/开盘：是否已被先手兑现 → 禁追高
- 低吸（用户口径：预判涨停、相对涨停价仍低、高开 5 点也可买；**≠抄底接飞刀**）
- 半路（平开后放量突破压力位跟随）——核具体买点与承接，不能把历史买点失误固化成整个通道负α或静态禁用；与打板/强势低吸按当日赚钱效应动态选择。
- 打板（`leader_breakout`）——用户数据显示打板正 α（64% 胜率）

**4. 短线结构词汇**（判断资金博弈位置）：
- **卡位**：个股争夺板块内身位（先于龙一封板/连板追平），卡住辨识度
- **弱转强**：前一日分歧/炸板，次日转强（高开秒板/低开拉板），分歧转一致信号
- **分离**：个股走势与板块/龙头分离（板块回调它逆势走强），独立资金运作，可能走独立行情
- **联动/助攻**：板块内同涨同跌；助攻=低位票先封板为龙头打开空间
- **补涨**：龙头拉高后低位/滞涨同板块票跟随，行情扩散末段信号（追补涨需谨慎）

**产出**：每只 execution 票写入 `t1_game_analysis`：`消息解读` / `预期差判断` / `买点结论`（竞价/低吸/半路/打板 + 先手风险） / `短线结构标签`。**买点结论必须与 Step 5 entry_rules 一致**；若推演显示"追高被兑现"→ 该票降级 watch 或改低吸节点。

---

### Step 4.8 — 跷跷板 / 对手盘 B 计划（2026-09-17 新增 · 用户钦定 · 硬要求）

**背景**：预案只写"买什么"是单向剧本。**预案票不及预期时，资金会去别的方向**——这是 A 股存量博弈的必然（钱不会消失，只会搬家）。用户钦定：预案必须写"如果这些票不及预期，我可以考虑做哪些跷跷板/对手盘机会"。

**产出**：`plan.seesaw_plan`（B 计划章节，每份预案必有）：

```json
{
  "trigger_conditions": ["触发1: 执行池≥2票竞价不及预期(高开<预期位或低开破位)", "触发2: 主线板块资金净流出且无承接", "触发3: 龙头断板/炸板率>25%"],
  "seesaw_directions": [
    {
      "direction": "防守/高股息", "source_evidence": "R2 次线银行/高股息 + R7 资金流向",
      "candidates": [{"name": "工商银行", "ts_code": "601398.SH", "role": "次线观察", "entry_note": "科技不及预期且指数走弱时启动"}],
      "trigger": "科技主线竞价集体低开 + 炸板率上升"
    },
    {
      "direction": "主线内部高低切(光通信→存储→低位补涨)", "source_evidence": "R2 主线分级 + R7 板块资金",
      "candidates": [...],
      "trigger": "主线高位票买不进/兑现，低位分支承接"
    },
    {
      "direction": "逆势新题材/次线", "source_evidence": "attention surge + R4 事件",
      "candidates": [...],
      "trigger": "surge 票竞价超预期 + 主线不及预期"
    }
  ],
  "opposite_side_note": "反向提示：若 B 计划方向也同步走弱 → 全市场降档，执行池全部后置/空仓"
}
```

**B 计划素材来源（按优先级）**：
1. **R7 `seesaw_pairs[]`**（板块跷跷板配对，20日相关<-0.6）——有配对直接用；空则用 R2 次线
2. **R2 次线板块**（国产算力/卫星/银行高股息等）+ 观察池票
3. **attention_signals 的 surge 票**（今日跳升=资金新去向的候选）
4. 预案里已列但没进 execution 的票（如"高开不追"的票→不及预期时的承接对象）

**触发判定（盘中 P2 会用）**：执行池≥2票竞价不及预期（高开低于预期位或低开破位）、或主线板块资金净流出无承接、或龙头断板——任一命中 → 切 B 计划，预案内已备好方向，不临时起意。

**约束**：B 计划是"预案内备选"，不是"盘中新开计划外仓"——所有候选必须在盘前预案里点名，触发后才按纪律执行（铁律 8：计划外不出手）。

---

## 硬价位完整性(2026-10-21 用户钦定 · Step 5 前置硬规则)

**价位不得由模型凭感觉写——必须先跑规则引擎拿基准值**（引擎：`src/plan/price_levels.py`）:

```python
# 在本轮生产者已有的工作对象plan、交易日date、已核summary对象saved上执行。
from scripts.research.build_research_summary import consume_authorized_inputs
from src.research.chart_evidence import chart_evidence_from_profiles
from scripts.plan.apply_price_levels import apply_to_plan
primary = consume_authorized_inputs(saved, root=ROOT)
chart_evidence = chart_evidence_from_profiles(
    primary["R5"], date, as_of=plan["generated_at"],
)
price_rows = apply_to_plan(
    plan, date, write_prices=True, chart_evidence_by_code=chart_evidence,
)
```

此 API 只在内存补充价位/资格证据，既有行情与技术位读取义务不变；逐票公式、RR、技术位从返回的 `price_rows` 保留供本轮正文引用。不要调用默认 CLI：即使不带 `--write-json`，其 `main()` 也会副写 `_价位推导.md`，超出当前身份边界。

**先选情景，再算价，最后独立判买权。** D1 须基于本轮已授权研究，为执行／观察／B计划中有买卖研究价值的对象明确选择已有适用通道并写入原始 `entry_rules`，然后调用引擎；不开仓决定不免除情景选择和价位推演。若旧稿只是因为禁新而留下空规则，局部修订应由计划 owner 补做这一步，不能保留空规则、让引擎返回缺通道后再据此宣称没有价格数据。选择情景不等于批准买入，也不为满足数字要求另创打法或把抄底改称低吸。

引擎仍不得替 D1 猜通道：无明确通道、仅有旧引擎生成规则或通道冲突时，不默认MA50，也不依MA10溢价替换原选择。区分“未做情景判断”“缺所需价格事实”“来源读取未获许可”和“公式／几何校验失败”，分别交回相应 owner，不能统称没行情。优先检查同版已授权画像中的收盘、均线及K线事实，复用时保留来源、日期、复权和窗口定义；缺权限不旁路读取，缺事实不补造。原通道的远离买区诊断不得通过换均线凑出买点；没有已核当日涨跌停边界时，不把原10%诊断当交易所级的可达性证明。原始及舍入后止损均须低于买区下沿，否则保留失败，不放宽止损或挪买区求通过。

计划情景以买区上沿推导并展示RR；触发价是确认条件，不自动等于拟买价。真实拟委托价（含实际最高接受价）沿用原消费者重算自己的RR，不能借用计划RR放行，也不能为统一数值而抬止损、止盈或最高接受价。沿用现有报价表示精度与阈值，不据两位小数自行认证所有品种的最小报价单位。

引擎口径（可复算）:
- **买区**: ①均线回踩 `[min(MA50,牛线)×0.99, MA50×1.01]`,区间>7%收窄至基准±1.5% ②分歧回踩(强势票,现价距MA10>8%) `[昨收×0.92, 昨收×0.97]` ③突破/打板 `pivot=max(昨收,20日高)`,买区 `[pivot×0.995, pivot×(1+1.5~3%)]`
- **止损**: 以**买入价(买区上沿)**为基准, `买价×(1-5%主板/8%20cm)` 与 `熊线×0.99`、`MA10×0.99` 取最高,且必须低于买区下沿
- **止盈**: 2R = 买价 + 2×(买价−止损);若20日高点在 2R 之下且高于买价5% → 取前高
- **RR** < 1.8 → `RR_FAIL`,不参与

**LLM 的义务**: 在引擎值上做事件/情绪/身位微调,但:
- 偏离引擎买区 >10% 必须在 `derivation_reason` 写明依据(如事件未落地后移买点)
- 不得无依据地凭空写数——引擎算不出的情况(一字板/无价格数据)必须显式说明

**执行池、观察池和B计划均须正常给有依据的数字价位，不因不适合开仓而整池留空**：
- 每个可推演情景给 `buy_zone` 两个数字、确认／`trigger_price`、最高接受价、`stop_loss`、`take_profit`／第一压力位、RR、数据日、有效窗口及取消条件；在主报告前部给简明买卖点总表，把“条件价位”和“当前能否买”分列。
- 量价／板块确认和竞价预期三档是附加条件，不能替代具体价格；全局禁新、零预算或审核未完成只改变权限与状态，不是删去研究价位的理由。
- 纯温度计／禁买锚确无买入情景、一字无成交买点、复牌旧价或所需事实缺失时，逐票解释具体例外；已有可核结构支撑／压力仍展示为参照，不冒称已确认买区。历史价必须标真实日期与不适用范围，不能伪装为今日可成交价。
- 在本轮生产对象中逐项核对引擎返回与实际字段：`apply_to_plan` 返回有数字不代表顶层止损／止盈和 `exit_rules` 已补全。将同一情景对应的真值绑定至消费者字段，清除无效的零元止损占位，再重算逐票资格；失败时保留未知及失败原因，不填默认成功。止损以拟买价为基准，新仓退出标T+1，未知底仓不编造可卖数量。
- 缺昨收或技术事实时先检查已绑定研究的实际payload；只有本轮明确授权时才读取其他价格来源，不扩大到数据库或实时行情旁路。不在渲染阶段查询或反推补价。

**价位推导交付内容**：在本轮模型原文的“价位推导”节保留逐票公式(止损/买区/止盈/RR/技术位)及缺数原因；共享表格另从同版 JSON 展示数字。用户仍须看到“为什么是这个价”，但不另写价位推导 MD。

**引擎会自动做的事**(不用 LLM 手工处理):
- RR 资格沿用当前 `apply_to_plan` / `buy_eligibility` 契约：逐票 blocked/unknown 不得新买，不将单票 RR_FAIL 扩成全局禁令；既有全局禁令及合法卖出保持不变。此处不新增或修改资格规则。
- 买区在现价上方 10%+ 自动标 `above_price`（"需上破 x% 站上才成立，不是现在能买"）
- 区间过宽 (>7%) 自动收窄到基准线 ±1.5%
- 一字板自动清空 trigger（无有效买点，等开板）

### 识图与引擎的一致性复核（辅助证据，不改价）

对每只执行候选，在原引擎价位生成后，将本轮已绑定R5中的识图快照副本交给`chart_consistency`复核。按突破位、支撑/止损位及途中压力各自语义比较；只对实际可比项写入`derivation_reason`的“识图确认”及项名、事实日期和限定，不能由一个一致项冒称全部通过。冲突保留双方价位和依据、标记人工复核；缺图、错日、未来输入、后复权、仅文字降级或无可比价均明确unknown。

此复核不改引擎或D1原始买区、触发价、止损、止盈，不改变池身份、预算、评级、资格或执行权限；图像支撑观察位不能自动变成执行止损。原理由完整保留，重复运行只更新本模块自己的复核注记。结构化诊断保存在个股层，不把新的非空诊断键塞入`entry_rules`导致真实执行器误认未知交易条件；规则中的展示只沿用已有`derivation_reason`元信息。识图注记不能充当缺失的手工偏价依据；原依据缺失/空或类型不适用时，保留该缺口，通过个股诊断及本轮正文展示，不为展示制造门禁可接受的价格解释。可同时诊断观察/B计划，但不新增全局禁令。辅助raw读取白名单仍为原三类；识图由已授权主研究R5传递，不另读未绑定的raw/latest、数据库或现场补图。

### Step 5.0 — 正常模型主路径的定稿顺序

1. 完成原有研究、entry/exit、T+1、行情/价位与门禁义务；在本轮工作对象上调用上述 `apply_to_plan`，保留 `price_rows`。模型复核事件/情绪微调、价位偏离与资格结果；若修改价位或对象，重新完成受影响校验后才定稿。
2. 对最终 JSON 完成既有 schema 与业务门禁校验，校验通过才写核心 JSON；不以渲染代替校验，不从表格补算或反推价位。
3. 同一本轮 LLM 自己写完整散文原文，包含原有写作契约、市场→板块→个股判断、逐票价位推导、T+1、风险与不交易条件。不得调用 `render_watchlist_plan_md` 或其他模板替代模型原文，也不另开模型/额外推理轮次改写报告。
4. 由本轮实际生产者先核对原文与最终 JSON 同批且内容一致，再按 Step 7 在唯一主 MD 原位组装共享表格；交付该主 MD，不交付额外 MD。

**禁用**：`scripts/plan/backfill_plan_prices.py` 已废弃，不在当前或历史 JSON 流程调用；缺价位回到本步骤的现有价位研究/引擎，并如实保留缺口，不在展示阶段补造。发现字段遗漏仍在当日 `meta` 留痕；同一字段一周内复发的错题反馈义务保留，交由既有 owner 链路处理，D1 不越权写错题文件。

### Step 5.1 — 同版 JSON 表格复用（必做）

复用 `src.plan.report_assembly.assemble_plan_report_files`，其内部调用既有 `render_plan_tables_md`；展示全局约束、板块、执行/观察池、B 计划、竞价及禁入/资格缺口，不增加判断、价格查询或交易许可。缺字段保持显式缺口，六候选、T+1、风险/持仓/订单上限均不变。

不得将 `render_plan_tables.py --date` 默认 CLI 当主报告组装：默认输出 `_点位表.md`，而直接指定主 MD 也只会写表格、覆盖原文。正确接线见 Step 7。

### Step 5 — entry_rules / exit_rules（D1 独有输出）

对 execution_pool 每只票：

**entry_rules**（偏好 `trading_time_preference.prefer_pullback_over_breakout`）：
- 类型枚举：`trend_pullback_buy` / `leader_breakout`（**禁止** `daban_confirm`）
- 含 `trigger_price`、`buy_zone`、`max_premium_pct`、`position_pct`、`execution_logic`
- 已持仓不加仓 → `entry_rules: []`

**auction_expectation（竞价预期三档 · 2026-09-17 用户钦定 · 每票必填）**：

> 用户要求：预案必须预先定义"集合竞价开出来多少算符合预期、多少算超预期、多少算不及预期，各怎么办"——09:27 竞价数据一到，机械对照执行，不靠盘中临场判断。

```json
"auction_expectation": {
  "base_close": 190.0,                // 昨日收盘
  "expected_open_band": [188.0, 193.0],  // 预期竞价区间(±1.5~2%内), 用昨收×板块强度+人气修正
  "bands": {
    "below_expected":  {"open_pct": "<-1.5%", "action": "低开破位→放弃/竞价后撤单, 不接(除非弱转强模型: 低开快速翻红才参与)", "action_type": "skip_or_weak_to_strong"},
    "in_expected":     {"open_pct": "-1.5%~+2%", "action": "按预案执行: 竞价/开盘按 buy_zone 承接", "action_type": "execute_plan"},
    "above_expected":  {"open_pct": "+2%~+5%", "action": "超预期→竞价强则半路/打板确认, 高开≤max_premium 可追, 超限不追", "action_type": "over_expected_confirm"},
    "far_above":       {"open_pct": ">+5%", "action": "高开过度→不追(兑现风险), 等回踩或放弃", "action_type": "skip"}
  }
}
```

**三档判定规则（写进每票，禁止只写文字不写区间）**：
- `expected_open_band` 必须有**具体数字区间**（不是"高开不追"这种话）——昨收 × (1±板块强度修正)，人气股可 +1~2%
- 20cm 票（300/688）区间按 1.2x 系数放宽
- 每档必须给 `action`（动作）+ `action_type`（枚举，P1 直接映射）
- **涨停价=基准的票**（预判一字）：only 两档——一字（放弃/等回封）vs 未一字（按 buy_zone）
- 预案 md 渲染时输出成表格：`竞价区间 | 判定 | 动作`

**exit_rules**（每只至少 1 条 `stop_loss_break`，`priority=1`）：
- 硬止损：`trigger_price = reference_close × (1 - drop_loss_threshold)`
- 技术破位：`intraday_break_exit`（收盘跌破 MA10）
- 板块降级：`sector_switch_exit` 或条件描述
- R6 `distribution_alert` → `distribution_confirmed` 减仓 50%
- 可选止盈：`take_profit_hit`，`trigger_price = reference_close × 1.15`，`quantity_pct=0.5`

**T+1 可执行性硬规则（无底仓新增仓 · 2026-10-26 用户纠正固化）**：

A 股新买入当天一股都不能卖。给**无底仓、当日新开仓**的票写"当日跌破 X 无条件走"= 不可执行的纸面建议。必须：

1. **先判持仓状态**：有底仓（T+0 可卖）走当日路径；**无底仓新开仓走 T+1 路径**。
2. **T+1 路径的离场规则**：次日集合竞价 `买价×(1-5%)` 挂单走；否则盘中冲 `买价×1.05` 止盈。"无条件走"在 T+1 下唯一合法形态是**下一交易日开盘集合竞价挂单**。
3. **止损价标 `effective_from: "T+1"`** —— 买入当日的离场参考位，不是当日止损。
4. **仓位按尾部风险倒推**：`单票仓位 ≤ 账户风险预算 ÷ 该形态历史 T+1 最差5%盘中亏损`；当天唯一可控的是仓位，不是盘中破位。
5. **历史 base rate 必须与用户处境匹配**：样本链为"昨日涨停 → 今日开盘价买入 → 次日卖出"，用"涨停日收盘价买入"是后验幻觉；分层维度（板制/首板/开板次数/5日涨幅/首封时间/连板高度/竞价强弱）见 `references/t1-exit-feasibility.md`。
6. **交付表格分三档**：可开仓 / 可观察 / 不可做；剔除理由带可复算数字与数据时点。

**配方、pandas 坑位、分层 base rate 模板与自检清单见** `references/t1-exit-feasibility.md`（新增仓位的 T+1 离场与历史 cohort 口径）。

**波段锁仓档 exit_rule（2026-09-05 新增 · 用户方法论）**：

> 用户原话: "对于做主线龙头来说, 其实也本身不太依赖于做T, 这种基本上就是做大波段锁仓的居多"

每只 execution 票按 `hold_style` 选择对应档位（`intraday` / `short` / `wave_main` / `wave_final`）:
- `hold_style=wave_main`(波段锁仓): 调 `@wave_exit_v1`（`src/plan/wave_exit.py::judge_wave_exit`）
  - 输出 4 个卖出信号 + 仓位档（一浪试仓 8% / 二浪加仓 18% / 三浪拉满 25%）
  - 止损 = 跌破20日均线 -12% (波段硬止损)
  - 禁止: 做 T、首阴加仓、跌破 20 日均线还拿
- `hold_style=wave_final`(鱼尾): 持仓 0%, 必清不贪
- `hold_style=short`(短线): 沿用 `-7%~-10%` 硬止损 (现有路径)
- `hold_style=intraday`(日内): T+0 强制平仓

每只 execution 票必须显式标注 `hold_style` 字段, 缺失则默认 `short`(系统 fallback 到短线档)。

**主升三浪映射（hold_style 推导依据）**：
- `mainline_lifecycle` stage=启动 → 一浪 → wave_main (持仓 8%)
- stage=主升早 → 一浪末/二浪初 → wave_main
- stage=主升中 → 二浪/三浪 → wave_main (加仓至 18-25%)
- stage=高潮 → 三浪(高潮前期) → wave_main; 但若 S3/S4 触发 → wave_final
- stage=退潮 → 鱼尾 → wave_final (持仓 0%)

**价格规范（v1.4 · 2026-08-16 新增 · 硬约束）**：
- `reference_close` 是 Python 侧注入的 **T-1 前复权收盘价**，已统一处理复权类型
- **禁止** agent 自行调用任何外部工具获取收盘价
- 所有止损/止盈/买入触发价必须基于 `reference_close` 计算

### 买卖节点合理性带（v1.6 硬约束 · 2026-08-20）

**背景**: 回测发现 33% 的 `take_profit` 设在买入价下方（脏/过期价）、低吸买入价设在中位 -28.6% 深回踩（=抄底非低吸）。D1 输出前必须对每只 execution 票做**节点合理性校验**，越界即判 invalid（剔除出 execution_pool 或标 `node_invalid` 降级 watch）：

使用本轮明确情景的`apply_to_plan` / `price_levels.derive`及`evaluate_stock_buy_eligibility`实际返回，不再运行旧的统一±5%买区带和“止损距离至少5%”伪代码：

1. 调用真实`src.plan.price_levels.validate_nodes(buy_px, stop, take, ref_close, channel=selected_channel, buy_zone=buy_zone, open_price=actual_open_or_None)`；原始`raw_buy_zone/raw_stop_loss`仅在与本情景绑定时传入。止盈必须高于同一情景拟买价；止损必须低于买区下沿，原始和报价舍入后都检验。更紧且有技术依据的止损不因小于5%被拒；报价舍入不等于策略违约。原账户风险预算、原RR门槛和最大损失约束不变。缺开盘价不是开盘检查通过。
2. 突破情景可基于已核前高而非只在昨收±5%；同时独立检查实际买价、最高接受价、已核可交易边界与原追高限制。价格距昨收诊断不替代真实可达性，也不授权追高。
3. 缺必要价格/明确通道、止盈低于拟买、止损几何非法、实际买价RR不达标、一字无成交买点或复牌旧价，保留具体失败并限制该对象；不挪买区、不扩大止损、不强改成-7%凑通过。
4. 低吸不是大跌抄底；按用户强势票预判涨停定义选择剧本，不能只凭距昨收百分比改写买点身份。通过价格几何仍不等于通过必要审核或取得买权。

**验收**：D1 JSON `meta` 须含 `node_invalid_count`；拟取得实际买入资格的执行票须 `node_valid: true`，明确节点失败仍降级。待补证执行候选保留实际未知／未完成状态及禁买，不为留在候选名单而伪写 `node_valid: true`。
**version**: v1.6 (2026-08-20)

- 若 `reference_close` 为 null，该股票必须降级到观察池并标注 `price_source: "missing"`

**version**: v1.7 (2026-10-16) · R6 strong_suggest 个股级闭环

**根因**: R6.M3（估值×主线临界）落盘的 strong_suggest 含个股 ts_code（如 605058.SH 澳弘电子），D1 v1 之前只把 R6.M5/主线级 strong_suggest 当记录参考（`strong_suggests_overridden`），个股级强 suggest 走了 reject 路径（即便票在 R2 候选里也被打掉）。这是 P5 闭环没接上的最后一环。

**变更**:
- `step2_r6_filter` 返回值新增 `strong_suggest_codes: set[str]`（个股级强 suggest 抽到的 ts_code 集合）
- `meta_r6.strong_suggests_accepted[]` 新增字段：每条带 `ts_code / id / suggestion`，便于后续审计
- `build_pools_and_rules` 在 step4_watch_pool 之后，对 watch_pool 里命中 strong_suggest_codes 的票加：
  - `r6_strong_suggest: true`
  - `r6_suggestion: <原始建议文本>`
  - `r6_position_factor: 0.85`（下游渲染/执行按 × 0.85 降仓）
- render_markdown v1.6 渲染的 R6 段已经能展示 `r6_strong_suggest: true` 的票与原文

**验收**（10-16 实跑）:
- watch_pool 4 只
- 命中 R6 strong_suggest 个股：605058.SH 澳弘电子，factor=0.85，suggestion 文本完整保留
- meta_r6.strong_suggests_accepted: 1

**未自动降仓**: D1 v1 仍标 `mode=dry_run`，需用户 review 后手动 flip。算法逻辑就位但执行受 D1_ALGORITHM_V1_IMPLEMENTED=False 守门。

**version**: v1.8 (2026-10-16) · R6 全市场级降仓信号（M5/M1 叠加）

**根因**: v1.7 闭环了 R6.M3 个股级（抽 ts_code → 单票 × 0.85 降仓）。但 R6.M5（马尔科夫 top1 预测偏差）和 R6.M1（数据源冲突）是**全市场级**信号，不针对个股，v1.7 没接。这是更上游的"该不该重仓"问题——比个股级降仓重要。

**变更**:
- `build_pools_and_rules` 末尾新增全市场级降仓逻辑：
  - 规则：`market_wide_factor = 0.7`（M5+M1 命中）、`0.85`（M5 命中）、`1.0`（不命中）
  - 应用：exec_pool/watch_pool 每票的 `base_mobile_ratio = prev × ind_factor(R6.M3) × market_wide_factor(R6.M5/M1)`
  - 写 `meta_r6.market_wide_factor` + `meta_r6.market_wide_signals{M5_hit, M1_strong_hit, rule}` 供 render 展示
- 每票加 3 字段：`base_mobile_ratio`（最终值）、`r6_position_factor`（个股级 1.0 或 0.85）、`market_wide_factor`（全市场级 0.7/0.85/1.0）
- `render_markdown` 显示 D1 v1.8 实算的 `market_wide_factor` + 规则说明

**验收**（10-16 fallback 跑）:
- exec_pool 1 票 base=1.0 mwf=1.0（无 R6 强 suggest）
- watch_pool 4 票：3 票 base=1.0（无 R6 强 suggest），1 票 **605058.SH 澳弘电子 base=0.85 r6_strong=True**（R6.M3 个股级生效）
- meta_r6.market_wide_factor=1.0（10-16 R6.M5/M1 未命中，10-14/15 的 M5 命中样本是设计目标，等生产跑）

**说明**: D1_ALGORITHM_V1_IMPLEMENTED 仍 = False；D1 v1.8 算法本体就位，等用户 review 手动 flip `mode=live`。

**version**: v1.9 (2026-10-17) · R3/R4 结构化整合段（用户钦定"LLM 层结合程序概率 + 新闻做分析"）

**根因**: 用户 2026-10-17 钦定产品方向——程序层算概率（emotion_cycle/node_predict 81% 命中），LLM 层结合 R3 群聊 + R4 新闻做客观分析。但 D1 落盘 meta 没有结构化 R3/R4 段，LLM 拿到也是"自由心证整合"。

**变更**:
- `main_decision.py` 新增 `_r3_r4_integration(trade_date)` 函数：
  - R3: sentiment_score / next_day_signal（verdict+direction+score）/ kol_summary（5 条，清洗 XML）/ resonance_top_themes（5 主题）
  - R4: top_events（10 条含 polarity+strength，清洗 XML）/ first_board_candidates_high（5 条 quality=high）
  - 4 个 LLM 整合提示（verdict_check / policy_catalyst / kol_corroboration / first_board_quality）——程序不算，留给 LLM 端判断
- D1 落盘 meta 新增 `r3_r4_integration` 段（schema_version="r3_r4_integration_v1"）
- render_markdown 新增 "## R3 群聊情绪 + R4 消息面整合" 段
- 微信原始 XML/HTML 清洗（`_clean`：去 `<?xml`、去 `<tag>`、截断补删残 `<`）

**验收**（10-16 fallback 跑）:
- R3: sentiment_score=61, verdict="中性（无明确次日方向信号）", 5 主题（创新药/网络安全/先进封装/AI视频/固态电池）, 5 KOL
- R4: 10 事件（中性/high 主导）, 5 首板高质量（日出东方 hit=4 / 中盐化工 hit=4 / 大晟文化 / 凯撒文化 / 洪田股份）
- LLM 整合任务 4 个 prompt 渲染可见

**设计边界**: 本段**不替 LLM 做判断**，只结构化抽取 + 给 LLM 提示任务。LLM 端 D1 消费 `meta.r3_r4_integration` 做 verdict/policy/kol/first_board 四类整合判断。

可内联推理或参考 `skills/exit_rules_derivation_v1/SKILL.md` 格式，**不委派** exit_rules skill 为独立 Agent。

### Step 6 — 可选二次核验（`_shared/`，不重写逻辑）

仅在 execution_pool 定稿前，对候选票做 last-minute 校验（`docs/01-系统现状全景.md` §1.3）：

| Skill | 场景 |
|-------|------|
| `skills/_shared/hithink-market-query` | 竞价前现价、涨跌停距离、停牌状态 |
| `skills/_shared/iwencai-query` | 硬条件复核（ST、连板高度、板块排名） |
| `@金融监管知识库`（v1.3 · 2026-08-06 新增） | 涨跌停规则合规、停牌/退市风险、跨市场监管差异（A 股/港股/美股/加密） |
| `@缠论形态识别`（v1.3 新增） | 候选票 30 日 K 跑 czsc，输出 `chanlun_signal: BUY1/BUY2/BUY3/SELL1/SELL2/SELL3/NONE`；**只有 BUY3 才加分 +0.03**（最强做多形态，2026-08-05 实测 002460 触三买） |
| `@大宗商品分析`（v1.3 新增） | 候选板块对应大宗商品月度动量检查，输出 `commodity_linkage_score: [-0.05, +0.05]`；与 R5 的 `commodity_linkage` 字段必须一致才有效 |

核验结果仅用于**剔除/降级**，不得用新数据重写 R2/R5 结论。突发公告可用 `news-search` / `announcement-search`（可选）。

### Step 7 — 组装、校验、落盘

1. 正常 LLM 主路径自行裁决，组装完整 `watchlist_plan.json`；先完成 Step 5.0 的价位研究与最终校验。默认仍为 `mode: "dry_run"`、`autonomous_trading_enabled: false`、`requires_user_confirmation: true`，不改变任何原门禁。
2. 对本轮内存中的最终 `plan` 执行 `WatchlistPlan.model_validate(plan)` 及既有业务校验，通过后才按既有原子写入方式发布核心 JSON；失败不写新版本。读回确认为本轮定稿的同一内容，保留最终对象/内容摘要；校验器不能由渲染器替代。
3. 由本轮 LLM 将完整原文（含下文 frontmatter/正文/写作要求与价位公式）写入唯一主 MD；保留原始 UTF-8 字节在本轮上下文或内存以供比对，不强制创建 raw 路径。原文必须尚未含组装 marker。
4. **同批一致性归实际生产者**：以本轮实际使用的研究输入、最终 JSON 对象/摘要和本轮新写原文逐项核对日期、决策来源、候选/维护身份、价位、资格、禁令、T+1 与仓位结论。文件同日、mtime、新文件存在或正文自报 LLM 均不是充分证据。模块不能证明正文与 JSON 同批或语义一致；无法证明时不组装、不宣称完成，报告具体缺口。
5. 确认后显式传入三个路径，允许主 MD 原位原子组装；这是确定性附表，不重新调用模型：

```bash
.venv/bin/python - <<'PY'
from pathlib import Path
from src.plan.report_assembly import assemble_plan_report_files

date = "YYYYMMDD"  # 替换为本轮实际交易日；此前必须已完成上述生产者核对
plan_path = Path(f"data/plans/{date}/watchlist_plan.json")
main_md = Path(f"chzl_kg/投研交易/盘前预案/{date}.md")
assemble_plan_report_files(
    plan_path=plan_path,
    narrative_path=main_md,
    out_path=main_md,
)
PY
```

6. 读回主 MD：比对“模型原文”区段与本轮保留 raw 字节完全一致；附录来自最终 JSON，报告头规范化 `plan_sha256` 与该 JSON 匹配，且 JSON 未被组装改写。该摘要仅证明表格来源，不自认证正文。来源与禁令以 JSON 为准，正文自述不得覆盖 fallback 警报或权限缺口。
7. 模块拒绝已组装正文、JSON 覆盖与输出 symlink。失败保留原文且报 `partial`，不把旧报告当本轮交付；重试不能把已组装报告当 raw，须使用本轮保留的原文，若原文不可得则阻塞而非剥 marker 猜测。不回滚已合法发布的 JSON，也不据此放宽交易权限。

---

## 事故：决策退化为「纯 Python 量价规则版」（2026-09-30 用户打脸 · 必读）

**用户原话**：「我的一个硬性要求应该是要用大模型来做决策呀，怎么能用纯的量价关系的
Python 程序决策呢？那肯定会被骗的呀。」

### 真实事故链（四环，缺一不可）

1. **08:00 D1 LLM cron 每天 404** — `b6a7a8c23050` 未 pin provider，{provider: null}
   飘到已下线的 `https://api.minimaxi.com/anthropic/chat/completions` → 404。
   **实测：2026-09-14 ~ 09-30 每一个交易日均 `max_retries_exhausted / 404`**。
   即大模型主路径**早已全月失效**，只是没人发现。
2. **08:30 安全网落规则兜底** — `ensure_watchlist_plan.py` 只做 python fallback，
   从不重试大模型。
3. **兜底版伪装成正常预案** — 它写 `mode=live` +
   `agent_name="D1-main-decision (main_decision_v1, rule v1)"`，**不暴露"非大模型决策"**。
   用户看到的只是"D1 今天没给票"。
4. **08:30 早于上游落地** — R5(08:33:51)/R6(08:52:36) 尚未落盘，规则版无档位数据
   → 执行池必然为空 → 空池预案一路流到 P1 与 execute。

### 已落地修复（四处）

| # | 位置 | 修复 |
|---|------|------|
| 1 | cron `b6a7a8c23050`/`75bf632522ce`/`757e83acebd7` | `--provider volcengine-agent-plan --model deepseek-v4-flash-ga-260731 --pin`（禁止 provider 漂移） |
| 2 | `ensure_watchlist_plan.py` | **先重试大模型**（hermes CLI fresh context，默认 600s 超时），成功即止；失败才落兜底 |
| 3 | `main_decision.py` | 兜底版强制 `mode="fallback"` + `decision_source="python_fallback"` + `agent_name` 含「PYTHON FALLBACK · 非大模型决策」；加断言 `assert not (fallback and mode=="live")` |
| 4 | `render_markdown.py` | 兜底版 md 顶部 🚨 横幅 + frontmatter `decision_source`，人读一眼可见 |

另加 `_upstream_ready()`：R5/R6 未落盘时**拒绝产预案**（空池规则版比没预案更坏）。

### 排查口诀

**"D1 今天没给票" → 先查是不是大模型根本没跑，而不是先怀疑选股逻辑。**

```bash
# 1. 看决策来源（llm / rule_v1_standalone / python_fallback）
python3 -c "import json;p=json.load(open('data/plans/YYYYMMDD/watchlist_plan.json'));print(p['decision_source'],p['mode'])"
# 2. 看 08:00 主路径是否报错
ls -t ~/.hermes/profiles/canghai-plan/sessions/request_dump_cron_b6a7a8c23050_* | head -3
# 3. 看 D1 日志
cat data/logs/research_shell/YYYYMMDD/D1.log        # 08:00 主路径
cat data/logs/research_shell/YYYYMMDD/D1_llm_retry.log  # 安全网重跑
```

### 兜底产物与 LLM 日志结论不一致时（新增）

同一个交易日可能同时存在两份结论：`data/plans/YYYYMMDD/watchlist_plan.json`（落盘产物） 与 `data/logs/research_shell/YYYYMMDD/D1.log`（LLM 主路径自述）。两者可以差一只票、差一个数量级的仓位——因为落盘的可能是安全网在 LLM 重试失败后生成的规则兜底版，而日志里留着 LLM 跑完闸门后的更严结论。

**规则**：下游（用户阅读、P1 校准、盘中执行、E1 复盘）消费前必须比对两者：

- 落盘产物 `decision_source == "python_fallback"` → 不是大模型裁决，只能当量价底线，回复时必须先声明，不得包装成「今日预案推荐」。
- 两者不一致 → **取更严的一版**（纪律先于叙事），并在输出中点出分歧与依据（例：兜底版 2 只 cap 60%，LLM 版闸门实跑后 1 只敞口 6% → 按 1 只 6%）。
- `D1_llm_retry.log` 里的 provider 失败码要区分：**403 = 账户余额逾期/额度耗尽**（需用户充值，改模型无用），404 = 端点漂移（改 provider/model 即可），超时 = 上游慢。排查口诀里的 404 那一支不适用于 403。

### 铁律

- **大模型是唯一决策者**；`d1_algorithm.py` 只能兜底占位，且必须**显眼自曝**。
- **agent 型 cron 必须 pin provider+model**，否则 provider 漂移到死端点会静默失败
  （drift 不报错、不告警，只是每天 404）。
- 预案里的 `decision_source` 字段是「今天谁做的决策」的唯一真相源，下游与 E1 都应消费它。

## Output Schema 要点

顶级字段必须齐全（详见 `docs/11-契约-盘前预案.md`）：

```json
{
  "schema_version": "watchlist_plan_v1",
  "trade_date": "YYYYMMDD",
  "mode": "dry_run",
  "agent_name": "D1-main-decision (main_decision_v1)",
  "generated_at": "ISO8601+08:00",
  "trading_style": "mainline_right_side_with_trend_pullback",
  "autonomous_trading_enabled": false,
  "requires_user_confirmation": true,
  "data_sources": { "...": "research_summary + fetch_manifest 审计" },
  "market_context": { "structure": "一句话结论", "...": "..." },
  "risk_limits": {
    "target_total_position_pct": 0.75,
    "max_positions": 5,
    "block_prefixes": [],  // 2026-08-06 起 300/688/920 全解禁(用户确认 QMT 端已可交易)
    "block_st": true
  },
  "execution_pool": [ "最多6个有来源的优先新机会候选，逐票区分待补证／暂不开仓与已具资格；另保留不占新机会容量的持仓维护／退出条目，不增加买权" ],
  "watch_pool": [ "StockEntry × 15-25" ],
  "rejected": [],
  "meta": {
    "position_cap_pct": 0.75,
    "position_cap_source": "R1-style",
    "r6_devil_advocate": {
      "hard_rejects_applied": [],
      "strong_suggests_accepted": [],
      "strong_suggests_overridden": [{ "id": "", "reason": "" }],
      "soft_notes": []
    }
  }
}
```

**StockEntry 枚举**（错一字校验失败）：
- `role`: `leader` / `core_midcap` / `core_largecap` / `elastic_core` / `watch_elastic` / `watch`
- `plan_status`: `execution_pool_hold` / `execution_pool_hold_add_on_pullback` / `watch_pool_only` / …
- `entry_rules[].type`: `trend_pullback_buy` / `leader_breakout`
- `exit_rules[].type`: `stop_loss_break` / `take_profit_hit` / `intraday_break_exit` / …
- `ts_code` 必须带后缀 `.SZ` / `.SH`；仓位为小数（0.14 = 14%）
- **`t1_game_analysis`**（v1.7 · 2026-09-04 新增 · 每只 execution 票必填，pydantic `extra=allow` 兼容）：`消息解读` / `预期差判断` / `买点结论` / `短线结构标签`——见 Step 4.5。缺失则该票不得进 execution_pool。

---

## 模型原文内容示意（正常主路径自行写完整正文，不由模板生成）

```markdown
---
date: YYYY-MM-DD
agent: D1-main-decision
generated_at: ...
position_cap: 0.70
execution_count: N
watch_count: M
mode: dry_run
---

# YYYYMMDD 盘前预案

## 一句话结论
风格 + 仓位上限 + 执行/观察数量 + R6 反证摘要

## 执行池(N 只)
### 1. 名称 ts_code(题材)
- **plan_status**: `...`
- **理由**: ...
- **stop_loss** / **take_profit**
- **entry_rules** / **exit_rules** 条数

## 观察池(M 只)
- ts_code 名称 — 理由

## R6 反证采纳
- hard_rejects / strong_suggest 记录
```

---

## Rules & Constraints（红线）

| # | 规则 |
|---|------|
| 1 | **fresh context**：只读 artifact，禁止携带 R1–R7 中间推理 |
| 2 | **禁止 override** R6 `hard_reject` |
| 3 | 新机会展示按Step 3第6项区分执行候选与实际买权；最多6个、不凑票，禁新不清候选或条件价位；实际新买仍须全部原门禁、预算和授权，持仓／订单／仓位约束不变 |
| 4 | 单票 `max_position_pct` ≤ 0.15；单板块 ≤ 0.40；总仓 ≤ position_cap |
| 5 | 观察数量按 Step 4 的真实覆盖记录，原范围是目标不是最低资格；不足或空池必须有覆盖/淘汰/缺口证据，不为凑数绕否决 |
| 6 | 每只 execution 须有完整 `entry_rules` + `exit_rules`（至少 1 条 `stop_loss_break`） |
| 7 | R6 `strong_suggest` 覆盖须写 `meta.r6_devil_advocate.strong_suggests_overridden[].reason` |
| 8 | `mode` 默认 `dry_run`；用户显式 flip 后才改 `live` |
| 9 | pydantic 校验失败 → **不写新文件**，告警用户 |
| 10 | **禁止**以 `d1_algorithm.py` / `main_decision.py` 为主路径 |

---

## 降级路径

| 上游状态 | D1 应对 |
|---------|---------|
| R1 死/骨架 | 默认震荡分化，`position_cap=0.50` |
| R2 死 | **拒绝出 plan** |
| R3/R4 死 | 忽略情绪/消息维度 |
| R5 死 | alpha/risk 默认 B，保守筛选 |
| R6 死 | 无反证，按最严风控 |
| `fetch_global_severity=3` | `mode=dry_run`，`autonomous_trading_enabled=false` |
| research_summary 缺失/过期 | 中止，不写 plan |

---

## mode 切换（用户 flip）

当前 T1' 批次 **`mode` 恒为 `dry_run`**。用户 review KG 主 MD 满意后，手动将 JSON 内：

```json
"mode": "live",
"autonomous_trading_enabled": true,
"requires_user_confirmation": false
```

或由用户在对话中明确指令「今日 plan 切 live」。LLM **不得**自行切 live。

---

## 对照路径（非主路径，仅供 diff / fallback）

```bash
# 规则版 fallback（显式 opt-in；Hermes 主路径 skill: main_decision_v1）
source .venv/bin/activate
python3 scripts/plan/run_main_decision.py --date YYYYMMDD --fallback
# 或: CHZL_HERMES_FALLBACK=1 python3 scripts/plan/run_main_decision.py --date YYYYMMDD
# 产出: data/plans/YYYYMMDD/watchlist_plan.json（mode 仍 dry_run）
```

---

## Data Sources

### 退潮次日不空仓等死 (2026-09-29)

当 T-1 判退潮、次日定为空仓/极轻仓时，D1 预案必须写明：次日是否翻多由 `retreat_reversal_detection_v1` 盘中右侧判定（核心二证：广度≥0.55+昨涨停红盘率≥0.6，命中率90%；10:00-11:40每20分钟自动跑），确认后仓位 30%→45%。近一年31个退潮日 61% 次日翻多，竞价时点无法预判，只能盘中确认。

无独立数据源。纯 pull + 综合裁决；可选 `_shared` 二次核验（§ Step 6）。

### 数据源审计铁律 (2026-09-29)

报告里的"源不可用"必须区分三态，不得把调用失败写成源故障：`call_failed`（会话内失败/超时→重试或探针，不定性）、`not_yet_landed`（并行兄弟节点当时未落盘，只记时点不写 unavailable）、`source_down`（探针实测 HTTP 错误/连接拒绝才可定性）。高频误用：两融明细 T-1 盘前常已发布（0929 实测 0928 可用却误报 0924）、hithink 问财 OpenAPI（实测可用）。流水线收尾走 `scripts/research/reconcile_pipeline_status.py --patch-md`。

---

## Version History

| 版本 | 日期 | 说明 |
|------|------|------|
| v1 | 2026-07-04 | 骨架建立，pull-based 消费 research_summary |
| v1 P0 | 2026-07-05 | T1' parallel track D：fresh context LLM 主路径 prompt 结构冻结；`plan.md` 双份 md；默认 dry_run；禁止 d1_algorithm 主路径 |
| v2.0 | 2026-11-01 | 此前新增的相对强度、热度和最高标机械门槛已撤销；保留事实时点与交叉观察。 |

---

## chzl_kg 人读 md 落盘（必需 · @render_kg_md_v1）

**契约来源**: `skills/_shared/render_kg_md_v1/SKILL.md`

除机读 JSON 落盘之外，本 skill 必须**同时**渲染一份人读 md 到 chzl_kg 供用户当日审阅。

### 落盘路径

```
chzl_kg/投研交易/盘前预案/{trade_date}.md
```

（目录若不存在，`mkdir -p` 创建。）

### 模型原文 frontmatter（必填，UTF-8 · Unix 换行）

以下完整元数据由本轮模型原文携带，组装后保留在“模型原文”区段；不要求模块重建或提升为外层字段。外层 frontmatter 沿用组装器的 date/decision_source/assembly_kind/plan_sha256 来源信息，以 JSON 为准。

```yaml
---
date: {trade_date YYYY-MM-DD}
agent: D1-main-decision
skill_version: main_decision_v1@1.0
generated_at: {ISO 8601 · 落盘时刻 · 含时区}
confidence: {从本 skill JSON artifact 读；缺则 null}
degraded: {true|false}
data_sources:
  - name: {源标识}
    path: {data/raw/... 或 MCP 名}
    status: {ok|error|timeout|stale}
    captured_at: {ISO 8601 或 null}
    record_count: {整数或 null}
    error: {可选 · 简短错误串}
input_freshness: {ok|partial|stale}
input_freshness_note: {任一源非 ok 时必填的说明}
---
```

### 正文（Markdown）

```markdown
# {trade_date 中文日期} · **主决策 / D1 盘前预案**

> **数据源新鲜度**: {input_freshness}
> **降级状态**: {degraded}
> **置信度**: {confidence}

## 一句话结论
{≤ 60 字核心判断}

## 详细分析
{3-5 段主体}

## 关键证据
- 证据 1: {内容} · 来源 {data_source}
- 证据 2: ...
- 证据 3: ...

## 数据源审计
| 源 | 状态 | 抓取时间 | 记录数 | 备注 |
|---|---|---|---|---|
...

## 不确定性 / 反证
{自我批判段}

## 与其他 R/D/E 的关系
- 依赖: {上游 artifact 列表}
- 被消费: {下游 skill 列表}

## Sub-Agent 元数据
- skill: main_decision_v1
- artifact: data/.../{...}.json
- 生成耗时: N 秒
- model: {model 名}
```

### 落盘规则

1. **atomic write**: 先写 `.tmp` → `mv` 到目标（避免 Obsidian 抓半写）
2. **overwrite**：只覆盖本身份允许的主 MD，不自动新增 `.md.bak` 或 raw 伴随文件；同日重跑仍须证明本轮原文与 JSON 的对应关系，按 Step 7 保留 raw 并核对。
3. **失败不阻塞**: md 渲染失败**不**回滚 JSON artifact 落盘；skill status 写 `partial` 并在汇报中标注

### 验收

主 MD 存在只是必要条件：按 Step 7 读回核对完整 raw 字节、JSON 未变、外层规范化摘要与共享表格；原文区段仍须满足本节完整 frontmatter 与正文要求，不能只检查文件存在或前 30 行。

---

## 写作契约(v1 · 2026-07-06 硬约束升级)

本 skill 输出的 md **必须**遵循 `skills/_shared/canghai_writing_contract_v1.md`,该契约定义了:

1. **写作风格锚点** — 对标 `样例/20260630_pre_open_plan.md`,表格化 + emoji + 因果句 · 禁 python dump JSON / 群名裸露 / 时分秒
2. **必含 mermaid 图表**(≥1 张 · 节点 ≥ 8) — 本 skill 推荐类型见契约
3. **推理深度三问** — 每个 top 分析对象显式回答 `**大资金意图**` / `**为什么走强**` / `**逻辑够不够硬**`
4. **每票思维链**(≥4 段) — 首推票必附 `**买入理由**` / `**风险点**` / `**止损条件**` / `**可验证假设**`
5. **数据源审计表** — 三色 emoji · 日期无时分秒 · 群名匿名化 · 主源缺失即 degraded=true

**验收硬门槛**: md 落盘后逐条自检契约第六节六项,任一缺失即 skill 状态 `partial`,视为执行失败须重跑。

## Version History (writing contract)

- v1 (2026-07-06): 加入沧海写作契约 · 覆盖 R1-R7 + D1
- v1.2 (2026-08-07): D1 LLM 增强 — 仓位上限推导 + T+1 三档候选 + 不交易条件

---

## v1.2 新增 · 盘前预案过薄修复（P1-2 修复）

**问题根因**: 2026-08-05/06 实盘跑中,D1 输出的 `plan.md` 仅列 execution_pool 5 只票 + 简单 stop_loss,**没有**:
1. 仓位上限是怎么从 R1 风格 + R7 资金推出来的(用户看不到推导链,只能信)
2. T+1 候选(开仓/加仓/止损三档) → 次日 / T+1 行为没有预判
3. 不交易条件 → 何时**完全不开仓**(虽 R1 给的是 0.6 cap,但 D1 仍可输出"全平"决定),无明确红线

**v1.2 D1 LLM 增强契约**(硬约束,新增到 §Step 7 之前):

### 1. 仓位上限推导链(`position_cap_derivation`)

**北向仅复盘参考**：盘前／盘中不得因北向缺失、延迟或净额语义未核验，触发R7整体失效、全局禁新、置信度归零或仓位加减。北向不参与置信度分子或分母，未知不填0或neutral。此规则不等于其他资金证据已通过；必须由R7按新边界重新评价适用证据，不自行重解释旧产物的unavailable、不恢复旧pre_override分数。R1、R6、逐票交易条件及有效零预算保持，不因去掉北向生成买权。

`watchlist_plan.json` 顶层新增字段(替代直接写死的 `position_cap_pct`):

```json
{
  "position_cap_derivation": {
    "r1_style_signal": "震荡分化",
    "r1_raw_cap": 0.60,
    "r7_northbound_strength": null,        // not_required；仅复盘参考，不判neutral
    "r7_cap_adjustment": 0.0,              // 北向不参与机械改仓；此0不是未知资金评分补零
    "r1_sentiment_score": 75,              // 来自 R1
    "emotion_cycle_phase": "贪婪",          // 来自 Step 0.5
    "emotion_cap_override": 0.60,          // 情绪联动:贪婪 → 顶格 0.60
    "r2_main_lines_count": 2,
    "main_lines_cap_multiplier": 1.0,      // 1 main=0.8, 2 main=1.0, 3 main=1.1
    "final_position_cap_pct": 0.60,
    "derivation_formula": "min(r1_raw=0.60, r7_adj=0.60, emotion_override=0.60) × main_lines_mult=1.0 = 0.60",
    "derivation_confidence": 0.85
  }
}
```

**公式**:
```
raw_cap = R1 风格给出的 cap
r7_adj = raw_cap + r7_cap_adjustment
emotion_override = 本轮LLM依据实际市场与风险提出的建议，不因极恐自动设正下限
main_mult = {1: 0.8, 2: 1.0, 3: 1.1}.get(main_lines_count, 0.7)  # 旧参考，非自动买权
final = min(raw_cap, r7_adj, emotion_override) * main_mult
market_final = min(final, 已签用户硬上限)  # 不读取/扣减真实或模拟持仓、余额；无机械正仓位下限
# 本轮LLM将市场总仓及初始试探建议写入market_position_advice，逐票建议写suggested_position_pct。
# 实际账户额度及已有敞口仅在独立执行链核验，不反向归零建议；不将market_final回填或替代执行预算/许可。
# 缺市场判断保持null，缺执行预算保持未知与原执行保护；旧市场零建议可按当日新证据重评。
```

### 2. T+1 候选三档(`t1_candidates`)

`watchlist_plan.json` 顶层新增字段,结构:

```json
{
  "t1_candidates": {
    "open_position": [                     // T+1 计划开仓
      {
        "ts_code": "002050.SZ",
        "name": "三花智控",
        "trigger": "板块高开 < 2% 且龙头未封板",
        "entry_zone": [38.5, 39.2],
        "stop_loss": 36.5,
        "position_pct": 0.12,
        "rationale": "R2 leaders 龙一, R3 L1+L2 共振, R4 催化持续; T+1 关注分歧低吸"
      }
    ],
    "add_on_pullback": [                   // T+1 已持仓的加仓窗口
      {
        "ts_code": "688981.SH",
        "name": "中芯国际",
        "pullback_trigger": "回踩 5 日线且缩量",
        "add_size_pct": 0.05,
        "max_add_position": 0.20,
        "rationale": "T+0 已建底仓 0.10, 板块共振强, T+1 分歧给加仓机会"
      }
    ],
    "stop_loss_only": [                    // T+1 仅观察,触发即止损
      {
        "ts_code": "300442.SZ",
        "name": "润泽科技",
        "stop_loss_trigger": "破 20 日线 OR 板块跌出 top10",
        "stop_loss_price": 28.0,
        "current_position": 0.08,
        "rationale": "R6 distribution_alert 弱化,持仓谨慎"
      }
    ]
  }
}
```

**约束**:
- `open_position` 总和 ≤ `final_position_cap_pct × 0.5`(留一半加仓空间)
- `add_on_pullback` 每只 `add_size_pct` ≤ 0.05
- `stop_loss_only`仅在已核存在持仓及合法退出资料时列出；未读账户或确无已知持仓时明确未知/不适用，不编造持仓，不把空的持仓退出列表变成全局不开新仓。

### 3. 不交易条件(`no_trade_conditions`)

`watchlist_plan.json`须保留有来源、对象及有效窗口的限制。只有实际生效的全局硬限制才触发全局不开仓；逐票必要缺证与硬否决只限制目标对象，资料质量/辅助覆盖诊断留在meta或data_sources，不伪装为active全局禁令。下列历史code须按来源重新判断，不能按名称自动激活：

```json
{
  "no_trade_conditions": [
    {
      "code": "R1_FAIL",
      "description": "R1资料质量不足的诊断；不凭confidence低于0.4独立禁止全市场开仓",
      "active": false
    },
    {
      "code": "R6_HARD_REJECT_OVERFLOW",
      "description": "逐项保留真实hard_reject及目标；数量占比不独立证明全市场存在系统风险",
      "active": false
    },
    {
      "code": "R7_STALE",
      "description": "保留适用资金证据缺口与目标；可用可靠替代证据须核实际时点，必要资金事实未核仅限制相关对象，北向缺口不全局禁买",
      "active": false
    },
    {
      "code": "GLOBAL_SEVERITY_3",
      "description": "fetch_global_severity >= 3 → 不开仓(数据基础设施异常)",
      "active": false
    },
    {
      "code": "EMOTION_EXTREME_GREED",
      "description": "emotion_cycle.phase = 贪婪/狂热 AND main_lines_count = 0 → 不开仓(无主线 + 情绪过热)",
      "active": false
    },
    {
      "code": "USER_HOLIDAY",
      "description": "用户标记 holiday/出行 → 不开仓(可人工 override)",
      "active": false
    }
  ]
}
```

**硬约束**:
- `no_trade_conditions` 必须存在(即使全部 `active: false`)
- 真实生效的全局硬限制使全局no_trade保持true，并保持dry_run、禁自主及人工确认；scope为stock/symbol的必要缺证或硬限制必须指明ts_code，只限制对应对象。辅助缺项不得借active字段偷变全局硬禁。用户/账户预算及未知来源保护保留，不因更激进取消。**不据此强制 `execution_pool: []` 或整池 `entry_rules: []`**。按Step 3第6项列有真实依据的优先执行候选，标“执行候选·待补证／暂不开仓”，并继续交付观察／B计划的条件买卖价位。所有未获授权对象保持 `auto_trade_enabled: false`、`requires_user_confirmation: true`、`max_position_pct: 0`、`entry_rules[].position_pct: 0`；如有 `trade_authorized` 字段须为false。真实逐票否决及未完成审核原样保留，数值RR通过不能冒充全部资格通过；无合法来源时允许空池并说明覆盖与缺口。`mode` 只表示执行环境，不新增枚举；不得删禁令或抬预算求交付。P1/P2及执行端不得凭候选身份、价位或promote自动解禁，实际新买仍须有权限owner独立复核全部原门禁。
- KG 主 MD 原文**必须**在顶部展示"不交易条件清单 + 当前 active 项"(便于用户 review)

**降级**:
- R1/R7缺失时逐项核仍可用的同版市场/资金证据，说明必要判断是否真的不能完成；不得自动激活所有不交易条件。
- 缺一个provider、辅助维度或某票审核不完整，不扩为所有票不可交易；所有必要依据确实均不可得时如实保留未就绪，不制造通过。
- 无来源的旧限制不能按名称擅删，应交合法owner核来源、有效窗口及替代依据；已核市场性旧判断按本节当日重评，不永续继承。

### Step 2.7 — 跷跷板强对冲减仓（2026-09-06 周末会议纪要落地）

> 用户原话: "银行保险等大金融板块的上涨会抽血科技股, 形成'二选一'的格局"

调用 `@detect_seesaw_pairs_v1`（R7 子能力, `skills/_archive/detect_seesaw_pairs_v1/`）：
- 20 日相关 < -0.6 + 5 日方向反转 → 跷跷板对
- 主线对冲强度 > 0.7 → `position_cap_derivation.seesaw_penalty` 启用, cap ×0.5
- 主线对冲强度 > 0.5 → cap ×0.75
- 主线对冲强度 ≤ 0.3 → 不减仓

**写盘位置**: `position_cap_derivation.seesaw_penalty` 字段:
```json
{
  "position_cap_derivation": {
    "base_cap": 0.65,
    "seesaw_penalty": {"ratio": 0.5, "counter_sector": "大金融", "correlation": -0.78, "applied": true}
  }
}
```

### Step 4.6 — 预期差维度(2026-09-06 周末会议纪要落地)

> 用户原话: "周末发酵热点集中在银行与大科技, 农业板块存在预期差, 若板块走强, 建议推仓位参与"

调用 `@expectation_diff_v1`（`src/research/expectation_diff.py::judge_expectation_diff`）：
- 输入: `weekend_hot_topics`(从 R4 周末消息)+ `current_mainlines`(从 R2)
- 输出 `expectation_diff.level` ∈ {vacuum, aligned, diverging, contrarian}
- `level=diverging`(预期差向上) → 主线优先级 +1, 仓位上浮 10%
- `level=aligned`(共识已 priced in) → 不加仓, 持仓待涨
- `level=vacuum`(发酵真空) → 不押注
- 写盘: `expectation_diff` 字段在 `meta` 下

### Step 4.7 — 一字板预判(2026-09-06 用户方法论 · 盘前 09:00 用)

> 用户原话: "我有快速交易通道, 一字板本身没风险(9:20 前大单撤单可撤)。只顶首板/二板一字。三板+不用系统讲, 风险太大。"

调用 `@yizi_predictor_v1`（`src/research/yizi_predictor.py::predict_yizi_candidates`）：
- 输入: R4 top_events + R2 main_lines
- 核心因子（按权重排序）:
  1. 事件强度 high/medium/low（权重最大）
  2. 事件源数（多源交叉验证）
  3. 板块主流强度（R2 score）
  4. 个股业务相关度（top_pick_logic.business_relevance）
  5. 板数加权（首板 > 二板）
- 输出：本轮预测结果保留在盘前预案原文“一字板预判”节；预测与人工审阅义务不变，不由 D1 另写超出 Ownership 的 `chzl_kg/投研交易/一字板预判/YYYYMMDD.json`。若其他消费者确需独立 artifact，报告归属/授权缺口，不自行扩大写白名单。

**硬约束**（防止过拟合到特定场景）:
- ❌ **不硬编码**任何具体标的/板块名
- ❌ **不预判三板+**（用户不顶，系统跳过）
- ❌ **不自动下单**（只生成提示，用户快速通道顶单）
- ✅ **写盘后用户人工 review**，可顶可不顶

**板数过滤逻辑**:
- `board_stage=首板` → 候选保留，rank=重点关注
- `board_stage=二板` → 候选保留，rank=建议关注
- `board_stage=三板+` → 系统跳过（用户自行判断）

**预期效果**:
- 09:25 集合竞价前盘前预案输出"一字板候选 Top 10"
- 用户可在 09:25 第一时间用快速通道顶单
- 09:20-09:25 之间大单撤单可跟撤（低风险）

**验收**:
- 交付验收分别核对：三个结构化字段存在、仓位推导非空；禁新时全局限制和逐票零新增权限完整、真实买入边界仍拒绝；执行／观察／B计划中的可推演对象有同版数字价位，例外逐票明确。不得把执行池必须为空当作禁新的验收目标；旧完整性检查若仍强制清池，应报告消费者契约冲突并另行修复，不能删除禁令或伪报通过。
- 缺任一字段 → orchestrator 标 D1 失败

---

## Version History

| 版本 | 日期 | 说明 |
|------|------|------|
| v1 | 2026-07-04 | 骨架建立 |
| v1.1 (T1' parallel track D) | 2026-07-05 | fresh context LLM 主路径 + default dry_run + 禁 d1_algorithm 主路径 |
| v1.3 (Step 0.5) | 2026-08-06 | 宏观+情绪+行为金融 周期定位 |
| v1.10 | 2026-10-21 | 硬价位完整性(执行/观察/B计划必须带数字买区) + 点位表版渲染(render_plan_tables.py) |
| v1.2 (P1-2 修复) | 2026-08-07 | position_cap_derivation + t1_candidates 三档 + no_trade_conditions 硬约束 |
