"""
forbidden_filter.py · 禁止清单过滤器 (2026-09-04 · 游资交易纪律落地)

心法依据（新生代游资交易纪律.md §3 禁止清单 14 项）:

  1. mid_laggard          - 中位股/杂毛/没地位的弱转强
  2. non_mainstream       - 已有既定主流时去看非主流(光神: 等于犯罪)
  3. opposite_of_strongest - 最强板块的对立面
  4. cold_heavy           - 非主流冷门当低风险重仓
  5. counter_emotion_turn - 情绪差时抓小转折点逆情绪
  6. buy_after_fade       - 确认退潮后还买
  7. cross_high_climax    - 博弈穿越高潮
  8. down_trend_break     - 下降趋势板、无板块效应秒拉板
  9. late_speculation     - 14:00-14:30 后投机点火板
 10. plan_outside_scan    - 计划外扫板/广撒网
 11. overnight_bad_streak - 手风不顺还隔夜赌反转
 12. cover_with_t         - 用 T 或补仓掩盖看错
 13. all_in_learning      - 梭哈(学习期禁止)
 14. mixed_template       - 纯图形/庄票 与 总龙锁仓 同天混用
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any


@dataclass
class ForbiddenCheckResult:
    ts_code: str
    trade_date: str
    is_allowed: bool           # True=通过, False=被禁止清单拦截
    hit_rules: list = field(default_factory=list)  # 命中的禁止项 code
    hit_details: list = field(default_factory=list)  # 命中的详细原因
    evidence: list = field(default_factory=list)
    generated_at: str = ""
    phase: str = "execution"
    context_diagnostics: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def check_forbidden(
    ts_code: str,
    trade_date: str,
    *,
    # 标的基础信息
    sector_rank: int,                    # 板块内排名 (1=龙头, 2=龙二, ≥3=杂毛/中位)
    sector_size: int = 30,
    has_mainline: bool = True,           # 当日是否有明确主线/主流板块
    mainline_sectors: list = None,       # 主流板块列表
    current_sector: str = "",            # 当前票所在板块
    is_downtrend: bool = False,          # 下降趋势
    has_sector_effect: bool = True,      # 有板块效应(板块前排有跟涨)
    # 板型/时间
    first_time_hhmmss: str = "100000",   # 首次封板时间
    open_times: int = 0,
    # 情绪/阶段
    emotion_phase: str = "high_chop",   # low_test/main_up/high_chop/main_down
    # 操作状态
    in_plan: bool = False,               # 执行须显式证明在已发布计划内
    phase: str = "execution",           # research / plan_formation / execution
    is_overnight: bool = False,          # 隔夜持有
    recent_losing_streak: int = 0,        # 连续亏损天数
    position_pct: float = 0.05,           # 当前仓位
    capital_total_pct: float = 0.30,     # 总仓占比
    # 模式
    template_a: bool = False,            # 首板隔日(北京炒家)
    template_b: bool = False,            # 总龙锁仓(陈小群)
) -> ForbiddenCheckResult:
    """
    分阶段检查禁止清单。默认执行阶段，缺少明确在计划内的证据则拒绝。

    research/plan_formation 是提名/形成计划，不要求已存在旧计划；
    跳过 plan_outside_scan；纯阶段温度、行业名称对立、模板并用推断
    保留为 context_diagnostics，供本轮证据复核，不作对象级硬否决。
    其余真实风险照查。默认execution保持原保护。is_allowed 只是本
    阶段硬检查结论，不授予执行、预算或交易权限。阶段错误不回退。
    """
    if phase not in ("research", "plan_formation", "execution"):
        raise ValueError(f"unsupported forbidden-check phase: {phase!r}")
    mainline_sectors = mainline_sectors or []
    hits: list[str] = []
    details: list[str] = []
    evidence: list[str] = []
    context_diagnostics: list[dict[str, Any]] = []

    def context_rule(code: str, detail: str) -> None:
        if phase == "execution":
            hits.append(code)
            details.append(detail)
        else:
            context_diagnostics.append({"code": code, "detail": detail,
                                        "effect": "context_only",
                                        "requires_evidence_review": True})

    # 1. mid_laggard: 板块内排名 ≥3 + 非龙头
    if sector_rank >= 3 and sector_rank > 2:
        hits.append("mid_laggard")
        details.append(f"板块内排名{ sector_rank }(杂毛/中位), 不碰")
    elif sector_rank > sector_size * 0.5:
        hits.append("mid_laggard")
        details.append(f"板块内排名后50%({ sector_rank }/{ sector_size })")

    # 2. non_mainstream: 有主线时, 当前板块不是主线
    if has_mainline and current_sector and mainline_sectors and current_sector not in mainline_sectors:
        hits.append("non_mainstream")
        details.append(f"有主流{ mainline_sectors }, 但本票板块'{ current_sector }'非主流(光神: 等于犯罪)")

    # 3. opposite_of_strongest: 在最强板块的对立面
    if has_mainline and current_sector:
        # 简化: 行业相反(如科技强时进钢铁/煤炭/银行)
        opposites = {"科技": ["钢铁", "煤炭", "银行"], "消费": ["钢铁", "煤炭"], "新能源": ["银行", "石油"], "医药": ["钢铁"]}
        for main, opps in opposites.items():
            if main in str(mainline_sectors) and current_sector in opps:
                context_rule("opposite_of_strongest",
                             f"主线'{ main }'但本票板块'{ current_sector }'按旧行业名称映射为反向，需当轮证据复核")
                break

    # 4. cold_heavy: 非主流冷门重仓
    if not has_mainline and position_pct >= 0.10:
        hits.append("cold_heavy")
        details.append(f"无主流时重仓({ position_pct:.0%}), 应小仓试错")

    # 5. counter_emotion_turn: 情绪差时抓小转折
    if emotion_phase in ("main_down", "low_test") and position_pct >= 0.05:
        context_rule("counter_emotion_turn",
                     f"情绪阶段={ emotion_phase }(情绪差), 仍开仓{ position_pct:.0%} ≥ 5% 偏重")

    # 6. buy_after_fade: 退潮后还买
    if emotion_phase == "main_down" and position_pct > 0:
        context_rule("buy_after_fade", "阶段标签为主跌期，是否已确认退潮须按当轮市场证据复核")

    # 7. cross_high_climax: 博弈穿越高潮
    if emotion_phase == "climax" and position_pct >= 0.10:
        context_rule("cross_high_climax",
                     f"高潮分歧期, 仓位{position_pct:.0%}≥10%, 容易接最后一棒")

    # 8. down_trend_break: 下降趋势 + 无板块效应
    if is_downtrend and not has_sector_effect:
        hits.append("down_trend_break")
        details.append("下降趋势 + 无板块效应(北京炒家: 下降趋势板+无板块效应=大面)")

    # 9. late_speculation: 14:00 后点火板
    if first_time_hhmmss and first_time_hhmmss.isdigit() and len(first_time_hhmmss) == 6:
        ft = int(first_time_hhmmss)
        if ft >= 140000 and ft < 143000:
            hits.append("late_speculation")
            details.append(f"首次封板{ first_time_hhmmss }在14:00-14:30, 投机板风险大")
        elif ft >= 143000:
            hits.append("late_speculation")
            details.append(f"首次封板{ first_time_hhmmss }在14:30+, 北京炒家几乎不碰")

    # 10. plan_outside_scan: 计划外扫板
    if phase == "execution" and in_plan is not True:
        hits.append("plan_outside_scan")
        details.append("不在盘前计划单内(光神: 计划外不出手)")

    # 11. overnight_bad_streak: 手风不顺还隔夜
    if recent_losing_streak >= 2 and is_overnight and position_pct >= 0.05:
        hits.append("overnight_bad_streak")
        details.append(f"手风不顺(连亏{ recent_losing_streak }天)还隔夜仓位{ position_pct:.0%}≥5%")

    # 12. cover_with_t: T 仓掩盖看错 (需 t 交易记录, 简化: 同票连续加仓)
    # 注: 严格需要 t 交易日志, 此处留为接口, 由调用方传 is_covering_with_t
    # 不在此处判断

    # 13. all_in_learning: 梭哈
    if position_pct >= 0.30:
        hits.append("all_in_learning")
        details.append(f"单票仓位{ position_pct:.0%}≥30% = 梭哈(纪律禁止)")

    # 14. mixed_template: 首板模板 + 总龙锁仓 模板同日混用
    if template_a and template_b:
        context_rule("mixed_template", "同日存在'首板隔日'与'总龙锁仓'模板，须逐对象核对适用情景")

    is_allowed = len(hits) == 0

    if is_allowed:
        evidence.append(f"✅ 通过本阶段禁止清单检查(phase={phase})；不构成交易授权")
    else:
        evidence.append(f"❌ 命中{ len(hits) }项禁止: {hits}")

    evidence.append("计划内身份已检查" if phase == "execution"
                    else "研究提名/计划形成阶段：未校验已发布计划身份，执行仍须独立复核")
    if context_diagnostics:
        evidence.append(f"保留{len(context_diagnostics)}项上下文诊断，非硬失败，须LLM结合本轮证据取舍")
    return ForbiddenCheckResult(
        ts_code=ts_code,
        trade_date=trade_date,
        is_allowed=is_allowed,
        hit_rules=hits,
        hit_details=details,
        evidence=evidence,
        phase=phase,
        context_diagnostics=context_diagnostics,
        generated_at=datetime.now().astimezone().isoformat(timespec="seconds"),
    )


if __name__ == "__main__":
    # 自测样例
    cases = [
        # (name, 各项参数)
        ("合规仓位", dict(
            sector_rank=2, has_mainline=True, current_sector="科技",
            is_downtrend=False, has_sector_effect=True,
            first_time_hhmmss="103000", open_times=0,
            emotion_phase="main_up", in_plan=True,
            position_pct=0.10,
        )),
        ("中位股+下降趋势", dict(
            sector_rank=8, has_mainline=True, current_sector="科技",
            is_downtrend=True, has_sector_effect=False,
            first_time_hhmmss="95800", open_times=0,
            emotion_phase="main_up", in_plan=True,
            position_pct=0.10,
        )),
        ("尾盘投机+计划外", dict(
            sector_rank=5, has_mainline=True, current_sector="科技",
            is_downtrend=False, has_sector_effect=True,
            first_time_hhmmss="143200", open_times=0,
            emotion_phase="high_chop", in_plan=False,
            position_pct=0.05,
        )),
        ("退潮期+重仓", dict(
            sector_rank=1, has_mainline=False, current_sector="钢铁",
            is_downtrend=False, has_sector_effect=True,
            first_time_hhmmss="103000", open_times=0,
            emotion_phase="main_down", in_plan=True,
            position_pct=0.15,
        )),
        ("有主线但去非主流", dict(
            sector_rank=1, has_mainline=True, mainline_sectors=["科技", "AI"],
            current_sector="银行", is_downtrend=False, has_sector_effect=True,
            first_time_hhmmss="100000", open_times=0,
            emotion_phase="main_up", in_plan=True,
            position_pct=0.05,
        )),
    ]
    for name, kw in cases:
        r = check_forbidden("TEST", "20260904", **kw)
        print(f"{name}: {'✅ 通过' if r.is_allowed else '❌ 拦截'}")
        for h, d in zip(r.hit_rules, r.hit_details):
            print(f"  - [{h}] {d}")
        print()
