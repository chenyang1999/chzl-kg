---
name: analyze_stock_profile_v1
description: R5 情报深挖 — 对 R2 龙头逐票六维画像；@ 估值/研报横切 skill
agent_owner: R5
version: v1
status: P1-T1prime
category: research/R5
created: 2026-07-04
updated: 2026-07-05
spec: docs/agents/R5-情报深挖Agent.md
---

# analyze_stock_profile_v1 · R5 情报深挖 Agent

**跑动时点**: 07:45（R2 完成 + filter_leader 后；与 orchestrator 串行批次）  
**权威规格**: `docs/agents/R5-情报深挖Agent.md`  
**产出路径**: `data/research/YYYYMMDD/R5_stock_profiles.json` · 可选 `chzl_kg/个股/{code}/YYYYMMDD_画像.md`

---

## 唯一职责

对 **R2 圈定的龙头候选**（通常 6–15 只）逐票输出 **六维画像**，供 D1 execution_pool 与 R6 反证消费。

**禁止**: entry/exit 价格、全市场扫描、风格(R1)、板块排序(R2)。

---

## 输入

| 路径 | 用途 |
|------|------|
| `data/research/YYYYMMDD/R2_main_sectors.json` | 候选票清单（`leader_filter_applied: true`） |
| `data/research/YYYYMMDD/R4_news.json` | 催化背景 |
| `data/research/YYYYMMDD/R7_capital_flow.json` | 个股/板块资金验证 |
| `data/raw/YYYYMMDD/manifest.json` | severity |

### 识图是独立证据，不替代数值判断

用`src.research.chart_evidence`统一核对代码、快照日期、原始事实时点、复权声明、错误与是否真实图像分析；保留`pattern/summary/volume_signal/key_levels`及原模型和来源。明确的突破、回踩、超买、背离标签只作为技术维度的一票证据，否定或待验证描述不能转成已确认标签。原日线指标、数值判断、评级与交易资格不因附加图像证据自动改变。

缺图、错日、未来数据、后复权或仅文字降级输出均保留具体unknown/限制，不伪造“识图确认”，不为此全局禁止研究。T-1图像可作为历史结构证据，但不得称为今日分钟承接；顶层fq=2也不独立证明所有周期均已核为前复权。

将实际采用的快照内容和校验结果保留在本轮画像技术维度，随R5主产物的版本绑定交给D1；不让D1另读后来刷新的raw/latest来冒充本轮输入。规则版只负责运输/校验，不冒充大模型综合裁决。实际接口为`normalize_chart_record`和`chart_evidence_from_profiles`；消费价位还须检查每条level的`price_usable`与`adjustment_status`，不能只看顶层available/fq。当天上午的完整日K或未闭合周K不能仅凭午夜日期标签通过截止检查；没有明确partial/available_at证据仍为unknown。

### MCP / `@` 横切 skill（引用，勿重写逻辑）

| Skill | 用途 |
|-------|------|
| `@report-search` | 研报检索 |
| `@announcement-search` | 公告核验 |
| `@hithink-insresearch-query` | 机构观点摘要 |
| `@hithink-management-query` | 治理/管理层 |
| `@hithink-business-query` | 业务结构 |
| `@hithink-market-query` | 行情/资金快照 |
| `@iwencai-query` | NL 条件复核 |
| `@serenity-alpha` | 事件 Alpha 框架 |
| `@bayesian-intrinsic-growth-valuation` / `@tam-adj-peg` / `@gf-dma-health-index` | 估值维度（择一或组合） |
| `@buy-side-equity-research-memo` | 重点票 deep-dive 结构 |
| `@缠论形态识别`（v1.3 · 2026-08-06 新增） | **技术形态维度的补充方法论**——chart_vision 看图识别，缠论看结构判定。两者必须**同向**才标 `chanlun_confirmed=true`；反向 → 标 `chanlun_divergence=true` 进 R6 观察池 |
| `@大宗商品分析`（v1.3 新增） | **板块联动维度的商品→板块映射**——若候选股所属板块与某商品强联动（黄金股/铜业/油服/锂电/化工），输出 `commodity_linkage: {gold: +0.05, copper: -0.02, ...}` 作为加分 |
| `@行为金融分析`（v1.3 新增） | **认知偏差高发区识别**——若候选股命中以下任一模式，输出 `cognitive_bias_warnings: [...]`：`8 板+ 高度龙头` / `创业板 20cm 1 板` / `业绩预增高位` / `反复触板未 ST` |

Tushare MCP（按需）: `anns_d`, `top_list`, `top_inst`, `hm_list`, `daily`, `daily_basic`, `report_rc`, `stk_surv`

### 大资金独立证据面（v1.3 · 2026-08-31 改：tushare 主源，vibe-trading 降为可选交叉核验）

**问题背景**:R5 六维中的"筹码结构"维度此前仅靠 tushare `top_list` + `margin_detail`,存在覆盖盲区(大宗交易营业部席位/两融日度趋势/龙虎榜溢价率)。v1.2 引入 vibe-trading 作独立 eastmoney 通道交叉核验。**但 vibe-trading MCP 未配置(不在 hermes_mcp.json),导致 R5 长期静默降级。v1.3 改为 tushare 为主源,不再依赖未配置的 MCP。**

| 数据 | 主源(tushare，先复用已核证据) | 交叉核验(可选,vibe-trading 可用时) |
|------|-------------------|----------------------------------|
| 大宗交易 | `block_trade`(近30日) → `chip_structure.block_trades` | `mcp__vibe_trading__get_block_trades(days=30)` |
| 两融趋势 | `margin_detail`(近15日) → `chip_structure.margin_15d_trend` | `mcp__vibe_trading__get_margin_trading(days=15)` |
| 龙虎榜 | `top_list`(orchestrator 层全市场每日1次) → `chip_structure.dragon_tiger_hit` | `mcp__vibe_trading__get_dragon_tiger` |

**硬约束(v1.3 调整)**:
- 每票`chip_structure.block_trades`与`margin_15d_trend`保留实际结果；明确已查无记录才空数组，不适用须有依据，未知为null及原因。优先用tushare或已核等价来源；缺这类辅助证据只局部降级，不独立按扣分封顶硬禁交易
- 仅有真实可比折溢价时，沿用大宗折价率`< -5%`或最近3日`avg_premium_pct <= -8%`的风险提示；不把无premium字段的接口臆算成折价，更不混同R3模式6的连续霸榜alert
- 融资余额 15 日下降 > 10% + 融券余额上升 > 20% → flags 追加 `short_pressure`(空头压制)
- **不再把 vibe-trading 当每票必调**;vibe-trading 仅在有配置时作为双源交叉核实

### tushare 字段级口径（v1.6 · 逐票资金三处必核）

**别信 `moneyflow.net_mf_amount`。** 该字段与同一条记录的分档明细自相矛盾（实测某票分档净额 +11.48 亿、该字段 -13.36 亿，而当日成交只有 23 亿）。主力净额一律自算：

```python
net_big = (buy_lg_amount + buy_elg_amount) - (sell_lg_amount + sell_elg_amount)  # 万元
net_big_yi = net_big / 1e4
```

再用 `moneyflow_dc.net_amount`（同为万元）做双源交叉。两源同日偏差 >5% → 写 `fund_source_conflict=true` 并降该票 `chip_structure` 置信度，**不得二选一硬用**。

**单位错一次结论全错**：`moneyflow` 各 `*_amount` = 万元（÷1e4→亿）；`top_list.net_amount` = 元（÷1e8→亿）；`block_trade.amount` = 万元。写完必须回代一次数量级——单票单日主力净额超过当日成交额即单位错。

**`block_trade` 没有 premium 字段**，成交价恒等于当日收盘价。只记笔数、总量、价格区间，并在 `block_trades.note` 明写「折溢价不可判」；不要据此写「大宗折价 < -5% → distribution_alert」这类根本算不出来的规则。

**`report_rc.tp` 是营业利润预测（万元），不是目标价**；同一 `report_date` 会按 `quarter` 返回多行（2026Q4/2027Q4/2028Q4）。只取最新 `report_date` 的 `rating` + `eps`，禁止把 `tp` 当 target price 写进画像。

完整字段清单、三年估值分位配方、席位归并口径见 `references/tushare-field-conventions.md`。

### 上游 gate 逐票保真，但不得固化旧市场意见

先核R2候选、来源、事实时点和本批身份，保留`gate_status`原文及证据。真实用户/账户硬禁、真实hard_reject和必要缺证仍逐票交D1，不能丢弃；但市场性no_trade、辅助缺数、质量分及旧计划缺席须与硬禁分开，不能一律转成永久`r2_execution_blocked`。旧`in_today_plan=false`/`plan_outside_scan`不得在本轮D1首次成案前被当成本批禁令；未知保留null，旧意见给适用窗口与重评条件，不自行增加买权。

在`dimensions.sector_linkage`记录原gate及来源、`constraint_kind`（user_account_hard/necessary_evidence_gap/market_assessment/unknown）、原理由与窗口；`r2_execution_blocked`只如实描述本次有据限制，不能因字符串含“拦截”就推布尔。保留`r2_role`（龙一/龙二/龙三/候补）和`research_template`；核心先完成必要判断，再补辅助深挖。研究分、档位和资料质量不单独硬禁，真实风险不因市场强势被删。

**次线也是合法票源。** `all_scored_boards_top10` 常缺失（R2 schema 降级）。此时 `secondary_lines[].leaders[]` 是补齐 6-15 只的正当来源：按 `secondary_lines[].score` 降序取，`provenance = "r2_secondary_pool"`，并在 `sector_linkage` 记 `r2_score` 与该线是否被 R2 拦截。不要因为 top10 缺失就空等，也不要为凑数造假票——次线 leader 是 R2 自己评估过的真实对象。

### 图表 & 多模态层（v1.1 · 2026-07-07 强化 · v1.4 · 2026-09-30 改为先读快照）

**问题背景**:此前 R5 的"技术形态"维度纯靠文字描述,没有真实图表输入 LLM,导致"下降通道内反弹/放量突破"等判断浮空。需要每只候选票有 30 日 K + 多模态识图的输入。

**按顺序执行，先核名单再补图**：

1. 从本批获准的R2对象确定研究候选，保留原角色与禁买标记；`partial`中的真实候选可用于研究补图，不等于正式审核完成或取得开仓资格。核对实际选池函数支持的状态，不把未验证的其他降级状态自动视为可用。不得因部分完成、空池或读取失败自动换成固定旧名单；无有效候选时零外部图像/模型调用，并明确空池或读取错误原因。
2. 在R2交付后、R5消费前，核对同日快照有效记录与所选候选的交集。复用成功记录，仅将缺失/失败对象送入补图；部分覆盖不等于全池覆盖，不能达到某个覆盖比例就跳过剩余对象。
3. 优先由具有图像输出权限的既有抓取入口批量补缺，再读取合并结果；不要让R5为补图自行扩大写白名单。已有快照命中不再重复调用外部服务，显式强制重算只作用于明确选中的票池。
4. 批量补图后仍缺失的对象，才按本轮授权考虑逐票MCP回退。失败保留在原票并说明阶段，不用其他股票替代；名单错误先查本地选池，外部服务不稳定须由实际调用证据另证。

| MCP 工具 | 何时调用 | 产出字段 |
|---------|---------|---------|
| **（优先）读文件** `data/raw/{trade_date}/chart_vision_snapshot.json` | **Step T 第一步**：读快照，命中即用，**不再调 MCP** | `technical.chart_vision` = 快照该票的 `{trend, pattern, key_levels, volume_signal}` |
| `mcp_canghai_charts_chart_vision_analyze` | 同日有效快照未命中、批量补图仍失败且本轮授权允许时，才逐票回退 | 同上；区分真实图像分析与仅行情文字结果 |
| `mcp_canghai_charts_chart_lwc_render_kline` | 需要产出 PNG 供 md 引用时(挑 Top3 首推票) | `technical.chart_png_path` |
| `mcp_canghai_charts_chart_fast_render_kline` | 快速四周期拼图(15m/60m/日/周),用于形态确认 | `technical.multi_period_chart_path` |

**硬约束**:
- 每只候选票 `technical.chart_vision.pattern` 字段**不得为空字符串** · 空 = 判定 fail
- 读快照时**必须校验 `snapshot["date"] == trade_date`** —— `data/cache/chart_vision_latest.json` 是跨日指针，直接用会把**前一日**快照当当日（这是旧机制的原始 bug）
- 快照命中时在 `technical.chart_vision.source = "snapshot"`，MCP 直调则记 `"mcp_live"`，便于复盘统计真实节省
- 若 MCP 全域 DOWN 且快照未命中 → `technical.chart_vision=null` + `chart_degraded=true`,该票 `strength` 顶格 `medium`
- 首推票(每主线 Top1)必须产出 `chart_png_path` 供 md 里以 `![](path)` 语法引用
- **快照未命中的票，先用脚本并发补渲，不要逐票串行调 MCP**：
  ```bash
  .venv/bin/python scripts/fetch/run_chart_vision_snapshot.py \
      --universe data/cache/<票池>.json --date <YYYYMMDD> --concurrency 5
  ```
  仅由有相应输出权限的入口使用已经获准的票池文件执行；此命令不授权新建任意缓存文件或由R5越权写图。脚本按 `ts_code` 合并同日结果，保留已有有效记录；核对实际请求的对象正好是本次缺失集合。只有批量补图仍失败且允许回退时才逐票调用MCP，并记录实际来源。调用成功、保存PNG和真正完成多模态分析是不同证据，不能把 `data_only` 返回冒充看图完成。

**只读覆盖核对示例（不触发补图或模型）**：

```python
from src.research.candidate_pool import derive_from_file, load_snapshot

pool, pool_meta = derive_from_file(trade_date)
cached, snapshot_meta = load_snapshot(trade_date)
selected = [code for code, name in pool]
covered = [code for code in selected if code in cached]
missing = [code for code in selected if code not in cached]
# covered复用；missing交有权限的抓取入口批量补图，再读回并核对。
# pool为空时报告pool_meta中的原因，不引入默认股票。
```

验收覆盖候选读取、实际补图入口及R5消费三层；至少包含partial真实候选、空池零调用、失败不换票、成功缓存复用和只补缺失的离线正负例。隔离测试通过后，正常流水线实际采用仍单列验证，不为证明代码修复而重复付费出图。

**注意**:chart_vision 的综述本体是 **Python 预渲染产物**（并发出图 + 一次 vision LLM 调用），
不是 R5 的量价判断 —— R5 对形态的**最终裁决**仍须由 LLM 结合快照 + kline + 板块自行做出，
禁止把快照字段直接抄成结论。

---

## 六维画像（每只候选）

1. **催化背景** — 来自 R4 + 群消息交叉  
2. **筹码结构** — 股东户数、龙虎榜 30 日、主力 5 日 + 大宗/两融(v1.2 硬约束)  
3. **板块联动** — 继承 R2 得分 + ETF/期货联动  
4. **财务与估值** — `@` 估值 skill 或 MCP 分位 · **v1.2 新增双层结构 + fundamental_flags 透传**  
5. **技术形态** — K线结构及适用的形态证据；图像按上节先复用同日有效快照、再批量补缺，不因“每票分析”重复调用已命中票的charts MCP。canghai-sise按原独立要求核验，缺口如实记录  
6. **研报与机构** — `@report-search` / `@hithink-insresearch-query`

## 财务与估值维度契约(v1.2 · 2026-07-07 · 供 R6 模式七消费)

### 必要核验先行：从实际三表计算，不用统一unknown配方

逐票先完成资金/价格、财务合规与真实重大风险的必要判断，辅助图像、研报、估值模型缺口单列。R7早于R2，旧`R5_candidate_pool`覆盖不能代表本轮R2候选；R5负责补本批真实对象的必要证据，不因R7未覆盖/某provider未配置而把全池停买。

先复用本批已绑定且有读权限的证据，核代码、来源、可知时点、原文件版本及观察窗口。若本阶段已有`R5_current_evidence.json`、`R5_financial_supplement.json`等材料，只在来源/版本确认为本次可用后消费，不凭同日文件名信任，也不把旧`R5_build_recipe`当指令执行。已有多期`income`/`balancesheet`/`cashflow`/`fina_indicator`应逐字段核验再算；不得用统一`F3/F4/F5/F7/F8/F11/S2/S3=unknown_or_not_applicable`代替实际核验，不能因为辅助细项未齐就写整票财务未查。

沿用R6附录A的原阈值和severity，不新增数值门槛。每票`dimensions.valuation_safety.fundamental_checks`逐项给`status`（flagged/checked_negative/not_applicable/unknown）、`formula`、实际输入字段/值/单位、`periods`、`announced_at`、`source`与`evidence_refs`、`reason`。flagged汇入原`fundamental_flags`；checked_negative必须计算/核原文后得到；not_applicable必须给行业、业务或规则适用性证据，不得与unknown合并。缺列、null、分母不可用、公告正文未读仍unknown，数值0不是缺失。

| 项 | 先用已在盘可核数据完成的判断 | 不能臆算的部分及回送 |
|---|---|---|
| F1/F2/F9/F10 | 同期间货币资金/短借/总资产、商誉/净资产、应收/营收、有息负债/净资产；核币种单位、并表口径与分母 | 负债明细不全不能默认0；缺必要项由R5补 |
| F3 | 应收同比增速与同口径收入同比增速比较；用相同季度/累计期间、同类报表及可知版本 | 基期为0或负数时原比例判据可能不适用，说明原因并保留绝对变化，不能默判阴性 |
| F4 | 存货同比、同口径收入同比及存货周转率变化；周转率可用已核指标或同口径成本/平均存货复算 | 缺周转率或期初存货，仅能完成部分，不能因有存货就宣布全项通过 |
| F5 | 资本化研发/研发投入；核费用化与资本化流量及期间 | `develop_exp`余额不是当期资本化流量；缺附注/研发披露回R5公告或有权限生产者 |
| F6/F8 | 扣非与净利润差异；F8核连续2期CFO为负且净利润为正。累计现金流先转同口径单季（Q1原值，后季减前季累计），保留计算与期间 | 不把连续2个累计负值冒充2个独立单季；已具8期三表不能无理由统一unknown |
| F7 | 关联交易/营收，查附注或已核关联交易披露 | 无公告标题不等于无关联交易；无原文仍unknown并交R5 |
| F11 | 控股股东质押股数/其持股数，核股东身份、时点与单位 | `pledge_stat`全公司质押率不能替代控股股东比例；需`pledge_detail`与股东持股/公告，`stk_holdertrade`不是质押率接口 |
| F12/S2/S3 | 核审计意见、风险警示/临近预警、立案/重大违规等实际公告与有效窗口；最新已披露年度/当前事件分别核 | 非标/造假/预警按原hard_reject；没有风险标题或盈利为正都不能证明S2/S3阴性，缺关键合规仅本票待核 |

实际字段足够就先算适用项，不为所有辅助细项强制新增查询。真正缺必要合规或实质风险证据时，`fundamental_gaps`逐项列代码、缺字段/原文、原因与有权限补抓者（R5或R4）；不能写“交R6复核抓数”。R6只读本版R5的事实/计算独立审查，不要求R6具MCP。`fundamental_screen_complete`仅概括声明的必要检查范围，必须同时列`required_checks`及逐项结果/适用性依据；辅助unknown单列，不能据空flags写全项排雷通过，也不能把所有估值陷阱自动设为必要合规。

### 同版可比资金/价格供R6独立交叉

在`dimensions.chip_structure`保留本票同窗口日序列、近5日主力净额（含原单位与公式）、实际`source`、事实时点和证据定位，并给相应`price_observations`（交易日/价格/涨跌/停牌状态/实际来源）。按既有字段口径自算大单+超大单净额，不用有冲突的总字段掩盖。R7覆盖缺失时，同版R5这些实际可比资金/价格可供R6模式1与R4交叉，不是改写R7或伪造其owner/provider。重复同底层接口不算独立信源，来源冲突保留双方；缺可比证据仍只限制相关票，不能编造资金确认。

### 双层估值决策树(参考 vibe-trading `valuation-model`)

**决策树**(按行业选估值方法,不再"一律 PE 分位"):

| 行业类型 | 首选估值 | 备选 | 命中即降 severity |
|---------|---------|------|-------------------|
| 稳定现金流(消费/公用) | DCF | PE + DDM | V9 分红陷阱 |
| 高成长(半导体/AI/新能源) | PEG + PS | 相对估值 | V2 高 PEG + V6 一次性收益 |
| 周期(资源/化工/钢铁) | PB × ROE 四象限 | 席勒 PE | **V1 低 PE 陷阱** |
| 金融(银行/券商/保险) | PB × ROE | DDM | V3 商誉炸弹 |
| 集团/多元(SOTP) | 分部加总 | PB | V10 SOTP 加总陷阱 |
| ST/仙股 | N/A | — | **V7 港股仙股 / ST 三轴 hard_reject** |

`@` 三个自研估值 skill 作为**实现层**: `@bayesian-intrinsic-growth-valuation`(DCF/成长) · `@tam-adj-peg`(高成长) · `@gf-dma-health-index`(健康度综合)。R5 按行业选一到两个跑,不再一律全跑。

### fundamental_flags[] 透传契约(供 R6 模式七)

每票 `dimensions.valuation_safety.fundamental_flags[]` 必须列出命中的红旗编号(F1-F12 财报 · V1-V10 估值 · S1-S3 ST 三轴,对应 R6 附录 A checklist),格式:

```json
"fundamental_flags": [
  {"code": "F2", "detail": "商誉/净资产=42%", "source": "vibe-trading get_financial_statements", "severity": "strong"},
  {"code": "V1", "detail": "PE=7 但净利率处于 10 年 top 15% (周期顶)", "source": "R5 valuation_layer", "severity": "strong"},
  {"code": "F11", "detail": "控股股东质押率 76%", "source": "tushare pledge_stat", "severity": "strong"}
]
```

**硬约束**:
- 无红旗时字段为 `[]`(空数组),**不得省略**
- 命中 F12(审计非标) 或 S2/S3(ST 合规/临近) → R5 自身 `valuation_safety.score` 顶格扣至 30 以下,并在 notes 写 `to_be_hard_rejected_by_R6=true`
- R5 未透传此字段 → R6 模式七 `degraded` · orchestrator 记 warning

### 检出实现建议

1. F1-F12先按上表与R6附录A检查已核三表，缺项才由有权限生产者补必要原文/字段；不要求特定provider、MCP标签或额外模型会话
2. V1-V10: 按上表决策树,只跑对应行业相关的 2-3 条陷阱检出
3. S1-S3分别核财务、合规与临近风险；质押按F11专门口径，市值/盈利不代替合规公告核验

---

## 输出 JSON

`data/research/YYYYMMDD/R5_stock_profiles.json`:

```json
{
  "schema_version": "research_unit_v1",
  "agent": "R5",
  "trade_date": "YYYYMMDD",
  "generated_at": "ISO8601",
  "status": "complete",
  "profiles": [
    {
      "ts_code": "",
      "name": "",
      "sector": "",
      "one_liner": "",
      "dimensions": {
        "catalyst": {"score": 0, "summary": ""},
        "chip_structure": {"score": 0, "summary": ""},
        "sector_linkage": {"score": 0, "summary": ""},
        "valuation_safety": {"score": 0, "summary": "", "total_mv_yi": 0, "circ_mv_yi": 0,
          "fundamental_flags": [], "required_checks": [],
          "fundamental_checks": {}, "fundamental_gaps": [],
          "fundamental_screen_complete": false},
        "technical_readiness": {"score": 0, "summary": "", "pullback_to_decision_line": false, "pullback_note": null, "ma50": null, "niu_xian": null, "xiong_xian": null},
        "institutional_interest": {"score": 0, "summary": ""}
      },
      "composite_score": 0,
      "alpha_grade": "B+",
      "risk_grade": "B",
      "flags": ["distribution_alert"],
      "data_sources_used": ["R4", "hithink-market-query"]
    }
  ]
}
```

---

## 档位字段 `alpha_grade` / `risk_grade`（必填 · 2026-09-30 硬约束）

D1 的风险闸门按 `position_cap` 分支消费这两个字段，且契约规定
**档位缺失时按 B 降级**（`main_decision_v1` §Step 3.5.5）。

事故背景：R5 长期只产出 `alpha_grade`、**从不产出 `risk_grade`**
（实测 30 个交易日 × 全部产出 = 0/330 有该字段），而 D1 一度把缺失档位
映射为 rank 0（比 C 还差），使 `position_cap ≥ 0.7` 时
`alpha≥B+ AND risk≥B-` 恒假 → **该类日期执行池被整体清空**。

规则：
- **两档均为每票必填**，不得省略、不得为 null。
- `alpha_grade`（进攻性，档位 A+ / A / A- / B+ / B / B- / C）：确定性、主线地位、
  资金持续性、催化硬度、龙头身位。
- `risk_grade`（风险度，档位 A / B+ / B / B- / C，**A 最安全**）：高位程度、
  是否霸榜出货、套牢盘、估值分位、筹码分散度、龙虎榜净卖。
- `flags` 含 `distribution_alert`（霸榜出货）→ `risk_grade` 不得优于 `B-`。
- 与 `R6` 分工：R6 是否决器（`hard_reject`），R5 是分档器，二者不可互相替代。

---

## 降级

- R2 经核验确无研究候选 → `status: skipped`, `profiles: []`，说明覆盖与空池原因；禁新仓/零预算本身不是“无研究候选”。存在真实研究观察对象时继续画像，但不因此取得 execution 资格  
- 单票 MCP 失败 → 该票 `partial: true`, 不阻塞其余票
- 档位确实无法判定 → 显式写 `"B"` 并在 `flags` 标注 `grade_defaulted`，
  **不得留空**（留空会触发 D1 侧降级路径，掩盖真实风险）

---

## chzl_kg 人读 md 落盘（必需 · @render_kg_md_v1）

**契约来源**: `skills/_shared/render_kg_md_v1/SKILL.md`

除机读 JSON 落盘之外，本 skill 必须**同时**渲染一份人读 md 到 chzl_kg 供用户当日审阅。

### 落盘路径

```
chzl_kg/投研交易/个股画像/{trade_date}.md
```

（目录若不存在，`mkdir -p` 创建。）

### frontmatter（必填，UTF-8 · Unix 换行）

```yaml
---
date: {trade_date YYYY-MM-DD}
agent: R5-stock-profiles
skill_version: analyze_stock_profile_v1@1.0
generated_at: {ISO 8601 · 落盘时刻 · 含时区}
confidence: {从本 skill JSON artifact 读；缺则 null}
degraded: {true|false}
data_sources:
  - name: {源标识}
    path: {data/raw/... 或 MCP 名}
    status: {ok|error|timeout|stale}
    captured_at: {ISO 8601 或 null}
    record_count: {整数或 null}
    error: {可选 · 简短错误串}
input_freshness: {ok|partial|stale}
input_freshness_note: {任一源非 ok 时必填的说明}
---
```

### 正文（Markdown）

```markdown
# {trade_date 中文日期} · **个股画像**

> **数据源新鲜度**: {input_freshness}
> **降级状态**: {degraded}
> **置信度**: {confidence}

## 一句话结论
{≤ 60 字核心判断}

## 详细分析
{3-5 段主体}

## 关键证据
- 证据 1: {内容} · 来源 {data_source}
- 证据 2: ...
- 证据 3: ...

## 数据源审计
| 源 | 状态 | 抓取时间 | 记录数 | 备注 |
|---|---|---|---|---|
...

## 不确定性 / 反证
{自我批判段}

## 与其他 R/D/E 的关系
- 依赖: {上游 artifact 列表}
- 被消费: {下游 skill 列表}

## Sub-Agent 元数据
- skill: analyze_stock_profile_v1
- artifact: data/.../{...}.json
- 生成耗时: N 秒
- model: {model 名}
```

### 落盘规则

1. **atomic write**: 先写 `.tmp` → `mv` 到目标（避免 Obsidian 抓半写）
2. **overwrite**: 同日重跑覆盖；若目标已存在先备份为 `.md.bak`
3. **失败不阻塞**: md 渲染失败**不**回滚 JSON artifact 落盘；skill status 写 `partial` 并在汇报中标注

### 验收

盘后 `test -f chzl_kg/投研交易/个股画像/{trade_date}.md` 必须为 true；前 30 行满足 frontmatter schema。

---

## 写作契约(v1 · 2026-07-06 硬约束升级)

本 skill 输出的 md **必须**遵循 `skills/_shared/canghai_writing_contract_v1.md`,该契约定义了:

1. **写作风格锚点** — 对标 `样例/20260630_pre_open_plan.md`,表格化 + emoji + 因果句 · 禁 python dump JSON / 群名裸露 / 时分秒
2. **必含 mermaid 图表**(≥1 张 · 节点 ≥ 8) — 本 skill 推荐类型见契约
3. **推理深度三问** — 每个 top 分析对象显式回答 `**大资金意图**` / `**为什么走强**` / `**逻辑够不够硬**`
4. **每票思维链**(≥4 段) — 首推票必附 `**买入理由**` / `**风险点**` / `**止损条件**` / `**可验证假设**`
5. **数据源审计表** — 三色 emoji · 日期无时分秒 · 群名匿名化 · 主源缺失即 degraded=true

**验收硬门槛**: md 落盘后逐条自检契约第六节六项,任一缺失即 skill 状态 `partial`,视为执行失败须重跑。

## Version History (writing contract)

- v1 (2026-07-06): 加入沧海写作契约 · 覆盖 R1-R7 + D1
- v1.4 (2026-08-07): R5 候选与 R2 主线脱钩修复 — 增加候选池扩池规则

---

## v1.4 新增 · R5 候选与 R2 主线脱钩修复（P0-1 修复）

**问题根因**: 2026-08-05 实盘跑中,R2 的 `main_lines.leaders[]` 仅输出 1 个候选(普冉股份),但 R2 自身 `all_scored_boards_top10` 还有 9 个 score >= 50 的板块未利用。R5 直接消费 R2 `leaders[]` → 当日候选池仅 1 只,无法支撑 D1 `execution_pool ≤ 5` 硬约束,导致 D1 反复走降级路径。

**v1.4 扩池规则**(硬约束,新增到 §输入 与 §六维画像之间):

```
# R5 启动时,先做"主候选池扩池"
candidates = r2_main_sectors.main_lines.leaders  # 原始 1-3 个 leaders

if len(candidates) < 3:
    # 从 R2.all_scored_boards_top10 中扩池(score >= 50)
    supplement = [
        {"ts_code": b["top_stock"]["ts_code"], "name": b["top_stock"]["name"],
         "source_sector": b["name"], "r2_score": b["score"]}
        for b in r2_main_sectors.all_scored_boards_top10
        if b["score"] >= 50
    ]
    # 按 r2_score 降序,去重
    seen = {c["ts_code"] for c in candidates}
    supplement = [s for s in supplement if s["ts_code"] not in seen]
    supplement.sort(key=lambda x: x["r2_score"], reverse=True)
    # 仅补有研究价值且未命中硬否决的真实对象；5只是扩池目标，不是最低配额
    need = max(0, 5 - len(candidates))
    candidates.extend(supplement[:need])

# 不足目标如实记录覆盖/剔除/缺口；真实空池允许 skipped，不绕否决、不凑数
# 研究扩池不产生开仓权限；后续R6完整性和D1逐票门禁保持不变
```

**消费契约**:
- 扩池来源的票必须在 R5 JSON `stock_profiles[].provenance.source` 字段标 `"r2_expand_pool"`,区别于 `"r2_leader_pool"`;来自 `secondary_lines[].leaders[]` 的标 `"r2_secondary_pool"`（同样不加 -3 起步分，因为它来自 R2 已评分的次线，不是无信号凑数）
- 扩池票的 `composite_score` 起步分 -3(因为无 R2 leaders 强信号),但仍跑完整六维画像
- 扩池来源与档位是研究参考，不独立硬禁；D1须按核心地位、必要风险及真实权限逐票裁决。R6无hard_reject不等于必要审核完成，不凭alpha_grade=A自动准入

**降级**:
- `R2_main_sectors.json` 缺失 `all_scored_boards_top10` 字段 → 视为 R2 schema 降级,本次跳过扩池,记录 `r2_schema_missing_top10=true` 到 R5 JSON 顶层,供 E1 复盘统计

**验收**:
- 验收按实际研究候选覆盖与缺口，不将未凑够5只本身判画像失败；真实空池须有 R2 证据，非空候选仍核数量/降级标记。不得为通过数量检查解除否决；对应检查器需先确认是否存在及与当前 contract_checks 一致，未验不得自报通过

---

## v1.5 新增 · 龙头判定维度（2026-08-20 · 用户方法论）

**背景**: 评价一只票不能只看个股 K 线 + 消息面，还要看**板块效应**。判龙头看两个维度：**高度**（连板数）+ **上榜时间**（封板早/首次上榜早）。上榜早=有带动性=龙头；上榜晚=跟风补涨。

**数据源**: tushare `limit_list_d`（打板/涨停专题，**含 first_time/last_time/open_times/limit_times**）+ `top_list` 历史（算首次上榜距今）。

### 每票必算 `leader_verdict`（六维中"板块联动"维度必填子块）

```python
ld = tushareMcp.limit_list_d(ts_code=stock.ts_code, trade_date=trade_date,
                             fields=["ts_code","name","first_time","last_time","open_times","limit_times","limit"])
first_seen = first_board_day(stock.ts_code, lookback=10)  # 板块这轮启动后第几天上榜
leader_verdict = {
  "height": ld.limit_times,          # 连板高度
  "first_board_time": ld.first_time, # 今日首次封板时间 (HH:MM, 越早越强)
  "open_times": ld.open_times,       # 开板次数 (越少越强/一致)
  "days_since_first_board": first_seen,  # 1=启动日=龙头
  "sector_breadth": r2_sector_zt_count,  # 板块内涨停家数 (板块效应)
}
```

### 龙头判定规则（硬约束）

1. **龙头信号**（进 execution_pool 加分）:
   - `height >= 2` + `first_board_time 早于 09:45` → `verdict: 龙头`
   - 或 `days_since_first_board == 1`（启动第一天上榜=带动性最强）→ `verdict: 龙头`
   - 且 `sector_breadth >= 3`（板块效应，板块内多只涨停）→ 龙头成立
2. **跟风/补涨**（降级，仅入 watch_pool）:
   - `days_since_first_board >= 3`（板块涨 3 天才上榜=跟风补涨）→ `verdict: 补涨/跟风`
   - 或 `open_times >= 4`（反复开板=分歧弱）→ `verdict: 分歧弱`
3. **无板块效应**（`sector_breadth == 1`，孤军涨停）→ `verdict: 孤军`, 龙头资格降级

**消费**: D1 优先 `verdict: 龙头` 进 execution_pool；`补涨/跟风`/`孤军` 仅入 watch_pool。R6 可据此挑 `分歧弱` 反向。
**version**: v1.5 (2026-08-20)

## Version History

| 版本 | 日期 | 说明 |
|------|------|------|
| v1.4 | 2026-08-07 | P0-1 修复: R2 leaders < 3 时从 all_scored_boards_top10(score >= 50)扩池保证 candidates >= 5 |
| v1.5 | 2026-08-20 | 新增龙头判定维度(limit_list_d 高度/封板时间 + 板块效应 + 首次上榜): 龙头 vs 跟风/补涨 vs 孤军 |
| v1.6 | 2026-10-26 | tushare 字段级口径(弃用 net_mf_amount / 单位回代 / block_trade 无 premium / report_rc.tp 非目标价)；R2 gate 逐票透传 `r2_execution_blocked`；次线 `r2_secondary_pool` 票源；快照未命中走脚本并发补渲 |
