---
name: analyze_sentiment_resonance_v1
description: R3 情绪与热度 — 双源(KOL+热榜)交叉共振，情绪浓度与 top5 主题（WeFlow 已于 2026-08-19 下线，详见文首）
agent_owner: R3
version: v1.1
status: draft
category: research/R3
created: 2026-07-03
updated: 2026-11-01
spec: docs/agents/R3-情绪与热度Agent.md
---

# analyze_sentiment_resonance_v1 · R3 情绪与热度 Agent

**跑动时点**: 07:30（与 R1、R4、R7 并行；可读磁盘已落盘 `R1_style.json` 作情绪基准）  
**权威规格**: `docs/agents/R3-情绪与热度Agent.md`  
**产出路径**: `data/research/YYYYMMDD/R3_sentiment.json`

> ## ⚠️ WeFlow 已下线（2026-08-19）
> `weflow-analytics` MCP 因 ngrok 隧道失效已于 2026-08-19 从所有 profile 移除，**永久不可用**。R3 从此改为**双源共振（Layer 1 热榜 + Layer 2 KOL）**，不再调用 Layer 3。共振最高等级为 `L1+L2`（不再出现 `L1+L2+L3`）。若遇到依赖 WeFlow 的旧字段（`weflow` / `unmapped_weflow_terms`），统一置空并标 `weflow_degraded=true`，不得编造。

---

## 唯一职责与任务分流

用热榜与群聊观点交叉，输出情绪浓度、共振主题、KOL方向摘要和热榜信号；公众号只作补充观点，WeFlow兼容字段不参与判断。

**禁止**：板块排序(R2)、个股深挖(R5)、基本面、技术分析。

### 临时问答：先核覆盖，再解释情绪

1. **锁定窗口**：将“这两天”落实为中国时区起止；周末按自然日读取，不拿包含周五的报告当纯周末样本。只问群聊时结论限于群聊，不强制重跑正式流水线或覆盖正式产物。
2. **实时取证**：读取抓取端当前名单，逐群补查至截止，核验分页与分日覆盖；操作配方见`references/chat-evidence-audit.md`。优先审阅证据，不只转述旧报告。
3. **区分表达与传播**：分别标记直接观点、卖方推广、会议邀请、链接标题和不可读消息；排除本人及其被引用观点，防止研究自循环。同一作者同文跨群仅计一次独立观点，出现群数只表示传播范围。
4. **审计“安静”**：核对记录内最早/最新时间、抓取时点及实际来源，不用文件名或mtime代替内容覆盖。比较消息量使用相同长度窗口；部分日少于完整日不代表降温。图片未读、正文不可展示或同步不明时标缺失，不判作沉默。
5. **追问真实市场时先补收盘**：由市场研究侧核对最新已完成交易日及前一交易日的广度、中位涨跌、成交额、涨跌停、炸板率、连板晋级和昨日涨停溢价，再对照群聊。读取内部观测时间，不以晨间/午间报告或文件名含`closed`代替收盘。含ST、北交所、触板及成交口径分别列示，炸板率分子分母同源；区分单日强修复与持续主升，不从舆论安静直接推出市场冰点。
6. **结论先行**：依次说偏向、两日变化、主题独立性、支持/反证和缺口；匿名群标签配带日期的短原文。只有文本时不给市场情绪分，不把产业观点当资金行为。综合问题分别交消息研究和催化剂日历核验，最终分栏，不强凑新主线。

临时问答不要求首推票、止损价、mermaid或正式R3文件；正式定时产物仍按下文契约验收。

---

## 三层数据源

### Layer 1 · 量化聚合（Tushare + XTick 主源）

| 源 | 接口 |
|----|------|
| Tushare MCP | `ths_hot`, `dc_hot`, `moneyflow_ths`, `moneyflow_dc` — 拉**两日**算 rank diff |
| XTick MCP | `/doc/hot/emotion`, `/doc/hot/moneyflow` |
| **XTick HTTP 直连（MCP 降级必选）** | XTick MCP 不可用(stdio 崩溃/超时)时,改用 `src/trading_agent/xtick_client.py` 的 `XTickClient.from_env()` 直连 `http://api.xtick.top`:`fetch_market_emotion(trade_date=...)` + `fetch_limit_board(flag=1, trade_date=...)`,与 E1 同法;`sources_status.xtick` 标 `http_fallback` |
| 横切 | `@hotlist_rank_signal_v1` 逻辑（若 `data/raw/YYYYMMDD/hotlist_signals.json` 已存在则直读） |
| **必读** | **`data/research/YYYYMMDD/attention_signals.json`（2026-09-14 新增 · 多平台人气股管道）** — 东财人气榜/飙升榜 + 同花顺热股/概念 + persistent 持续人气 + surge 跳升 + 多平台合力。**人气 = 股票潜力核心（用户钦定）**，R3 情绪与热度的个股级底座 |
| **周末/周一档必读** | `data/research/YYYYMMDD/attention_weekend.json`（2026-10-19 新增 · `scripts/research/weekend_attention.py`）— 按**自然日**直取的榜单（绕过 `attention_pipeline` 的"非交易日回落最近交易日"逻辑），含周六/周日榜单与 `weekend_persistent`（跨日连续在榜 = 周末发酵热度）。周末档与周一盘前档的情绪浓度应以它为个股级底座，`attention_signals.json` 为 T-1 已收盘基准 |
| `@hithink-market-query` | `skills/_shared/hithink-market-query` | 热榜/资金快照与 MCP 交叉验证 |
| `@news-search` | `skills/_shared/news-search` | KOL 主题与新闻标题语义对齐（可选） |

### Layer 2 · KOL 文本（5 群 wechat-cli）

**名单权威源**：`src/fetch/wechat_sources.py::WECHAT_CLI_GROUPS`。不把技能缓存的旧群名当实时配置；单群匹配失败时用`wechat-cli contacts --query "稳定关键词"`查当前名称，只报告差异，不未经授权改配置。

**提取算法**：

1. 排除本人及被引用的本人观点、系统消息与纯宣传；图片和无法展开正文标不可读，链接标题单列传播证据，不推测全文或转发者赞同。
2. 优先长正文，但保留短句及回复上下文；核心判断可能短于60字，不能按长度直接丢弃。长文候选和短对话旁证分开统计。
3. 先精确去重，再语义归并同稿改写和同一底层事件；不同群、API或转发者不自动构成独立信源。
4. **LLM语义抽取**主题、方向、有效时间及支持/反证；禁止用关键词次数代替理解或打分。

### Layer 2b · 公众号观点（取阅 RSS · 2026-10-13 接入）

公众号大 V/官媒与群聊同属"市场参与者观点"层。读 `data/raw/YYYYMMDD/wechat_official_rss.jsonl`
（R3 JSON 已预聚合为 `official_account_opinions` + 每个 top 主题的 `official_voices`）。

- **只当观点证据，不当量化共振**：公众号文章偏正式、发文少，不计入 `resonance_level`（L1/L2/L3）与情绪浓度打分，避免几篇官媒长文制造假共振。
- 渲染人读 md 时单列一节「公众号观点」：命中 top5 主题的观点标在对应主题下；无板块命中的宏观/情绪标题（如大 V 复盘、诺奖、监管表态）单列"宏观与情绪"，**这部分往往是判断市场情绪偏向的关键，不要丢**。
- 取阅新订阅号可能 0 条（历史未抓完），属正常降级，在数据源状态注明即可。

### 公众号与热榜交叉观察
记录报道和热榜的实际来源、覆盖窗口、数量、重复转载与缺口；可提出拥挤或派发假设，但热度本身不能证明持仓结构、出货或方向。`crowding_reading` 如保留兼容用途须标注方法与未知，不作为机械扣分或执行门槛。

### 历史兼容说明 · WeFlow旧协议（不执行）

以下旧协议仅用于解释历史文件，所有“必调”、调用顺序和非空字段要求均不属于当前执行路径；不得调用、回填旧快照或据其生成本次共振。当前仅使用L1/L2并将WeFlow兼容字段置空。

**A. 通用热词层**（先跑,建立宏观舆情坐标）:

| 工具 | 用途 | 触发条件 |
|------|------|---------|
| `export_analytics_snapshot` | 全量快照,一次拉全 terms/group_keywords/heatmap/river | **必调**(fallback: 读 `data/raw/YYYYMMDD/weflow_snapshot.json`) |
| `get_hot_terms` | 通用热词排行 + citations 原文 | snapshot 无 citations 时补 |
| `get_river` | 热词时间序列(河流图) | 判断"新词发酵中/老词过气"必用 |

**B. 股票/概念映射层**（关键 · 群聊情绪→个股 收敛路径,3 个工具**每个都要调**）:

| 工具 | 用途 | 硬调用位置 |
|------|------|---------|
| `get_stock_hot_terms` | **A 股股票热词排行**(直接给个股) | Step 3.1 · 拿到 Top20 个股 → 与 R2 主线板块交叉 |
| `get_concept_hot_terms` | **概念/题材热词排行** | Step 3.2 · 概念权重 → 映射到板块共振等级 |
| `get_concept_linked_stocks` | **概念→共现股票 + edge_weight** | Step 3.3 · 对 Step 3.2 每个热概念调一次,edge_weight ≥ 阈值的股票 |

### vibe-trading MCP 补充（2026-08-06 新增 · 情绪量化交叉验证）

**目的**：R3 用 weflow 群聊语义 + Tushare 热榜，vibe-trading 提供独立量化基准（基本面/筹码/资金）作交叉验证，提升情绪判断置信度。

| 工具 | 调用方式 | 典型问句 | 返回字段 |
|------|---------|---------|---------|
| `vibe_trading__iwencai_search` | NL 问句 | `基本面：{个股} ROE>15% 近3年持续，PEG<1` | 财务数据表 |
| `vibe_trading__iwencai_search` | NL 问句 | `筹码：{个股} 股东户数环比降幅>10%`（机构收集信号） | 股东户数序列 |
| `vibe_trading__iwencai_search` | NL 问句 | `量价：{个股} 近5日主力净流入占比>5%` | 资金流表 |
| `vibe_trading__get_stock_news` | ts_code | R3 热股池每只，查近5日新闻标题 | 新闻列表 |
| `vibe_trading__get_block_trades` | ts_code | 查近10日大宗交易（溢价率>0 = 主力接盘信号） | 大宗交易表 |

**调用时序**：Step 3.3（概念→个股）完成后，对 edge_weight top 20 股票 → `iwencai_search` 基本面/筹码验证。  
**节流**：对 top 5 热股详细验证，其余 top 20 仅做筹码初筛；全 skill ≤ 10 次调用。  
**降级**：`vibe_trading__iwencai_search` 失败 → 直接用 R3 已有 weflow + Tushare 数据。

**调用顺序范式**(不许颠倒):

```python
# Step 3.1 通用坐标
snapshot = mcp_weflow_analytics_export_analytics_snapshot()
# Step 3.2 概念热度
concepts = mcp_weflow_analytics_get_concept_hot_terms(top_n=30)
# Step 3.3 概念→股票(核心动作)
for concept in concepts[:15]:
    linked = mcp_weflow_analytics_get_concept_linked_stocks(concept=concept.term)
    # linked.edges: [{stock_code, stock_name, edge_weight, chatroom_count}, ...]
# Step 3.4 股票直接热词(交叉验证 3.3)
stock_terms = mcp_weflow_analytics_get_stock_hot_terms(top_n=50)
```

**产出契约**:每只被 R3 命中的股票必须在 `sources_hit.weflow[]` 里写清 `{concept, edge_weight, chatroom_count, evidence_citation}` 四字段,缺一不可。

**降级**:整段 MCP 失联 → 读 `weflow_snapshot.json`,标 `weflow_degraded=true`,B 层三工具产出全部置空(**不许**用 A 层通用热词硬套个股)。

**语义映射要求（关键）**:

- WeFlow 热词（如「特斯拉产线」「Optimus」「人形」）须通过 **语义等价/上下位关系** 映射到 A 股板块/概念名（如「机器人」「特斯拉链」），**不得**仅做字符串 `in` 匹配  
- 记录映射理由到 `sources_hit.weflow`（例：「WeFlow 热词『产线启动』语义→板块『机器人』，3 群共提及」）  
- 若语义无法可靠映射 → 该词进 `unmapped_weflow_terms[]`，**不得**强行归入共振主题

---

## 输入文件

### `data/raw/YYYYMMDD/`（必需）

| 文件 | 用途 |
|------|------|
| `manifest.json` | severity |
| `wechat_cli_5groups.jsonl` | Layer 2 KOL |
| `weflow_snapshot.json` | Layer 3（可选） |
| `mcp_health.json` | 源存活 |

### 可选 upstream

| 路径 | 用途 |
|------|------|
| `data/research/YYYYMMDD/R1_style.json` | `sentiment_score` 基准（`status=complete` 时） |
| `chzl_kg/主线/*.md` | 长期主线交叉 |

---

## 共振等级枚举（WeFlow 下线后，双源为最高）

| 等级 | 含义 |
|------|------|
| `L1_only` | 仅热榜 — **不算正向共振**，`early_or_late: late` |
| `L1+L2` | 热榜 + KOL — 当前**最高可达等级**，`middle` |
| `L2_only` | 仅 KOL — 单源，**不进入** `resonance_top_themes`（红线 4） |

**旧 `L1+L3` / `L1+L2+L3` / `L2+L3_only` 等级已随 WeFlow 下线移除。**

**单源（仅 L2 或仅 L1）** → 跳过，不进入 `resonance_top_themes`（红线 4）。

---

## 执行步骤

### Step 1 · Layer1 热榜 diff

Tushare `ths_hot` 今/昨 → 计算：

- `rank_momentum_up`（排名上升 ≥10）  
- `new_in_top`（新进 top20）  
- `distribution_alert`（**霸榜 ≥2 日 top1** → 待资金交叉的出货警报，不是单独hard_reject或机械扣分）

#### 必交：出货警报的已查范围与阴性证据

在`hotlist_signals.distribution_alert_checks`数组逐已查对象写：`target_type`（stock/sector）、`ts_code`或`sector_id`、`observed_at`、`window_start`/`window_end`、`source`、`evidence_refs`、`check_status`（checked/unknown）及`distribution_alert`（true/false/null）。精确代码/板块映射与连续榜单窗口可核才标checked；实际检查后未命中才false，已命中为true，缺页、缺前日榜单、对象未覆盖或尚未查为null/unknown并写原因。保留原命中列表作为兼容正例，不将其空数组或缺某票等同false。

R3早于R2，只声明实际热榜/KOL已覆盖范围；不用当时不存在的最终候选名单伪造逐票完成，也不为模式6新增全市场扫描。后续候选可精确关联到已检查的板块/对象及同窗口时，R6才可消费其结果；范围外仍未知，交R3原生产权限协调补证，不交禁MCP的R6抓取。

辅助KOL、热榜渠道缺失局部降级，不全局禁买；优先为已有核心热榜对象形成可核结果。热度本身不能证明派发，既有alert+近5日资金净流出硬否决仍由R6按原条件独立核定。

### Step 2 · Layer2 KOL 语义抽取

读 `wechat_cli_5groups.jsonl`，对 5 群分别产出 `kol_summary[]`：

```yaml
source: 颜晓滨群
time: 2026-07-02 23:50
view: "资金切 AI 应用/机器人/商业航天"
valid_period: 1-3 天
sectors_semantic: [AI应用, 机器人, 商业航天]  # LLM 抽取，非 regex
```

### Step 3 · 语义归并与兼容字段

对实际可用的群聊观点与热榜主题做语义归并，记录映射依据及底层来源独立性。跳过WeFlow调用与历史快照；`sources_hit.weflow`、`unmapped_weflow_terms`置空，保留降级说明。

### Step 4 · 跨源共振打分

对每个主题名（统一用 A 股板块/概念标准名）：

1. 判定 `resonance_level`  
2. 填 `sources_hit`: `{weflow, kol_text[], hotlist{}}`  
3. `suggested_sectors`, `suggested_stocks`（龙头用 dc_concept lead_stock 或 KOL 点名，排除 ST）  
4. `early_or_late`: `early` | `middle` | `late`  
5. 排序取 **top 5** → `resonance_top_themes`

### Step 5 · 情绪浓度

- 基准：检查R1观测时点、状态和依据，确认符合本次窗口后使用其`sentiment_score`；没有有效量化基准时标缺失，不填默认50伪装测量值。
- 调整：仅使用实际可验证的`L1+L2`证据并写明规则，不使用WeFlow或撤销的三源等级。
- 纯文本临时问答不计算市场分；正式产物缺量化依据时不得宣称完整通过验收。
- 写入`sentiment_score_basis`与证据观测时间，区分数据质量置信度、主题集中度及市场情绪分。

**v1.1 · 2026-08-06 新增 · `@市场情绪分析` 5 维度加权法**（作为反向校验）：

```
score_5d ≈ 0.25 × 涨停强度 + 0.20 × 跌停压制 + 0.20 × 连板结构
         + 0.15 × (100 - 4×炸板率) + 0.20 × 杠杆外资中位
```

R3 现行 `sentiment_score`（多源共振基准） 与 `score_5d`（5 维度加权）**差 > 15 分时**，在 `sentiment_score_basis` 注明：`r3_vs_5d_gap: XX, reason: "5 维度法偏重连板结构" / "5 维度法缺杠杆外资数据"`。R3 **不接管**市场情绪 skill 的输出，只是双源交叉。

### Step 6 · 数据源健康度

`sources_status`: weflow / wechat_cli_by_group / hotlist / xtick

### Step 7 · 写盘

`data/research/YYYYMMDD/R3_sentiment.json`

---

## 产出 JSON 契约（核心字段）

```json
{
  "schema_version": "research_unit_v1",
  "agent": "R3",
  "trade_date": "20260704",
  "generated_at": "2026-07-04T07:38:00+08:00",
  "status": "complete",
  "confidence": 0.75,
  "sentiment_score": 75,
  "sentiment_score_basis": {"r1_baseline": 70, "resonance_adjustment": 5},
  "resonance_top_themes_count": 3,
  "resonance_top_themes": [
    {
      "rank": 1,
      "theme_name": "机器人",
      "resonance_level": "L1+L2",
      "sources_hit": {
        "weflow": [],
        "kol_text": ["颜晓滨@23:50: 资金切入机器人"],
        "hotlist": {"rank_momentum_up": "rank 32→18"}
      },
      "suggested_sectors": ["机器人", "特斯拉链"],
      "suggested_stocks": ["002050三花智控"],
      "early_or_late": "middle"
    }
  ],
  "kol_summary": [],
  "hotlist_signals": {
    "rank_momentum_up": [],
    "new_in_top": [],
    "distribution_alert": [],
    "distribution_alert_checks": [
      {"target_type": "stock", "ts_code": "002050.SZ", "sector_id": null,
       "observed_at": null, "window_start": null, "window_end": null,
       "source": null, "evidence_refs": [], "check_status": "unknown",
       "distribution_alert": null, "reason": "仅为字段示意，未查不能照抄true或false"}
    ]
  },
  "unmapped_weflow_terms": [],
  "sources_status": {},
  "method": "llm_v1"
}
```

---

## 红线

1. ❌ 不做板块排序（R2）  
2. ❌ 不做个股画像（R5）  
3. ❌ **`L1_only` 不得标为强共振**  
4. ❌ 霸榜按既有连续窗口形成出货警报，不等于已证实出货；不得将警报自身作为正向共振，也不得从无alert推阴性
5. ✅ `sentiment_score` 0–100 且给依据  
6. ✅ WeFlow 映射必须 **语义级**，禁止纯 keyword 子串

---

## 降级（spec §7）

| 失效 | 处理 |
|------|------|
| WeFlow 死 | 不阻塞；L1+L2 继续 |
| wechat-cli 全死 | 仅热榜，群聊观点缺失，不构造双源共振 |
| tushare 热榜死 | 核验其他热榜后与KOL交叉；新闻不能冒充量化热榜 |
| 全主源死 | 有效文本仅作定性摘要；标缺失与`severity=3`，不计算市场情绪分 |

---

## chzl_kg 人读 md 落盘（必需 · @render_kg_md_v1）

**契约来源**: `skills/_shared/render_kg_md_v1/SKILL.md`

除机读 JSON 落盘之外，本 skill 必须**同时**渲染一份人读 md 到 chzl_kg 供用户当日审阅。

### 落盘路径

```
chzl_kg/投研交易/群聊情绪/{trade_date}.md
```

（目录若不存在，`mkdir -p` 创建。）

### frontmatter（必填，UTF-8 · Unix 换行）

```yaml
---
date: {trade_date YYYY-MM-DD}
agent: R3-sentiment-resonance
skill_version: analyze_sentiment_resonance_v1@1.0
generated_at: {ISO 8601 · 落盘时刻 · 含时区}
confidence: {从本 skill JSON artifact 读；缺则 null}
degraded: {true|false}
data_sources:
  - name: {源标识}
    path: {data/raw/... 或 MCP 名}
    status: {ok|error|timeout|stale}
    captured_at: {ISO 8601 或 null}
    record_count: {整数或 null}
    error: {可选 · 简短错误串}
input_freshness: {ok|partial|stale}
input_freshness_note: {任一源非 ok 时必填的说明}
---
```

### 正文（Markdown）

```markdown
# {trade_date 中文日期} · **群聊情绪共振**

> **数据源新鲜度**: {input_freshness}
> **降级状态**: {degraded}
> **置信度**: {confidence}

## 一句话结论
{≤ 60 字核心判断}

## 详细分析
{3-5 段主体}

## 关键证据
- 证据 1: {内容} · 来源 {data_source}
- 证据 2: ...
- 证据 3: ...

## 数据源审计
| 源 | 状态 | 抓取时间 | 记录数 | 备注 |
|---|---|---|---|---|
...

## 不确定性 / 反证
{自我批判段}

## 与其他 R/D/E 的关系
- 依赖: {上游 artifact 列表}
- 被消费: {下游 skill 列表}

## Sub-Agent 元数据
- skill: analyze_sentiment_resonance_v1
- artifact: data/.../{...}.json
- 生成耗时: N 秒
- model: {model 名}
```

### 落盘规则

1. **atomic write**: 先写 `.tmp` → `mv` 到目标（避免 Obsidian 抓半写）
2. **overwrite**: 同日重跑覆盖；若目标已存在先备份为 `.md.bak`
3. **失败不阻塞**: md 渲染失败**不**回滚 JSON artifact 落盘；skill status 写 `partial` 并在汇报中标注

### 验收

盘后 `test -f chzl_kg/投研交易/群聊情绪/{trade_date}.md` 必须为 true；前 30 行满足 frontmatter schema。

---

## 写作契约(v1 · 2026-07-06 硬约束升级)

本 skill 输出的 md **必须**遵循 `skills/_shared/canghai_writing_contract_v1.md`,该契约定义了:

1. **写作风格锚点** — 对标 `样例/20260630_pre_open_plan.md`,表格化 + emoji + 因果句 · 禁 python dump JSON / 群名裸露 / 时分秒
2. **必含 mermaid 图表**(≥1 张 · 节点 ≥ 8) — 本 skill 推荐类型见契约
3. **推理深度三问** — 每个 top 分析对象显式回答 `**大资金意图**` / `**为什么走强**` / `**逻辑够不够硬**`
4. **每票思维链**(≥4 段) — 首推票必附 `**买入理由**` / `**风险点**` / `**止损条件**` / `**可验证假设**`
5. **数据源审计表** — 三色 emoji · 日期无时分秒 · 群名匿名化 · 主源缺失即 degraded=true

**验收硬门槛**: md 落盘后逐条自检契约第六节六项,任一缺失即 skill 状态 `partial`,视为执行失败须重跑。

## Version History (writing contract)

- v1 (2026-07-06): 加入沧海写作契约 · 覆盖 R1-R7 + D1
