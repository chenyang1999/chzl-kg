"""
core_judge.py · 个股核心地位判定 + 共振/逆势检测（2026-09-04 · 游资交易纪律落地）

目标: 回答「这只票是不是核心 / 有没有地位 / 是共振还是逆势抱团」。
纪律依据（新生代游资交易纪律.md）:

    开仓资格: 个股有市场地位——能带板块、能带跟风赚钱效应，或明确是低位复制最强效应
    龙头认定(过3条): 高度辨识度 / 逻辑硬 / 能带动板块 / 容量换手够
    合力认定: 龙头上板后板块出现跟风涨停; 大单砸封单增; 该弱不弱视为强
    核心判定(用户 2026-09-04): 个股主动与否看分时、看板块与指数是共振还是逆势抱团

三个量化判定:
    A. 共振 vs 逆势抱团: 个股 20 日走势与所属板块、大盘的相关系数
        共振(高相关)      = 跟随板块/大盘，正常联动
        逆势抱团(低/负相关) = 严重偏离板块大盘独自走 → 抱团炒作或庄家控盘嫌疑
    B. 带动性(能否带板块): 个股涨停后，同板块其他票的跟随度/板块当日强度
    C. 核心地位综合分: 连板高度 + 板块内排名 + 带动性 + 资金流入 的加权
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any

import numpy as np


@dataclass
class CoreJudgeResult:
    trade_date: str
    ts_code: str
    name: str
    is_core: bool                    # 是否核心票
    core_grade: str                  # leader / core / laggard / watch
    correlation_stock_sector: float  # 个股 vs 板块 20日相关
    correlation_stock_index: float   # 个股 vs 大盘 20日相关
    resonance_type: str              # resonance共振 / anti_rotation逆势抱团 / neutral
    leading_score: float             # 带动性得分 0-1
    composite_score: float           # 核心地位综合分 0-100
    evidence: list = field(default_factory=list)
    generated_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _corr(a: list[float], b: list[float]) -> float:
    """皮尔逊相关系数，长度不足或方差为0返回0。"""
    if len(a) < 5 or len(b) < 5:
        return 0.0
    aa, bb = np.array(a, dtype=float), np.array(b, dtype=float)
    if aa.std() == 0 or bb.std() == 0:
        return 0.0
    return float(np.corrcoef(aa, bb)[0, 1])


def judge_core(
    trade_date: str,
    ts_code: str,
    name: str,
    stock_returns: list[float],       # 个股近20日日收益率
    sector_returns: list[float],      # 所属板块近20日日收益率
    index_returns: list[float],       # 大盘(如沪深300/上证)近20日日收益率
    limit_times: int,                 # 连板高度
    sector_rank: int,                 # 板块内涨幅排名（1=最强）
    sector_size: int,                 # 板块内成分股数量
    money_inflow_pct: float,          # 主力净流入占成交额比
    sector_limit_up_count: int = 0,   # 板块内今日涨停家数（带动性）
) -> CoreJudgeResult:
    """
    判定个股核心地位。输入全部可由 tushare daily / daily_basic / moneyflow 计算。
    """
    evidence: list[str] = []

    # ── A. 共振 vs 逆势抱团 ──
    corr_sector = _corr(stock_returns, sector_returns)
    corr_index = _corr(stock_returns, index_returns)

    if corr_sector >= 0.6:
        res_type = "resonance"
        evidence.append(f"个股-板块 20日相关 {corr_sector:.2f} ≥ 0.6 → 共振（跟随板块，正常联动）")
    elif corr_sector <= -0.2 or (corr_sector < 0.3 and corr_index < 0.2 and abs(corr_sector) < 0.3):
        # 与板块弱相关/负相关 + 与大盘也低 → 独自运行，逆势抱团/控盘嫌疑
        res_type = "anti_rotation"
        evidence.append(
            f"个股-板块相关 {corr_sector:.2f}、个股-大盘相关 {corr_index:.2f} 均低 → 逆势抱团/独立运行，注意控盘"
        )
    else:
        res_type = "neutral"
        evidence.append(f"个股-板块相关 {corr_sector:.2f} → 中性联动")

    # ── B. 带动性（龙头认定核心） ──
    # 简化代理: 板块内涨停家数多 + 个股排名靠前 = 有带动性（真龙头能带板块）
    leading_score = min(1.0, sector_limit_up_count / 5.0) * 0.5 + (1.0 - min(1.0, sector_rank / 10.0)) * 0.5
    if sector_limit_up_count >= 3:
        evidence.append(f"板块内 {sector_limit_up_count} 家涨停（≥3）→ 有板块效应，带动性强")
    if sector_rank <= 3:
        evidence.append(f"板块内涨幅第 {sector_rank}（≤3）→ 板块前排，有辨识度")

    # ── C. 综合得分 ──
    score = (
        min(1.0, limit_times / 5.0) * 30          # 连板高度 30%
        + (1.0 - min(1.0, sector_rank / 10.0)) * 25  # 板块排名 25%
        + leading_score * 25                        # 带动性 25%
        + min(1.0, max(0.0, money_inflow_pct / 0.05)) * 20  # 资金流入 20%
    )
    # 共振票才有资格当核心（逆势抱团默认降级——可能控盘，非市场合力）
    if res_type == "anti_rotation":
        score *= 0.6
        evidence.append("逆势抱团 → 综合分 ×0.6（可能是控盘而非市场合力）")

    if score >= 75 and res_type != "anti_rotation":
        is_core, grade = True, "leader"
        evidence.append(f"综合分 {score:.0f} ≥ 75 且共振 → 核心龙头")
    elif score >= 55:
        is_core, grade = True, "core"
        evidence.append(f"综合分 {score:.0f} ≥ 55 → 板块核心（中军/前排）")
    elif score >= 35:
        is_core, grade = False, "laggard"
        evidence.append(f"综合分 {score:.0f} → 跟风/补涨，非核心")
    else:
        is_core, grade = False, "watch"
        evidence.append(f"综合分 {score:.0f} → 观察，无地位")

    return CoreJudgeResult(
        trade_date=trade_date,
        ts_code=ts_code,
        name=name,
        is_core=is_core,
        core_grade=grade,
        correlation_stock_sector=round(corr_sector, 3),
        correlation_stock_index=round(corr_index, 3),
        resonance_type=res_type,
        leading_score=round(leading_score, 3),
        composite_score=round(score, 1),
        evidence=evidence,
        generated_at=datetime.now().astimezone().isoformat(timespec="seconds"),
    )


if __name__ == "__main__":
    # 自测样例
    import random
    random.seed(42)
    base = [random.uniform(-0.02, 0.02) for _ in range(20)]

    # 共振龙头: 跟随板块强相关 + 板块3家涨停 + 板块内第1
    ret = [b * 1.2 + random.uniform(-0.005, 0.005) for b in base]
    r1 = judge_core("20260904", "002050.SZ", "三花智控", ret, base, [b * 0.8 for b in base],
                    limit_times=4, sector_rank=1, sector_size=30, money_inflow_pct=0.06, sector_limit_up_count=5)
    print(f"{r1.name}: {r1.core_grade} ({r1.composite_score}) | {r1.resonance_type} 相关板块={r1.correlation_stock_sector}")
    print(f"   {'是核心' if r1.is_core else '非核心'} | {r1.evidence[0]}")

    # 逆势抱团庄股: 与板块负相关
    anti = [-b + random.uniform(-0.01, 0.01) for b in base]
    r2 = judge_core("20260904", "600000.SH", "疑似庄股", anti, base, base,
                    limit_times=3, sector_rank=1, sector_size=30, money_inflow_pct=0.04, sector_limit_up_count=1)
    print(f"{r2.name}: {r2.core_grade} ({r2.composite_score}) | {r2.resonance_type} 相关板块={r2.correlation_stock_sector}")
    print(f"   {'是核心' if r2.is_core else '非核心'} | {r2.evidence[0]}")

    # 跟风杂毛: 低高度 + 板块内中游
    r3 = judge_core("20260904", "300001.SZ", "跟风票", ret, base, base,
                    limit_times=1, sector_rank=12, sector_size=30, money_inflow_pct=0.005, sector_limit_up_count=0)
    print(f"{r3.name}: {r3.core_grade} ({r3.composite_score}) | {r3.resonance_type}")
    print(f"   {'是核心' if r3.is_core else '非核心'} | {r3.evidence[0]}")
