"""
board_pattern.py · 板型识别 + 时间节点 + 弱转强 (2026-09-04 · 游资心法落地)

心法依据（《新生代游资核心观点整理.md》）:

    北京炒家 §1.5 (板型):
      换手板  5-8 个点横够久(半小时级)再一笔上板
      回封板  炸后回封, 空头卖完; 多次打开/尾盘封=弱
      秒拉板  快速打到涨停, 排板优于冲; 需有板块效应
      中军板  行业一提就想到的名企
      尾盘板  14:00-14:30 后的少打; 14:30 后=投机板(几乎不碰)
      反包    总龙首阴反包; 大资金舒适区偏反包二板

    时间节点:
      竞价秒板 09:25-09:30 集合竞价直接封涨停
      午前秒板 09:30-10:30 一笔打到涨停
      午后秒板 13:00-14:00
      尾盘拉   14:00-14:30 (视为投机)
      尾盘封板 14:30+ (最差)

    92科比 §3.3.27 (弱转强):
      烂板一般第二天竞价会很低, 但开盘后买盘很凶=弱转强
      强转强=卖点 (强转弱概率大)

数据来源: limit_list_d 自带字段
  first_time  首次封板时间(HHMMSS)
  last_time   最后封板时间
  open_times  炸板次数
  limit       涨停状态(U/Z)
  amount      当日成交额
  limit_amount 封单金额
  limit_times 连板数

使用:
    from src.research.board_pattern import classify_pattern
    r = classify_pattern(
        first_time="95857",   # 9:58:57
        last_time="100103",
        open_times=0,
        amount=5e8,
        limit_amount=3e8,
        limit_times=3,         # 3连板
    )
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any


# 时间段定义(秒数, 09:25 集合竞价开始)
def _hhmmss_to_sec(s: str | int | None) -> int | None:
    """'95857' / 95857 / int → 自 00:00 起的秒数."""
    if s is None or s == "":
        return None
    try:
        s = int(str(s).strip())
        s = max(0, min(235959, s))
        return (s // 10000) * 3600 + ((s % 10000) // 100) * 60 + (s % 100)
    except Exception:  # noqa: BLE001
        return None


def _sec_to_hhmmss(sec: int) -> str:
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


@dataclass
class BoardPatternResult:
    ts_code: str
    trade_date: str
    pattern: str                    # 板型
    pattern_action: str            # 该板型怎么做
    time_window: str                # 竞价/午前/午后/尾盘
    is_weak_to_strong: bool         # 是否弱转强(隔日判定)
    is_strong_to_weak: bool         # 是否强转弱
    limit_amount_ratio: float       # 封单金额/成交额, 衡量承接
    open_times: int
    confidence: float
    evidence: list = field(default_factory=list)
    generated_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


# 心法原文 → 板型判定规则
def classify_pattern(
    ts_code: str,
    trade_date: str,
    first_time: str | int | None,
    last_time: str | int | None,
    open_times: int,
    amount: float,
    limit_amount: float,
    limit_times: int,
    *,
    prev_open_times: int | None = None,   # 昨炸板次数 → 弱转强判定
    prev_pct_chg: float | None = None,    # 昨涨幅 → 弱转强判定
    today_pct_chg: float | None = None,   # 今日涨幅 (开板幅度)
    sector_limit_up_count: int = 0,        # 板块今日涨停家数(板块效应)
    avg_amount_5d: float | None = None,    # 5日均量(放量/缩量)
) -> BoardPatternResult:
    """
    板型识别 + 时间节点 + 弱转强判定.
    """
    fts = _hhmmss_to_sec(first_time)
    lts = _hhmmss_to_sec(last_time)
    evidence: list[str] = []

    # ── A. 时间节点 ──
    # 一字板信号 (2026-09-06 周末会议纪要落地)
    # 92 科比 §3.3.27: "一字二板定真龙" → 09:25集合竞价即封板+0开板 = 板块启动信号
    # 陈小群 §2.9.7: "龙头急拉后前一两次分歧转强点补涨"
    is_yizi_open_signal = bool(
        fts is not None and fts <= 9 * 3600 + 25 * 60  # ≤ 09:25 集合竞价
        and open_times == 0                              # 全天未开
        and amount is not None and limit_amount is not None
        and limit_amount >= amount * 0.5                # 封单 ≥ 半天成交额(强势一字)
    )
    if is_yizi_open_signal:
        time_window = "一字板(09:25集合竞价封板)"
    elif fts is None:
        time_window = "未知"
    elif fts < 9 * 3600 + 30 * 60:  # 09:30 集合竞价
        time_window = "竞价秒板"
    elif fts < 10 * 3600:
        time_window = "午前秒板"
    elif fts < 11 * 3600 + 30 * 60:
        time_window = "午前封板"
    elif fts < 13 * 3600 + 30 * 60:
        time_window = "午间封板"
    elif fts < 14 * 3600 + 30 * 60:
        time_window = "尾盘封板(14:00-14:30)"
    else:
        time_window = "尾盘投机(14:30+)"
    evidence.append(f"首次封板时间 {first_time} → {time_window}")

    # ── B. 封单强度 = 封单金额/成交额 ──
    limit_amount_ratio = (limit_amount / amount) if amount > 0 else 0.0

    # ── C. 板型分类(按北京炒家 §1.5 案例级) ──
    # 优先级: 1) 多次开板=回封板 2) 0 次开板按时间分(秒/中军) 3) 尾盘单独
    if open_times >= 2:
        pattern = "回封板(多次开板)"
        pattern_action = "❌ 多次开板已较弱, 不碰; 若硬要只看最后封死的一笔"
        evidence.append(f"开板{ open_times }次(≥2) → 多次开板=弱, 北京炒家明言'多次打开/尾盘才封的就弱了'")
    elif open_times == 1 and fts and fts < 14 * 3600 + 30 * 60:
        # 1 次开板 + 14:30 前 = 正常回封板(北京炒家 §1.5.2: 炸后回封空头卖完)
        pattern = "回封板(1次开板)"
        pattern_action = "⚠️ 1 次开板+午前=回封板, 空头削弱; 需结合题材/板型判断(尾盘炸=弱)"
        evidence.append(f"开板 1 次 + {time_window} → 回封板, 北京炒家'炸后回封, 空头卖完'")
    elif fts and fts >= 14 * 3600 + 30 * 60:
        # 14:30 后封板 → 尾盘板(投机)
        if open_times >= 1:
            pattern = "尾盘投机板"
            pattern_action = "❌ 14:30 后点火板, 几乎不碰; 北京炒家'两点半以后的板叫投机板'"
        else:
            pattern = "尾盘板"
            pattern_action = "⚠️ 尽量不打; 只打高位久横换手板, 需主模板允许"
        evidence.append("尾盘板: 北京炒家明言'两点半以后的板叫投机板, 不建议频繁打'")
    elif fts and fts < 10 * 3600:
        # 10:00 前封板 = 秒拉板
        pattern = "秒拉板"
        if sector_limit_up_count >= 3:
            pattern_action = "⚠️ 需有板块效应(前排已红), 优先排板不冲"
            evidence.append(f"秒拉板 + 板块{ sector_limit_up_count }家涨停(≥3) → 板块效应强, 可排不可冲")
        else:
            pattern_action = "❌ 无板块效应(前排无红), 封住概率低, 不碰"
            evidence.append(f"秒拉板 + 板块仅{ sector_limit_up_count }家涨停(<3) → 无板块效应, 弃")
    elif fts and 10 * 3600 <= fts < 11 * 3600 + 30 * 60:
        # 10:00-11:30 封板 = 午前封板
        if open_times == 0 and avg_amount_5d and amount >= avg_amount_5d * 0.8:
            # 放量+无开板=午前强势封板
            if limit_times >= 2:
                pattern = "换手板(午前)"
                pattern_action = "✅ 可扫; 半小时级横盘后一笔上板最稳; 龙头股优先"
                evidence.append(f"午前封板 + 0 开板 + 放量({amount/max(avg_amount_5d,1):.1f}x 5日均) → 换手板")
            else:
                pattern = "中军板(午前)"
                pattern_action = "✅ 行业一提就想到的名企, 下午若打优先中军"
                evidence.append("午前封板 + 0 开板 + 首板 → 中军板, 容量大")
        else:
            pattern = "午前封板(普通)"
            pattern_action = "⚠️ 午前封但量/换手不够, 改排板不扫"
            evidence.append("午前封板但量/换手不及格, 不扫")
    elif fts and 11 * 3600 + 30 * 60 <= fts < 14 * 3600:
        # 11:30-14:00 = 午间/午后
        pattern = "午后封板(午间)"
        pattern_action = "⚠️ 14:00 前可做, 但要走换手板逻辑(高位久横)"
        evidence.append("午后封板(11:30-14:00), 14:00 前勉强可做, 14:00 后基本不碰")
    elif fts and 14 * 3600 <= fts < 14 * 3600 + 30 * 60:
        # 14:00-14:30 = 尾盘封板
        if open_times >= 1:
            pattern = "尾盘投机板"
            pattern_action = "❌ 14:00-14:30 后的板, 北京炒家'两点半以后的板叫投机板'"
        else:
            pattern = "尾盘封板(14:00-14:30)"
            pattern_action = "⚠️ 尽量不打; 只打高位久横换手板, 需主模板允许"
        evidence.append("14:00-14:30 尾盘板: 北京炒家'两点半以后少打'")
    elif fts and fts >= 14 * 3600 + 30 * 60:
        # 14:30+ = 投机板
        pattern = "尾盘投机板(14:30+)"
        pattern_action = "❌ 14:30 后点火板, 几乎不碰"
        evidence.append("14:30+ 投机板: 北京炒家明言'两点半以后不建议频繁打'")
    else:
        pattern = "未知"
        pattern_action = "数据不足, 跳过"

    # ── D. 弱转强/强转弱(92科比) ──
    is_weak_to_strong = False
    is_strong_to_weak = False
    if prev_open_times is not None and prev_pct_chg is not None and today_pct_chg is not None:
        # 烂板(昨炸板≥1) + 今日转强(开盘买盘凶) → 弱转强
        if prev_open_times >= 1 and today_pct_chg >= 9.5:
            is_weak_to_strong = True
            evidence.append(f"昨炸板{ prev_open_times }次 → 今日涨停, 弱转强 ✅(92科比: 烂板后买盘凶=弱转强)")
        # 昨日涨停但今日弱 → 强转弱
        if prev_pct_chg >= 9.5 and today_pct_chg < 5.0:
            is_strong_to_weak = True
            evidence.append(f"昨涨停+今日 {today_pct_chg:.1f}%(<5%) → 强转弱 ❌(92科比: 第三天可能强转弱, 卖点)")

    # ── E. 综合置信度 ──
    conf = 0.7
    if fts and lts and open_times is not None and amount > 0:
        conf = 0.9
    elif fts and lts:
        conf = 0.75

    return BoardPatternResult(
        ts_code=ts_code,
        trade_date=trade_date,
        pattern=pattern,
        pattern_action=pattern_action,
        time_window=time_window,
        is_weak_to_strong=is_weak_to_strong,
        is_strong_to_weak=is_strong_to_weak,
        limit_amount_ratio=round(limit_amount_ratio, 3),
        open_times=open_times,
        confidence=conf,
        evidence=evidence,
        generated_at=datetime.now().astimezone().isoformat(timespec="seconds"),
    )


if __name__ == "__main__":
    # 自测样例
    cases = [
        # (code, name, first_time, last_time, open_times, amount, limit_amount, limit_times,
        #  sector_limit_up_count, [prev_open_times, prev_pct_chg, today_pct_chg])
        # 北京炒家 §1.5 案例(全数据)
        ("603022.SH", "天娱数科_秒拉板",  "95857",  "95857", 0, 5e8, 3e8, 2, 4),
        ("600076.SH", "雪人股份_回封板",  "103300", "140123", 2, 4e8, 1e8, 1, 3),
        ("600702.SH", "舍得酒业_换手板",  "105430", "105430", 0, 6e8, 2e8, 1, 5),
        ("002460.SH", "赣锋锂业_尾盘",    "142130", "142130", 0, 8e8, 3e8, 1, 2),
        ("601933.SH", "永辉超市_中军板",  "110130", "110130", 0, 1.2e9, 4e8, 1, 6),
        # 弱转强: 昨炸板, 今日涨停
        ("600519.SH", "弱转强_示例",  "93857",  "100103", 0, 1e9, 4e8, 2, 5, 3, 9.8, 10.0),
    ]
    for c in cases:
        code, name = c[0], c[1]
        fts, lts, opn, amt, lam, lt, sector = c[2], c[3], c[4], c[5], c[6], c[7], c[8]
        if len(c) >= 12:
            r = classify_pattern(code, name, fts, lts, opn, amt, lam, lt,
                                 sector_limit_up_count=sector,
                                 prev_open_times=c[9], prev_pct_chg=c[10], today_pct_chg=c[11])
        else:
            r = classify_pattern(code, name, fts, lts, opn, amt, lam, lt,
                                 sector_limit_up_count=sector)
        print(f"{code} [{name}]")
        print(f"  板型: {r.pattern} | 时间: {r.time_window} | 封单占比: {r.limit_amount_ratio:.1%}")
        print(f"  做法: {r.pattern_action}")
        print(f"  弱转强={r.is_weak_to_strong} 强转弱={r.is_strong_to_weak} 置信度={r.confidence}")
        print()
