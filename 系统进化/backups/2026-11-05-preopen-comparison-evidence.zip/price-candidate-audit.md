# 20261105 逐票资格／价格消费者／策略收缩审计（只读）

## 结论

- 当前22票不是被持久价格算法算坏后逐个淘汰。22票均已有D1选择的单一 `leader_breakout`、非空买区和顶层/退出三价；实际 `buy_eligibility.reasons` 全是 `STOCK_NO_TRADE_CONDITION`，发生在价格读取前。
- 确认的当日组装问题：全22票都被写入同一个 active `RIGHT_SIDE_CORE_NOT_VERIFIED`。主控提供的本次真实会话证据为 canghai-plan `local-8db93012...` 消息5360：在 `for c,p in profiles.items()` 内无条件 `local.append(...)`，早于5362 `apply_to_plan`。本子审未重新调取该长会话，执行顺序证据归主控；冻结JSON独立确认22/22落盘。应称“本轮LLM现场组装把待核上下文统一物化为硬阻断”，不是“价格引擎全票误杀”。
- 北方华创和备份差异首先是板块划分/角色和打法选择：本版是封测主线的设备候补龙三；备份网页自报设备龙一、反抽承接+突破二选一。本版未产出第二通道，不能说已产出后被运输丢掉。
- 独立阻塞仍在：21票R6必要审核未齐，6票战术项，2票R6硬否决；新易盛是唯一必要审核完整者，仍被统一右侧阻断。福莱原价RR=1.78<1.8也是独立价格拒绝，当前被前置条件遮蔽。
- 不把识图一致性升级成必过门禁。北方548.17途中压力是辅助人工复核证据，不是本次统一阻断来源。

## 范围、证据等级与时间

主根为本报告同目录冻结 plan/md/R1-R7/skills/source，plan generated_at=2026-11-05T09:17:53+08:00，事实日20261104，意见有效至09:30。没有使用09:30后行情解释盘前，也未补抓行情、模型重跑、测试/模拟、交易或读取settings/凭据/账户。只执行冻结纯资格函数对原对象的只读求值，以及AST抽取 validate_nodes 对原已落盘三价的诊断；没有改输入再执行反事实。

冻结根没有 `scripts/plan/apply_price_levels.py`、`src/research/core_judge.py`、`src/research/board_pattern.py` 和心法原文；这些使用仓库当前源码/原文只读补链，不冒充已经被冻结的当日调用字节。主控的真实会话证据补足现场组装，不以当下源码反推当日执行。

## 审计发现ID

### PC-01【当日已触发／LLM组装契约冲突】统一右侧门禁

位置：plan `/watch_pool/{i}/no_trade_conditions` 中 code=`RIGHT_SIDE_CORE_NOT_VERIFIED`，22/22 active=true；`/data_sources/entry_channels` 明列仅leader_breakout；22个`core_judge.status=unknown,is_core=null`。真实循环来源见主控消息5360。

冻结 skill `main_decision_v1/SKILL.md:475-483`要求真实地位/板块/资金判断，不能把缺20日收益喂空数组、不能由默认grade造拒绝；`:377-392`通道不受阶段白名单机械开关；`:527-540`半路/低吸/打板动态比较；`:606-626`先逐票选情景、再算价、最后独立判权。当前统一append即使逐票description不同，也不是逐票决定此条件是否应active。未核可阻止认证已通过，但不能把“没有量化认证”偷换成“已证非核心/反抽不能做”。

边界裁决：不能说持久代码实现了“MA20以下一律禁止反抽”；当前S是LLM循环无条件添加，连R5已记载在MA20/30/60上方的兆威、已收复MA20的阳光也有S，证明它不只是一个实际MA20比较器。纪律稿“有主升不做反抽”（原文比较优先级）与“不在下降趋势”（摘要全资格）不等义，更不等于“没有已证主升就连反抽承接研究也不能有”。把未确认新主升和缺量化核心并为全票active硬禁，确与当前D1动态按赚钱效应选择通道、逐对象说明必要未知的要求冲突；但这种冲突不证明北方或新易盛当时已经值得买，也不应以识图短周期转强替代必要审核。

独立阻塞：去掉这一项本身不补齐R6、战术、价位/实际报价、发布身份和权限。最小反事实（仅逻辑未执行）：由owner逐票说明应保留的必要未知与明确负面，并独立比较反抽承接/半路等场景，而不是22票一概填true；新易盛先重评这项，北方仍必须补模式6和本轮角色/打法判断。不删除真实审核或授权保护。

### PC-02【研究策略差异＋单场景表达限制，非已证字段丢失】北方双通道

本版 `/watch_pool/2`：R2 `/main_lines/0/leaders/2`原角色候补、rank龙三、leader_filter_eligible=false；D1保留此身份。备份txt:175-177、191-218则网页自报设备龙一：低吸500.5—515，触发515、stop479、take587；次通道546—552，触发548.5、stop522.5、take610，二选一。网页txt:420、443解释用MA5承接及双通道规避全深回踩。

同版本地R5 `/profiles/2/dimensions/technical_readiness` 已有ma5=500.472、ma10=509.903、ma20=548.1695、ma50=620.251、hi20=634.41（图内日K）；并非完全没有承接/压力资料。图中542—548压力、60分/15分转强亦保留，但分钟复权与当日承接未核，只能辅助，不能自动认领为执行价。

本地entry明确只有leader_breakout，买区532.82—543.53，触发535.5，实际最高543.53，stop516.35，take597.89。冻结 `price_levels.py:196-218`：远hi20高于按板制推算可达线即pivot回昨收；slack默认1.5%，得到该买区。不是后复权证据，也不是备份546—552被改坏；是“以昨收续强”与“突破MA20/近端压力”的不同确认语义。本版543.53上沿低于548.17压力，若把站上MA20当必需右侧确认，就存在确认时已离开原买区的场景张力；不能据此宣称盘前已发生无法成交。

当前 `apply_price_levels.py:29-49`只表达一个原始通道，多通道冲突返回None，而非悄悄选第一条；`:56-62,154-161`保留已有D1价位。`buy_eligibility.py:118-122`多条规则必须显式选择，选中规则后读其买区上沿。表达/消费链确有双场景限制，需owner级场景选择，不意味着现在丢过第二规则。最小反事实：先经合法研究比较该票反抽承接与近端突破各自证据、风险与互斥关系；不能只把entry_rules追加一条就指望现引擎全链通过。

### PC-03【已触发的诊断耦合，非实际缺价】资格先返回导致node unknown

冻结 `buy_eligibility.py:110-112`遇任何非引擎RR的active stock条件即返回blocked，尚未读entry/exit。`apply_price_levels.py:203-223`把该提前返回中的null buy/stop/take拿去validate_nodes，于是22票外层 `/node_validation/errors=[missing_or_invalid_node_prices]`、node_valid=null，而各自 `/engine_levels/node_validation/status=valid` 且原始三价实际存在。

本审对冻结原对象直接执行资格：22/22 exact_original blocked/STOCK_NO_TRADE_CONDITION；对各自真实entry买区上沿、顶层stop/take直接调用冻结AST几何函数：22/22 errors=[]。这只说明给定三价几何，不认证实际开盘/报价/交易所边界。21票原价RR=2.0，福莱1.78。属资格阻断污染几何诊断的当日可见缺陷，不是生产数据丢价，也不是全池不开仓的原始原因。最小反事实：让几何诊断从已选择三价独立读取，不以授权/业务资格的短路null证明价格缺失；仍保留原blocked。

### PC-04【潜在纯函数误判，未证当日使用】core_judge与默认缺项

仓库 `src/research/core_judge.py:47-54`样本<5或零方差返回0；`:79-109`0相关被归anti_rotation、分数×0.6；`:112-123`形成core/laggard/watch。缺数据可能被误当逆势/无地位，此实现风险真实存在；但当前plan22票均显式unknown并说明不调用空数组，不能把该潜在风险称为当日已触发线上bug。repo调用搜索仅见模块示例、历史`.tmp_calc2.py`（日期20261026，非本次），未见持久D1主路径调用证据。

`forbidden_filter.py:49-70`默认in_plan=false、phase=execution；若形成计划漏传phase会错用计划外保护，但本日实际有函数输出的票phase都为plan_formation，北方因无真实可比rank未调用而保留unknown。没有本日默认phase误拒证据。不能用R2候补名次冒充全板块实际排名。

### PC-05【原规则硬化／当日6票触发；不是北方阻塞】tactical与forbidden

冻结skill:444-451将多开板>=2硬拒绝；`forbidden_filter.py:145-153`14点后首次封板硬拒绝；但原文《新生代游资核心观点整理.md》:225-241只是“多次打开临近尾盘很弱”“尾盘少打”，还含“数次回封放量突破”的雪人股份正例，以及高位久横换手板/中军例外。纪律稿:81-82,122-126已更硬，D1 skill再明确>=2。这是来源→摘要→门禁的策略硬化，不是单纯照搬无例外原文。

当日6票tactical active：长电、沃格、云南、龙版、福莱、兆威；其中云南check_forbidden本身is_allowed=true，但board open3触发D1 repeated_open_board。兆威正文最终理由未强调板型，结构化tactical仍active，要以JSON为阻塞真值。采用三格模板且研究次日半路/突破，却把T-1多开板作为全天新情景一票否决，属于须owner裁决的跨时间/打法适用范围问题；现行skill确实要求，因此不能直接定性“程序未按规则运行”。最小反事实是修订明确适用通道/例外及所需当天转强证据，不是删除真实失败。

### PC-06【当日已触发分类标签错误，未造成北方拒绝】13:30—14点时间标签

仓库 `board_pattern.py:135-140`把13:30至14:30都标“尾盘封板(14:00-14:30)”，与`:191-195`13:47仍是午后板矛盾。冻结plan北方board_result/evidence明确134703却显示14点时段；通富134724、博杰135821、四川133348、深中华133057亦有相同标签。北方 `/tactical_signals/forbidden_hits=[]`，classification_limitation已声明不将粗标签作14点后事实，没有证据因它late_speculation被误拒。最小反事实仅修标签边界，不改变北方R6/角色/统一右侧限制。

### PC-07【不是图像门禁】识图只做辅助

冻结skill:637-641和当前apply:261-279明确图像复核后置且不回写资格、价格、权限。北方 `/chart_consistency`冲突是日K548.17途中压力早于597.89目标；其60分535.5参考因复权口径未知不能认证执行突破。当前统一右侧限制在apply前已写，不能倒因为图像冲突。缺图/冲突不单独必过，不能拿图像辅助加出第23层硬门禁。

### PC-08【独立审核缺口，非已证误拒】北方R6模式6

北方 `/watch_pool/2/r6_review/required_mode_completion/6=incomplete`，缺R3精确对象或声明板块/窗口distribution检查。冻结R3 `/hotlist_signals/distribution_alert_checks/84`：886009.TI先进封装 rank_previous=null、check_status=unknown；没有北方精确stock行，空distribution_alert不能当阴性。新易盛R3 checks23/60是精确代码已核false，R6四项完成，确实不是全体R6一刀切。最小反事实需补/核真实必要证据，不能把“未霸榜所以应通过”或空列表改通过。这里只说明为何当前缺证，是否模式6必须覆盖所有候选本身属研究政策评估。

## 当前22票逐个ID与最小反事实

所有行都：单规则leader_breakout；core_judge=unknown；实际buy_eligibility=blocked，唯一返回理由STOCK_NO_TRADE_CONDITION；三价已存在、直接几何合法。S=RIGHT_SIDE_CORE_NOT_VERIFIED（全22），N=NECESSARY_REVIEW_INCOMPLETE（21），T=TACTICAL_OR_FORBIDDEN_HIT（6），H=R6_HARD_REJECT（2）。M1/2/6/7为R6必要审核项。全局执行保护/池身份还独立存在，本表不重复预算审计。

| ID | 代码／名称 | JSON pointer | 独立逐票阻塞 | 未完成R6模式 | 战术实际命中 | 原三价RR | 最小反事实（只作逻辑，未执行） |
|---|---|---|---|---|---|---|---|
| W01 | 002156.SZ 通富微电 | `/watch_pool/0` | N+S | 6 | 无明确hit／部分未知 | 2.00 | 只补R6 M6仍剩S；无任何单项足以授权买入 |
| W02 | 600584.SH 长电科技 | `/watch_pool/1` | N+T+S | 6,7 | late_speculation,repeated_open_board | 2.00 | 只补R6 M6,7仍剩S；T须独立裁决，不能以转强想象抹去；无任何单项足以授权买入 |
| W03 | 002371.SZ 北方华创 | `/watch_pool/2` | N+S | 6 | 无明确hit／部分未知 | 2.00 | 只补R6 M6仍剩S；无任何单项足以授权买入 |
| W04 | 002975.SZ 博杰股份 | `/watch_pool/3` | N+S | 1,6,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,6,7仍剩S；无任何单项足以授权买入 |
| W05 | 603773.SH 沃格光电 | `/watch_pool/4` | H+N+T+S | 1,6,7 | repeated_open_board | 2.00 | 硬否决仍不可覆盖；只补R6 M1,6,7仍剩S；T须独立裁决，不能以转强想象抹去；无任何单项足以授权买入 |
| W06 | 002428.SZ 云南锗业 | `/watch_pool/5` | N+T+S | 7 | repeated_open_board | 2.00 | 只补R6 M7仍剩S；T须独立裁决，不能以转强想象抹去；无任何单项足以授权买入 |
| W07 | 300502.SZ 新易盛 | `/watch_pool/6` | S | 无 | 无明确hit／部分未知 | 2.00 | R6已齐，须按实际证据重评S；无任何单项足以授权买入 |
| W08 | 300308.SZ 中际旭创 | `/watch_pool/7` | N+S | 7 | 无明确hit／部分未知 | 2.00 | 只补R6 M7仍剩S；无任何单项足以授权买入 |
| W09 | 002980.SZ 华盛昌 | `/watch_pool/8` | N+S | 1,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,7仍剩S；无任何单项足以授权买入 |
| W10 | 002578.SZ 闽发铝业 | `/watch_pool/9` | N+S | 1,6,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,6,7仍剩S；无任何单项足以授权买入 |
| W11 | 603381.SH 永臻股份 | `/watch_pool/10` | H+N+S | 1,6,7 | 无明确hit／部分未知 | 2.00 | 硬否决仍不可覆盖；只补R6 M1,6,7仍剩S；无任何单项足以授权买入 |
| W12 | 300274.SZ 阳光电源 | `/watch_pool/11` | N+S | 6 | 无明确hit／部分未知 | 2.00 | 只补R6 M6仍剩S；无任何单项足以授权买入 |
| W13 | 605577.SH 龙版传媒 | `/watch_pool/12` | N+T+S | 1,7 | repeated_open_board | 2.00 | 只补R6 M1,7仍剩S；T须独立裁决，不能以转强想象抹去；无任何单项足以授权买入 |
| W14 | 601599.SH 浙文影业 | `/watch_pool/13` | N+S | 1,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,7仍剩S；无任何单项足以授权买入 |
| W15 | 605488.SH 福莱新材 | `/watch_pool/14` | N+T+S | 1,7 | repeated_open_board | 1.78 | 只补R6 M1,7仍剩S；T须独立裁决，不能以转强想象抹去；原价RR仍拒绝，不挪价求过；无任何单项足以授权买入 |
| W16 | 003021.SZ 兆威机电 | `/watch_pool/15` | N+T+S | 1,7 | repeated_open_board | 2.00 | 只补R6 M1,7仍剩S；T须独立裁决，不能以转强想象抹去；无任何单项足以授权买入 |
| W17 | 301127.SZ 武汉天源 | `/watch_pool/16` | N+S | 1,6,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,6,7仍剩S；无任何单项足以授权买入 |
| W18 | 300199.SZ 翰宇药业 | `/watch_pool/17` | N+S | 1,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,7仍剩S；无任何单项足以授权买入 |
| W19 | 001337.SZ 四川黄金 | `/watch_pool/18` | N+S | 6,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M6,7仍剩S；无任何单项足以授权买入 |
| W20 | 002029.SZ 七匹狼 | `/watch_pool/19` | N+S | 1,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,7仍剩S；无任何单项足以授权买入 |
| W21 | 601566.SH 九牧王 | `/watch_pool/20` | N+S | 1,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,7仍剩S；无任何单项足以授权买入 |
| W22 | 000017.SZ 深中华A | `/watch_pool/21` | N+S | 1,6,7 | 无明确hit／部分未知 | 2.00 | 只补R6 M1,6,7仍剩S；无任何单项足以授权买入 |

### 各行精确字段契约

表中pointer后追加 `/buy_eligibility/reasons` 看消费者实际理由；追加 `/no_trade_conditions` 看全部独立阻塞（不是只看首错）；追加 `/r6_review/missing_necessary_items` 看审核证据缺项；追加 `/entry_rules/0` 和顶层 `/stop_loss`、`/take_profit` 看实际价格；追加 `/engine_levels` 看引擎比较证据。`buy_eligibility.py:42-61,123-160`优先买区上沿、顶层显式exit（即使显式非法也不静默fallback）；原始D1无price_src默认属于legacy D1，不能把None冒称未知源；`:185-208`实际ask另算RR。全22原规则price_src未显式填写但已有引擎比较证据，不构成价位丢失。

## 备份证据上限

只持有冻结网页HTML/提取txt，不持有备份JSON、hash绑定的输入版本、真实loader回执或成交证明。txt:471-477关于pydantic/buy gate/识图/enrichment通过都是网页自报，不可据此认定真实consumer支持双通道、资格真过或已成交。备份自身也写auto_trade=false、用户确认、开盘判据、review_required，不能比较成“备份已买、本地没买”。可以确认的是网页展示了更开放的反抽承接研究与双剧本，而本版22票统一单通道及统一S阻断；其优劣不以盘后涨跌倒证。

## 文件与未尽事项

仅新增scratch本报告；未修改代码、配置、skills、正式plan/MD/runtime。无测试/模拟/模型/行情/券商调用。源码潜在core/default问题未证本日触发；双通道消费者全链不在本审执行验证范围。应先由计划owner纠正统一active组装/逐票证据裁决与场景解释，再分别讨论持久双通道表达、历史板型硬化和纯函数缺数据语义；这些只是建议，不包含实施授权。
