# V1-WEB｜用户网站退役边界（只读范围收敛）

## 结论与授权

**推荐先退役“用户网站展示与构建入口”，不整删 `web/`、不整停后台栈、不整删 `src/api/`。** 当前研究出图仍直接使用 `web/` 内的无头脚本、指标和 Node 依赖；行情共用模块放在 `src/api/`，却被研究、MCP、午盘快照及交易行情读取器直接导入。网站不再有价值，不等于这些底层能力没有价值。

用户目标是系统 1.00 收敛，不是修 UI。本报告不沿用 G 的“修页面/统一界面”实施目标；G/A/H 仅复用为已有事实与限制。本轮只补网站边界和消费者证据，未做第二遍全仓审计。

- 项目根：`/Users/chenyang/Downloads/demo/沧海巨浪`；下文项目路径相对该根。
- 静态探针截止：2026-10-24 16:41:12 +08:00；活工作树，未冻结服务或重查 Git。HEAD/脏树背景沿用委派上下文，不冒充本轮核验。
- 实施状态：**全部建议，未停、未隔离、未删除、未修前端**。唯一写入是授权 scratch 的 `WEB.md`、`WEB.json`。
- 未调任何业务接口、未启动服务/浏览器/生产脚本/pytest；未读 `.env`、完整配置、账户/持仓/成交数据库。外部脚本只读与路径解析有关的片段。

## 一、事实：展示、HTTP 适配器、底层业务是三层

| 层 | 当前证据（path:line） | 退役含义 |
|---|---|---|
| 用户 SPA | `web/index.html:9-10` → `web/src/main.jsx:1-10` → `web/src/App.jsx:17-28`，当前 8 个页面入口 | 页面、导航、交互组件可退出维护；不必先修旧页面错误 |
| SPA 静态托管 | `src/api/main.py:54-71` 仅在 dist 存在时挂载 `/`；API 路由在 `:39-52` 独立注册 | “不构建/不开放页面”与“停全部 REST”是不同变更；`--skip-build` 仍会服务现存 dist，不能当展示已关闭 |
| 网站 HTTP 适配器 | `src/api/routers/*.py`、`jobs.py`、`registry.py` | 可以作为第二批隔离候选，但必须核外部 HTTP 客户端、人工流程及路由内写操作；不能因页面退出就立即删后台业务实现 |
| 共用行情函数 | `src/api/market_data.py:8-15,72-100,274,340` | 是 Python 库，不依赖先运行 FastAPI/Uvicorn。文件虽叫 api，仍必须留；`src/api/__init__.py:1` 保留包路径兼容 |
| 无头图表 | `src/analytics/lwc_chart_renderer.py:18,81-86` 直接启动 Node 本地脚本；`web/scripts/headless/lwc_headless_render.mjs:73-76,111-115` 使用本地模板与 `setContent` | 不需要 Vite、dist 或用户网站 HTTP，但需要 web 内的非展示运行时 |

本轮对 `src/scripts/trading` 的源码字符串检查未发现非 API 代码直接导入 `src.api.main/jobs/registry/routers`；测试有 API 消费者（如 `tests/agent/test_macro_contract.py:8`）。这只能支持“HTTP 适配层隔离候选”，不能证明无动态、远端或人工 HTTP 调用。`src/fetch/mcp_health.py:3` 的“共用探测逻辑”是说明文字，不能误读成导入 `system.router` 的证据。

### 1.1 必须保留的精确 `web/` 闭包

1. `web/scripts/headless/lwc_headless_render.mjs`：`:10-15` 依赖 Playwright、指标、lightweight-charts 本地 bundle 和 HTML 模板。
2. `web/scripts/headless/chart_template.html`：`:33,100-145,152-163` 是无头 PNG 的绘制模板，**不是可随 SPA 删除的网页**。
3. `web/src/lib/technicalIndicators.js`：由无头脚本 `:11` 导入，内部 `:285-296` 再导出 bullBear 指标。
4. `web/src/lib/bullBearIndicator.js`：上述转导出依赖；另有 `tests/sise/test_sise_siliang.py:157-179` 的 Python/JS 对照消费者。
5. `web/package.json`：`:5` 的 `type: module` 保证 `.js` ESM 语义；`:13,24` 仍承载 lightweight-charts 与 Playwright 的安装声明。
6. `web/package-lock.json` 和用于无头出图的 Node 依赖安装闭包。**不能整删 `web/node_modules`，也不能直接 `npm ci --omit=dev`**：Playwright 目前在 devDependencies，却是研究出图的运行依赖（`package.json:21-27`）。Chromium 运行环境也不能按“网站浏览器”卸载。

静态闭包探针实际得到 3 个 JS 模块：无头入口、technicalIndicators、bullBearIndicator；模板和 Node bundle 是文件读取边，另行保留。本轮确认上述文件和两个 Node 包的 package.json 存在，但没有启动 Chromium，也没有宣称能出图。

### 1.2 为什么研究、MCP、交易仍要保留它们

| 消费者链 | 证据 | 结论 |
|---|---|---|
| R2 后预渲染 → R5 | `scripts/research/run_research_shell.sh:191-206` → `scripts/fetch/run_chart_vision_snapshot.py:100-110` → LWC renderer | 删无头 web 闭包会破坏真实研究能力；non-blocking 只意味着有降级，不等于可以删 |
| 图表 MCP | `scripts/run_charts_mcp_server.py:11-14` → `src/mcp/charts_server.py:40-51` → `src/mcp/tools.py:839-901` | MCP 直接导入 Python renderer，不需要网站 API；LWC 和视觉分析仍是有效消费者 |
| 快图/替代图引擎 | `src/analytics/fast_chart_renderer.py:16`、`lwc_chart_renderer.py:13`、`mplfinance_renderer.py:33-34` | 三者都依赖 `src.api.market_data`；存在 mplfinance 不证明生产已切换，更不能据注释“对等”先删 LWC |
| 技术分析/选股 | `src/agents/chart_vision_agent.py:11`、`src/screener/engine.py:5` | 同样直接调用行情库，不经网站 |
| 午盘行情快照 | `src/fetch/midday_snapshot.py:127-129` | 直接使用 `fetch_intraday_bars`，不能整删 api 包 |
| 执行行情适配 | `src/execute/market_snapshot.py:173-191` | XTick 行情读取路径直接导入 `fetch_quotes`；不是订单接口，但属于执行依赖 |
| 正式预案/交接 | `scripts/research/pipeline_artifacts.py:128-173` → `trading.load_plan` | 正式、staged、loaded 不因网站退出而合并/删除；不能调用带 dispatch 的 load CLI 来做“只读验收” |
| 日周复盘 | `src/review/daily_review_prep.py:355-381,427-451`、`weekly_evolution_prep.py:26-49` | 直接读计划/研究/E1 文件，无网站前置；prep 是骨架，不是完成版复盘 |

**保留整个业务能力边界，而不是把路由调用的业务模块一起列删。** `src/agents`、`src/analytics`、`src/mcp`、`src/screener`、`src/review`、`src/kb`、`src/trading_agent`、`trading/` 不能打包进“网站退役”；A:22-24,50-60 与 H:78-84 已给出共享消费者反例。宏观 strength 当前修复也保留（G:21-23），不因旧宏观页面退出撤销。

## 二、三级退役候选（递进，不是三个已执行动作）

### L1｜仅停止展示：最先推荐，最低业务耦合

**候选范围**：用户 SPA 的访问入口、Vite dev/preview、网站构建及推广使用入口；旧 SPA 的页面修复不再排期。纯展示源文件暂留，便于回滚。API 和无头出图保持原状。

- `web/package.json:6-9`：dev/build/preview 是 UI 生命周期，不是研究生命周期。
- `src/api/main.py:54-71`：未来需签核决定“不挂 SPA 静态路由”或“只撤入口但不触碰服务”。仅不运行 Vite 不够，现存 dist 仍可能被 API 托管。
- `scripts/start_local.sh:128-144,173-219`；`scripts/start_web_hermes_ngrok.sh:140-155,188-238`：网站构建与 API/Hermes/Nginx 绑在同一栈。**不运行这些总启动脚本**可以避免未来重建，但不能据此说现有网站已停止。
- 禁用展示的具体部署入口/代理变更另需签核与只读部署发现；本轮未读完整 Nginx/公网配置，也未检查驻留进程，所以不指定可立即停掉哪个 PID/端口。

**不能用 `--stop` 代替停止展示。** `start_local.sh:88-103` 会停止 API、Hermes、公众号容器及 Nginx；公网脚本 `:89-105,256-258` 还含广域 `pkill -f "ngrok http"`。它们是复合停栈，不是精确网站开关。

### L2｜隔离可恢复：签核后做分层，不做整包删除

**候选 A：SPA 专用源码与构建器**：JSON 附 51 个精确源文件清单；即 `web/src` 中除两份指标库以外的文件，再加 `web/index.html`、`web/vite.config.js`、`web/tailwind.config.js`、`web/postcss.config.js`、现存 `web/dist/`。这里的 51 是源码文件盘点，不是经过用户签字的删除量，也不保证全部由当前页面可达。

**候选 B：网站 REST 外壳**：`src/api/main.py`、`src/api/routers/`、`src/api/jobs.py`、`src/api/registry.py` 可另成隔离批次。保留 `market_data.py` 与包初始化；保留它们所导入的业务模块及数据库文件。以下路由不是“纯展示”，应登记为停止 HTTP 入口的功能损失，而非无害删文件：

- `routers/agent_ops.py:53-76`：信号生成、回测、建议闸门；属于旁路入口，不证明可绕过实盘门禁。
- `routers/chart_vision.py:79-166`：视觉/股票池分析和 job 操作。
- `routers/macro.py:106-120,171-172`、`routers/intel.py:11-15`：生成/后台 job。
- `routers/sise.py:98-100`：同步动作。
- `routers/system.py:243-249`：管理阈值写入（沿用 G06）；撤 HTTP 写入口不意味着删配置加载器或阈值文件。
- `routers/evolution.py:204-228`、`trading_agent.py:21-44`、`briefings.py:45-50`：旧读取视图不是正式 D1/E1 产物本身。

**候选 C：混合启动脚本**：`scripts/start_local.sh`、`start_web_hermes_ngrok.sh`、`start_stack_with_nginx.sh` 和 `scripts/archive/start_api.sh`、`start_with_ngrok.sh`。只可先退出默认使用并保留归档；需要先明确 API、Hermes、代理及隧道的实际服务归属，不能为了网站把独立 Hermes 聊天或研究通道停了。配置、ngrok、Docker、Nginx 和系统服务本轮一律不列可删。

**恢复契约建议**：单独归档获准文件、记录相对路径/摘要/依赖锁与恢复命令；不 `git reset/clean`，不移动生产产物；恢复只还原展示边界，不恢复交易授权或自动重启旧任务。此契约未实施。

### L3｜可删待签：只有通过隔离观察与依赖验收后

1. 精确的 SPA 专用 51 源文件与上述 4 个构建入口文件、dist 生成物，可列删除候选；不得扩大成 `web/`、`web/src/lib/` 或整个 Node 安装目录。
2. UI 专用直接依赖可从未来分拆的 UI manifest 退役：`@tanstack/react-query`、`react`、`react-dom`、`react-markdown`、`react-router-dom`、`recharts`、`remark-gfm`、`@vitejs/plugin-react`、`autoprefixer`、`postcss`、`tailwindcss`、`vite`（`web/package.json:12-27`）。先为无头运行时保留独立 manifest/lock 与 ESM 语义，再重解锁依赖；不得手删 lock 的局部条目或直接删当前 package 文件。
3. REST 外壳、API 专用测试、混合启动脚本**暂不升级为确定可删**：外部 HTTP、人工入口、在途 jobs、代理所有权未核。可以“可删待签”的条件项登记，但本轮不能给它们零消费者结论。
4. Python `fastapi/uvicorn/python-multipart` 是候选依赖审查项，不是批准移除项（`requirements.txt:7-8,14-15`）。MCP 运行依赖闭包、其他服务与测试未做卸载验收；`requirements.txt:20` 的 Python Playwright 也不等于 Node Playwright。保留行情、模型 SDK、pydantic、pandas、matplotlib、numpy、httpx、MCP 等业务依赖，不以网站退役为由清库。

## 三、相对脚本实际解析：防同名 wrapper 误判

1. Hermes 相对 `script` 的基准是当前 `HERMES_HOME/scripts/`，**不是项目 CWD**：`/Users/chenyang/.hermes/hermes-agent/cron/scheduler_script.py:323-346`。本轮只读代码，没有调用解析函数（它自身会 ensure 目录）。
2. 已有 A 投影中的研究任务 `canghai_research_daily.sh` 应解析为 `/Users/chenyang/.hermes/scripts/canghai_research_daily.sh`；实际脚本 `:5-6` 再绝对指向项目 `scripts/research/run_research_shell_cron_wrapper.sh`；后者 `:10-11,69-71` 转到研究 shell，**没有经 start_local/网站启动器**。任务注册状态沿用 A 投影，不重查全量 cron。
3. 外部 `/Users/chenyang/.hermes/scripts/canghai_chart_vision_snapshot.sh:15-21` 先 cd 项目，再绝对调用 `scripts/fetch/run_chart_vision_snapshot.py`。即使外部同名手工脚本是否仍调度未核，主研究 shell 已有独立真实调用，足够阻止删除无头闭包。
4. `scripts/start_stack_with_nginx.sh:4` 用自身目录转发到 **同目录 `scripts/start_local.sh`**；不是 `.hermes/scripts/` 的同名文件。两条路径规则不能混用。
5. `src/api/jobs.py:77-82` 的后台 job 精确解析为项目 `scripts/run_pipeline.py`，本轮文件检查不存在；存在的是 `scripts/legacy/run_pipeline.py`。**同名脚本存在不构成自动回退**，不能报这个旧 job 已接通；也不应把“修复它”列为 1.00 网站退役任务。
6. H:56-60 已纠正 keepalive 同名 wrapper 的历史误判，本报告采用其“仓库文件不等于当前部署入口”的口径，不再重复审计执行守护。

## 四、不跑网站的可执行验收建议

### A. 现在可做的只读门槛（本轮已做）

- AST 解析 8 个指定 Python 文件通过；只读检查受保护文件、两份 Node 包安装声明存在。
- 静态闭包确认 headless 不引用 React/Vite/用户 SPA；确认主研究入口不经过网站启动脚本。
- `src/scripts/trading` 中未找到直接导入 `src.api.main/jobs/registry/routers` 的非 HTTP 消费者。此项不是 HTTP 调用量证明，也不是无头出图运行成功。

### B. 后续需授权的隔离回归（本轮未执行）

在**另建的授权 sandbox 副本**中，移出 SPA 专用清单、禁止生产路径/凭据访问、禁止网络与下单；不得在脏项目原地运行。先把源码根、DATA_DIR、REPORTS_DIR、图表输出等显式重定向到 sandbox；不要认为 `--dry-run`、`write=False` 自动无副作用。

可复用的真实离线测试命令（`SANDBOX` 须是预先准备的隔离源码副本，不是本仓库；解释器须具备依赖）：

```bash
cd "$SANDBOX"
PYTHONDONTWRITEBYTECODE=1 "$PYTHON" -m pytest -p no:cacheprovider \
  --basetemp "$SANDBOX/test-tmp" \
  tests/pipeline/test_research_pipeline_reliability.py \
  tests/pipeline/test_plan_staging_freshness.py
```

对应源码证据：reliability `:1-5,33-85` 使用假 Hermes/行情夹具和真实 summary/state/handoff；staging `:55-85` 重定向数据并阻断真实 QMT/dispatch。**前者明确 stub chart vision，不能用其通过声称真实出图或真实 LLM 研究已验收。** 复制范围、环境钩子与只读生产守卫也需先验收，不能直接照抄命令裸跑项目。

另设两个独立验收用例（尚未实现，不冒称已有测试）：

- **无头图表**：提供合成 OHLCV `payload.json`，禁全部网络，使用保留下来的入口运行：`node web/scripts/headless/lwc_headless_render.mjs --input "$SANDBOX/payload.json" --output "$SANDBOX/chart.png"`。断言 PNG 非空、timings renderer 正确、牛熊/四色四量/MACD 序列存在；不启动 Vite/Uvicorn，不读取真实股票账户。当前 renderer 不需要 HTTP server，但真实数据版 Python fetch 会联网，因此不能拿线上股票作“离线”验收。
- **E1/E2 文件链**：在隔离目录放合成 canonical D1、同 run 的 research_summary、行情、观察池与独立 paper 汇总夹具；将行情/情绪重算/数据库客户端全部替换为夹具。验证 E1 输入 gate、日期、来源、执行池/观察池分离、缺项为 unknown/unavailable；最终 E1 JSON 与 KG MD 同一事实源，E2 读取相同 E1。`daily_review_prep.py:384-451` 只写 skeleton，不能以其退出 0 代替 Agent 完整复盘；`build_market_panorama` 还可能重算写入（`:337-345`），所以 `write=False` 也不能作为安全隔离保证。

### C. 不补跑生产的交付观察门槛

后续由有权限者观察**正常计划任务**的自然产物，非本轮启动/补跑：

- 盘前：R1-R7 本次 run 产物 → summary → `data/plans/YYYYMMDD/watchlist_plan.json` ＋ `chzl_kg/投研交易/盘前预案/YYYYMMDD.md`；仅文件存在不算 complete。
- 交接：canonical → staged；loaded 是账户投影，可能与 canonical 不同，不能要求三份 hash 全相等；保留降级、禁新、有效零约束。禁止调用 `run_load_plan` 做只读探针，其 dispatch 风险已见 A01/H06。
- 复盘：`data/reports/YYYYMMDD/E1_data.json` ＋ KG 复盘 MD，检查状态、日期、来源、已完成/缺失、不把价格场景收益当真实成交收益；E2 不漏当周最后一日依赖。H01 已证 Agent 消费独立 paper 快照，不再说完全未接；常驻与统一核算仍待认证。
- 展示关闭、无头回归、业务交付、执行授权四项分别记账。关站不是实盘放行，也不承诺解决已审计的上游交付/执行缺陷。

## 五、验收与限制

**本轮完成的是退役边界与实施验收设计，不是停站或运行认证。** 真实静态输出：8 文件 AST 通过；受保护 8 个文件均存在；2 个无头 Node 包声明存在；候选 SPA 源文件 51 个；API 旧 job 目标不存在而 legacy 同名存在。JSON 保留完整候选清单、事实/建议分栏与门槛。

尚缺：系统级/远端 HTTP 消费者、Nginx/隧道实际所有权、在途 jobs、驻留进程加载版本、真实调用量、无头 PNG 实跑、停站后的自然日完整交付。未读取生产账户、没有凭空补齐这些证据。**没有任何目录获得删除授权，没有任何服务被本轮停止。**
