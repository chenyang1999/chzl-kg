# V1-DATA｜data 原地治理与瘦身候选（只读）

盘点区间：2026-10-24T16:39:15.604546+08:00—2026-10-24T16:39:16.040680+08:00。项目未移动、未删除、未改写；只有授权 scratch 的 DATA* 产物。

## 结论与优先顺序

- **先管体积**：普通文件 12,207 个，逻辑 2,012,626,210 B（1.874 GiB）。`runtime/sanban_zhaban` + `runtime/mainboard_yao4` 共 1,121,196,167 B，占 55.71%；它们是带交叉消费者的历史实验，非立即可删垃圾。
- **再管阅读**：嵌在数据区的 Python 脚本 37 个/351,847 B；治理价值主要是减少检索噪声。错题本仅 194,168 B、health 1,742,290 B、backtest 76,440 B，不是主要瘦身体积。
- **不先搬家**：优先给现有路径登记 owner/class/producer/consumer/as-of/rebuild/retention-status，默认浏览/搜索区分正式产物与实验工具。登记是后续建议，本次没有写回data。不要另造data_v1或另一套平行目录。
- **不按年龄抹证据**：正式版本、账本、错题、失败诊断、人工sign-off先保护；路径变更和保留期限逐项待签，没有“默认30天删除”。

## 顶层盘点（逻辑字节；普通文件数）

| 顶层 | 文件 | 逻辑 B | 分配量估计 B |
|---|---:|---:|---:|
| runtime | 3,251 | 1,290,378,612 | 1,297,141,760 |
| raw | 5,679 | 501,752,440 | 516,362,240 |
| research | 1,816 | 118,064,079 | 123,248,640 |
| reports | 502 | 60,025,184 | 61,120,512 |
| [sensitive top-level aggregate] | 14 | 9,776,489 | 9,805,824 |
| logs | 242 | 8,147,844 | 8,687,616 |
| retrospective | 14 | 8,010,036 | 8,036,352 |
| cache | 197 | 6,738,916 | 7,274,496 |
| rules | 4 | 3,634,208 | 3,645,440 |
| plans | 210 | 3,483,990 | 3,960,832 |
| health | 119 | 1,742,290 | 2,048,000 |
| [top-level files] | 5 | 236,059 | 245,760 |
| evolution | 31 | 227,474 | 282,624 |
| corrections | 110 | 194,168 | 458,752 |
| review | 3 | 131,811 | 139,264 |
| backtest | 8 | 76,440 | 102,400 |
| human_thesis | 2 | 6,170 | 12,288 |
| events | 0 | 0 | 0 |
| patterns | 0 | 0 | 0 |

目录 819 个（不含data根），链接 12 个，扫描错误 0。命中保守敏感筛选 681 文件/100,590,547 B，只计metadata、不列私有明细、不读库或凭据。分配量合计 2,042,572,800 B ≠ APFS唯一物理占用，更不是保证可回收量。

## 布局、脚本、latest 与有限重复证据

- **data/data**：当前完整不跟链枚举未见任何嵌套data目录；源码字面量搜索也未命中。附树可能来自不同状态，不据此虚构迁移项。
- **顶层散落**：5普通文件/236,059 B，其中4个可列例：`.DS_Store`、`sise_daily_scan_days7.json`、`source_diversity_matrix.md`、`user_preferences.yaml`；另1个敏感筛选项不列名。preferences是配置真源；矩阵被历史文档标注用户维护；旧scan未证实现用归属，均不能一键清空。
- **脚本分布**：`retrospective/_*.py`、`research/日期/_*.py`及`_tmp/`、`reports/20260716/*.py`、`raw/20261013/_p1*.py`、`cache/r5_*20261012.py`。完整37项metadata在DATA.json。只读源码，未运行这些生成器。
- **latest协议**：8个名字含latest的非敏感文件均为普通文件；`cache/latest_weflow_forecast.json`为0字节，不可因名字视为有效JSON或最新结果。12个实际symlink均为research日期目录下R7文件别名，不重复计目标文件字节。没有跟随链接或打开目标。
- **确定的一组复制**：`rules/theme_anchors/20261020.json`与`latest.json`各1,815,814 B、不同inode，SHA256同为`7faacc30f8b65999e388f551ff21d26bff99351c4f17e077161d2eca70741970`。生成器同时写两份完整payload；消费者直接JSON解码latest，所以它不是可直接删的小指针。
- **查重口径**：先按metadata等长筛选，仅hash 18 文件/3,672,087 B，预算上限32文件/8MiB/单件2MiB；16个等长daily_check样本没有同hash。仅证实样本额外逻辑副本1,815,814 B，不能外推全量重复率或磁盘收益。

## 代表路径：生产者、消费者、去留边界

### data/corrections/
- 分类：protected_learning_evidence
- 生产者：E1 fresh-context Agent；skills/daily_review_v1/SKILL.md Outputs / Step7: error_case_XXX.md；scripts/review/_e1_build_20261020.py:99-110,135-136 (correction payload only, not proof it writes case files)
- 消费者：盘前纠错读取器；scripts/trading_tools.py:115-153; legacy CORR JSON + weekly error_case MD, summary truncates to 600 chars
- 消费者：E2 weekly prep；src/review/weekly_evolution_prep.py:51-60; indexes weekly MD paths
- 边界：错题/复发链与采纳证据保留；并非可重建缓存；找到消费者不等于已证明纠错有效。

### data/rules/theme_anchors/latest.json
- 分类：derived_but_active_consumer_contract
- 生产者：build_theme_anchors CLI；scripts/research/build_theme_anchors.py:247-254,300-303; writes both dated and latest full payload
- 消费者：一字板预判；scripts/plan/run_yizi_predict.py:31-39 reads JSON payload directly
- 消费者：R2 Agent (skill contract, not runtime proof)；theme_anchor_builder_v1/SKILL.md 数据与脚本/消费规则
- 边界：保留规则版本、输入股性表与概念成分as-of；派生锚可在输入齐全时复算，latest入口不可直接删除。

### data/retrospective/
- 分类：historical_experiment_plus_source_tools
- 生产者：embedded _gather/_analyze/_backtest_node/_finalize* scripts；data/retrospective/_gather.py:12-14,38-45 generates dated market CSV caches；data/retrospective/_analyze.py:10-16,28-34 consumes cached market data and old runtime plans
- 消费者：embedded analysis/render scripts；data/retrospective/_render_node.py:9-14; external temporary pickle + CSV
- 边界：非普通生产复盘目录；JSON结论、源计划与行情快照先保护，市场CSV只是可重建候选，未确认能按当时as-of重建。局部源码扫描无新增外部consumer命中，不证明无人使用。

### data/backtest/window_*/
- 分类：experiment_results_and_failure_evidence
- 生产者：research backtest window runner；src/research/backtest_window.py:25,66-73,136-149
- 消费者：CLI/人工汇总 (partly unknown)；run_backtest_window returns summary at line151; current scan does not establish external file reader
- 边界：四窗口8文件；原始summary/per_day不是大量磁盘负担，保留旧错误指标与污染证据；不可通过生产重跑来恢复/覆盖。

### data/health/
- 分类：mixed_state_run_evidence_and_ledger
- 生产者：health/fetch/research tools；scripts/health/check_datasources.py:459-467 checks report writer；src/fetch/lookback.py:33,40-55 fetch cursor；scripts/research/pipeline_state.py:33-34 pipeline state path；scripts/health/datasource_ledger.py:1730-1738 ledger writer
- 消费者：fetch lookback；src/fetch/lookback.py:40-47 cursor reader
- 消费者：summary build run freshness；scripts/research/build_research_summary.py:121-128 started_ns reader
- 消费者：reliability ledger/trend；scripts/health/datasource_ledger.py:1095-1103,1660-1669
- 边界：datasource_ledger明确禁止后来文件存在把旧missing事实改成成功；游标不是日志，台账历史不是可丢缓存。

### data/runtime/{sanban_zhaban,mainboard_yao4}/
- 分类：historical_research_experiment_caches_and_results
- 生产者：scripts/_tmp research CLIs；scripts/_tmp/sanban_zhaban_nextday.py:15-23；scripts/_tmp/mainboard_yao_4plus.py:14-19
- 消费者：mainboard_yao_4plus；scripts/_tmp/mainboard_yao_4plus.py:15 consumes sanban cache
- 消费者：yao_features；scripts/_tmp/yao_features.py:15-19 reads episodes and creates derived cache
- 消费者：yao_cluster_prelaunch；scripts/_tmp/yao_cluster_prelaunch.py:16,19,326 consumes cache/features/episodes
- 边界：有交叉消费者，不是孤立无主pkl；最大体积治理候选但暂停删除，确认实验是否继续与结果保留。

## 原地分类与待签迁移建议

1. **事实/正式版本/账本/错题/人工批准**：原地保护。保留源hash、来源时点、失败与部分完成状态、历史规则版本；账本按环境独立，禁止合并或清空。 保留口径：未设删除期限，待owner与用户签核。
2. **当前状态与接口**：原路径登记current/dated/loaded不同语义；状态快照与历史证据分型，不把全部runtime称缓存。 保留口径：按状态与引用关系签核，不按年龄一刀切。
3. **可重建缓存候选**：先逐文件类证明输入版本、权限成本、as-of复现和回滚；在原目录owner manifest中记录，后续可讨论压缩/分层保留，不先搬目录。 保留口径：待签；不默认30天。
4. **实验遗留与阅读干扰**：先原地标记experiment/evidence/script；默认检索排除嵌入工具但仍可显式查找。保留实验结论和参数。以后批准才迁到现有scripts/research、scripts/review等，不新建data_v1或平行四大目录。 保留口径：按项目/实验验收结项签核。
5. **未知归属**：矩阵在历史架构中注明用户维护；rules双格式不能据后缀判重复，未验证source-of-truth；登记owner/最后消费者与来源后再议。 保留口径：未明归属先保留。
6. **小型系统杂项**：可列精确文件待签清理，收益极小；.gitkeep与空目录可能是目录契约，不能连带删除。 保留口径：未执行。

推荐首项是只建立现路径owner/类型/消费者索引及默认检索排除，不迁移文件：成本最低、可减少后续误删。随后只对两大实验目录提出逐类缓存恢复验证；确认输入版本、权限和复算费用后才讨论压缩、保留数量或删除。37个脚本的未来搬迁目的地只复用现有scripts/research或scripts/review；每项必须改生成器/消费者并保留回滚映射。

## 不可混同的事实

- corrections有真实静态读者，不能“无人消费所以删”；其getter只截600字，保留全部错题比缩小这194KB更重要。
- health既有一次检查、流水线状态，又有fetch游标和跨日台账。删除游标会改变回看窗口；删除旧台账损害趋势和失败追溯。
- retrospective `_render_node.py:10`依赖临时pickle；本轮没读该pickle、没读CSV/JSON结果内容，不能承诺可重建。
- backtest调用compute_and_write/write_prediction，历史报告已指出正式research污染；本轮没运行。隔离写路径属另行代码与路径签核，不是授权清理目录。
- 不触碰canonical/staged/loaded版本区分、独立paper账本和私有账户。任何重构不能拿“文件更少”替代研究/执行许可边界。

## 可核验输出与限制

统计程序：`DATA_inventory.py`（scandir+lstat、从不读data内容）、`DATA_refs.py`（限定源目录静态关键词）、`DATA_probe.py`（有限公共样本hash）、`DATA_sources.py`（限定源码片段）、`DATA_report.py`（聚合报告）。对应JSON保留原数；DATA.json至少包含inventory/findings/ownership_examples/retention_proposals/approval_boundaries/limitations。

- 只读工作树，没有git操作、移动、删除、项目写入、交易、生产研究/复盘重跑、网络或项目模块导入。输出仅scratch DATA*。
- 敏感正则是保守路径筛选，不是已完成DLP；681文件为命中筛选的聚合量，不等同681个真实敏感文件。私有目录明细未输出，所有DB/SQLite/凭据均未开。仅打开公共规则与daily_check样本做字节hash；未读运行事件内容。
- 只检索6类源码/文档目录，659份文本为静态关键词扫描，不是659份深读；历史文档命中只作背景。未核OS调度、外部机器、LLM动态消费日志或所有人工操作；静态零命中不是无人使用。
- 元数据扫描是短时间区间，不是事务快照；st_size为逻辑字节，st_blocks*512为分配量估计，APFS压缩/克隆/快照/硬链接/稀疏文件使其不等于唯一物理占用或可回收空间。
- 有限哈希18文件、3672087字节，非全量查重；不对2GB数据全量hash，不解pickle，不检查每个JSON完整性/每条latest新鲜度。
- 用户所附data/data在当前树未复现；不能否定另一时点、机器或未展示路径存在。
- 一条组合heredoc命令返回pending_approval、未计为执行成功；哈希独立命令与已落scratch源码摘录脚本随后实际执行成功。未修改/保存技能，跨任务工作流由主控决定。

外部边界参考：本次已读同级前轮A-architecture/F-evaluation/H-reconciliation报告。旧审计结论仅约束去留，不冒充本轮动态复验。源码扫描与hash命令实际退出0；没有生产完成、策略有效性或真实账户表现承诺。
