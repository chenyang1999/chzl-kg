# V1-DOCS｜1.00 文档与职责关系核对

**范围：2026-10-24 只读工作树；无网站核心。仅生成本报告与JSON，没有修改项目、SOUL、skill、配置、cron、Git。**

## 结论

1. 旧 `docs/00-CANONICAL-ARCHITECTURE-v1.md` **已不存在**。内容承接者是现存 `docs/02-历史架构蓝图.md`，`00-阅读指南`、`skills/README` 及其正文目录树互证。**没有读Git，不能认证哪次提交执行了mv、何时改名或逐字一致。** 00称它2026-08-02，正文实际写v1.2定稿2026-07-04、v1.2.1修正2026-07-05，也应消歧。
2. 不需要重写整套宪法。保留无情绪纪律、研究/交易分离、D1独立取舍、artifact通信、R6硬否决、诚实降级与用户签核等资产；整理的是**效力、时效和消费者对应关系**。
3. 推荐沿用 **`docs/00-阅读指南.md` 为唯一人读主入口**；01只记部署事实，architecture只解释原理，10–12解释契约并链接实际schema/registry。发布号 **1.00不等于schema_version改成1.00**。
4. 用户已明确不要网站：1.00核心交付应是**可审计JSON + 可读MD + 业务状态/必要通知**。网站不再是验收前提；**不等于已授权停网站、删API、改隧道或退役任何服务**。

## 一、版本关系与职责地图

| 层/文件 | 本轮观察 | 1.00建议定位 |
|---|---|---|
| 根README | v6“即将完全重构”、13页工作台、公网站点叙事；有8处相对断链 | 只说明产品范围并指向00，不再作为另一份现状图 |
| 00-阅读指南 | 2026-08-31；称01唯一当前、02历史 | 唯一主入口：范围、权限、现状、契约、验收、未决项 |
| 01-系统现状全景 | v2，2026-08-31；旧时刻、旧DAG、watcher暂停 | 唯一部署现状表；逐项as_of、入口、owner、消费者、未知项 |
| 02-历史架构蓝图 | CANONICAL v1.2/1.2.1正文；仍称“唯一权威” | 保留历史原文，只加效力说明；不把施工部署当今日强制指令 |
| architecture/README与分章 | 2026-10-01、9/30样本；10/12单元混写 | 架构解释主文；规模与样本标日期，不冒充实时清单 |
| 03-数据源与降级 | 仍列sanji主源、WeFlow可选 | source_id的active/optional/retired/compatibility表 |
| 10/11/12契约 | 部分最新保护已修，但旧字段与skeleton尚混杂 | 人读契约与代码逐字段对应，当前能力/设计/待验收分开 |
| 09-交易端运行手册 | 6/15计划、live默认、旧wrapper例子 | 先标legacy；隔离fixture通过后才作为执行手册 |
| skills/README | 新CANONICAL路径已修；章节定位与旧清单待更新 | 只指职责入口，不把目录名等同实际加载owner |
| 14-项目边界 | 薄触发器边界有价值；正文累积过时与后续修正 | 保留边界，不照旧迁移命令再操作一次 |
| pipeline/schema/registry/loader | 当前实际接受行为 | 运行证据；不是反向批准策略的依据 |

完整逐文件地图见JSON `document_map`。

### 实际主链（直接读源码，不运行）

`run_research_shell_cron_wrapper.sh` → 独立worker/交易日guard/等manifest → `run_research_shell.sh`：

**R1/R4/R7并行 → R3（等R1）→ R2（读R3/R4）→ 按R2候选预渲染vision → R5 → R6 → build_research_summary → D1（canghai-plan独立会话）→ 单向runtime交接 → 业务状态对账。**

证据：shell:148–246；wrapper:18–71。R6只读已落盘研究；summary构建器不重跑规则研究。`src/orchestrator/pipeline.py` 不应凭同名认成日研究LLM主链；本轮此点仅参考A审计，不扩大到其他入口退休。

### 活跃引用核对

- Python精确扫描非归档 `src` 207个、`skills` 164个文本文件：**旧token `00-CANONICAL-ARCHITECTURE-v1` 均0命中**。项目内这一旧引用迁移已经做过，不能再报成未修。最终计数不跟随symlink，未覆盖全局技能所有副本。
- 根README仍有 **8处**其他旧路径断链：行7/176/214的`docs/01-架构总览.md`，114的`docs/runbooks/daily-ops.md`，120/216的`docs/trading_agent_datasources.md`，215的`docs/02-闭环自进化机制.md`，217的`docs/trading_agent_runtime_runbook.md`。
- `skills/README`、00、01、architecture/README的本地行内Markdown链接均可解析；**不代表章节锚点、裸代码路径或内容已正确**。
- 本轮实际加载的外部纪律skill仍有 **2处**旧CANONICAL引用（第8、201行），且`§2.5`误指profile处置；相关sign-off原文在§1.4、§5.2和§5.1的L3。它是活动技能，不是项目历史附件，须另签修订。

## 二、权限与效力：不要混成一条“新文档压旧文档”

| 载体 | 有什么权限 | 没有什么权限 |
|---|---|---|
| **SOUL** | 身份、角色、写入白名单与硬边界；用户当前明确指令仍决定本轮授权 | 文档/skill不许静默改它；工具写得进去不等于获授权；不因版本整理就自动同步 |
| **项目架构宪法/批准决策** | 认知分工、稳定不变量、变更程序与通信边界 | 历史时刻/来源/部署数量不能永久支配今日；“唯一权威”不是运行事实证明 |
| **操作手册** | 经实测的启动、诊断、隔离验证和回滚步骤 | 不能代替实盘授权，不能把无效参数当验证，更不能自动停任务 |
| **skill** | 角色流程、模板、允许输入与推理方法；展开后是活动指令 | 不能越SOUL白名单或硬门禁；顶部退役提示不能容忍后文仍必调 |
| **可执行契约** | schema/registry/loader/状态机决定真实接受与副作用 | 当前代码缺陷不自动合法；不能为让测试绿而反改宪法或放松预算 |
| **历史样本/记忆** | 带日期的证据与解释 | 不是当天许可；不能凭样本完成推导研究就绪或获准下单 |

主SOUL第51–52行明确：配置/skill/SOUL/路径先diff等签，SOUL须用户当面同意。本轮**不建议静默改SOUL**。第33句“节点只定温度”和第38句“阶段决定打法/上限”可理解为资格/上限约束与允许集合内择法，**不列确定矛盾**。时刻表不新鲜可以单列待澄清，不借此重写身份。

## 三、八个最重要漂移（不是八起生产事故）

### DOCS-01｜旧宪法已有现存承接文件，但权威声明与旧引用没有完全收束

**分类：文字错；P1。** 旧 docs/00-CANONICAL-ARCHITECTURE-v1.md 不存在；02-历史架构蓝图.md 承接了 CANONICAL v1.2/v1.2.1 内容，00 与 skills/README 均指向它。可以确认内容承接/现路径，未读取 Git，不能认证实际 mv 的提交、日期或逐字相同。

证据：`docs/00-阅读指南.md`:9-10,26；`docs/02-历史架构蓝图.md`:1-21,82-87,413；`skills/README.md`:3-4；`/Users/chenyang/.hermes/skills/workflow-discipline/codebase-modification-discipline/SKILL.md`:8,201。

**最小处理：**保留历史正文，只加历史效力边界；修入口和精确旧引用。全局 skill 另列 diff 等签，不以项目整理为由改它。

### DOCS-02｜网站中心叙事与无网站1.00范围冲突

**分类：需用户决定 / 文字错；P1。** 本轮用户明确不要网站，因此 1.00 交付不应要求 React、Nginx、公网站点或网页按钮验收。旧 README 的“主站必须指向 Nginx”是旧部署条件，不是核心研究系统的永久必要条件。无网站不等于已停服务，也不授权删除 API/共享逻辑。

证据：`README.md`:17-29,91-114,180-198；`docs/02-历史架构蓝图.md`:1205-1230,1255-1296；`/Users/chenyang/.hermes/skills/canghai-architecture-principles/SKILL.md`:Web 看板精简 / STATE.md 模式。

**最小处理：**文档先改为无网站核心交付；网站列存量非核心、待独立退役评估。具体停用清单、消费者迁移和回滚须单独签核，不能顺手停任何任务。

### DOCS-03｜现状文档、SOUL时刻表及真实pipeline依赖已不同步

**分类：文字错 / 需用户决定；P1。** 01 是 2026-08-31 快照，architecture 是 2026-10-01 快照；不能同时标今日真实状态。实际 shell 为 R1/R4/R7 并行→R3→R2→R5（其前按R2候选做vision）→R6→summary→D1(plan profile)→runtime交接。SOUL中的旧时刻不能静默改写；不据文档直接改 cron。

证据：`docs/01-系统现状全景.md`:18-30,46-90；`docs/architecture/README.md`:23-34,46-74；`scripts/research/run_research_shell.sh`:148-246；`/Users/chenyang/.hermes/SOUL.md`:9-13。

**最小处理：**1.00文档把职责不变量与部署时刻分开，部署表只保留一处并附核验日期与证据；重新登记实际调度仍需授权只读核对。SOUL只登记待用户裁决，不提供自动改写。

### DOCS-04｜旧来源指令仍活跃：WeFlow硬调用与sanji主源

**分类：文字错；P1。** R3文首退役通知与后文必调协议自相矛盾；03数据源文档仍把三刀当主源，而当前 fetch 脚本已调用 RSS。不是建议恢复WeFlow、sanji或mptext。

证据：`skills/analyze_sentiment_resonance_v1/SKILL.md`:19-20,62-89,107-115；`docs/03-数据源与降级.md`:81,139-159；`skills/fetch_all_sources_v1/SKILL.md`:18,22-45；`scripts/fetch/fetch_all_sources.py`:35-37,79-113,159-165,372-373；`scripts/research/run_research_shell.sh`:173。

**最小处理：**旧配方转历史说明/不可执行段，保留兼容字段的disabled语义；同步03与fetch模式说明。修改skill语义单独等签；本轮只报告。

### DOCS-05｜人读schema落后于执行注册与正式源规则

**分类：文字错 / 实现缺陷 / 需用户决定；P1。** 11仅列两种entry及部分旧exit，而真实注册是5种entry/8种exit。10仍要求7键全部存在和昨日fallback，与现实现只列本次可用主产物不符。12还写“昨日plan原样执行”，不应成为容错授权。另一方面load_plan在canonical不存在时仍回退runtime，确有实现/契约差距，不能假称已全封。

证据：`docs/11-契约-盘前预案.md`:3,138-160,179-190；`trading/executors/registry.py`:27-44；`trading/schema/watchlist_plan.py`:50-82,123-147；`trading/load_plan.py`:33-38,54-102；`docs/10-契约-研究汇总.md`:50-53；`scripts/research/build_research_summary.py`:25-55,65-113；`docs/12-契约-竞价修订.md`:32-34,270-279。

**最小处理：**冻结现有真实schema口径并从registry校验文档；发布号1.00不修改schema枚举。canonical缺失是否保留受限legacy兼容必须用户决定；未裁决前不能标“仅正式源强制已实现”。P1/P2 observe-only与auto-reload分别标明，不能靠改文档启用。

### DOCS-06｜不能把已修summary、confidence、交接、日历保护再写成当前全局缺陷

**分类：已修内容 / 文字错；P1。** architecture中的9/30缺summary样本仍可作历史证据，但当前shell已有summary步骤；空confidence已有null保留及真实0保护；坏canonical拒绝/限制版禁止自动晋升已存在。研究wrapper也已接交易日guard，不能再概括“全系统没有日历”。这不证明完整业务或所有入口已通过。

证据：`docs/architecture/01-设计哲学.md`:65-77；`docs/architecture/05-调度与时序.md`:102-135,145-160；`scripts/research/run_research_shell.sh`:105-138,217-271；`scripts/research/pipeline_artifacts.py`:110-173,176-181；`trading/load_plan.py`:122-153；`scripts/research/run_research_shell_cron_wrapper.sh`:18-55；`docs/10-契约-研究汇总.md`:28,97-104；`docs/11-契约-盘前预案.md`:3,29。

**最小处理：**在入口列“已实现保护/待验收缺口”双栏，历史案例标日期，不删除证据，不撤掉保护。保留canonical缺失fallback、未知日历fail-open等未解子项。

### DOCS-07｜旧具体规则仍可能抵消现行研究与授权分层

**分类：文字错 / 需用户决定；P1。** 半路禁止、R1零confidence默认50%、北向缺失令R7整体归零或默认50%是具体冲突候选，不以主SOUL“节点只定温度”与“阶段决定打法”两句机械制造冲突。当前主SOUL并未明确对所有半路授予交易权；须保留禁新/零预算等最终门禁。

证据：`skills/short_line_thinking_v1/SKILL.md`:195-207；`skills/main_decision_v1/SKILL.md`:218,337,914；`skills/analyze_capital_flow_v1/SKILL.md`:247-272；`/Users/chenyang/.hermes/SOUL.md`:27-38,49-52；`docs/01-系统现状全景.md`:145-149,173-180。

**最小处理：**只提交最小skill语义diff：缺源只标缺口；未知与评价零区分；不得把缺源/零confidence自动转正仓。具体半路是否可在资金确认与预算内作为通道需用户裁决，不借术语统一放宽交易资格。

### DOCS-08｜旧运行手册的验证命令已不等价于今天的验证

**分类：文字错 / 实现缺陷；P1。** 09仍拿6/15 live计划和旧wrapper做dry-run示例，但兼容wrapper明确忽略--quote-json/--now；这样的命令不能证明固定行情或固定时间被消费。当前daemon仍load后intraday，各自到dispatch，不能由文档写“唯一执行器”就视为通过。

证据：`docs/09-交易端-运行手册.md`:3-20,53-62；`scripts/trading_agent_intraday_watcher.py`:20-59；`src/execute/watcher_daemon.py`:167-170；`trading/load_plan.py`:330-336；`trading/watcher/run_once.py`:59-70；`/Users/chenyang/.hermes/cache/scratch/system-audit-20261024/H-reconciliation.md`:54-60。

**最小处理：**先给09加旧入口兼容/不作验收提示；后续经授权提供隔离fixture用例，核quote/time注入与一轮一次dispatch。禁止直接复制旧live命令做1.00验收，也不以dry_run标签推导没有状态写入。

## 四、最小整顿顺序与唯一入口方案

**推荐先做入口/效力/已修状态这批文案**：成本低，立刻减少Agent误读，不改策略、不换路径、不扩大系统。

1. **入口批次（先提交diff等签）**：README→00；00定义无网站1.00范围及权限；02加历史效力提示；01去掉无日期“真实状态”断言；architecture保留日期样本并补“已修/待验收”。不新造第二本宪法。
2. **契约与手册批次**：10对齐本次主产物/null/0；11对齐registry与accepted schema；12删除昨日回退执行授权、注明observe-only；09先标旧入口不可作验收，后经隔离测试补命令。
3. **单独待签的活动指令批次**：R3旧WeFlow必调、fetch全系统禁no-agent、R7整体归零/默认正仓、D1零confidence正仓及半路规则的精确语义diff；不顺带改SOUL。全局skill不假装已由项目文档修好。
4. **实现/退役不是文档补丁**：canonical缺失兼容、双dispatch另列实现授权；网站仅退出产品验收范围，后续服务退役要查调用者/共享逻辑/恢复方案并逐项签核。不能用“不要网站”推导可整删src/api、src/agents或数据目录。

主入口00建议只保留八块：范围；效力/权限；01部署事实；architecture原理；10–12及代码定位；可用手册/隔离验证；已修与未决；02等历史溯源。让01与architecture互链，不继续争“谁是第二个唯一权威”。

## 五、小型建议diff草案（仅展示，未修改原件）

以下是审阅草案，不是已批准补丁。旧README首段的长链接句仅作定位摘要；最终应用前需对当时原文生成精确diff。

**PD-01 · `README.md`** — 项目文档最小diff签核后实施

```diff
@@
-> 老版本即将完全重构；目标架构见 docs/01-架构总览.md。
+> 1.00 范围（待发布签核）：无网站核心研究—计划—执行适配—复盘闭环。
+> 现行阅读入口：docs/00-阅读指南.md；网站/公网部署不属于1.00核心验收。
+> 本声明不代表已停用任何现存服务或放行实盘。
```

**PD-02 · `docs/02-历史架构蓝图.md`** — 只加说明，不重写旧宪法；签核后实施

```diff
@@
 # 沧海巨浪 · 权威架构文档 v1
+
+> 历史蓝图：承接原 CANONICAL v1.2/v1.2.1。正文“唯一权威”指施工期语境。
+> 现行范围从 00-阅读指南.md 进入；部署事实以带核验日期的现状表为准。
+> 身份/安全边界、已签规则及变更签核要求不因归档失效。
```

**PD-03 · `docs/00-阅读指南.md`** — 入口整顿，非另造宪法；签核后实施

```diff
@@
-# docs/ 阅读地图（2026-08-31 更新）
+# docs/ 阅读指南（1.00 发布候选，待签核）
+
+> 产品范围：无网站核心；JSON 是机器交付，MD 是人读交付。
+> 01 记录部署现状与核验时间；architecture/ 解释原理；10–12 解释契约。
+> 02 是历史蓝图，不以旧时刻/来源覆盖当前实现；SOUL 修改另行当面授权。
```

**PD-04 · `docs/10-契约-研究汇总.md`** — 对齐现实现；签核后实施

```diff
@@
-- 7 个键必须全部存在（即使某单元 failed，路径仍指向占位 JSON 或昨日 fallback）
+- artifacts 仅列本次有效主产物；缺失单元记 timeouts/units/contract_results，状态明确失败或部分完成。
+- 不用昨日引用或占位文件冒充本次研究；confidence 未评价为 null，真实 0 原样保留。
```

**PD-05 · `docs/11-契约-盘前预案.md`** — 只补说明，不修改可执行契约版本或交易权限；签核后实施

```diff
@@
-**type 枚举值（必须正确）：**
-- `trend_pullback_buy` - 趋势股回踩低吸买入
-- `leader_breakout` - 龙头突破买入
+**入场 type（与 trading/executors/registry.py 同步）：**
+`trend_pullback_buy` / `leader_breakout` / `daban_confirm` / `low_absorption_intraday` / `t_add_pullback`。
+退出 type 同步 registry 的8项；未知 type 在交接时拒绝。
+发布号1.00与schema分离：当前交接仅接受 `1.0` / `watchlist_plan_v1`。
+注意：canonical缺失时现loader仍可回退runtime；该legacy兼容是否关闭须另签，不能标作已封。
```

**PD-06 · `docs/12-契约-竞价修订.md`** — 纠正危险旧文字；不启用auto-reload；签核后实施

```diff
@@
-  用昨日 `watchlist_plan.json` 原样执行）；P2（午盘修订）30 分钟窗口，相对宽松，
+  不合并本次 amendment）；仅允许在当日有效预案及既有授权内继续，不能借超时启用昨日预案。P2 窗口单列，
+  observe-only 与自动合并分别声明；自动应用须单独签核及实现验收。
```

**PD-07 · `/Users/chenyang/.hermes/skills/workflow-discipline/codebase-modification-discipline/SKILL.md`** — 全局skill单独签核，不能随文档补丁执行

```diff
@@
-**宪法依据**：`docs/00-CANONICAL-ARCHITECTURE-v1.md` v1.2 §2.5（"E2 不能自动改，必须用户 sign-off"）
+**历史依据**：`docs/02-历史架构蓝图.md` v1.2 §1.4 / §5.2（E2仅提建议，变更须sign-off）；现行入口见 `docs/00-阅读指南.md`。
```

以上未覆盖所有旧句；只给最小方向，不以小草案冒充全量迁移。PD-05的8个exit逐项见JSON `executable_contract`，实现时应从registry比对，不人工发明新type。SOUL无任何拟应用diff。

## 六、1.00可验证验收条款（本轮没有宣称通过）

- **V1-DOC-A01**：1.00范围表显式排除网站建设与公网部署，核心交付=可审计JSON+人读MD+状态/必要通知；不把QMT live作为文档改版默认授权。
  - 验法：审阅00/01及批准记录；无站点也能定位同一trade_date的研究、计划、修订、复盘；服务退役另有单独批准。
  - 本轮：`pending_scope_document_patch`。
- **V1-DOC-A02**：根README、00、01、architecture、skills/README所有本地Markdown链接可解析；现行规范不再依赖不存在的CANONICAL旧路径。
  - 验法：离线路径解析，排除历史归档但单列外部加载skill；精确旧token扫描；内部报告型历史引用不计有效规范链接。
  - 本轮：`failed_root_readme_8_broken_occurrences_external_skill_2_old_refs`。
- **V1-DOC-A03**：唯一部署现状表能逐项给owner、真实触发入口、as_of、产物、消费者与deadline；DAG和shell依赖相符，历史快照明确不作今日断言。
  - 验法：静态提取shell阶段与部署登记对照；实际cron重新只读白名单投影核对，不打印凭据；未读项标unknown。
  - 本轮：`partial_shell_verified_schedule_not_reaudited`。
- **V1-DOC-A04**：正式源/运行副本/loaded投影三层有明确路径owner与许可，不把同名副本误当重复可删。
  - 验法：隔离fixture覆盖坏canonical、缺canonical、旧runtime、同日限制→live；缺canonical兼容政策另签后断言，禁止以删runtime替代收口。
  - 本轮：`partial_bad_canonical_and_no_promotion_present_missing_canonical_fallback_remains`。
- **V1-DOC-A05**：plan文档类型集合等于registry，并写明accepted schema=1.0/watchlist_plan_v1；发布号1.00不触发schema重命名。
  - 验法：AST提取registry与Markdown类型集合比对；未知schema/type交接拒绝测试。
  - 本轮：`failed_doc_type_sets_drift`。
- **V1-DOC-A06**：summary只引用本次合法主产物；未知confidence=null、真实0原样保留；交付成功、研究就绪与执行授权分开。
  - 验法：在隔离输出根运行缺R、旧同日R7指针、null/0/false/NaN及缺MD等fixture；参考tests/test_canghai_repair_plan_contracts_20261023.py但先审副作用。
  - 本轮：`implementation_present_tests_not_rerun`。
- **V1-DOC-A07**：退役源不会因技能旧正文被必调；RSS可达空文、实际错误与retired三态明确，缺源不自动赋予正预算。
  - 验法：静态核R3/fetch/R7/main_decision各活动正文；批准后用离线来源状态fixture，断言无WeFlow强调用与零预算不被替换。
  - 本轮：`failed_stale_active_skill_instructions`。
- **V1-DOC-A08**：P1/P2明确observe-only或已批准应用；超时不套昨日计划；时间戳区分观察/构建/提交。
  - 验法：同日计划ref版本不匹配、超时、空items均不扩权；对声明期限逐日检查真实业务产物完成时间；不把captured_at当交易所观察/写盘完成。
  - 本轮：`pending_isolated_and_business_deadline_acceptance`。
- **V1-DOC-A09**：操作手册中每条fixture命令确实消费指定行情和时点；成功轮次只dispatch一次，重复意图不重复动作；禁新不误伤合法退出。
  - 验法：隔离测试桩计数与参数观察；严禁真实QMT/生产路径；旧wrapper ignored 参数不算验证；现双dispatch需实现修复另批。
  - 本轮：`failed_static_runbook_and_dispatch_gap`。
- **V1-DOC-A10**：SOUL、skill、配置、路径或停用变更均有单独diff和用户签核；未批准保持不动；已修保护和历史证据不被抹掉。
  - 验法：逐文件批准范围对照；规则有authority/owner/version/supersedes/approval/test；SOUL改动必须当面授权，不以文档优先顺序覆盖。
  - 本轮：`respected_this_read_only_audit_release_approval_pending`。

**验收分账：**文档可读/断链清零 ≠ 工程修复通过 ≠ 研究业务完成 ≠ 实盘许可。若1.00包含执行适配，双dispatch、缺正式源回退政策等未决不能被文档整理掩盖；若先发研究/计划版，必须明确执行仅受限模式，不给整体交易安全认证。

## 七、边界、局限与交付

- 只读文档、明确相关技能、主SOUL和源码；未读取凭据、私有账户/持仓/成交/独立paper账本，也未读Git。没有网络、模型调用、服务/cron/生产pipeline运行或pytest。
- 静态依赖、引用计数、registry AST来自真实Python探针输出；没有把源码检查当业务端到端验收。现文件可能继续变化，不是一致性部署快照。
- 实际cron本轮未重新全量核对；A/G/H旧报告均带截止日期。采用H纠正：主SOUL两句不机械判冲突、旧keepalive风险不等于当前注册wrapper、已修保护不重复报未修。本轮不复述未经本次核对的北向optional全局实现声明。
- 研究/计划/复盘owner、JSON与KG MD、运行副本、独立paper与QMT边界都应保留；没有因为减重而删除资产、降低R6/预算/合法退出保护。
- **仅新建**授权scratch内`DOCS.md`和`DOCS.json`。原项目文档、配置、技能、SOUL、cron与路径均未修改；不保存新skill（超出本轮授权）。
