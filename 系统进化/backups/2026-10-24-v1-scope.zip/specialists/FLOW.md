# V1-FLOW｜报告是否日更、是否真正进入盘前预案

**固定样本：2026-10-19—23。只读核对，未修复、未代跑、未联网取数。**
项目根：`/Users/chenyang/Downloads/demo/沧海巨浪`。以下路径除特别说明均相对此根；逐日字段、来源哈希、代码行及日志投影见 `FLOW.json`。

## 结论

**不是所有报告每天生成，也不是所有现存报告都汇入D1。核心研究有正式主链，但交付不齐、辅助接入不统一、读取收据不足。**

- 七研究×五日共 **35个应交槽**，当前主JSON **34/35**、KG主MD **34/35**：缺的是 **10/20 R7**。这是“现在有文件”，不是“34份按时、完整且当时被读过”。10/22 R5为合法空池跳过；10/23七份是午间恢复版。
- `research_summary.json` **4/5**，10/20缺；五天都有现存LLM来源预案，但10/20绕过缺失汇总直接引用R1—R6与原始资金代理，10/22现存版09:53、10/23现存版14:22，**不能算五天盘前主链全成功**。
- 最明确的辅助非闭环：独立宏观报告固定目标五天都缺；节点预测与预测验证五天都缺；生命周期文件五天都是空骨架。图表虽五天都有，10/23旧12票与午间R5四候选 **0/4重合**；股性只证明规则版读取、不能冒充LLM主路径接入。
- **不能说“LLM已经消化全部研报”**：本轮核到路径引用、结果字段、CLI汇报及部分输入hash，没有逐文件成功读取的结构化tool-event收据。现存10/22、23预案合计 **20/20个所核已声明hash与当前文件匹配**，只证明当前版本相符，不等于独立读取证明，更不是理解/因果证明。

## 四层必须分开

| 层级 | 本次能核什么 | 不能顺推什么 |
|---|---|---|
| L1 文件存在 | 真实路径、JSON可解析、MD、时间/状态、当前hash | 不证明按时生成、当时版本或完整研究 |
| L2 汇总引用 | `summary.artifacts`、`fetch_manifest`与R*内部辅助引用 | 路径提供给Agent不等于Agent实际打开 |
| L3 Agent实际读取 | 应有session/tool事件，绑定run/attempt/path/hash与投影范围 | 本次CLI日志、diff和`file_read_status=ok`自报不足以独立认证；无日志记“未证”，不是“没读” |
| L4 决策采纳 | plan中的明确接受/拒绝/延后及理由、对应字段 | “引用”不等于采纳；采纳声明不等于模型理解、判断正确或允许交易 |

## 报告 → 汇总 → 预案：核心与主要辅助全图

记号：`研究/{D}`＝`data/research/{D}`；`KG/<类>`＝`chzl_kg/投研交易/<类>/{D}.md`；`raw/{D}`＝`data/raw/{D}`。JSON列是机读入口；XLSX不伪称MD。**“进D1”列描述已证路径/声明，不给LLM读取认证。**

| 报告 | 实际触发频率 / 生产者 | 机读JSON / 人读交付 | 直接消费者 → 间接消费者 | 汇总 → D1接入及样本缺口 |
|---|---|---|---|---|
| R1 风格 | 工作日06:10流水线 / research LLM | `R1_style.json` / KG风格研判 | R3、R2、R6、D1 → 复盘 | 七主指针之一；22/23降级，23为恢复批 |
| R2 主线 | 同批，R3之后 / research LLM | `R2_main_sectors.json` / KG主线研判 | R5、R6、D1 → 复盘 | 七主指针之一；19—21因子层缺口，22无候选，23保留研究载体 |
| R3 情绪/热榜 | 同批，R1之后 / research LLM | `R3_sentiment.json` / KG群聊情绪 | R2、R6、D1 → 复盘 | 七主指针之一；19/21 JSON complete但MD降级；20降级标记；22/23降级 |
| R4 消息 | 同批基础并行 / research LLM | `R4_news.json` / KG消息面 | R2、R5、R6、D1 → 复盘 | 七主指针之一；22/23 partial，不以事件数量替代证据质量 |
| R5 画像 | 同批R2/图表之后 / research LLM | `R5_stock_profiles.json` / KG个股画像 | R6、D1 → 复盘 | 七主指针之一；画像9/10/10/0/4。22 skipped，原执行日志MD被白名单阻塞；当前MD存在 |
| R6 反证 | 同批R1—R5/R7之后 / research LLM | `R6_devil_advocate.json` / KG反证 | D1 → E1/E2 | 七主指针+hard_reject提取；22/23降级；23正式反证未完成，空否决不是通过 |
| R7 资金 | 同批基础并行 / research LLM | `R7_capital_flow.json`，同日带日期主产物可解析 / KG资金面 | R2、R5、R6、D1 → 复盘 | **20缺JSON和MD**；19/21有降级；22置信度0；23 partial，北向可选缺失非全域失效 |
| 研究汇总 | 每次R6之后 / `build_research_summary.py` | `research_summary.json` / 无固定summary.md | D1 → 后续预案消费者 | 仅收七主产物路径、状态、置信度/校验及R6否决，不是全部报告正文总包；20缺 |
| 独立宏观 | 有手动/旧入口，所核启用任务无独立日更 / `hermes_macro_daily.py` | `data/runtime/hermes_macro_{D}.json` / `data/reports/hermes_macro_{D}.md` | 旧宏观/sector-effects调用面；本轮未认证在线消费 | 不在七主指针；五日两类目标均缺，未证到D1。**R1外盘、D1宏观方法论不是读独立宏观报告**；不据此判已退休 |
| 图表/视觉 | 每日R2后R5前，失败回退 / `run_chart_vision_snapshot.py` | `raw/{D}/chart_vision_snapshot.json` / 无独立MD，应嵌R5图片/结论 | R5 → R6、D1；22恢复预案另声明读快照 | 不在summary主键，R5内部引用为间接接入。19—21逐票可见；22空池未产画像；23四票视觉全null，不能说图表全接通 |
| 股性表 | **月度**：1日06:40；另18日18:30股性+锚任务，可手动 / stock构建器 | `data/cache/stock_character.json` / 个股股性目录XLSX，不是MD | 锚构建器、规则`d1_algorithm` → R2间接先验 | 当前10/17表/缓存，不应每天缺报；五份LLM plan股票均无`stock_character`字段，规则模块读缓存不能算LLM读过 |
| 题材心智锚 | 股性更新后/月度18日；skill另要求每周，未检得独立每周注册 / `build_theme_anchors.py` | `data/rules/theme_anchors/latest.json`与日期版 / KG题材心智锚`20261020_*.md` | R2、一字预测脚本 → D1 | 不在summary主键；21—23 R2明确引用10/20版；19/20 R2未见引用。22历史锚是先验，不替代当日龙头资格 |
| 错题本 | E1日复盘+事件 / review Agent | 本样本主要MD，E1_data含纠错字段 / `data/corrections/{week}/error_case_*.md` | D1、E2 → 下一日研究/预案 | 不在summary；19/20/21 plan分别声明采纳4/3/4条。22限读未读取，23明确`applied=false`，不虚算闭环 |
| 情绪周期 | 每日fetch预计算 / `compute_cycle_metrics` | `emotion_cycle.json`、`emotion_cycle_closed.json` / 嵌R1/R3/预案，无独立MD契约 | R1/R3/D1、预测验证 → 温度/风险说明 | fetch manifest另有指针，非summary.artifacts；五日均有，**closed五日均标盘前代理，不是收盘actual** |
| 主线生命周期 | 每日fetch生成骨架，R2应填 / compute→R2 | `mainline_lifecycle.json` / 嵌R2，无独立MD | R2 → D1 | 五日`lines=[]`。23 R2有内嵌生命周期诊断，不等于外部文件已回填，不给完整生命周期日更认证 |
| 人气/周末热度 | 每日fetch；周一/节后08:30补采 / attention管道 | `研究/{resolved_D}/attention_signals.json`、`attention_weekend.json` / 嵌R3，无独立MD契约 | R3/R5/D1按需 → R2/D1 | fetch manifest指实际归属日：19指16、20指19、21指20、22指21、23指22。**19—22当日目录当前有但均次晨才生成；23缺**，不能回填盘前成功 |
| 明日节点预测/验证 | CLI手动可用；本次启用主shell/fetch/所核cron未检得每日触发 / `node_predict`、`prediction_track` | `node_prediction.json`、`prediction_track.json` / 渲染器有条件嵌入 | 预案渲染器、规则R6 M5、复盘/回测 | 两文件五日均缺；渲染是决策后处理，不证明D1先读。情绪阶段文件不等于两跳预测，历史命中率不代替本周交付 |
| 次日一字预测 | 工作日22:00，可手动 / `run_yizi_predict.py` | KG一字板预判`{data_D}.json` / 同目录MD | 用户；脚本读心智锚 → D1未证 | 以**数据日命名→下一交易日**，不是同日盘前输入。JSON五份；19缺MD；19/20现存版分别次日15:30才生成，非有效隔夜收据；23预测26是未来 |
| E1 / E2 | E1工作日18:00；E2周度契约，所核任务未见E2注册，未遍查其余profile | `data/reports/{D}/E1_data.json`；`data/evolution/2026-W43/weekly_summary.json` / E1报告与KG复盘、系统进化周报 | E2/用户 → 错题本/D1下一日 | 不进同日summary；E1五日都有，22/23 partial；E2 23日17:02版早于周五E1 18:22，不能叫完整周闭环 |
| P1 / P2（下游） | P1每日09:28、P2每日11:40 / plan Agent | `data/plans/{D}/{auction,midday}_amendment.json` / KG竞价判断、午盘briefing须分清展示与修订 | 用户/修订消费者 → reload未认证 | 不属于盘前研究输入。P1五日全timeout；P2 21缺，19/20自报complete，22/23 timeout；不凭JSON存在称已执行采纳 |

> 扩池、事件追踪、催化剂等另有辅助交付：本次目录核到扩池五日MD、事件追踪五日MD、催化剂10/19 MD，已注册频率分别为工作日06:30、每日19:00、周一07:30。它们**没有因此自动成为七主汇总输入**；本轮没有逐项审计其机读产物及消费者，不宣称“所有辅助都接入”。本表重点为七研究与所问宏观、图表、股性/锚、纠错和预测节点，不扩成全仓审计。

## 五日交付矩阵：当前文件 ≠ 历史按时成功

`C`＝产物status complete；`D`＝degraded标记/状态；`P`＝partial；`S`＝合法skipped；`缺`＝固定主路径未检得。C不抹掉字段级/MD降级。

| 报告/交付 | 10/19 | 10/20 | 10/21 | 10/22 | 10/23现存恢复版 |
|---|---|---|---|---|---|
| R1 JSON / KG MD | C / 有 | C / 有 | C / 有 | D / 有 | D / 有 |
| R2 JSON / KG MD | C因子降级 / 有 | C因子降级 / 有 | C因子降级 / 有 | P无候选 / 有 | P / 有 |
| R3 JSON / KG MD | C / MD降级 | C且D / MD降级 | C / MD降级 | D / 有 | D / 有 |
| R4 JSON / KG MD | C / 有 | C / 有 | C / 有 | P / 有 | P / 有 |
| R5 JSON / KG MD | C，9画像 / 有 | C，10画像 / 有 | C，10画像 / 有 | S，0画像 / 当前有，原run曾阻塞MD | P，4画像 / 有 |
| R6 JSON / KG MD | C / 有 | C / MD降级 | C / 有 | D / 有 | D、正式未完成 / 有 |
| R7 JSON / KG MD | 有且D / 有 | **缺 / 缺** | C且D / 有 | P、conf=0 / 有 | P / 有 |
| summary | complete 07:29 | **缺** | complete 07:43 | skeleton 06:44 | partial **14:13** |
| D1 JSON / KG MD | llm 07:37 / 有 | llm 08:01 / 有，直接读R1—R6 | llm 07:47 / 有 | llm **09:53恢复** / 有 | llm **14:22恢复** / 有 |
| `data/plans/{D}/plan.md` | 缺 | 缺 | 缺 | 缺 | 缺 |
| 图表快照→R5画像覆盖 | 9/9 | 10/10 | 10/10 | 画像0，快照12票 | **0/4**，快照12票 |
| 独立宏观JSON/MD | 未检得 | 未检得 | 未检得 | 未检得 | 未检得 |
| 生命周期JSON | 空骨架 | 空骨架 | 空骨架 | 空骨架 | 空骨架 |
| 节点预测 / prediction_track | 缺/缺 | 缺/缺 | 缺/缺 | 缺/缺 | 缺/缺 |
| attention同日目录 | 有，20日次晨生成 | 有，21日次晨生成 | 有，22日次晨生成 | 有，23日次晨生成 | 缺 |
| 错题本当周新增MD / D1采纳声明 | 2 / 4条旧案 | 2 / 3条旧案 | 1 / 4条旧案 | 4 / 未读 | 3 / 未读，applied=false |
| E1 JSON / 两类MD | C / 都有 | C / 都有 | C / 都有 | P / 都有 | P / 都有 |
| 一字预测JSON / MD | 有 / 缺；次日15:30版 | 有 / 有；次日15:30版 | 有 / 有；22:00版 | 有 / 有；22:00版 | 有 / 有；目标26日 |

`plan.md`五天缺不等于用户预案五天没交：五天KG主MD都存在。当前shell D1 prompt只授权核心JSON与KG主MD，明示不写附加MD；skill仍要求多份点位/价位报告。这是**交付契约/ownership冲突**，应统一，不先越权补文件或把旧run倒填成功。10/21另有点位表与价位推导，不能据此说每天都有这些附加报告。

## 真实代码与历史日志的追踪结果

1. **当前调用链不是Python代做七研究。** 已安装default wrapper → 仓库cron wrapper → `run_research_shell.sh`。真实顺序是R1/R4/R7并行 → R3 → R2 → 图表预渲染 → R5 → R6 → 汇总 → **canghai-plan身份D1**。证据：shell **148—243行**、cron wrapper **57—71行**。不采用shell顶部已过时的“R3并行/R2-R5并行”注释。
2. **当前汇总是指针/质量manifest，不是报告全文合订本。** `build_research_summary.py:25—55`只遍历七主映射；本run的health交付与时间检查后收主产物，`58—113`写真实状态、run_id、校验与否决；底层`orchestrator.py:331—372`写`fetch_manifest/artifacts/units/confidence`。宏观、图表、锚、预测不会自动加进`artifacts`。R7解析只允许同日精确带日期主产物：`pipeline_artifacts.py:76—107`，不能用任意evidence文件凑数。
3. **当前D1 prompt也不是“读所有目录”。** shell **241行**限定“仅使用本次summary.artifacts列出的主产物”，只写核心JSON与KG主MD；而D1 skill另有情绪、attention、错题本等要求。必须按本次授权范围与实际plan记述判断，不把skill里的愿望当读取事实。23日plan明确不读summary之外错题本；22日也明确限读未查。
4. **历史实现确实不同，不能拿今天源码覆盖整周。** 20日日志`cron_061207.log:56—65`明确R7缺导致当时汇总不生成，D1仍继续并直接消费；R7.log **454行**明确交付物未落盘。22日日志`cron_061147.log:41—46,74`为D1三次失败/MD缺，而现存09:53版是后续恢复。23日晨批console有06:49汇总/06:54结束，但D1.log已是14:22恢复汇报、health也是恢复run，**旧console成功不认证晨批研究质量/当前内容**。
5. **来源版本问题可定位但不猜根因。** 19日summary自报07:29却列R2/R5 07:52、R4 07:35、R6 07:58；21日summary07:43、plan07:47，当前R6自报07:52。可能是后续重写或时间元数据不可靠；没有不可变版本不能还原当时精确输入。22日所核8份研究/汇总+4份raw声明hash全匹配；23日summary+七主产物8项全匹配，但上游run_id多未内嵌，plan自身也承认不能做全链run认证。
6. **23日的“08:00”不是完成时刻。** summary仍有`completed_by=08:00`，实际`generated_at=14:13:47`；plan14:22:58，health14:24完成。plan同时`production_ready=false / research_completion_passed=false / reassessment_required=true`，不能以交付completed宣称研究完成。

## 最小改进：先做收据，不合并所有研究，也不做网站

**首推：扩展现有health/summary为一条版本化交接收据，再输出本地每日MD索引。** 成本和权限边界最小，能直接回答“今天少哪份、有没有用”，不要求新抓数、不增网站、不强迫每种报告日更。

| 收据层 | 最少字段 | 防止什么误判 |
|---|---|---|
| 生产交付 | report_id、run_id、attempt、应交频率/截止点、目标交易日/数据归属日、实际生成时刻、JSON/MD路径与hash、`delivery_status`及`research_status`分列 | 月报当缺日报、旧文件顶新run、JSON可读掩盖MD漏交、partial当complete |
| 汇总绑定 | declared_path、resolved_path、hash、producer_run、required/optional/historical、校验/缺口、迟到标记 | 辅助孤岛、R7别名错指、历史/恢复版混入盘前 |
| Agent读取 | 实际session_id、成功tool_event_id、read_at、path、hash、full/field_projection | “给了路径”当“确实读取”；收据应来自真实工具事件，不让Agent自填一个绿灯 |
| 决策采纳 | report/claim_id、source_hash、plan字段JSON pointer、accepted/rejected/deferred/not_read、简短理由 | “读过”当“采用”、引用过但没用、旧错题反复声明已避开 |

最小本地交付只需一页：`应交/已交/迟到/未到期 → summary绑定 → 已读/未证 → 采纳/拒绝/未用`。辅助先登记required/optional/historical及消费者；不必把所有全文塞进D1，也不能用大prompt制造“都接上”的假象。月度股性保留源版本，R2读锚可登记为间接依赖；独立宏观和节点预测若要纳入V1，应先决定是否为必需输入、谁触发、失败怎么显式降级，再签核接线。

**验收要点：** 同run/attempt绑定JSON与承诺MD；实际读取无日志就显示未证；恢复版保留时间与版本不补历史；23→26一字预测只记未来目标；不因收据齐全抬零预算、解禁交易或把研究未就绪转为通过。完整拟议schema在JSON的`proposed_receipt`，本轮未实施。

## 边界与交付

- 复用C/E/H的恢复版、研究就绪与交付分离、P1超时及E1已有paper消费者等纠正结论；本次独立核主链、日文件、hash和来源字段。**不重报“E1完全孤岛/没消费paper”**，也不重新读取账本。
- 未遍查所有profile、旧入口、全文或每个辅助主题；宏观无本周目标文件不等于从未生成或已获准退休。没有结构化工具读取证据，不说模型一定读过，也不说它一定没读。
- 仅写授权scratch：`FLOW.md`、`FLOW.json`与可重算的`FLOW_probe.py`。JSON含21项报告目录、五日矩阵、代码/日志/manifest证据、未证明消费、最小收据、验收及限制。未改项目、配置、cron、skills、Git或历史产物；未跑任何生产/金融任务。
