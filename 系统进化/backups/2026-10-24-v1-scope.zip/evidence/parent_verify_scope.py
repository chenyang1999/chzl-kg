"""Parent read-only verification of V1 scope evidence; no production jobs/imports."""
from __future__ import annotations
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import stat

BASE = Path(__file__).resolve().parent
ROOT = Path('/Users/chenyang/Downloads/demo/沧海巨浪')

def load(p):
    return json.loads(Path(p).read_text())

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

web, data, flow, docs = [load(BASE / f'{n}.json') for n in ('WEB','DATA','FLOW','DOCS')]
# UI retirement never includes the two headless indicator libraries.
ui = web['pure_ui_manifest']
protected = web['keep_dependencies']['protected_web']
assert len(ui) == len(set(ui)) == 51
assert not (set(ui) & set(protected))
assert all((ROOT / p).is_file() for p in ui + protected)
actual_ui = {str(p.relative_to(ROOT)) for p in (ROOT / 'web/src').rglob('*') if p.is_file()}
actual_ui -= {'web/src/lib/technicalIndicators.js', 'web/src/lib/bullBearIndicator.js'}
assert actual_ui == set(ui)
headless = (ROOT / 'web/scripts/headless/lwc_headless_render.mjs').read_text()
assert '../../src/lib/technicalIndicators.js' in headless and 'playwright' in headless
assert 'lightweight-charts/dist/' in headless and 'chart_template.html' in headless
package = load(ROOT / 'web/package.json')
assert package['type'] == 'module' and 'playwright' in package['devDependencies']
# Recount metadata without reading file contents or following symlinks.
totals = {'files': 0, 'logical_bytes': 0, 'symlinks': 0, 'python_files': 0, 'python_bytes': 0}
subtotals = {name: 0 for name in ['runtime/sanban_zhaban', 'runtime/mainboard_yao4']}
errors = []
for current, dirs, files in os.walk(ROOT / 'data', followlinks=False):
    for name in list(dirs):
        p = Path(current) / name
        if p.is_symlink():
            totals['symlinks'] += 1
            dirs.remove(name)
    for name in files:
        p = Path(current) / name
        try:
            s = p.lstat()
        except OSError as e:
            errors.append(type(e).__name__)
            continue
        if stat.S_ISLNK(s.st_mode):
            totals['symlinks'] += 1
        elif stat.S_ISREG(s.st_mode):
            totals['files'] += 1
            totals['logical_bytes'] += s.st_size
            if p.suffix == '.py':
                totals['python_files'] += 1
                totals['python_bytes'] += s.st_size
            rel = str(p.relative_to(ROOT / 'data'))
            for prefix in subtotals:
                if rel.startswith(prefix + '/'):
                    subtotals[prefix] += s.st_size
assert not errors
old = data['inventory']['totals']
data_delta = {k: totals[k] - old[k] for k in ['files','logical_bytes','symlinks']}
# Core count and current hash checks using explicitly public research artifacts.
core_json = core_md = 0
missing = []
checked_hashes = 0
for day in flow['daily_matrix']:
    td = day['trade_date']
    for unit, info in day['research_units'].items():
        for kind in ('json','md'):
            rec = info[kind]
            p = ROOT / rec['path']
            present = p.is_file()
            assert present == rec['exists'], (td, unit, kind, 'existence drift')
            if present:
                assert sha(p) == rec['sha256'], (td, unit, kind, 'content drift')
                checked_hashes += 1
                if kind == 'json': core_json += 1
                else: core_md += 1
            else:
                missing.append({'day':td,'unit':unit,'kind':kind})
assert core_json == flow['counts']['core_json_present'] == 34
assert core_md == flow['counts']['core_kg_md_present'] == 34
assert len(flow['daily_matrix']) * 7 == flow['counts']['core_expected_slots'] == 35
summary_count = sum((ROOT / f'data/research/{d["trade_date"]}/research_summary.json').is_file() for d in flow['daily_matrix'])
assert summary_count == flow['counts']['summaries_present'] == 4
r5 = load(ROOT / 'data/research/20261023/R5_stock_profiles.json')
charts = load(ROOT / 'data/raw/20261023/chart_vision_snapshot.json')
profiles = r5['profiles']
profile_symbols = {x['ts_code'] for x in profiles}
chart_symbols = set(charts['results'])
assert len(profile_symbols) == 4 and not profile_symbols.intersection(chart_symbols)
# The actual D1 restriction explains why auxiliary inputs cannot be assumed read.
shell = (ROOT / 'scripts/research/run_research_shell.sh').read_text()
assert '仅使用本次 research_summary.json artifacts 列出的主产物' in shell
assert not (ROOT / 'docs/00-CANONICAL-ARCHITECTURE-v1.md').exists()
assert (ROOT / 'docs/02-历史架构蓝图.md').is_file()
result = {
 'verified_at': datetime.now().astimezone().isoformat(),
 'scope': 'read-only metadata, bounded public research hashes, source literals; no service/runtime certification',
 'web': {'spa_candidate_files': len(ui), 'protected_files_exist': len(protected), 'headless_dependencies_confirmed': True, 'runtime_executed': False},
 'data': {'current_totals':totals, 'delta_from_child_inventory':data_delta, 'large_experiment_bytes':subtotals,
          'large_experiment_share_pct':round(sum(subtotals.values()) / totals['logical_bytes'] * 100,2),
          'GiB':round(totals['logical_bytes']/1024**3,3), 'is_reclaimable_space_estimate':False,
          'nested_data_data_exists':(ROOT/'data/data').exists()},
 'flow': {'expected_slots':35,'json_present':core_json,'md_present':core_md,'public_file_hashes_rechecked':checked_hashes,
          'missing':missing,'summaries_present':summary_count,'r5_candidates_20261023':len(profile_symbols),
          'chart_overlap_20261023':len(profile_symbols.intersection(chart_symbols)), 'd1_auxiliary_input_restriction_confirmed':True},
 'docs': {'old_canonical_missing_successor_exists':True, 'release_accepted':False},
 'changed_production_files': [], 'production_jobs_executed':False}
path = BASE / 'parent-scope-verification.json'
assert not path.exists(), 'Refuse overwrite'
path.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
