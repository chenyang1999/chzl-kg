# 本批工程证据包

本包不是完整系统、干净Git提交、生产数据备份或实盘许可。

- report.md：授权、实际测试、修复边界、未尽事项。
- native-final/：主控当前冻结树原生JUnit与机器回执；native-before-F4/：前一轮真实红测。
- before/、after/、repair-only.patch：仅本批六个实现及三个新增测试的字节与增量。基底是修前脏工作树，不是HEAD；不要盲目向不同工作树应用。
- runner/：实跑入口的同字节副本，依赖原项目工作树、现有.venv、macOS隔离工具；不是独立安装包。
- pending-skills.patch：未批准的语义差异建议，不可当作已经应用；不包含角色权限放宽。
- knowledge/：最终导航与四项精确迁移的摘要核验；不含私人交易材料、Wiki正文或模型配置私有备份。

复跑：将本包解到本机授权scratch中的新目录；先对照 native-final/source-manifest.json 核验当前项目字节。用项目 .venv/bin/python -B <解包目录>/runner/run_joint.py --mode final --label <未用过的简单名称>。

每次实际冻结／回归都会生成新证据，不能拿之前的绿测认证后来改过的源码。禁止把这个入口改为生产账户、业务模型、行情或调度任务运行器。
