#!/usr/bin/env python3
"""F3 finite offline joint gate. Each invocation re-freezes CURRENT allowlisted bytes.
Run with project .venv/bin/python -B run_joint.py --mode final after A3 stops.
Any drift, guard event, identity mismatch, failure/skip gives NONZERO. The
original independent C2-F1 test remains unmodified; after repair it must pass.
"""
from pathlib import Path
import argparse, ast, datetime as dt, hashlib, json, os, shutil, subprocess, sys, uuid
import xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parent
REPO=Path('/Users/chenyang/Downloads/demo/沧海巨浪')
PY=REPO/'.venv/bin/python'
KNOWN='test_C2_F1_existing_plan_reader_must_reject_replaced_bound_input'
C2_FILES=['scripts/research/pipeline_artifacts.py','scripts/research/pipeline_state.py','scripts/research/reconcile_pipeline_status.py','scripts/research/build_research_summary.py','scripts/research/run_research_shell.sh','src/research/orchestrator.py','src/research/contract_checks.py','src/plan/main_decision.py','src/plan/d1_algorithm.py','src/plan/render_markdown.py','src/research/stock_character.py']
SHIMS=['scripts/execute','scripts/research','scripts/plan','src/execute','src/trading_agent','trading/schema','trading/order','trading/executors','trading/watcher']
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def clock():return dt.datetime.now().astimezone().isoformat()
def clone_files(src,dst,rels):
    for rel in rels:
        p=dst/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/rel,p)
def env_for(root,group=None,app=None):
    env={'PATH':str(PY.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','HOME':'/Users/chenyang','LANG':'en_US.UTF-8','LC_ALL':'en_US.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','TMPDIR':str((group or root)/'fixtures')}
    Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
    if group:
        (group/'audit-receipts').mkdir(parents=True,exist_ok=True)
        env.update(F3_RUN=str(root),F3_GROUP=str(group),F3_APP=str(app),PYTHONPATH=str(root/'guard')+os.pathsep+str(app))
    return env

def command(argv,cwd,env,out,timeout=550):
    out.mkdir(parents=True,exist_ok=True)
    dump(out/'command.json',{'argv':argv,'cwd':str(cwd),'env':env,'started_at':clock()})
    try:
        cp=subprocess.run(argv,cwd=cwd,env=env,text=True,capture_output=True,timeout=timeout)
        rc=cp.returncode; stdout=cp.stdout;stderr=cp.stderr;error=None
    except subprocess.TimeoutExpired as exc:
        rc=124;stdout=exc.stdout or '';stderr=exc.stderr or '';error='harness timeout'
    (out/'stdout.txt').write_text(stdout.decode(errors='replace') if isinstance(stdout,bytes) else stdout)
    (out/'stderr.txt').write_text(stderr.decode(errors='replace') if isinstance(stderr,bytes) else stderr)
    dump(out/'exit.json',{'returncode':rc,'error':error,'finished_at':clock()})
    return {'argv':argv,'cwd':str(cwd),'returncode':rc,'evidence':str(out),'error':error}

def cases(path,group):
    if not path.is_file():return []
    rows=[]
    for x in ET.parse(path).iter('testcase'):
        status=next((s for s in ['failure','error','skipped'] if x.find(s) is not None),'passed')
        rows.append({'identity':x.get('classname','')+'::'+x.get('name',''),'name':x.get('name',''),'classname':x.get('classname',''),'group':group,'status':status,'junit':str(path),'detail':'' if status=='passed' else ''.join(x.find(status).itertext())})
    return rows

def canonical(nodeid):
    # Source file plus class/function/param id; no flattening parameter identities.
    a,*b=nodeid.split('::'); return '/'.join(a.split('/')[-(3 if '/pipeline/' in a else 2):])+'::'+'::'.join(b)

def inspect_drift(repo,manifest):
    drift={}
    for rel,info in manifest.items():
        path=Path(repo)/rel
        after={'sha256':sha(path)} if path.is_file() and not any(x.is_symlink() for x in [path,*path.parents]) else {'missing_or_symlink':True}
        if after.get('sha256')!=info['sha256']:drift[rel]={'frozen':info,'after':after}
    return drift

def gate_exit(drift,frozen_drift,copies,violations,coverage,harness_errors,receipts,totals):
    return 2 if drift or frozen_drift or copies else 96 if violations else 3 if coverage else 4 if harness_errors else 1 if any(r['returncode'] for r in receipts) or any(totals[s] for s in ['failure','error','skipped']) else 0

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['preflight','final'],default='preflight')
    p.add_argument('--label',default=None)
    args=p.parse_args();label=args.label or args.mode+'-'+dt.datetime.now().strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:6]
    if not label.replace('-','').replace('_','').isalnum():p.error('simple label required')
    root=BASE/label;root.mkdir()
    config=json.loads((BASE/'scope.json').read_text()); old=json.loads((BASE/'case-identity-contract.json').read_text())
    files=sorted(set(config['legacy_sources']+config['research_sources']))
    frozen=root/'frozen';frozen.mkdir();started=clock();manifest={}
    for rel in files:
        src=REPO/rel
        if not src.is_file() or any(x.is_symlink() for x in [src,*src.parents]):raise ValueError('missing/linked allowlist source: '+rel)
        blob=src.read_bytes()
        if src.suffix=='.py':ast.parse(blob)
        dst=frozen/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(blob)
        manifest[rel]={'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'mtime_ns':src.stat().st_mtime_ns}
    freeze_end=clock();dump(root/'source-manifest.json',manifest)
    # Reusable harness/support evidence is local, explicitly named and hashed.
    clone_files(BASE,root,['audit_worker.py','case-identity-contract.json','research_worker.py','legacy_bootstrap.py','scope.json','run_joint.py'])
    clone_files(BASE/'support',root/'support',['legacy_s2_before_ledger.py','test_s3_ast_diagnostics.py','test_audit_d_diagnostics.py'])
    (root/'guard').mkdir();shutil.copyfile(BASE/'research_guard.py',root/'guard/sitecustomize.py')
    receipts=[];coverage=[];rows=[];subtests=[];all_collections={};audits=[]
    phases=['collection','execute']
    for phase in phases:
        stage=root/phase;stage.mkdir()
        clone_files(root,stage,['audit_worker.py','case-identity-contract.json'])
        clone_files(root/'support',stage/'support',['legacy_s2_before_ledger.py','test_s3_ast_diagnostics.py','test_audit_d_diagnostics.py'])
        dump(stage/'source-manifest.json',{k:manifest[k] for k in config['legacy_sources']})
        oldwriter=stage/'pre/app/trading/paper/ledger.py';oldwriter.parent.mkdir(parents=True);shutil.copyfile(root/'support/legacy_s2_before_ledger.py',oldwriter)
        for group in config['old_groups']+list(config['new_groups']):
            g=stage/group;app=g/'app';(g/'fixtures').mkdir(parents=True)
            isold=group in config['old_groups']; selected=config['legacy_sources'] if isold else config['research_sources']
            clone_files(frozen,app,selected)
            if isold:
                for d in SHIMS:
                    f=app/d/'__init__.py';f.parent.mkdir(parents=True,exist_ok=True);f.write_text('')
                clone_files(root/'support',app/'tests',['test_s3_ast_diagnostics.py','test_audit_d_diagnostics.py'])
                argv=[str(PY),'-B',str(stage/'audit_worker.py'),group]
                env=env_for(root);env['TMPDIR']=str(g/'fixtures')
            else:
                for d in ['scripts','scripts/research','scripts/plan','src/plan']:
                    f=app/d/'__init__.py';f.parent.mkdir(parents=True,exist_ok=True)
                    if not f.exists():f.write_text('')
                argv=[str(PY),'-B',str(root/'research_worker.py'),config['new_groups'][group]]
                env=env_for(root,g,app)
            if phase=='collection':argv+=['--collect-only']
            rec=command(argv,app,env,g);rec.update(group=group,phase=phase)
            receipts.append(rec)
            meta=json.loads((g/'run.json').read_text()) if (g/'run.json').is_file() else {}
            collection=json.loads((g/'collected-nodeids.json').read_text()) if (g/'collected-nodeids.json').is_file() else []
            if not meta or not collection:coverage.append({'phase':phase,'group':group,'issue':'missing collection/metadata'})
            if isold and sorted(collection)!=old['groups'][group]['collected']:coverage.append({'phase':phase,'group':group,'issue':'fixed old identity contract mismatch','missing':sorted(set(old['groups'][group]['collected'])-set(collection)),'unexpected':sorted(set(collection)-set(old['groups'][group]['collected']))})
            if phase=='collection':all_collections[group]=collection
            elif sorted(collection)!=sorted(all_collections[group]):coverage.append({'group':group,'issue':'collection execution identity mismatch'})
            if phase=='execute':
                group_rows=cases(g/'junit.xml',group);rows+=group_rows
                if len(group_rows)!=len(collection):coverage.append({'group':group,'issue':'collection vs native JUnit count mismatch','collection':len(collection),'native':len(group_rows)})
                if isold and sorted(x['identity'] for x in group_rows)!=old['groups'][group]['junit']:coverage.append({'group':group,'issue':'fixed old native JUnit identity mismatch'})
                if not isold:
                    expected=[]
                    for node in collection:
                        path,*parts=node.split('::');classname=path[:-3].replace('/','.')+(':'+':'.join(parts[:-1]) if len(parts)>1 else '')
                        classname=classname.replace(':','.')
                        expected.append(classname+'::'+parts[-1])
                    if sorted(expected)!=sorted(x['identity'] for x in group_rows):coverage.append({'group':group,'issue':'collected vs native execution identity mismatch'})
                st=json.loads((g/'subtest-index.json').read_text()) if (g/'subtest-index.json').is_file() else []
                subtests += [dict(x,group=group) for x in st]
            audit_files=list((g/'audit-receipts').glob('audit-*.json'))
            if not isold and not audit_files:coverage.append({'phase':phase,'group':group,'issue':'missing guard persistence receipt'})
            for a in audit_files:
                audits.append({'file':str(a),**json.loads(a.read_text())})
            if meta.get('violations'):audits.append({'file':str(g/'run.json'),'violations':meta['violations']})
            print(json.dumps({'phase':phase,'group':group,'exit':rec['returncode'],'collected':len(collection)}),flush=True)
        if phase=='collection':
            identities={}
            for group,nodes in all_collections.items():
                for node in nodes:identities.setdefault(canonical(node),[]).append(group)
            duplicates={i:g for i,g in identities.items() if len(g)>1}
            dump(root/'collection-unique-case-list.json',{'unique':sorted(identities),'duplicate_scheduled':duplicates,'groups':all_collections})
            if duplicates:
                coverage.append({'issue':'duplicate selection; stopped before execution','duplicates':duplicates});break
            if any(x['returncode'] for x in receipts if x['phase']=='collection'):
                # Failed collection remains an explicitly failed harness; do not
                # exercise a cohort whose import boundary was not established.
                coverage.append({'issue':'collection preflight failed; execution suppressed'});break
    # Independent C2 queue, all original 38 function cases plus four shell cases.
    c2=root/'c2';c2.mkdir();clone_files(BASE/'c2_assets',c2,['guard.py','real_modules.py','test_c2_boundaries.py','pytest.ini','run_checks.py','shell_probe.py','shell_child.py'])
    snap=c2/'snapshot';snap.mkdir();clone_files(frozen,snap/'code',C2_FILES)
    for rel in ['scripts/__init__.py','scripts/research/__init__.py','src/__init__.py']:
        f=snap/'code'/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('')
    dump(snap/'snapshot.json',{'sources':{k:manifest[k] for k in C2_FILES},'purpose':'F3 common finite frozen snapshot'})
    for group,worker,label,selection in [('c2-functions','run_checks.py','functions','not '+KNOWN),('c2-known-F1','run_checks.py','known-F1',KNOWN),('c2-shell','shell_probe.py','shell',None)]:
        out=c2/label;env=env_for(root);env['HOME']=str(c2);env['TMPDIR']=str(c2/'fixtures');Path(env['TMPDIR']).mkdir(exist_ok=True)
        if selection:env['C2_SELECTION']=selection
        rec=command([str(PY),'-B',str(c2/worker),str(snap),label],c2,env,c2/('command-'+label),180);rec.update(group=group,phase='execute');receipts.append(rec)
        rows+=cases(out/'junit.xml',group)
        for a in out.rglob('audit*.json') if out.exists() else []:
            d=json.loads(a.read_text());audits.append({'file':str(a),'violations':d.get('unexpected_violations',d.get('violations',[]))})
        if (out/'result.json').is_file():
            d=json.loads((out/'result.json').read_text());audits.append({'file':str(out/'result.json'),'violations':d.get('unexpected_guard_violations',[])})
        print(json.dumps({'phase':'execute','group':group,'exit':rec['returncode'],'native_cases':len(cases(out/'junit.xml',group))}),flush=True)
    # Deduplication and native identities: no summing delegated self-reports.
    byid={}
    for row in rows:byid.setdefault(row['identity'],[]).append(row)
    dupe={k:len(v) for k,v in byid.items() if len(v)>1}
    if dupe:coverage.append({'issue':'native duplicate identities','duplicates':dupe})
    oldrows=[r for r in rows if r['group'] in config['old_groups']]
    if len(oldrows)!=790:coverage.append({'issue':'prior fixed native count','expected':790,'actual':len(oldrows)})
    paper=[s for s in subtests if s['group']=='paper']
    if len(paper)!=65:coverage.append({'issue':'prior paper subtests','expected':65,'actual':len(paper)})
    # Old A2/B2 overlap is scheduled once; compare the 62/34/3 native names to
    # already-recorded receipts, not their status or reported totals.
    contract=json.loads((BASE/'additional-identity-contract.json').read_text())
    for group,expected in contract.items():
        actual=sorted(r['name'] for r in rows if r['group']==group)
        if actual!=sorted(expected):coverage.append({'group':group,'issue':'preserved additional identity mismatch','missing':sorted(set(expected)-set(actual)),'unexpected':sorted(set(actual)-set(expected))})
    c2rows=[r for r in rows if r['group'].startswith('c2-')]
    if len(c2rows)!=42:coverage.append({'issue':'C2 original total','expected':42,'actual':len(c2rows)})
    drift=inspect_drift(REPO,manifest);frozen_drift=[];copies=[]
    for rel,info in manifest.items():
        if sha(frozen/rel)!=info['sha256']:frozen_drift.append(rel)
    for rel in C2_FILES:
        if sha(snap/'code'/rel)!=manifest[rel]['sha256']:copies.append('c2:snapshot:'+rel)
    for phase in phases:
        for group in config['old_groups']+list(config['new_groups']):
            app=root/phase/group/'app'
            if not app.exists():continue
            for rel in config['legacy_sources'] if group in config['old_groups'] else config['research_sources']:
                if not (app/rel).is_file() or sha(app/rel)!=manifest[rel]['sha256']:copies.append(str(app/rel))
    violations=[a for a in audits if a.get('violations')]
    totals={s:sum(v[0]['status']==s for v in byid.values()) for s in ['passed','failure','error','skipped']}
    known=[r for r in rows if r['group']=='c2-known-F1']
    known_rc=next(r['returncode'] for r in receipts if r['group']=='c2-known-F1')
    known_boundary_retained=len(known)==1 and known[0]['name']==KNOWN and known[0]['status']=='failure' and known_rc==1
    known_fixed=len(known)==1 and known[0]['name']==KNOWN and known[0]['status']=='passed' and known_rc==0
    if not (known_boundary_retained or known_fixed):
        coverage.append({'issue':'original independent C2-F1 test lost or inconsistent result'})
    unexpected_failures=[r for r in rows if r['status']!='passed' and r['group']!='c2-known-F1']
    harness_errors=[r for r in receipts if r['returncode'] not in [0,1] or r.get('error')]
    # Drift never returns zero; the known strict negative never makes overall green.
    rc=gate_exit(drift,frozen_drift,copies,violations,coverage,harness_errors,receipts,totals)
    result={'mode':args.mode,'label':root.name,'root':str(root),'freeze_started_at':started,'freeze_finished_at':freeze_end,'finished_at':clock(),'snapshot_manifest_sha256':sha(root/'source-manifest.json'),'source_count':len(manifest),'exit_code':rc,'totals':dict(unique_cases=len(byid),**totals),'prior_fixed_cases':len(oldrows),'prior_paper_subtests':len(paper),'subtests_total':len(subtests),'subtests_by_group':{g:sum(s['group']==g for s in subtests) for g in sorted({s['group'] for s in subtests})},'coverage_errors':coverage,'current_source_drift':drift,'frozen_drift':frozen_drift,'app_copy_drift':copies,'guard_violations':violations,'harness_errors':harness_errors,'known_C2_F1_boundary':{'retained_strict_original_name_exit1':known_boundary_retained,'exit':known_rc,'cases':known},'unexpected_product_failures':unexpected_failures,'runs':receipts,'scope':'finite offline working-tree snapshot, never A3 final sign-off or a production cycle','limitations':['Native tests and exact relocated shell/fake Hermes only; no real model/market/QMT/IB/tasks/services/push.','No business network or production data/account/CSV/ledger/DB read. Synthetic paper SQLite is confined to original legacy fixture guard.','Source closure is explicit and minimal to reviewed existing fixtures; legacy internal copytree only sees this filtered frozen tree.','C2 uses its existing exact-AST orchestrator helper extraction and exact run_agent shell extraction; other research cohorts import unchanged real modules.','Not an OS-general sandbox; reviewed local shells use reused macOS seatbelt boundary plus inherited Python audit guard.','Preflight is not A3 final acceptance. Final mode still re-freezes and refuses any subsequent source drift.']}
    result['known_C2_F1_boundary']['fixed_by_original_test']=known_fixed
    result['scope']='parent final finite offline frozen working-tree regression; not a production-cycle or trading approval'
    dump(root/'native-case-index.json',[dict(identity=k,observations=v) for k,v in sorted(byid.items())]);dump(root/'subtest-index.json',subtests);dump(root/'guard-receipts.json',audits)
    combined=ET.Element('testsuites')
    for f in sorted({r['junit'] for r in rows}):
        tree=ET.parse(f).getroot()
        for suite in list(tree) if tree.tag=='testsuites' else [tree]:combined.append(suite)
    ET.ElementTree(combined).write(root/'junit.xml',encoding='utf-8',xml_declaration=True)
    harness_paths=[p for p in root.rglob('*.py') if p.parent in [root,root/'guard',root/'support',root/'c2']]
    dump(root/'harness-hashes.json',{str(p.relative_to(root)):sha(p) for p in harness_paths})
    dump(root/'F3-result.json',result);dump(BASE/'F3-result.json',result)
    counts={g:{s:sum(r['group']==g and r['status']==s for r in rows) for s in ['passed','failure','error','skipped']} for g in config['old_groups']+list(config['new_groups'])+['c2-functions','c2-known-F1','c2-shell']}
    md='# F3 '+args.mode+' 联合验收\n\n- Exit: **'+str(rc)+'**；不得描述为整体全过。\n- 冻结区间：'+started+' → '+freeze_end+'\n- Manifest SHA256: `'+result['snapshot_manifest_sha256']+'`（完整逐文件 hash：`source-manifest.json`）。\n- 唯一原生 case：'+str(len(byid))+'；状态 '+json.dumps(totals)+'。旧固定 '+str(len(oldrows))+' case、'+str(len(paper))+' paper subtests 独立核对。\n- 所有 subtests 分列：'+json.dumps(result['subtests_by_group'])+'。\n- C2-F1 原名严格失败/exit1 独立队列保留：'+str(known_boundary_retained)+'。\n- 当前源码漂移 '+str(len(drift))+'；冻结/复制漂移 '+str(len(frozen_drift)+len(copies))+'；身份/覆盖错误 '+str(len(coverage))+'；守卫违规 '+str(len(violations))+'；harness 错误 '+str(len(harness_errors))+'。\n\n## 原生队列\n\n| group | pass | fail | error | skip |\n|---|---:|---:|---:|---:|\n'
    for g,c in counts.items():md+='| '+g+' | '+' | '.join(str(c[s]) for s in ['passed','failure','error','skipped'])+' |\n'
    md+='\n## 重跑\n\n```sh\n'+str(PY)+' -B '+str(BASE/'run_joint.py')+' --mode final\n```\n\n每次新建 run、重新冻结当前白名单；不复用旧测试结果。退出 2=漂移，96=守卫，3=身份/覆盖，4=harness，1=严格测试失败（含已知 C2-F1）；0 仅所有测试实际通过且无任何边界错误。\n\n## 证据与限制\n\n完整命令/清理后环境、原生 JUnit、唯一身份、subtests、源码 hash 和守卫日志均在 `'+str(root)+'`。\n\n'+'\n'.join('- '+s for s in result['limitations'])+'\n\n## 未预期失败\n\n'+('\n'.join('- '+r['identity']+' ('+r['status']+')' for r in unexpected_failures) or '无')+'\n\n## 漂移与覆盖错误\n\n```json\n'+json.dumps({'drift':drift,'coverage':coverage,'harness':harness_errors},ensure_ascii=False,indent=2)+'\n```\n'
    (root/'F3-result.md').write_text(md);(BASE/'F3-result.md').write_text(md)
    print(json.dumps({'root':str(root),'exit':rc,'totals':result['totals'],'drift':list(drift),'coverage_errors':len(coverage),'guard_violations':len(violations)},ensure_ascii=False),flush=True)
    return rc
if __name__=='__main__':raise SystemExit(main())
