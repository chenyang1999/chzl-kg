"""Load real frozen functions. Only external holdings is a synthetic boundary."""
import ast, importlib, json, pathlib, sys, types

def package(name,path):
 m=types.ModuleType(name); m.__path__=[str(path)]; sys.modules[name]=m
 return m

def load(root):
 root=pathlib.Path(root)
 for name,rel in [('scripts','scripts'),('scripts.research','scripts/research'),('src','src'),('src.research','src/research'),('src.plan','src/plan')]: package(name,root/rel)
 # Summary's helper implementation is executed unchanged; importing unused
 # legacy rule builders would import settings/.env. Select exact AST nodes.
 p=root/'src/research/orchestrator.py'
 tree=ast.parse(p.read_text(),filename=str(p))
 names={'_now_iso','_rel','load_fetch_manifest','_read_r6_hard_rejects','build_research_summary'}
 nodes=[]
 for n in tree.body:
  if isinstance(n,(ast.Import,ast.ImportFrom)):
   if isinstance(n,ast.ImportFrom) and n.module=='src.research': continue
   nodes.append(n)
  elif isinstance(n,(ast.Assign,ast.AnnAssign)):
   nodes.append(n)
  elif isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names: nodes.append(n)
 m=types.ModuleType('src.research.orchestrator'); m.__file__=str(p)
 sys.modules[m.__name__]=m
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),m.__dict__)
 a=importlib.import_module('scripts.research.pipeline_artifacts')
 s=importlib.import_module('scripts.research.pipeline_state')
 b=importlib.import_module('scripts.research.build_research_summary')
 r=importlib.import_module('scripts.research.reconcile_pipeline_status')
 # Do not import settings or REST holdings. Use an explicitly synthetic empty
 # holdings boundary; all algorithm, reader and renderer functions remain real.
 q=types.ModuleType('src.plan.qmt_holdings')
 q.fetch_holdings_map=lambda: {}
 q.holdings_qty=lambda holdings,code: int((holdings or {}).get(code,{}).get('qty',0))
 sys.modules[q.__name__]=q
 package('src.collectors',root/'src/collectors')
 xt=types.ModuleType('src.collectors.xtick_collector')
 xt.XTickCollector=lambda: types.SimpleNamespace(latest_close=lambda code: None)
 sys.modules[xt.__name__]=xt
 algorithm=importlib.import_module('src.plan.d1_algorithm')
 main=importlib.import_module('src.plan.main_decision')
 return types.SimpleNamespace(a=a,s=s,b=b,r=r,o=m,algorithm=algorithm,main=main)
