"""Deny production I/O, credentials, network, processes; retain swallowed denials."""
import os, pathlib, sys
VIOLATIONS=[]
EXPECTED=[]
APPROVED_PROCESS=None
WRITABLE=None
C2=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/chenyang/Downloads/demo/沧海巨浪')
READ_ROOTS=(C2,pathlib.Path(sys.prefix).resolve(),pathlib.Path(sys.base_prefix).resolve(),pathlib.Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework').resolve(),pathlib.Path('/usr/lib'),pathlib.Path('/System/Library'))
class GuardViolation(PermissionError): pass

def _under(p,root): return p==root or root in p.parents

def deny(kind,path):
 item={'kind':kind,'target':str(path)}
 if EXPECTED: EXPECTED[-1].append(item)
 else: VIOLATIONS.append(item)
 raise GuardViolation(kind+': '+str(path))

def validate_path(value,write=False):
 if isinstance(value,int) or value is None: return
 try: p=pathlib.Path(os.fsdecode(value)).absolute().resolve()
 except (TypeError,ValueError): return
 if p.name=='.env' or p.name.startswith('.env.') or p.name in {'SOUL.md','credentials.json','accounts.json'}: deny('credential',p)
 if _under(p,REPO) and not (not write and _under(p,pathlib.Path(sys.prefix).resolve()/'lib')): deny('production_write' if write else 'production_read',p)
 if str(p)=='/dev/null': return
 if write:
  if WRITABLE is None or not _under(p,WRITABLE): deny('write_outside_run',p)
 elif str(p) not in {'/dev/null','/etc/localtime','/private/etc/localtime','/etc/hosts','/private/etc/hosts'} and not any(_under(p,r) for r in READ_ROOTS): deny('read_outside_allowlist',p)

def hook(event,args):
 if event=='open':
  mode=args[1]; flags=args[2]
  write=isinstance(mode,str) and any(c in mode for c in 'wax+') or isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
  validate_path(args[0],write)
 elif event in {'os.mkdir','os.remove','os.rmdir','os.chmod','os.utime','os.truncate','os.chown','os.link','os.symlink'}:
  validate_path(args[0],True)
  if event in {'os.link','os.symlink'}: validate_path(args[1],True)
 elif event in {'os.rename'}:
  validate_path(args[0],True); validate_path(args[1],True)
 elif event in {'os.listdir','os.scandir'}: validate_path(args[0])
 elif event=='sqlite3.connect': deny('database',args[0])
 elif event=='os.fork': deny('process',event)
 elif event.startswith('socket.') and event not in {'socket.__new__','socket.gethostname'}: deny('network',event)
 elif event in {'os.system','os.exec','os.posix_spawn','os.spawn','pty.spawn'}: deny('process',event)
 elif event=='subprocess.Popen':
  argv=tuple(str(v) for v in args[1]) if isinstance(args[1],(list,tuple)) else args[1]
  if APPROVED_PROCESS is None or argv!=APPROVED_PROCESS: deny('process',argv)
 elif event=='os.kill':
  if args[0]!=os.getpid() or args[1]!=0: deny('signal',str(args))

def interpreter_aliases():
    current=pathlib.Path(sys.executable); aliases={str(current)}; links=set()
    for _ in range(12):
        changed=False
        for part in [*reversed(current.parents),current]:
            if part.is_symlink():
                links.add(str(part)); target=part.readlink()
                target=target if target.is_absolute() else part.parent/target
                current=target/current.relative_to(part);aliases.add(str(current));changed=True;break
        if not changed:break
    return aliases,links

def install(write_root):
 global WRITABLE
 WRITABLE=pathlib.Path(write_root).resolve()
 sys.dont_write_bytecode=True
 sys.addaudithook(hook)

from contextlib import contextmanager
@contextmanager
def expected_denial():
 events=[]; EXPECTED.append(events)
 try: yield events
 finally: EXPECTED.pop()
