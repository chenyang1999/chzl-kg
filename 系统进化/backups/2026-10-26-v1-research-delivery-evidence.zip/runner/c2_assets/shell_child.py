#!/usr/bin/env python3
"""Only invoked via C2's OS-sandboxed, exact local helper paths."""
import json, os, pathlib, re, sys
BASE=pathlib.Path(__file__).resolve().parents[1] if pathlib.Path(__file__).resolve().parent.name.startswith('shell-') else pathlib.Path(os.environ['C2_BASE'])
sys.path.insert(0,os.environ['C2_BASE'])
import guard
root=pathlib.Path(os.environ['C2_SHELL_ROOT']).resolve()
guard.install(root)
from real_modules import load
modules=load(pathlib.Path(os.environ['C2_SNAPSHOT'])/'code')
for m in [modules.s,modules.b,modules.r,modules.o]: m.ROOT=root
DATE='20261025'; RUN='C2-shell-run'
name=pathlib.Path(sys.argv[0]).name
try:
 if name=='local-python':
  args=sys.argv[1:]
  expected=str(root/'scripts/research/pipeline_state.py')
  if not args or args[0]!=expected: raise ValueError('unapproved helper script')
  tail=args[1:]
  allowed=[]
  for attempt in range(1,4):
   for status in ['running','completed']:
    allowed.append(['stage','--stage','R1','--status',status,'--attempt',str(attempt),'--date',DATE,'--run-id',RUN])
   allowed.append(['stage','--stage','R1','--status','failed','--attempt',str(attempt),'--error',f'agent process/delivery failed (rc=7); log={root}/logs/R1.log','--date',DATE,'--run-id',RUN])
   allowed.append(['stage','--stage','R1','--status','failed','--attempt',str(attempt),'--error',f'agent process/delivery failed (rc=0); log={root}/logs/R1.log','--date',DATE,'--run-id',RUN])
  allowed.append(['check','--stage','R1','--date',DATE,'--run-id',RUN])
  if tail not in allowed: raise ValueError('unapproved state argv: '+repr(tail))
  sys.argv=['pipeline_state.py',*tail,'--root',str(root)]
  rc=modules.s.main()
 elif name=='fake-hermes':
  expected=['-p','canghai-research','chat','-Q','--yolo','-s','analyze_style_v1','--max-turns','60','-q','C2 synthetic local R1 only']
  if sys.argv[1:]!=expected: raise ValueError('unexpected fake-Hermes argv')
  state=modules.a.read_object(modules.s.state_path(root,DATE)); attempt=state['stages']['R1']['attempt']
  calls=root/'fake-calls.json'
  previous=json.loads(calls.read_text()) if calls.exists() else []
  previous.append({'argv':sys.argv[1:],'attempt':attempt,'run_id':state['run_id']})
  modules.a.atomic_json(calls,{'unused':True}) if False else None
  calls.write_text(json.dumps(previous))
  case=os.environ['C2_CASE']
  if case in {'success','nonzero-fresh'}:
   modules.a.atomic_json(root/f'data/research/{DATE}/R1_style.json',{'trade_date':DATE,'status':'complete','style':'synthetic','confidence':0})
   human=root/f'chzl_kg/投研交易/风格研判/{DATE}.md'; human.parent.mkdir(parents=True,exist_ok=True); human.write_text('# synthetic\nline\nline\nline\nline\n')
  elif case=='invalid-json':
   p=root/f'data/research/{DATE}/R1_style.json'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text('{broken')
  elif case=='no-output': pass
  else: raise ValueError('unapproved scenario')
  rc=7 if case=='nonzero-fresh' else 0
 elif name=='local-grep':
  args=sys.argv[1:]
  expected=['-q','429\\|rate.limit\\|too frequent\\|usage quota',str(root/'logs/R1.log')]
  if args!=expected: raise ValueError('unapproved grep argv')
  rc=0 if re.search(r'429|rate.limit|too frequent|usage quota',(root/'logs/R1.log').read_text()) else 1
 elif name=='local-wc':
  if sys.argv[1:]!=['-c']: raise ValueError('unapproved wc argv')
  print(len(sys.stdin.buffer.read())); rc=0
 else: raise ValueError('unapproved helper name')
finally:
 (root/('audit-'+name+'-'+str(os.getpid())+'.json')).write_text(json.dumps({'unexpected_violations':guard.VIOLATIONS}))
raise SystemExit(rc)
