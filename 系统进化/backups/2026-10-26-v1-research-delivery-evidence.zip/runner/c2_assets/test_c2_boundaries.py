"""Finite independent C2 tests. Synthetic fixtures only; no prod task/model."""
import copy, importlib, json, os, pathlib, socket, sys
import pytest
import guard
from real_modules import load
DATE='20261025'; RUN='C2-frozen-run'
MOD=load(pathlib.Path(os.environ['C2_SNAPSHOT'])/'code')
FIELDS={
 'R1': {'style':'synthetic','position_cap_suggestion':0.0},
 'R2': {'main_lines':[{'name':'synthetic','leaders':[{'ts_code':'000001.SZ'},{'ts_code':'000002.SZ'}],
                       'cross_validation':{'r3_resonance_match':False,'r4_catalyst_match':False,'r7_capital_match':False,'cross_validation_score':0}}], 'consensus_themes':[]},
 'R3': {'resonance_top_themes':[]}, 'R4':{'top_events':[]},
 'R5': {'profiles':[{'ts_code':'000001.SZ'}],'r2_expand_shortfall':4},
 'R6': {'counter_arguments':[{'ts_code':'000002.SZ','severity':'hard_reject','reason':'synthetic veto'}],'hard_rejects':[{'ts_code':'000001.SZ','severity':'hard_reject'}]},
 'R7': {'main_force':{},'northbound':{},'staleness_status':'ok','resolved_trade_date':'20261023'},
}

def write(p,v): MOD.a.atomic_json(p,v)

def payload(unit,**changes): return {'trade_date':DATE,'status':'complete','confidence':0 if unit=='R1' else None,**FIELDS[unit],**changes}

def deliver(root,unit,md=True,**changes):
 p=root/'data/research'/DATE/MOD.a.UNIT_FILES[unit]; write(p,payload(unit,**changes))
 if md:
  human=root/'chzl_kg/投研交易'/MOD.a.MD_DIRS[unit]/(DATE+'.md')
  human.parent.mkdir(parents=True,exist_ok=True); human.write_text('# synthetic\nline\nline\nline\nline\nline\n')
 return p

def state(root): return MOD.a.read_object(MOD.s.state_path(root,DATE))

def begin(root,unit,attempt=1): MOD.s.stage(root,DATE,RUN,unit,'running',attempt=attempt)

@pytest.fixture
def env(tmp_path,monkeypatch):
 for module in [MOD.s,MOD.r,MOD.b,MOD.o,MOD.algorithm,MOD.main]: monkeypatch.setattr(module,'ROOT',tmp_path)
 MOD.s.start(tmp_path,DATE,RUN,os.getpid(),'running')
 for unit in MOD.a.UNIT_FILES:
  begin(tmp_path,unit); deliver(tmp_path,unit)
  assert MOD.s.check(tmp_path,DATE,RUN,unit)
  MOD.s.stage(tmp_path,DATE,RUN,unit,'completed',attempt=1)
 write(tmp_path/'data/raw'/DATE/'manifest.json',{'date':DATE,'global_severity':0,'sources':{}})
 yield tmp_path
 assert guard.VIOLATIONS==[], 'Unexpected sandbox denial (including swallowed errors): '+repr(guard.VIOLATIONS)

def build(): return MOD.b.make_summary(DATE,run_id=RUN)

def test_positive_native_receipt_summary_serialization_consumer(env):
 summary,missing=build(); assert not missing
 consumed=MOD.b.consume_authorized_inputs(json.loads(json.dumps(summary)))
 assert set(consumed)==set(MOD.a.UNIT_FILES)
 assert consumed['R1']['position_cap_suggestion']==0
 assert summary['confidence']['R1']==0 and summary['confidence']['R2'] is None
 assert {x['ts_code'] for x in summary['hard_rejects']}=={'000001.SZ','000002.SZ'}
 MOD.s.stage(env,DATE,RUN,'summary','running')
 write(env/'data/research'/DATE/'research_summary.json',summary)
 MOD.s.stage(env,DATE,RUN,'summary','completed')
 MOD.s.summary_contract(env,DATE,RUN,state(env)['started_ns'])

@pytest.mark.parametrize('fault',['missing_receipt','missing_hash','wrong_run','wrong_attempt','replaced_bytes'])
def test_unbound_primary_not_authorized(env,fault):
 st=state(env)
 if fault=='missing_receipt': st['contract_results'].pop('R2')
 elif fault=='missing_hash': st['contract_results']['R2']['json'].pop('sha256')
 elif fault=='wrong_run': st['contract_results']['R2']['json']['run_id']='old'
 elif fault=='wrong_attempt': st['stages']['R2']['attempt']=2
 else: deliver(env,'R2',notes='replaced')
 if fault!='replaced_bytes': write(MOD.s.state_path(env,DATE),st)
 summary,missing=build()
 assert 'R2' in missing and 'R2' not in summary['artifacts']
 assert 'R2' not in MOD.b.consume_authorized_inputs(summary)

@pytest.mark.parametrize('kind',['bytes','receipt_deleted','attempt_changed','new_run'])
def test_saved_summary_consumer_rejects_drift(env,kind):
 summary,_=build(); st=state(env)
 if kind=='bytes': deliver(env,'R1',style='replacement')
 elif kind=='receipt_deleted': st['contract_results'].pop('R1')
 elif kind=='attempt_changed': st['stages']['R1']['attempt']=2
 else: st['run_id']='later-run'
 if kind!='bytes': write(MOD.s.state_path(env,DATE),st)
 with pytest.raises(ValueError): MOD.b.consume_authorized_inputs(summary)

def test_json_consumable_despite_md_delivery_gap(env):
 (env/'chzl_kg/投研交易/主线研判'/f'{DATE}.md').unlink()
 summary,missing=build()
 assert 'R2' not in missing and 'R2' in summary['missing_md']
 assert 'R2' in MOD.b.consume_authorized_inputs(summary)
 assert summary['orchestrator_status']=='partial'
 observation=MOD.r.artifact_status(DATE)['R2_main_sectors']
 assert observation['valid'] is True and observation['delivery_complete'] is False

@pytest.mark.parametrize('mode',['valid','absolute','traversal','conflicting','symlink'])
def test_r7_alias_and_escape(env,mode):
 begin(env,'R7',2)
 deliver(env,'R7')  # Refresh both promised outputs for this new attempt.
 canonical=env/'data/research'/DATE/MOD.a.UNIT_FILES['R7']
 target=canonical.with_name(f'R7_capital_flow_{DATE}.json')
 write(target,payload('R7'))
 pointer=target.name
 if mode=='absolute': pointer=str(target)
 if mode=='traversal': pointer='../'+DATE+'/'+target.name
 if mode=='symlink':
  other=env/'synthetic-outside.json'; write(other,payload('R7')); target.unlink(); target.symlink_to(other)
 alias={'trade_date':DATE,'alias_of':pointer}
 if mode=='conflicting': alias['target']='R7_capital_flow_20261024.json'
 write(canonical,alias)
 assert MOD.s.check(env,DATE,RUN,'R7') is (mode=='valid')
 summary,missing=build()
 assert ('R7' not in missing) is (mode=='valid')

@pytest.mark.parametrize('leaders,reason,expected',[([], 'R2 no candidates',True),([], '',False),([{'ts_code':'000001.SZ'}],'no candidates',False)])
def test_r5_skip_verified_prerequisite(env,leaders,reason,expected):
 begin(env,'R2',2)
 deliver(env,'R2',main_lines=[{'leaders':leaders}],empty_pool_reason='none')
 assert MOD.s.check(env,DATE,RUN,'R2')
 MOD.s.stage(env,DATE,RUN,'R2','completed',attempt=2)
 begin(env,'R5',2); deliver(env,'R5',profiles=[],status='skipped',skip_reason=reason)
 assert MOD.s.check(env,DATE,RUN,'R5') is expected
 summary,missing=build()
 assert ('R5' not in missing) is expected
 if expected: assert summary['units']['R5']['status']=='skipped' and summary['confidence']['R5'] is None

@pytest.mark.parametrize('value,expected',[(0,0.0),(None,None),(False,None),(float('nan'),None),(float('inf'),None),(-1,None)])
def test_confidence_zero_null_and_invalid(value,expected): assert MOD.a.confidence({'confidence':value})==expected

def test_auxiliary_default_neither_reads_nor_authorizes(env,monkeypatch):
 seen=[]; original=MOD.b._snapshot
 def track(root,path): seen.append(str(path)); return original(root,path)
 monkeypatch.setattr(MOD.b,'_snapshot',track)
 result=MOD.b.auxiliary_input_manifest(DATE)
 assert seen==[]
 assert all(x['authorized'] is False and x['availability']=='not_inspected' for x in result.values())

@pytest.mark.parametrize('path',['../.env','data/raw/20261025/private.json','data/rules/theme_anchors/../latest.json'])
def test_auxiliary_opt_in_cannot_escape_category(env,path):
 with pytest.raises(ValueError): MOD.b.auxiliary_input_manifest(DATE,approved_paths={'theme_anchors':[path]})

def test_forged_model_read_adoption_never_promoted(env):
 begin(env,'R5',2); deliver(env,'R5',actual_tool_read=True,decision_adoption=True,read_files=['data/corrections/fake.md'],corrections_applied=[{'adopted':True}])
 assert MOD.s.check(env,DATE,RUN,'R5')
 MOD.s.stage(env,DATE,RUN,'R5','completed',attempt=2)
 summary,_=build(); evidence=summary['input_manifest']['units']['R5']
 assert evidence['actual_tool_read']==evidence['decision_adoption']=='not_independently_verified'
 assert all(not x['authorized'] for x in summary['input_manifest']['auxiliary_candidates'].values())

def test_rule_consumer_zero_budget_preserves_watch_no_permission(env):
 summary,_=build(); MOD.b.consume_authorized_inputs(summary)
 plan=MOD.main.build_watchlist_plan(DATE,summary,{},fallback=True)
 assert plan['execution_pool']==[] and len(plan['watch_pool'])==2
 assert all(not x['auto_trade_enabled'] and not x['entry_rules'] for x in plan['watch_pool'])
 assert plan['risk_limits']['target_total_position_pct']==0 and not plan['autonomous_trading_enabled']

def test_partial_summary_keeps_available_observation_inputs(env):
 (env/'data/research'/DATE/MOD.a.UNIT_FILES['R5']).unlink()
 summary,missing=build(); consumed=MOD.b.consume_authorized_inputs(summary)
 assert missing==['R5'] and 'R2' in consumed
 assert len(consumed['R2']['main_lines'][0]['leaders'])==2
 assert summary['orchestrator_status']=='partial' and 'execution_pool' not in summary

def test_terminal_old_finish_cannot_cover_new_run(env):
 MOD.s.finish(env,DATE,RUN,23,'synthetic error')
 MOD.s.start(env,DATE,'new-run',os.getpid(),'running')
 MOD.s.finish(env,DATE,'new-run',24,'synthetic newer error')
 before=MOD.s.state_path(env,DATE).read_bytes()
 with pytest.raises(ValueError,match='superseded'): MOD.s.finish(env,DATE,RUN,0)
 assert MOD.s.state_path(env,DATE).read_bytes()==before

# These are strict expected-contract checks, not assertions of buggy behavior.
# If they fail, JUnit preserves the minimal product counterexample.
def test_C2_F1_existing_plan_reader_must_reject_replaced_bound_input(env):
 summary,_=build(); write(env/'data/research'/DATE/'research_summary.json',summary)
 deliver(env,'R2',notes='replaced-after-summary')
 with pytest.raises(ValueError): MOD.b.consume_authorized_inputs(summary)
 with pytest.raises(ValueError): MOD.main.load_research_summary(DATE)

def test_partial_research_rule_reader_keeps_watch(env):
 (env/'data/research'/DATE/MOD.a.UNIT_FILES['R5']).unlink()
 summary,_=build(); assert 'R2' in MOD.b.consume_authorized_inputs(summary)
 plan=MOD.main.build_watchlist_plan(DATE,summary,{},fallback=True)
 assert plan['execution_pool']==[] and len(plan['watch_pool'])==2

def test_C2_F2_malformed_primary_is_rejected_without_losing_other_research(env):
 begin(env,'R2',2)
 deliver(env,'R2',main_lines='synthetic-wrong-shape')
 checked=MOD.s.check(env,DATE,RUN,'R2')
 print('C2_F2 native_check_returned='+repr(checked))
 # Whether the unit check rejects or not, the summary must localize this bad
 # unit and preserve independent usable research; a total crash is not partial.
 summary,missing=build()
 assert 'R2' in missing and 'R1' in MOD.b.consume_authorized_inputs(summary)
 assert checked is False

def test_C2_F3_exact_same_day_relative_r7_canonical_symlink_is_supported(env):
 begin(env,'R7',2); deliver(env,'R7')
 canonical=env/'data/research'/DATE/MOD.a.UNIT_FILES['R7']
 dated=canonical.with_name(f'R7_capital_flow_{DATE}.json')
 write(dated,payload('R7')); canonical.unlink(); canonical.symlink_to(dated.name)
 checked=MOD.s.check(env,DATE,RUN,'R7')
 summary,missing=build()
 print('C2_F3 native_check='+repr(checked)+' summary_missing_R7='+repr('R7' in missing))
 assert checked is True and 'R7' not in missing
 assert MOD.b.consume_authorized_inputs(summary)['R7']['trade_date']==DATE

def test_sandbox_sentinels():
 for operation in [lambda: pathlib.Path('/Users/chenyang/Downloads/demo/沧海巨浪/.env').read_text(),
                   lambda: pathlib.Path('/Users/chenyang/Downloads/demo/沧海巨浪/data/SHOULD_NOT_EXIST_C2').write_text('denied'),
                   lambda: socket.create_connection(('127.0.0.1',9)),
                   lambda: __import__('subprocess').run(['/bin/echo','denied'])]:
  with guard.expected_denial() as events:
   with pytest.raises(guard.GuardViolation): operation()
  assert events
