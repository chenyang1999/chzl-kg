#!/usr/bin/env python3
"""Exercise the unchanged extracted run_agent, never the production launcher."""
import datetime, hashlib, json, os, pathlib, shlex, subprocess, sys, xml.etree.ElementTree as ET
BASE=pathlib.Path(__file__).resolve().parent
snapshot=pathlib.Path(sys.argv[1]).resolve()
label=sys.argv[2] if len(sys.argv)>2 else 'shell-'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
if snapshot.parent!=BASE or not label.replace('-','').replace('_','').isalnum(): raise SystemExit('C2 snapshot/simple label only')
out=BASE/label; out.mkdir()
import guard
guard.install(out)
from real_modules import load
m=load(snapshot/'code')
source=(snapshot/'code/scripts/research/run_research_shell.sh').read_text()
start=source.index('run_agent() {'); end=source.index('\n}\n',start)+3
function=source[start:end]
approved_function_sha256='6ea48df4c246f40722393022c415434186a0108a4be5c8eac659be3346c95a39'
if hashlib.sha256(function.encode()).hexdigest()!=approved_function_sha256:
 raise SystemExit('run_agent bytes drifted: manual C2 shell review required; no shell subprocess launched')
(out/'extracted-run_agent.sh').write_text(function)
# Reject command substitutions/calls outside the reviewed function surface.
required=['state stage','state check','"$HERMES_BIN"','"$PYTHON"','sleep $backoff','grep -q','wc -c']
if not all(t in function for t in required): raise SystemExit('launcher drift: re-review extraction')
child=(BASE/'shell_child.py').read_text()
results=[]; suite=ET.Element('testsuite',name='C2.real-extracted-run_agent')
for case in ['success','no-output','invalid-json','nonzero-fresh']:
 root=out/case; root.mkdir(); (root/'logs').mkdir()
 for name in ['fake-hermes','local-python','local-grep','local-wc']:
  p=root/name; p.write_text('#!'+sys.executable+' -B\n'+child); p.chmod(0o700)
 m.s.start(root,'20261025','C2-shell-run',os.getpid(),'running')
 q=shlex.quote
 script='\n'.join([
  'set -euo pipefail', 'PATH=/C2-NO-EXTERNAL-PATH', 'TRADE_DATE=20261025', 'DRY_RUN=',
  'CHZL_RESEARCH_RUN_ID=C2-shell-run', 'ROOT='+q(str(root)), 'LOG_DIR='+q(str(root/'logs')),
  'HERMES_BIN='+q(str(root/'fake-hermes')), 'PYTHON='+q(str(root/'local-python')),
  'date() { printf "C2-local-time"; }',
  'sleep() { case "$1" in 15|30) return 0;; *) return 91;; esac; }',
  'grep() { '+q(str(root/'local-grep'))+' "$@"; }',
  'wc() { '+q(str(root/'local-wc'))+' "$@"; }',
  'state() { "$PYTHON" "$ROOT/scripts/research/pipeline_state.py" "$@" --date "$TRADE_DATE" --run-id "$CHZL_RESEARCH_RUN_ID"; }',
  function,
  'run_agent R1 analyze_style_v1 "$ROOT/data/research/$TRADE_DATE/R1_style.json" "C2 synthetic local R1 only"',
 ])+'\n'
 launch=root/'isolated-run-agent.sh'; launch.write_text(script)
 # OS-level enforcement covers bash too. No arbitrary exec, no network, no
 # home/private files, no production reads, writes confined to this case.
 profile='''(version 1)
(allow default)
(deny network*)
(deny process-exec)
(deny file-read* (subpath "/Users/chenyang"))
(deny file-write*)
'''
 for path in ['/System','/usr/lib','/usr/share',str(pathlib.Path(sys.prefix).resolve()),str(pathlib.Path(sys.base_prefix).resolve()),str(BASE)]:
  profile+='(allow file-read* (subpath '+json.dumps(path,ensure_ascii=False)+'))\n'
 for path in ['/dev/null','/dev/random','/dev/urandom','/etc/localtime','/private/etc/localtime','/bin/bash','/usr/bin/sandbox-exec']:
  profile+='(allow file-read* (literal '+json.dumps(path,ensure_ascii=False)+'))\n'
 profile+='(allow file-write* (subpath '+json.dumps(str(root),ensure_ascii=False)+') (literal "/dev/null"))\n'
 aliases,links=guard.interpreter_aliases()
 for path in sorted(aliases|links):profile+='(allow file-read* (literal '+json.dumps(path,ensure_ascii=False)+'))\n'
 for path in ['/bin/bash',*sorted(aliases),*[str(root/n) for n in ['fake-hermes','local-python','local-grep','local-wc']]]:
  profile+='(allow process-exec (literal '+json.dumps(path,ensure_ascii=False)+'))\n'
 for parent in sorted({str(p) for x in [BASE,pathlib.Path(sys.prefix),pathlib.Path(sys.base_prefix),pathlib.Path(sys.executable)] for p in x.parents}):
  profile+='(allow file-read-metadata (literal '+json.dumps(parent,ensure_ascii=False)+'))\n'
 policy=root/'sandbox.sb'; policy.write_text(profile)
 argv=['/usr/bin/sandbox-exec','-f',str(policy),'/bin/bash','--noprofile','--norc',str(launch)]
 env={'PATH':'/C2-NO-EXTERNAL-PATH','HOME':str(root/'synthetic-home'),'TMPDIR':str(root),
      'C2_BASE':str(BASE),'C2_SNAPSHOT':str(snapshot),'C2_SHELL_ROOT':str(root),'C2_CASE':case,
      'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
 guard.APPROVED_PROCESS=tuple(argv)
 try: proc=subprocess.run(argv,cwd=root,env=env,text=True,capture_output=True,timeout=45)
 finally: guard.APPROVED_PROCESS=None
 (root/'stdout.txt').write_text(proc.stdout); (root/'stderr.txt').write_text(proc.stderr)
 st=m.a.read_object(m.s.state_path(root,'20261025'))
 calls=json.loads((root/'fake-calls.json').read_text()) if (root/'fake-calls.json').exists() else []
 audits=[json.loads(p.read_text()) for p in root.glob('audit-*.json')]
 expected=case=='success'
 passed=(proc.returncode==0)==expected and len(calls)==(1 if expected else 3) and st['stages'].get('R1',{}).get('status')==('completed' if expected else 'failed') and not any(x['unexpected_violations'] for x in audits)
 record={'scenario':case,'passed':passed,'exit_code':proc.returncode,'fake_calls':len(calls),'stage':st['stages'].get('R1'),
         'audit_reports':len(audits),'argv':argv,'function_sha256':hashlib.sha256(function.encode()).hexdigest()}
 results.append(record)
 node=ET.SubElement(suite,'testcase',name=case,classname='C2.real-extracted-run_agent')
 if not passed: ET.SubElement(node,'failure',message='isolated launcher contract mismatch').text=json.dumps(record)+'\n'+proc.stderr
suite.set('tests',str(len(results))); suite.set('failures',str(sum(not r['passed'] for r in results))); suite.set('errors','0'); suite.set('skipped','0')
ET.ElementTree(suite).write(out/'junit.xml',encoding='utf-8',xml_declaration=True)
(out/'result.json').write_text(json.dumps({'results':results,'unexpected_guard_violations':guard.VIOLATIONS,'coverage':'exact extracted run_agent + native state/check; not full launcher/production timing'},ensure_ascii=False,indent=2))
print(json.dumps({'output':str(out),'cases':results},ensure_ascii=False,indent=2))
raise SystemExit(0 if all(r['passed'] for r in results) and not guard.VIOLATIONS else 1)
