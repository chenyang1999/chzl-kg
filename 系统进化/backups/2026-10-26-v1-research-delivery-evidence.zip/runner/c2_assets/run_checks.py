#!/usr/bin/env python3
"""Run finite C2 scope with bytecode/plugins off; outputs only under C2."""
import datetime, json, os, pathlib, sys
BASE=pathlib.Path(__file__).resolve().parent
snapshot=pathlib.Path(sys.argv[1]).resolve()
if snapshot.parent!=BASE or not (snapshot/'snapshot.json').is_file(): raise SystemExit('C2 snapshot required')
label=sys.argv[2] if len(sys.argv)>2 else 'run-'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
if not label.replace('-','').replace('_','').isalnum(): raise SystemExit('simple label only')
out=BASE/label; out.mkdir()
os.environ['C2_SNAPSHOT']=str(snapshot)
os.environ['C2_RUN']=str(out)
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['HOME']=str(out/'synthetic-home')
os.environ['TMPDIR']=str(out/'tmp')
(out/'tmp').mkdir(); (out/'synthetic-home').mkdir()
# Explicit minimal environment; do not pass inherited provider/broker tokens.
keep={'PATH','HOME','TMPDIR','C2_SNAPSHOT','C2_RUN','PYTEST_DISABLE_PLUGIN_AUTOLOAD','PYTHONDONTWRITEBYTECODE','LANG','LC_ALL','C2_SELECTION','F3_COLLECT'}
for key in list(os.environ):
 if key not in keep: del os.environ[key]
os.chdir(out)
import pytest
import guard
guard.install(out)
args=['--noconftest','-k',os.environ.get('C2_SELECTION',''),'--collect-only'] if os.environ.get('F3_COLLECT') else ['--noconftest','-k',os.environ.get('C2_SELECTION','')]
args += ['-c',str(BASE/'pytest.ini'),'-p','no:cacheprovider','--confcutdir',str(BASE),
      '--basetemp',str(out/'fixtures'),'--junitxml',str(out/'junit.xml'),'-vv',str(BASE/'test_c2_boundaries.py')]
code=pytest.main(args)
(out/'audit.json').write_text(json.dumps({'unexpected_violations':guard.VIOLATIONS,'process_allowlist':'none in Python function cohort','bytecode_disabled':sys.dont_write_bytecode,'plugin_autoload_disabled':os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'],'pytest_args':args,'exit_code':int(code)},indent=2))
print('C2_OUTPUT='+str(out))
raise SystemExit(code)
