"""F3 scoped adaptation of reviewed A2/C2 guards; not a general sandbox."""
from pathlib import Path
import os, sys, json, atexit, fcntl, socket, re, subprocess
socket.has_ipv6=False
RUN=Path(os.environ['F3_RUN']).resolve()
GROUP=Path(os.environ['F3_GROUP']).resolve()
APP=Path(os.environ['F3_APP']).resolve()
FIX=GROUP/'fixtures'
AUDIT_DIR=GROUP/'audit-receipts'
PROD=Path('/Users/chenyang/Downloads/demo/沧海巨浪')
LIBS={Path(sys.prefix).resolve(),Path(sys.base_prefix).resolve(),Path(sys.executable).resolve().parent.parent}
READ=(RUN,*LIBS,Path(__file__).resolve().parent)
violations=[]; busy=False
EXACT={'/dev/null','/dev/urandom','/dev/random','/System/Library/CoreServices/SystemVersion.plist','/etc/localtime','/private/etc/localtime'}
SHELLS={'run_research_shell.sh','run_research_shell_cron_wrapper.sh','run_missing_only.sh','run_missing_20260909.sh','run_missing_20260910.sh'}
HELPERS={'pipeline_state.py','reconcile_pipeline_status.py','trading_day_guard.py'}
RAW_OPEN=open

def deny(event,target):
    violations.append({'event':event,'target':str(target)[:1600]})
    raise PermissionError('F3 guard: '+event+': '+str(target))

def pathcheck(value,write=False,dir_fd=None):
    if value is None or isinstance(value,int):return
    token=os.fsdecode(value)
    if dir_fd not in (None,-1) and not os.path.isabs(token):
        parent=fcntl.fcntl(dir_fd,50,b'\0'*1024).split(b'\0',1)[0].decode(); token=os.path.join(parent,token)
    p=Path(token).absolute().resolve()
    if p.name.startswith('.env') or 'credential' in p.name.lower():deny('credential_io',p)
    if str(p)=='/dev/null':return
    if p.is_relative_to(PROD) and not any(p.is_relative_to(x) for x in LIBS):deny('production_io',p)
    if write:
        if not p.is_relative_to(GROUP) or p.is_relative_to(APP):deny('write_outside_fixture_receipts',p)
    elif str(p) not in EXACT and not any(p.is_relative_to(x) for x in READ):deny('read_outside_closure',p)

def audit(event,args):
    global busy
    if busy:return
    busy=True
    try:
        if event=='open':
            mode=args[1]; flags=args[2] or 0
            pathcheck(args[0],bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)) or isinstance(mode,str) and any(c in mode for c in 'wax+'))
        elif event in {'os.mkdir','os.chmod'}:pathcheck(args[0],True,args[2])
        elif event in {'os.remove','os.rmdir'}:pathcheck(args[0],True,args[1])
        elif event=='os.utime':pathcheck(args[0],True,args[3])
        elif event in {'os.rename','os.replace'}:pathcheck(args[0],True,args[2]);pathcheck(args[1],True,args[3])
        elif event=='os.symlink':pathcheck(args[0]);pathcheck(args[1],True,args[2])
        elif event in {'os.truncate','os.chown'}:pathcheck(args[0],True)
        elif event=='os.link':deny(event,args)
        elif event.startswith('socket.') and event not in {'socket.__new__','socket.gethostname'}:deny('network',event)
        elif event in {'sqlite3.connect','os.system','os.posix_spawn','os.fork','os.spawn','pty.spawn'}:deny(event,args)
        elif event=='os.exec':
            executable,argv,env=args
            if executable!=sys.executable or len(argv)<2:deny(event,argv)
            p=Path(argv[1]).resolve()
            if not p.is_relative_to(FIX) or p.name not in HELPERS:deny(event,argv)
            if p.name=='reconcile_pipeline_status.py' and '--offline' not in argv:deny(event,argv)
        elif event=='subprocess.Popen':
            # All permitted Popen requests have been rewritten/checked below.
            if tuple(map(str,args[1])) not in APPROVED:deny('unreviewed_Popen',args[1])
    finally:busy=False

APPROVED=set()
ORIGINAL_INIT=subprocess.Popen.__init__

def normalize_shell(body,root):
    body=re.sub(r'^ROOT="[^"]*"$', 'ROOT="<ROOT>"',body,flags=re.M)
    body=re.sub(r'^HERMES_BIN="[^"]*"$', 'HERMES_BIN="<HERMES>"',body,flags=re.M)
    return body

def interpreter_aliases():
    current=Path(sys.executable); aliases={str(current)}; links=set()
    for _ in range(12):
        changed=False
        for part in [*reversed(current.parents),current]:
            if part.is_symlink():
                links.add(str(part)); target=part.readlink()
                target=target if target.is_absolute() else part.parent/target
                current=target/current.relative_to(part);aliases.add(str(current));changed=True;break
        if not changed:break
    return aliases,links

def policy(root):
    text='(version 1)\n(allow default)\n(deny network*)\n(deny process-exec)\n(deny file-read* (subpath "/Users/chenyang"))\n(deny file-write*)\n'
    for p in ['/System','/usr/lib','/usr/share','/bin','/usr/bin',str(RUN),*[str(x) for x in LIBS]]:
        text+='(allow file-read* (subpath '+json.dumps(p,ensure_ascii=False)+'))\n'
    for p in EXACT:text+='(allow file-read* (literal '+json.dumps(p,ensure_ascii=False)+'))\n'
    text+='(allow file-write* (subpath '+json.dumps(str(FIX),ensure_ascii=False)+') (subpath '+json.dumps(str(AUDIT_DIR),ensure_ascii=False)+') (literal "/dev/null"))\n'
    binaries=['/bin/bash','/bin/mkdir','/bin/sleep','/bin/ls','/bin/date','/usr/bin/grep','/usr/bin/wc','/usr/bin/nohup','/usr/bin/env',sys.executable,str(Path(sys.executable).resolve()),str(root/'fake-hermes'),str(root/'.venv/bin/python')]
    aliases,links=interpreter_aliases();binaries+=sorted(aliases)
    for p in sorted(aliases|links):text+='(allow file-read* (literal '+json.dumps(p,ensure_ascii=False)+'))\n'
    for x in [Path(sys.executable),*[Path(p) for p in binaries]]:
        binaries.append(str(x.resolve()))
    for parent in sorted({str(p) for x in [RUN,Path(sys.prefix),Path(sys.base_prefix),Path(sys.executable)] for p in x.parents}):
        text+='(allow file-read-metadata (literal '+json.dumps(parent,ensure_ascii=False)+'))\n'
    for p in binaries:text+='(allow process-exec (literal '+json.dumps(p,ensure_ascii=False)+'))\n'
    p=FIX/('sandbox-'+str(os.getpid())+'-'+str(len(launches))+'.sb');p.write_text(text);return p

launches=[]
def guarded_init(self,args,*pos,**kw):
    if not isinstance(args,(list,tuple)) or kw.get('shell'):deny('shell_string',args)
    argv=list(map(str,args)); cwd=Path(kw.get('cwd') or os.getcwd()).resolve()
    env=dict(kw.get('env') if kw.get('env') is not None else os.environ)
    # Only noncredential fixture controls and our containment contract survive.
    allowed={'PATH','HOME','TMPDIR','TMP','TEMP','BASH_ENV','SANDBOX_ROOT','FAIL_MODE','FAIL_UNIT','FAKE_GUARD_RC','EXPECTED_TURNS','AGENT_MAX_TURNS','CHZL_RESEARCH_RUN_ID','LANG','LC_ALL'}
    env={k:v for k,v in env.items() if k in allowed}
    for k in ['F3_RUN','F3_GROUP','F3_APP','PYTHONPATH','PYTHONDONTWRITEBYTECODE','PYTEST_DISABLE_PLUGIN_AUTOLOAD']:
        env[k]=os.environ[k]
    kw['env']=env
    if argv[0]=='/bin/bash':
        syntax=len(argv)==3 and argv[1]=='-n'
        target=Path(argv[2] if syntax else argv[1]).resolve()
        if target.name not in SHELLS:deny('unreviewed_shell',argv)
        pathcheck(target)
        if not syntax:
            root=Path(env.get('SANDBOX_ROOT','/not-a-fixture')).resolve()
            if cwd!=root or not root.is_relative_to(FIX) or not target.is_relative_to(root):deny('shell_root',argv)
            if argv[2:] not in [['20261022'],['20260909'],['20260910'],['20261022','dry-run'],['--launch','20261022']]:deny('shell_argv',argv)
            original=(APP/'scripts/research'/target.name).read_text(); body=target.read_text()
            if normalize_shell(original,root)!=normalize_shell(body,root):deny('shell_bytes_not_exact_relocation',target)
            if 'ROOT="'+str(root)+'"' not in body or ('HERMES_BIN=' in body and 'HERMES_BIN="'+str(root/'fake-hermes')+'"' not in body):deny('shell_not_relocated',target)
            if env.get('BASH_ENV') not in [str(root/'bash-env'),str(root/'bash_env')]:deny('bash_env_path',env.get('BASH_ENV'))
            bashenv=Path(env['BASH_ENV']).read_text()
            if bashenv not in ['sleep() { :; }\n','sleep() { /bin/sleep 0.1; }\n','sleep() { printf "%s\\n" "$1" >> "$SANDBOX_ROOT/sleeps"; }\n']:deny('bash_env_bytes',bashenv)
            argv=['/usr/bin/sandbox-exec','-f',str(policy(root)),'/bin/bash','--noprofile','--norc',*argv[1:]]
        elif not target.is_relative_to(APP):deny('syntax_target',target)
    elif Path(argv[0]).name=='fake-hermes':
        p=Path(argv[0]).resolve()
        if not p.is_relative_to(FIX) or cwd!=p.parent:deny('fake_hermes_path',argv)
        if argv[1:4]!=['-p','canghai-plan','chat'] or 'main_decision_v1' not in argv:deny('fake_hermes_argv',argv)
    elif argv[0]==sys.executable and len(argv)==3 and argv[1]=='-c':
        code=argv[2]
        prefix="from pathlib import Path; from scripts.plan import ensure_watchlist_plan as m; m.ROOT=Path("
        if not code.startswith(prefix) or "m._try_lock('20261022')" not in code or str(FIX) not in code or cwd!=APP:deny('lock_probe',argv)
        argv=[argv[0],'-B',*argv[1:]]
    else:deny('unreviewed_process',argv)
    launches.append({'argv':argv,'cwd':str(cwd),'env_keys':sorted(env)})
    APPROVED.add(tuple(argv))
    try:return ORIGINAL_INIT(self,argv,*pos,**kw)
    finally:APPROVED.discard(tuple(argv))
subprocess.Popen.__init__=guarded_init
sys.addaudithook(audit)

def finish():
    try:
        with RAW_OPEN(AUDIT_DIR/('audit-'+str(os.getpid())+'.json'),'w') as f:json.dump({'pid':os.getpid(),'violations':violations,'launches':launches},f,indent=2)
    except BaseException:
        sys.stderr.write('F3_AUDIT_PERSISTENCE_FAILED\n');sys.stderr.flush();os._exit(97)
    if violations:sys.stderr.write('F3 AUDIT VIOLATIONS '+repr(violations)+'\n');sys.stderr.flush();os._exit(96)
atexit.register(finish)
