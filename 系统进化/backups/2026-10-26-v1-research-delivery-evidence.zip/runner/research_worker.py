"""One fixed, audited native pytest cohort; never rewrites business tests."""
from pathlib import Path
import json, os, sys
# sitecustomize has installed the guard before this worker/collection.
import sitecustomize as guard
GROUP=Path(os.environ['F3_GROUP'])
APP=Path(os.environ['F3_APP'])
sys.path.insert(0,str(APP))
# Source-honesty tests import the reader during collection. Reuse C2's
# reviewed holdings/quote boundaries and exact orchestrator helper closure;
# no original policy function or test assertion is replaced.
if sys.argv[1] == 'tests/pipeline/test_d1_decision_source.py':
    import importlib.util
    bootstrap_path=Path(os.environ['F3_RUN'])/'legacy_bootstrap.py'
    spec=importlib.util.spec_from_file_location('final_legacy_bootstrap',bootstrap_path)
    bootstrap=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bootstrap)
    bootstrap.load(APP)
import pytest
collected=[]; subtests=[]
class Receipts:
    def pytest_collection_modifyitems(self,items):
        collected.extend(x.nodeid for x in items)
        assert len(collected)==len(set(collected))
    def pytest_runtest_logreport(self,report):
        ctx=getattr(report,'context',None)
        if ctx is not None:subtests.append({'nodeid':report.nodeid,'outcome':report.outcome,'message':getattr(ctx,'msg',None),'params':getattr(ctx,'kwargs',{})})
args=[sys.argv[1],'--rootdir',str(APP),'-c','/dev/null','--noconftest','-p','no:cacheprovider','--basetemp',str(GROUP/'fixtures/pytest'),'--junitxml',str(GROUP/'junit.xml'),'-q']
if '--collect-only' in sys.argv:args+=['--collect-only']
rc=99
try:rc=pytest.main(args,plugins=[Receipts()])
finally:
    (GROUP/'collected-nodeids.json').write_text(json.dumps(collected,ensure_ascii=False,indent=2))
    (GROUP/'subtest-index.json').write_text(json.dumps(subtests,ensure_ascii=False,indent=2,default=repr))
    (GROUP/'run.json').write_text(json.dumps({'pytest_argv':args,'exit_code':int(rc),'collected_count':len(collected),'subtest_count':len(subtests),'violations':guard.violations},indent=2))
raise SystemExit(98 if guard.violations else rc)
