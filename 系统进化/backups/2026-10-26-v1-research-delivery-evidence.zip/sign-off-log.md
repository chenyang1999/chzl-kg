# Sign-off 日志 · 2026-W44

## 2026-10-26 · 全部实际 profile 主模型切换与最小校验

- 用户原话：“改完之后，帮我把全部 profile 的模型基座换成 Agent plan 的 deepseek-v4.1-flash，然后简单校验一下”；随后再次明确要求“好了吗？这么简单的任务帮我把全部 profile 的模型基座换成 Agent plan 的 deepseek-v4.1-flash，然后简单校验一下”。本次仅实施其明确指定的角色主模型，不将此要求解释为辅助输入提案获批。
- 实际目标：default、canghai-fetch、canghai-plan、canghai-research、canghai-review、hermes-visitors，共6个。canghai-execute/candidates仅为没有身份文件的目录，不另造角色。
- 五份已有配置仅将 model.provider 从 openai-codex 改为 volcengine-agent-plan、model.default 从 gpt-6.1-sol 改为 deepseek-v4.1-flash；逐份与备份作语义比较，其他字段一致。访客原无 config.yaml，使用 Hermes 配置接口补既有通道连接及相同模型，最终仅含 providers/model 两节；复用现有认证、不展示凭据、不修改 .env。
- 真实验证：六份配置回读均正确；六个新会话均不传通道/模型覆盖参数，串行真实调用模型及一次 terminal 打印 MODEL_SWITCH_OK，退出码均0。按独特测试提示、串行执行顺序与受限时间窗从日志恢复会话，六个均确认实际 deepseek-v4.1-flash API调用和 terminal 完成事件。
- 校验脚本首次只在 stdout 查会话ID导致误报未验证，原失败保留；补从真实日志核对，不重复业务调用。访客首次调用未装配的桌面内部 helper 报 NameError，改用已读审的 Hermes endpoint seed/config 接口后完成。没有为误报修改产品或放松测试。
- 回滚与证据：~/.hermes/backups/model-switch-20261026T000659/，0700目录、原配置及 verification.json/smoke-verification.json 为0600；含认证的原配置不公开、不纳Git。scratch不是唯一恢复依据。
- 未改：15项定时任务的固定 provider/model/base_url 经逐项比较保持原值；任务仍固定原模型，不会随 profile 默认值改变。未动SOUL、技能、交易规则、模型以外的已有配置、业务数据、调度时刻或常驻服务，没有提交/推送。
- 生效边界：保存默认值对新会话生效；现有对话/在跑任务不声称热切换。最小测试不是完整生产研究链、并发容量或交易验收。此前辅助读取提案仍未批准、未启用。

## 2026-10-26 · 第二批研究交付修复收尾与主控验收

- 授权沿用用户“可以，按照你说的这样，批量的去做吧”及此前有边界的实施方案；没有将辅助输入确认超时解释为批准。
- 本批限定六个实现文件、三个新增测试文件；最后旧读取器复用现有输入校验，只允许汇总本身真正缺失时进入原有备用路径。既有测试断言未为转绿而改写。
- 主控真实运行 `FINAL/run_joint.py --mode final --label parent-after-F4-20261026`，冻结／执行时段为 2026-10-26 00:41:15—00:43:28 CST；1114个唯一原生测试全过，失败／错误／跳过均0，退出码0。原790例身份保留；模拟65和角色启动16子例分列，模拟子例身份与此前核验版本一致。99个白名单文件无漂移，覆盖错误、守卫违规、运行器错误均0。
- 原严格反例 `test_C2_F1_existing_plan_reader_must_reject_replaced_bound_input` 保留，主控前一轮真实失败及本轮通过分别留证；不是删例、跳过或放宽守卫得到的全绿。
- 知识库仅补导航和本报告，四项历史迁移及3项Finder元数据清理按先前已批准范围复核；其他迁移、私密材料、Wiki源快照、编辑器配置未动。
- 文档：`chzl_kg/系统进化/2026-10-26 第二批研究交付修复与主控验收.md`；证据：同目录 `backups/2026-10-26-v1-research-delivery-evidence.zip`。修复前字节、增量、原生JUnit、来源摘要及复跑入口按精确清单封装，不包含模型配置私有备份。
- Git main/HEAD、原index及NUL安全暂存记录保持；无新提交／推送。没有本批业务模型／行情／券商／生产任务／重载／推送；没有修改SOUL、技能、既有任务固定模型、读取权限、风控阈值或交易授权。
- `V1-AUX-05`及技能差异仍待确认、不应用。上述全绿仅认证本批隔离工程回归；自然调度、模型实际读取／采纳、首批执行安全残余与完整V1.00仍未验收，不放行实盘。
