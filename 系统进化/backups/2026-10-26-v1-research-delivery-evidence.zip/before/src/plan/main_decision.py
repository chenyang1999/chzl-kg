"""canghai-plan · D1 主决策(main_decision_v1),规则版 v1。

五步决策流(docs/agents/D1-主决策Agent.md §3):
  Step1 position_cap ← R1
  Step2 R6 hard_reject 过滤
  Step3 execution_pool ← R2 龙一/龙二 + R5 画像
  Step4 watch_pool
  Step5 entry_rules / exit_rules / base_mobile_ratio

裁决记录(2026-07-05):
  1. exit_rules[].type 以 docs/11-契约-盘前预案.md 为准(非 hermes-contract-reply)
  2. D1 是 data/plans/ 唯一写者(T2 execute 只读,不写回)
  3. max_positions=5 硬约束(override execution_pool_size_range [5,8])
  4. 买入信号: KB 牛熊线/决策线(ma50)回踩; MA5/10 仅止损参考
  5. daban_confirm 永久不做(无低延迟通道)
  6. QMT REST 拉持仓可选,失败降级

D1_ALGORITHM_V1_IMPLEMENTED=False 时 mode 恒为 dry_run,但 pool/规则仍真实计算供 review。
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None  # type: ignore[assignment]

from src.plan.d1_algorithm import build_pools_and_rules
from src.plan.render_markdown import render_watchlist_plan_md
from src.research.contract_checks import check_d1_completeness

ROOT = Path(__file__).resolve().parents[2]

PLAN_SCHEMA_VERSION = "watchlist_plan_v1"
REQUIRED_RESEARCH_KEYS = (
    "schema_version",
    "trade_date",
    "orchestrator_status",
    "artifacts",
    "confidence",
    "hard_rejects",
    "timeouts",
)
REQUIRED_ARTIFACT_UNITS = ("R1", "R2", "R3", "R4", "R5", "R6", "R7")

# 算法已实现; mode=live 仍由用户 review 后手动改 True
D1_ALGORITHM_V1_IMPLEMENTED = False


def _now_iso() -> str:
    tz = timezone(timedelta(hours=8))
    return datetime.now(tz).isoformat(timespec="seconds")


def _rel(path: Path) -> str:
    return str(path.relative_to(ROOT))


def load_research_summary(trade_date: str) -> dict[str, Any]:
    path = ROOT / "data" / "research" / trade_date / "research_summary.json"
    if not path.is_file():
        raise FileNotFoundError(f"research_summary missing: {_rel(path)}")

    summary = json.loads(path.read_text(encoding="utf-8"))

    missing = [k for k in REQUIRED_RESEARCH_KEYS if k not in summary]
    if missing:
        raise ValueError(f"research_summary missing keys: {missing}")

    if summary.get("trade_date") != trade_date:
        raise ValueError(f"research_summary trade_date mismatch: expected {trade_date}, got {summary.get('trade_date')}")

    artifacts = summary.get("artifacts") or {}
    missing_units = [u for u in REQUIRED_ARTIFACT_UNITS if u not in artifacts]
    if missing_units:
        raise ValueError(f"research_summary artifacts missing units: {missing_units}")

    for unit, rel_path in artifacts.items():
        if not (ROOT / rel_path).is_file():
            raise ValueError(f"research artifact for {unit} does not exist on disk: {rel_path}")

    return summary


def load_user_preferences() -> dict[str, Any]:
    path = ROOT / "data" / "user_preferences.yaml"
    if not path.is_file() or yaml is None:
        return {}
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def _data_sources(summary: dict[str, Any], d1_result: dict[str, Any]) -> dict[str, Any]:
    return {
        "research_summary": {
            "tool": "src.research.orchestrator (rule v1)",
            "asof": summary.get("generated_at"),
            "status": summary.get("orchestrator_status"),
        },
        "fetch_manifest": {
            "tool": "scripts/fetch/fetch_all_sources.py",
            "asof": summary.get("generated_at"),
            "path": summary.get("fetch_manifest"),
            "global_severity": summary.get("fetch_global_severity"),
        },
        "qmt_holdings": {
            "tool": "src.plan.qmt_holdings REST /v1/holdings",
            "status": "ok" if d1_result.get("qmt_note") is None else "degraded",
            "note": d1_result.get("qmt_note") or f"positions={d1_result.get('holdings_count', 0)}",
        },
        # 入口通道决策留痕：exec=0 时应能区分"regime 未开放通道"与"候选被过滤"。
        "entry_channels": d1_result.get("entry_channels") or {},
        "grade_gate_drops": d1_result.get("grade_gate_drops") or [],
    }


def _r3_r4_integration(trade_date: str) -> dict[str, Any]:
    """R3 群聊情绪 + R4 消息面整合段（2026-10-17 新增）。

    目的：让 LLM 端 D1 落盘有结构化的 R3/R4 整合段，不再只是"按 LLM 自由心证整合"。
    用户钦定方向（2026-10-17）：程序算概率（emotion_cycle / node_predict）+ LLM 整合 R3/R4 → 客观分析。
    本函数不替 LLM 做判断，只结构化抽取 R3/R4 落盘 JSON 的关键字段。
    """
    import re

    def _clean(s: str) -> str:
        """清洗 R3/R4 落盘里的微信原始 XML/HTML 标签 + 多余换行。"""
        if not s:
            return ""
        s = re.sub(r"<\?xml[^>]*\?>", "", s)
        s = re.sub(r"<[^>]+>", "", s)  # 去所有 HTML/XML 标签
        s = re.sub(r"\\n+", " ", s)
        s = re.sub(r"\s+", " ", s)
        s = s.strip()[:200]
        # 截断可能留下残缺标签（如 "<videomsg aeskey=..." 在 200 字符处断）→ 补删残 <
        if "<" in s:
            s = re.sub(r"<[^>]*$", "", s).strip()
        return s

    out: dict[str, Any] = {
        "schema_version": "r3_r4_integration_v1",
        "trade_date": trade_date,
        "r3_sentiment": {},
        "r4_news": {},
        "llm_integration_prompts": {
            "verdict_check": (
                "请检查 R3.next_day_signal.verdict 是否与 emotion_cycle 阶段一致；"
                "若 R3 判强修复 + emotion_cycle 判主跌/低位试错 → 倾向采纳 R3 修复信号"
            ),
            "policy_catalyst": (
                "请检查 R4.top_events 中强政策/业绩催化的板块；"
                "若 R4 催化 R2 主线内板块 → 强化该主线信心"
            ),
            "kol_corroboration": (
                "请检查 R3.kol_summary 是否多源验证同一修复/退潮方向；"
                "若 ≥3 条 KOL 同向 → 调整 R3 段位强度"
            ),
            "first_board_quality": (
                "请检查 R4.first_board_candidates 中 quality=high 的票；"
                "若 R4 命中但 D1 execution_pool 未包含 → 候选回灌 watch_pool"
            ),
        },
    }

    # R3 群聊情绪
    r3_path = ROOT / "data" / "research" / trade_date / "R3_sentiment.json"
    if r3_path.is_file():
        try:
            r3 = json.loads(r3_path.read_text(encoding="utf-8"))
            out["r3_sentiment"] = {
                "sentiment_score": r3.get("sentiment_score"),
                "next_day_signal": r3.get("next_day_signal"),
                "kol_summary": [
                    {
                        "source": k.get("source"),
                        "time": k.get("time"),
                        "view": _clean(k.get("view")),
                        "valid_period": k.get("valid_period"),
                    }
                    for k in (r3.get("kol_summary") or [])[:5]
                ],
                "resonance_top_themes": [
                    {
                        "theme_name": t.get("theme_name"),
                        "resonance_level": t.get("resonance_level"),
                        "suggested_sectors": t.get("suggested_sectors"),
                        "early_or_late": t.get("early_or_late"),
                    }
                    for t in (r3.get("resonance_top_themes") or [])[:5]
                ],
                "hotlist_signals": r3.get("hotlist_signals"),
                "fetch_global_severity": r3.get("fetch_global_severity"),
                "data_quality": "ok" if r3.get("status") == "complete" else "degraded",
            }
        except (json.JSONDecodeError, OSError):
            out["r3_sentiment"] = {"data_quality": "parse_error"}
    else:
        out["r3_sentiment"] = {"data_quality": "missing"}

    # R4 消息面
    r4_path = ROOT / "data" / "research" / trade_date / "R4_news.json"
    if r4_path.is_file():
        try:
            r4 = json.loads(r4_path.read_text(encoding="utf-8"))
            out["r4_news"] = {
                "top_events": [
                    {
                        "title": _clean(e.get("title")),
                        "strength": e.get("strength"),
                        "polarity": e.get("polarity"),
                        "sectors_impact": e.get("sectors_impact"),
                        "stocks_impact": e.get("stocks_impact"),
                    }
                    for e in (r4.get("top_events") or [])[:10]
                ],
                "first_board_candidates_high": [
                    {
                        "code": c.get("code"),
                        "name": c.get("name"),
                        "industry": c.get("industry"),
                        "quality": c.get("quality"),
                        "hit_count": c.get("hit_count"),
                    }
                    for c in (r4.get("first_board_candidates") or []) if c.get("quality") == "high"
                ][:5],
                "sectors_catalyzed": r4.get("sectors_catalyzed"),
                "fetch_global_severity": r4.get("fetch_global_severity"),
                "data_quality": "ok" if r4.get("status") == "complete" else "degraded",
            }
        except (json.JSONDecodeError, OSError):
            out["r4_news"] = {"data_quality": "parse_error"}
    else:
        out["r4_news"] = {"data_quality": "missing"}

    return out


def build_watchlist_plan(
    trade_date: str,
    summary: dict[str, Any],
    preferences: dict[str, Any],
    *,
    fallback: bool = False,
) -> dict[str, Any]:
    now = _now_iso()
    orchestrator_status = summary.get("orchestrator_status", "unknown")
    research_is_skeleton = orchestrator_status in ("skeleton", "partial")
    algorithm_ready = D1_ALGORITHM_V1_IMPLEMENTED or fallback
    is_skeleton = research_is_skeleton or not algorithm_ready

    artifacts = summary.get("artifacts") or {}
    d1 = build_pools_and_rules(trade_date, summary, preferences, artifacts)

    hard_rules = preferences.get("position_hard_rules") or {}
    position_cap = d1["position_cap"]
    risk_limits = {
        "target_total_position_pct": min(position_cap, hard_rules.get("max_total_position_pct", 0.8)),
        "max_positions": hard_rules.get("max_positions", 5),
        "max_buy_orders_per_day": min(4, hard_rules.get("max_positions", 5)),
        "max_orders_per_symbol_per_day": 2,
        "block_prefixes": preferences.get("execution_block_prefixes", []),
        "block_st": bool(preferences.get("st_filter", True)),
        "kill_switch_file": "data/execution/KILL_SWITCH",
    }

    r1_conclusion = d1.get("r1_conclusion") or ""
    # 2026-09-30：这里原先无条件写 "D1 规则版 v1: … mode=live."，兜底时也照写，
    # 于是人读预案看到 "规则版 v1 … mode=live"，完全无法察觉今天没有大模型决策。
    # 现在按真实来源标注：兜底 / 规则直出 / 正常。
    if fallback:
        _mode_note = "mode=fallback(🚨 python 量价兜底 · 非大模型决策)"
    elif is_skeleton:
        _mode_note = "mode=dry_run(D1_ALGORITHM_V1_IMPLEMENTED=False · 规则直出)"
    else:
        _mode_note = "mode=live"
    structure = (
        f"D1 规则版 v1: {r1_conclusion} "
        f"execution={len(d1['execution_pool'])} watch={len(d1['watch_pool'])} "
        f"position_cap={position_cap:.0%}. {_mode_note}."
    )
    if is_skeleton and not fallback:
        structure += " ⚠️ 本预案为规则引擎直出（非大模型决策）"
    if fallback:
        structure = "🚨 本预案由 Python 量价规则兜底生成，非大模型决策，勿据此下单。" + structure

    # ────────────────────────────────────────────────────────────────────────
    # 2026-09-30 事故修复：兜底规则版 plan 绝不能标成 mode=live。
    #
    # 事故链：D1 大模型(cron b6a7a8c23050, 08:00) 因 provider 404 挂掉 →
    #   08:30 安全网用 d1_algorithm(纯量价规则) 补了一个 plan 到契约路径 →
    #   该 plan 写着 agent="D1-main-decision (main_decision_v1, rule v1)" +
    #   mode="live" + execution_count=0，人读预案(md frontmatter `mode: live`)
    #   完全看不出"今天根本没有大模型决策"，只看到"D1 今天没给票"。
    #   用户 2026-09-30 打脸："怎么能用纯的量价关系的Python程序决策呢？"
    #
    # 铁律：大模型是唯一决策者；Python 规则只能兜底占位，且必须**显眼标注**。
    #
    # 注意：本函数**永远不是**大模型路径 —— LLM 自己写 plan，不调这里。
    # 所以 decision_source 绝不能是 "llm"；两个取值都如实说明"规则在算"。
    # ────────────────────────────────────────────────────────────────────────
    if fallback:
        mode = "fallback"
        decision_source = "python_fallback"
        agent_name = "D1-main-decision (PYTHON FALLBACK · 非大模型决策 · 仅兜底占位) [main_decision_v1 rule v1]"
    elif is_skeleton:
        mode = "dry_run"
        decision_source = "rule_v1_standalone"
        agent_name = "D1-main-decision (main_decision_v1, rule v1)"
    else:
        mode = "live"
        decision_source = "rule_v1_standalone"
        agent_name = "D1-main-decision (main_decision_v1, rule v1)"

    is_degraded_plan = fallback or not d1["execution_pool"]

    # 硬不变量：兜底版永远不许伪装成 live 决策
    assert not (fallback and mode == "live"), "python fallback 不得标 mode=live"

    plan: dict[str, Any] = {
        "schema_version": PLAN_SCHEMA_VERSION,
        "trade_date": trade_date,
        "mode": mode,
        # 显式决策来源，供下游/人读一眼区分「大模型决策」与「规则/兜底」
        "decision_source": decision_source,
        "is_fallback": bool(fallback),
        "agent_name": agent_name,
        "generated_at": now,
        "trading_style": "mainline_right_side_with_trend_pullback",
        "autonomous_trading_enabled": False,
        "requires_user_confirmation": True,
        "data_sources": _data_sources(summary, d1),
        "market_context": {
            "structure": structure,
            "index_status": {},
            "mainline_ranking": d1.get("mainline_ranking") or [],
            "defense_allocation": {
                "reason": "规则版 v1 未单独计算防御仓位",
                "target_pct": max(0.0, 1.0 - position_cap),
                "candidates": [],
            },
            "risk_terms": [
                f"research orchestrator_status={orchestrator_status}",
                f"fetch_global_severity={summary.get('fetch_global_severity')}",
                d1.get("qmt_note") or "QMT holdings ok",
            ],
            "sise_sector_ranking": [],
        },
        "risk_limits": risk_limits,
        "portfolio_rebalance": {
            "action_required": False,
            "action": "D1 v1 未实现真实调仓算法(留 T2/T3)",
            "reason": "需要完整持仓成本/浮盈，本轮只做选股+规则",
            "source_position_risk": None,
            "current_position_count": d1.get("holdings_count") or 0,
            "target_position_count": len(d1["execution_pool"]),
            "sell_first_list": [],
            "consider_partial_take_profit_list": [],
            "keep_list": [],
            "after_trim_new_buys": [],
            "hard_rules": [],
        },
        "sector_core_watchlist": d1.get("sector_core_watchlist") or [],
        "execution_pool": d1["execution_pool"],
        "watch_pool": d1["watch_pool"],
        "rejected": d1.get("rejected") or [],
        "research_anchor_only": [],
        "meta": {
            "research_summary_path": f"data/research/{trade_date}/research_summary.json",
            "research_orchestrator_status": orchestrator_status,
            "research_confidence": summary.get("confidence", {}),
            "position_cap_source": "R1-style",
            "position_cap_pct": position_cap,
            "d1_status": "python_fallback" if fallback else "rule_v1",
            "d1_algorithm_implemented": algorithm_ready,
            "python_fallback": fallback,
            # 「今天到底是谁做的决策」——人读预案与下游审计的唯一真相字段
            "decision_source": "python_fallback" if fallback else "llm",
            "is_fallback": bool(fallback),
            "is_degraded_plan": is_degraded_plan,
            "r6_devil_advocate": d1.get("meta_r6") or {},
            "r3_r4_integration": _r3_r4_integration(trade_date),  # 2026-10-17 P2 补全：R3 群聊 + R4 消息面结构化整合段
            "note": "规则版 v1 真实选股+entry/exit 规则;"
            + (
                " python_fallback via d1_algorithm."
                if fallback
                else (" mode=dry_run 待用户 review 后设 D1_ALGORITHM_V1_IMPLEMENTED=True" if is_skeleton else "")
            ),
            "known_gaps": [
                "portfolio_rebalance 未实现",
                "E1 观察池未接入",
                "leader_breakout/daban_confirm 未实现(后者永久不做)",
            ],
        },
    }
    return plan


def compare_with_legacy_plan(trade_date: str, new_plan: dict[str, Any]) -> dict[str, Any]:
    legacy_path = ROOT / "data" / "runtime" / f"watchlist_plan_{trade_date}.json"
    result: dict[str, Any] = {
        "trade_date": trade_date,
        "compared_at": _now_iso(),
        "new_plan_path": f"data/plans/{trade_date}/watchlist_plan.json",
        "legacy_plan_path": _rel(legacy_path) if legacy_path.exists() else None,
        "legacy_plan_exists": legacy_path.exists(),
    }
    if not legacy_path.exists():
        result["note"] = "旧系统当日无 plan(未跑或非交易日),无法对比"
        return result

    try:
        legacy = json.loads(legacy_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        result["note"] = f"旧 plan JSON 解析失败: {exc}"
        return result

    result["comparison"] = {
        "new_execution_pool_count": len(new_plan.get("execution_pool", [])),
        "legacy_execution_pool_count": len(legacy.get("execution_pool", [])),
        "new_watch_pool_count": len(new_plan.get("watch_pool", [])),
        "legacy_watch_pool_count": len(legacy.get("watch_pool", [])),
        "new_mode": new_plan.get("mode"),
        "legacy_mode": legacy.get("mode"),
    }
    result["note"] = "D1 规则版 v1 与旧 plan 规模对比(非字段级 diff)"
    return result


def _minimal_summary(trade_date: str) -> dict[str, Any]:
    """research_summary 缺失时的降级 summary: 自动发现 R1-R7 已落盘 artifact.

    与 D1 主路径(LLM 直接消费 R1-R7 原始 artifact)口径一致; fallback 模式下使用。
    """
    research_dir = ROOT / "data" / "research" / trade_date
    unit_files = {
        "R1": "R1_style.json",
        "R2": "R2_main_sectors.json",
        "R3": "R3_sentiment.json",
        "R4": "R4_news.json",
        "R5": "R5_stock_profiles.json",
        "R6": "R6_devil_advocate.json",
        "R7": "R7_capital_flow.json",
    }
    artifacts: dict[str, str] = {}
    for unit, fname in unit_files.items():
        p = research_dir / fname
        if p.is_file():
            artifacts[unit] = f"data/research/{trade_date}/{fname}"
    return {
        "schema_version": "research_summary_v1",
        "trade_date": trade_date,
        "generated_at": _now_iso(),
        "orchestrator_status": "degraded",
        "artifacts": artifacts,
        "note": "research_summary 缺失, fallback 自动发现 R1-R7 原始 artifact(2026-09-18)",
    }


def run_main_decision(trade_date: str, *, fallback: bool = False) -> dict[str, Any]:
    try:
        summary = load_research_summary(trade_date)
    except (FileNotFoundError, ValueError) as exc:
        if not fallback:
            raise
        # 2026-09-18 修: fallback(安全网)在 research_summary 缺失时不应失败——
        # D1 主路径(LLM)本就"直接消费 R1-R7 原始 artifact"能成功, fallback 却硬依赖 summary。
        # 降级为最小 summary(R1-R7 已落盘即够), 与主路径口径一致。
        summary = _minimal_summary(trade_date)
        print(f"[warn] research_summary 缺失({exc}), fallback 降级为最小 summary", file=sys.stderr)
    preferences = load_user_preferences()
    plan = build_watchlist_plan(trade_date, summary, preferences, fallback=fallback)

    out_dir = ROOT / "data" / "plans" / trade_date
    out_dir.mkdir(parents=True, exist_ok=True)

    plan_path = out_dir / "watchlist_plan.json"
    plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")

    md_text = render_watchlist_plan_md(plan)
    (out_dir / "watchlist_plan.md").write_text(md_text, encoding="utf-8")

    kg_dir = ROOT / "chzl_kg" / "投研交易" / "盘前预案"
    kg_dir.mkdir(parents=True, exist_ok=True)
    (kg_dir / f"{trade_date}.md").write_text(md_text, encoding="utf-8")

    comparison = compare_with_legacy_plan(trade_date, plan)
    comparison_path = out_dir / "legacy_comparison.json"
    comparison_path.write_text(json.dumps(comparison, ensure_ascii=False, indent=2), encoding="utf-8")

    # ===== D1 契约校验（P1-2 完整性硬约束）=====
    d1_failures = check_d1_completeness(plan)
    plan["contract_failures"] = d1_failures
    plan["contract_checks_passed"] = len(d1_failures) == 0
    # 重新写盘（补上契约校验结果）
    plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")

    plan["_written_to"] = _rel(plan_path)
    plan["_legacy_comparison"] = comparison
    return plan
