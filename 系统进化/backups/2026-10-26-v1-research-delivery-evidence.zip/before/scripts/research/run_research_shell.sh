#!/bin/bash
# 沧海巨浪 · 研究端 R1-R7 shell wait 编排（替代 delegate_task process-local 陷阱）
# 2026-07-06 用户签 B 口径：R1-R7 必须 LLM sub-agent，Python 规则版作废
#
# 用法：
#   bash scripts/research/run_research_shell.sh YYYYMMDD [dry-run]
#
# 依赖：
#   - hermes CLI 已装（which hermes）
#   - canghai-research / canghai-plan profiles 已配置
#   - .venv 已激活或用绝对路径 python
#
# 时序：
#   07:15 fetch (前置，独立 skill)
#   07:30 R1 / R3 / R4 / R7 并行（& + wait）
#   07:45 R2 / R5 并行
#   07:55 R6（依赖 R1-R5/R7）
#   08:00 D1（依赖 R1-R7）
#
# 每个 R/D 由 hermes CLI 起独立 session，调对应 skill，写 chzl_kg/*/YYYYMMDD.md + data/research/YYYYMMDD/*.json

set -euo pipefail

# 修复 cron 环境 PATH 缺失问题（cron 默认 PATH 不含 /usr/local/bin 或 ~/.local/bin）
export PATH="/usr/local/bin:/Users/chenyang/.local/bin:$PATH"

# 强制使用 OpenViking memory provider（所有 canghai-* profile 共享同一套记忆）
export HERMES_MEMORY_PROVIDER="openviking"
# 显式指定 OpenViking 配置文件路径
export OVCLI_CONFIG_PATH="/Users/chenyang/.openviking/ovcli.conf.Livermore"
# 设置 actor_peer_id 确保所有 profile 共享同一个记忆空间
export OVCLI_ACTOR_PEER_ID="canghai-shared"

# 绝对路径 fallback（避免 PATH 问题）
HERMES_BIN="/Users/chenyang/.local/bin/hermes"

TRADE_DATE="${1:-$(date +%Y%m%d)}"
DRY_RUN="${2:-}"
ROOT="/Users/chenyang/Downloads/demo/沧海巨浪"
LOG_DIR="$ROOT/data/logs/research_shell/${TRADE_DATE}"
mkdir -p "$LOG_DIR"
mkdir -p "$ROOT/data/research/${TRADE_DATE}"

cd "$ROOT"

# Business state is independent of scheduler/nohup exit status. Use only the
# existing health path; each retry/run gets fresh delivery evidence.
PYTHON="$ROOT/.venv/bin/python"
[[ -x "$PYTHON" ]] || PYTHON="$(command -v python3)"
export CHZL_RESEARCH_RUN_ID="${CHZL_RESEARCH_RUN_ID:-$(date +%Y%m%dT%H%M%S)-$$-${RANDOM}}"
state() { "$PYTHON" "$ROOT/scripts/research/pipeline_state.py" "$@" --date "$TRADE_DATE" --run-id "$CHZL_RESEARCH_RUN_ID"; }
PIPELINE_RC=0
if [[ "$DRY_RUN" != "dry-run" ]]; then
    state start --pid "$$" --status running
    on_exit() {
        local rc=$?
        trap - EXIT
        if [[ $rc -eq 0 && $PIPELINE_RC -ne 0 ]]; then rc=$PIPELINE_RC; fi
        if ! state finish --rc "$rc"; then rc=1; fi
        exit "$rc"
    }
    trap on_exit EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM HUP
fi
if [[ ! -x "$HERMES_BIN" && "$DRY_RUN" != "dry-run" ]]; then
    echo "FATAL: hermes CLI not found at $HERMES_BIN" >&2
    exit 1
fi

echo "=== $(date '+%F %T') research shell orchestrator start ==="
echo "trade_date=${TRADE_DATE} dry_run=$DRY_RUN"

# hermes CLI 调用模板
# 注意：workdir 不能有中文，用 cd 替代
run_agent() {
    local agent="$1"
    local skill="$2"
    local out_json="$3"
    local prompt="$4"
    # R steps keep their research identity; D1 explicitly selects the plan profile.
    local profile="${5:-canghai-research}"
    local log="$LOG_DIR/${agent}.log"


    echo "  [$(date '+%H:%M:%S')] launching $agent (skill=$skill)"

    if [[ "$DRY_RUN" == "dry-run" ]]; then
        echo "    DRY-RUN: $HERMES_BIN -p $profile chat -Q --yolo -s $skill --max-turns ${AGENT_MAX_TURNS:-60} -q \"$prompt\""
        echo "    would write: $out_json"
        return 0
    fi

    # 修复 2026-09-08 R7 429 引发的整条流水线崩溃：
    #   429 是临时限流, 10-30 秒后重试大概率成功。
    #   加重试 2 次, 间隔 15s/30s, 同时检查输出文件存在性作为成功标志。
    local max_attempts=3
    local attempt=1
    local backoff=15
    # 2026-09-17: R5 串行 40min → D1 09:42 落盘晚于 P1 09:28 竞价窗口。
    #   max-turns 80→60 提速（R5/D1 各少 20 轮），同时 D1 独立 safety-net cron 兜底。
    #   每个 agent 按需覆盖: 轻任务 R3/R6 可 50, 重任务 R5/D1 保持 70 平衡质量。
    local turns=${AGENT_MAX_TURNS:-60}

    while [[ $attempt -le $max_attempts ]]; do
        state stage --stage "$agent" --status running --attempt "$attempt"

        local rc=0
        # Explicit conditional capture: set -e otherwise aborts background R1/
        # R4/R7 before recording/retrying a nonzero Hermes exit.
        "$HERMES_BIN" -p "$profile" chat -Q --yolo \
            -s "$skill" \
            --max-turns "$turns" \
            -q "$prompt" \
            > "$log" 2>&1 || rc=$?

        # Process success + nonempty artifact + actual JSON/date/freshness/MD
        # contracts. R7 may legally publish the exact same-day dated primary.
        # 注意: "exceeded" 单独出现可能只是正常英文输出(如 exceeded max turns)，故用更精确的 "usage quota" 匹配配额错误
        if [[ $rc -eq 0 ]] && \
           [[ -s "$out_json" || ( "$agent" == "R7" && -s "$ROOT/data/research/${TRADE_DATE}/R7_capital_flow_${TRADE_DATE}.json" ) ]] && \
           ! grep -q "429\|rate.limit\|too frequent\|usage quota" "$log" 2>/dev/null && \
           state check --stage "$agent"; then
            state stage --stage "$agent" --status completed --attempt "$attempt"
            echo "    ✅ $agent 成功 (attempt $attempt)"
            return 0
        fi

        if [[ $attempt -lt $max_attempts ]]; then
            echo "    ⚠️ $agent attempt $attempt failed (rc=$rc, log_size=$(wc -c < "$log" 2>/dev/null || echo 0)), 等待 ${backoff}s 重试..."
            sleep $backoff
            backoff=$((backoff * 2))
            attempt=$((attempt + 1))
        else
            echo "    ❌ $agent 重试 $max_attempts 次仍失败"
            state stage --stage "$agent" --status failed --attempt "$attempt" --error "agent process/delivery failed (rc=$rc); log=$log"
            return 1
        fi
    done
}

# === 07:15 fetch（假设已由独立 cron 触发，此处 skip 或校验 manifest 存在）===
MANIFEST="$ROOT/data/raw/${TRADE_DATE}/manifest.json"
if [[ ! -f "$MANIFEST" && "$DRY_RUN" != "dry-run" ]]; then
    echo "WARN: fetch manifest not found, R agents will run with degraded=true"
fi

# === 07:30 Batch 1: R1 / R4 / R7 并行 ===
# R3 移出本批（依赖 R1 情绪基线，见下方 Batch 2）。修复 2026-08-19/20 R3 早于 R1 用前一日基准的 bug。
echo ""
echo "[$(date '+%H:%M:%S')] Batch 1: R1 / R4 / R7 (parallel via & + wait)"

R1_PROMPT="按 analyze_style_v1 skill 分析 22 个同花顺风格板块 + 20 只 ETF + 外盘。trade_date=${TRADE_DATE}，30 日窗口，6 簇聚类，产出 data/research/${TRADE_DATE}/R1_style.json + chzl_kg/投研交易/风格研判/${TRADE_DATE}.md 自然语言散文体。完成后退出。"
R4_PROMPT="按 analyze_news_impact_v1 skill 聚合 8 条硬事件 + 板块极性叉乘。trade_date=${TRADE_DATE}。产出 data/research/${TRADE_DATE}/R4_news.json + chzl_kg/投研交易/消息面/${TRADE_DATE}.md。完成后退出。"
R7_PROMPT="按 analyze_capital_flow_v1 skill 做时序资金流 + 昨日前十 5 日追踪 + 龙虎榜诱多识别 + 隔夜美股核心个股(overseas_snapshot)。trade_date=${TRADE_DATE}。产出 data/research/${TRADE_DATE}/R7_capital_flow.json + chzl_kg/投研交易/资金面/${TRADE_DATE}.md。完成后退出。"

run_agent "R1" "analyze_style_v1"                  "$ROOT/data/research/${TRADE_DATE}/R1_style.json"        "$R1_PROMPT" &
R1_PID=$!
run_agent "R4" "analyze_news_impact_v1"          "$ROOT/data/research/${TRADE_DATE}/R4_news.json"         "$R4_PROMPT" &
R4_PID=$!
run_agent "R7" "analyze_capital_flow_v1"           "$ROOT/data/research/${TRADE_DATE}/R7_capital_flow.json" "$R7_PROMPT" &
R7_PID=$!

for pid in "$R1_PID" "$R4_PID" "$R7_PID"; do
    wait "$pid" || PIPELINE_RC=1
done
echo "[$(date '+%H:%M:%S')] Batch 1 done."

# === Batch 2: R3（依赖 R1 情绪基线，须等 R1 落盘后）===
echo ""
echo "[$(date '+%H:%M:%S')] Batch 2: R3 (depends on R1 baseline)"

R3_PROMPT="按 analyze_sentiment_resonance_v1 skill 做 L1+L2 双源共振（WeFlow 已下线）。消费 data/research/${TRADE_DATE}/R1_style.json 作当日情绪基线（勿用前一日）。trade_date=${TRADE_DATE}，群名匿名化。产出 data/research/${TRADE_DATE}/R3_sentiment.json + chzl_kg/投研交易/群聊情绪/${TRADE_DATE}.md。完成后退出。"
run_agent "R3" "analyze_sentiment_resonance_v1"    "$ROOT/data/research/${TRADE_DATE}/R3_sentiment.json"    "$R3_PROMPT" || echo "WARN: R3 failed, continuing"
echo "[$(date '+%H:%M:%S')] Batch 2 done."

# === 07:45 Batch 3: R2（依赖 R3/R4 叙事共振）===
echo ""
echo "[$(date '+%H:%M:%S')] Batch 3: R2 (depends on R3/R4)"

R2_PROMPT="按 analyze_main_sectors_v1 skill 做 5 维板块打分。消费 data/research/${TRADE_DATE}/R3_sentiment.json 和 R4_news.json 的叙事共振主题。trade_date=${TRADE_DATE}。产出 data/research/${TRADE_DATE}/R2_main_sectors.json + chzl_kg/投研交易/主线研判/${TRADE_DATE}.md。完成后退出。"
run_agent "R2" "analyze_main_sectors_v1"    "$ROOT/data/research/${TRADE_DATE}/R2_main_sectors.json"   "$R2_PROMPT" || echo "WARN: R2 failed, continuing"
echo "[$(date '+%H:%M:%S')] Batch 3 done."

# === Batch 4: R5（依赖 R2 龙头候选，须等 R2 落盘后；修复 R5 早于 R2 的 bug）===
echo ""
echo "[$(date '+%H:%M:%S')] Batch 4: R5 (depends on R2)"

R5_PROMPT="按 analyze_stock_profile_v1 skill 做候选池挖掘 + 六维画像。消费 data/research/${TRADE_DATE}/R2_main_sectors.json 的龙头候选（6-15 只）。≥30 日 K + 量价 + 事件时间线。trade_date=${TRADE_DATE}。产出 data/research/${TRADE_DATE}/R5_stock_profiles.json + chzl_kg/投研交易/个股画像/${TRADE_DATE}.md。完成后退出。"

# ── R5 前置：chart_vision 预渲染（2026-09-30 新增）────────────────────────
# 动机：R5 每票直调 chart_vision_analyze（单次 33–44s，串行 12 票 ≈ 500s），
#   是 R5 单步最贵的一段（占其工具耗时 64%）。本步骤用 R2 龙头票池**并发**
#   预渲染快照，R5 改为"先读快照，未命中才调 MCP"。
# 位置必须在 R2 之后、R5 之前 —— R2 的 main_lines[].leaders 是票池唯一真源。
#   历史：旧的 06:50 档 cron 读不到当日 R2（R2 落盘 07:43~08:08），
#   实测与 R5 真实候选仅 1/12 重合，每天白烧 24 次 vision 调用，已删除该 cron。
# 失败不阻塞：R5 会自行回退到直调 MCP。
echo ""
echo "[$(date '+%H:%M:%S')] Pre-rendering chart_vision snapshot from R2 leaders (non-blocking)"
if [[ "$DRY_RUN" != "dry-run" ]]; then
    .venv/bin/python scripts/fetch/run_chart_vision_snapshot.py --date "${TRADE_DATE}" --concurrency 6 \
        || echo "WARN: chart_vision pre-render failed, R5 will call MCP directly"
fi

run_agent "R5" "analyze_stock_profile_v1"   "$ROOT/data/research/${TRADE_DATE}/R5_stock_profiles.json" "$R5_PROMPT" || echo "WARN: R5 failed, continuing"
echo "[$(date '+%H:%M:%S')] Batch 4 done."

# === 07:55 R6（依赖 R1-R5/R7）===
echo ""
echo "[$(date '+%H:%M:%S')] Batch 3: R6"

R6_PROMPT="按 analyze_devil_advocate_v1 skill 做 6 类反证 + 四象限负面识别 + 霸榜出货 hard_reject。只读磁盘 R1-R5/R7 JSON，不抓新数据。trade_date=${TRADE_DATE}。产出 data/research/${TRADE_DATE}/R6_devil_advocate.json + chzl_kg/投研交易/反证/${TRADE_DATE}.md。完成后退出。"

run_agent "R6" "analyze_devil_advocate_v1" "$ROOT/data/research/${TRADE_DATE}/R6_devil_advocate.json" "$R6_PROMPT" || echo "WARN: R6 failed, continuing"

# ── research_summary.json 汇总（2026-09-30 bug 修复）─────────────────────
# 问题：生产流水线跑的是 LLM sub-agent，各写各的 R*.json，**从来没有人生成
#   research_summary.json**。D1 大模型读不到 → 走 _minimal_summary() 兜底 →
#   research_orchestrator_status=degraded，2026-09-30 预案里 `degraded: true`。
#   实测 0914~0929 每一天都缺这个文件。
# 修法：R6 落盘后由只读脚本汇总（**不跑 orchestrator**——那会用规则版覆盖 LLM 产物）。
echo ""
echo "[$(date '+%H:%M:%S')] Building research_summary.json (read-only over R1-R7)"
if [[ "$DRY_RUN" != "dry-run" ]]; then
    state stage --stage summary --status running
    if .venv/bin/python scripts/research/build_research_summary.py --date "${TRADE_DATE}" --force; then
        state stage --stage summary --status completed
    else
        state stage --stage summary --status failed --error "summary has missing/invalid current-run research"
        PIPELINE_RC=1
    fi
fi

# R5/R6 have already been waited/retried synchronously. Waiting another 45min
# cannot repair a finished producer and can only disguise an old same-day file.
# Summary lists usable current-run inputs; absent inputs remain explicit failures.

echo "[$(date '+%H:%M:%S')] Batch 5: D1"

D1_PROMPT="按 main_decision_v1 skill 综合 R1-R7 全部产出 + 四象限叉乘 + 数据源审计。消费 R6 hard_rejects 从 execution_pool 剔除。trade_date=${TRADE_DATE}。仅使用本次 research_summary.json artifacts 列出的主产物；失败或缺研究不视为通过，不读同日旧文件冒充本次研究。decision_source 明确标注 llm。产出 data/plans/${TRADE_DATE}/watchlist_plan.json + chzl_kg/投研交易/盘前预案/${TRADE_DATE}.md 散文体。输出范围仅以上核心 JSON 与 KG 主 MD；不写 runtime 副本或其他附加 MD，若 skill 输出要求超出 profile 白名单则报告该项阻塞，勿越权。完成后退出。"

if run_agent "D1" "main_decision_v1" "$ROOT/data/plans/${TRADE_DATE}/watchlist_plan.json" "$D1_PROMPT" "canghai-plan"; then
    if [[ "$DRY_RUN" != "dry-run" ]]; then
        state stage --stage runtime_handoff --status running
        if state handoff; then
            state stage --stage runtime_handoff --status completed
        else
            state stage --stage runtime_handoff --status failed --error "canonical D1 to runtime handoff failed"
            PIPELINE_RC=1
        fi
    fi
else
    echo "WARN: D1 failed, continuing"
    PIPELINE_RC=1
fi

# D1 writes the canonical plan directly; never copy a stale runtime plan over it.

# Final contract checks + atomic business terminal state run in the EXIT trap.
# Reconciliation is offline here: no external probes or report rewriting after
# delivery, and dry-run must never invoke any helper or external model.
if [[ "$DRY_RUN" != "dry-run" ]]; then
    state stage --stage reconciliation --status running
    if "$PYTHON" "$ROOT/scripts/research/reconcile_pipeline_status.py" --date "$TRADE_DATE" --offline; then
        state stage --stage reconciliation --status completed
    else
        state stage --stage reconciliation --status failed --error "offline reconciliation failed"
        PIPELINE_RC=1
    fi
fi
printf '\n=== %s research shell process finished (business result in data/health/research_pipeline_%s.json) ===\n' "$(date '+%F %T')" "$TRADE_DATE"
exit "$PIPELINE_RC"
