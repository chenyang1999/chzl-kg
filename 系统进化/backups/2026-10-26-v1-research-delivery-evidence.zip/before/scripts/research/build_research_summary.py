#!/usr/bin/env python3
"""Summarize existing LLM primary artifacts, never run/overwrite rule builders.

Always re-inspect inputs: existence-only idempotence can pin yesterday's or a
previous same-day run's summary. Missing/invalid units are visible failures, not
fabricated passes. R7 aliases resolve to the actual same-day primary artifact.
"""
from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from scripts.research.pipeline_artifacts import (  # noqa: E402
    UNIT_FILES, atomic_json, confidence, read_object, research_artifact,
)
from src.research.orchestrator import build_research_summary, load_fetch_manifest  # noqa: E402


def collect_artifacts(trade_date: str, *, since_ns: int | None = None, run_id: str = "") -> tuple[dict, dict, list]:
    artifacts, unit_meta, missing = {}, {}, []
    state = {}
    if run_id:
        try:
            state = read_object(ROOT / "data/health" / f"research_pipeline_{trade_date}.json")
        except (OSError, ValueError):
            pass
    for unit in UNIT_FILES:
        try:
            delivered_json = state.get("contract_results", {}).get(unit, {}).get("json", {}).get("passed")
            if run_id and (state.get("run_id") != run_id or not delivered_json):
                raise ValueError("unit not delivered by this run")
            path, payload = research_artifact(ROOT, trade_date, unit, since_ns=since_ns)
            status = payload.get("status") or ("degraded" if payload.get("degraded") else "complete")
            if status in {"completed", "ok"}:
                status = "complete"
            if payload.get("degraded") and status == "complete":
                status = "degraded"
            artifacts[unit] = str(path.relative_to(ROOT))
            unit_meta[unit] = {
                "status": status, "started_at": payload.get("generated_at"),
                "finished_at": payload.get("generated_at"),
                "notes": str(payload.get("reason") or payload.get("notes") or "LLM primary artifact"),
                "confidence": confidence(payload),
            }
        except (OSError, ValueError, TypeError) as exc:
            missing.append(unit)
            unit_meta[unit] = {"status": "failed", "started_at": None, "finished_at": None,
                               "notes": str(exc), "confidence": None}
    return artifacts, unit_meta, missing


def make_summary(trade_date: str, *, since_ns: int | None = None, run_id: str = "") -> tuple[dict, list]:
    artifacts, unit_meta, missing = collect_artifacts(trade_date, since_ns=since_ns, run_id=run_id)
    try:
        manifest = load_fetch_manifest(trade_date)
        manifest_error = None
    except (OSError, ValueError, TypeError) as exc:
        manifest, manifest_error = {}, str(exc)
    summary = build_research_summary(trade_date, manifest, artifacts, unit_meta)
    # Explicitly distinguish a legitimate skip/degraded primary from a skeleton.
    usable = [m for m in unit_meta.values() if m["status"] in {"complete", "partial", "degraded", "skipped"}]
    summary["orchestrator_status"] = (
        "failed" if not usable else "complete" if all(m["status"] == "complete" for m in unit_meta.values()) else "partial"
    )
    summary["timeouts"] = missing
    summary["run_id"] = run_id or None
    if manifest_error:
        summary["fetch_global_severity"] = None
        summary["manifest_error"] = manifest_error
        if usable:
            summary["orchestrator_status"] = "partial"
    unit_data = {unit: read_object(ROOT / rel) for unit, rel in artifacts.items()}
    try:
        from src.research import contract_checks
        failures = {k: v for k, v in contract_checks.run_research_checks(unit_data, trade_date).items() if v}
        # A no-mainline decision explicitly explained by R2 is not a missing
        # cross-validation contract. Preserve the skip, do not claim it passed.
        results = {}
        r2 = unit_data.get("R2", {})
        if (r2.get("main_lines") == [] and r2.get("empty_pool_reason") and
                "consensus_themes" in r2):
            failures.pop("R2", None)
            results["R2"] = {"status": "not_applicable", "reason": r2["empty_pool_reason"]}
        for unit in missing:
            failures.setdefault(unit, []).append(unit_meta[unit]["notes"])
        for unit in UNIT_FILES:
            if unit in results:
                continue
            status = unit_meta[unit]["status"]
            results[unit] = {"status": "failed" if unit in failures else "skipped" if status == "skipped" else "degraded" if status in {"partial", "degraded"} else "passed",
                             "research_status": status}
        summary["contract_results"] = results
        summary["contract_failures"] = failures
        summary["contract_checks_passed"] = not failures
        if failures and usable:
            summary["orchestrator_status"] = "partial"
    except Exception as exc:  # checker failure is recorded, never all-green
        summary["contract_failures"] = {"_error": [f"{type(exc).__name__}: {exc}"]}
        summary["contract_checks_passed"] = False
        summary["orchestrator_status"] = "partial" if usable else "failed"
    # R6 vetoes remain effective even in an explicitly degraded real artifact.
    # No new vetoes are inferred and no trading rule is changed here.
    r6 = unit_data.get("R6", {})
    summary["hard_rejects"] = r6.get("hard_rejects") or []
    summary["decision_source"] = "llm"
    summary["summary_builder"] = "scripts/research/build_research_summary.py (read-only primary artifacts)"
    return summary, missing


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--date", default=datetime.now().strftime("%Y%m%d"))
    parser.add_argument("--force", action="store_true", help="compatibility flag; inputs are always re-inspected")
    parser.add_argument("--since-ns", type=int)
    parser.add_argument("--run-id", default=os.environ.get("CHZL_RESEARCH_RUN_ID", ""))
    args = parser.parse_args()
    since_ns = args.since_ns
    if args.run_id and since_ns is None:
        state = read_object(ROOT / "data/health" / f"research_pipeline_{args.date}.json")
        since_ns = state["started_ns"]
    summary, missing = make_summary(args.date, since_ns=since_ns, run_id=args.run_id)
    path = ROOT / "data/research" / args.date / "research_summary.json"
    atomic_json(path, summary)
    print(f"research_summary: status={summary['orchestrator_status']}, units={len(summary['artifacts'])}, missing={missing}, contracts_passed={summary['contract_checks_passed']}")
    return 1 if missing or "_error" in summary["contract_failures"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
