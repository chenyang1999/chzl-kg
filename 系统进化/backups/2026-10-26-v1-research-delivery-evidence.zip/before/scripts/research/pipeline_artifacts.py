"""Shared, offline artifact inspection; never builds research or trading decisions."""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
import tempfile

UNIT_FILES = {
    "R1": "R1_style.json", "R2": "R2_main_sectors.json", "R3": "R3_sentiment.json",
    "R4": "R4_news.json", "R5": "R5_stock_profiles.json", "R6": "R6_devil_advocate.json",
    "R7": "R7_capital_flow.json",
}
MD_DIRS = dict(zip((*UNIT_FILES, "D1"),
                   ("风格研判", "主线研判", "群聊情绪", "消息面", "个股画像", "反证", "资金面", "盘前预案")))
PRIMARY_FIELDS = {
    "R1": ("style", "sentiment_score"), "R2": ("main_lines",),
    "R3": ("resonance_top_themes", "sentiment_score"), "R4": ("top_events",),
    "R5": ("profiles",), "R6": ("counter_arguments", "hard_rejects"),
    "R7": ("main_force", "northbound"),
}
USABLE_STATUSES = {"complete", "completed", "ok", "partial", "degraded"}


def read_object(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"JSON object required: {path.name}")
    return data


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            json.dump(value, out, ensure_ascii=False, indent=2, allow_nan=False)
            out.write("\n")
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _fresh(path: Path, since_ns: int | None) -> None:
    if since_ns is not None and path.stat().st_mtime_ns < since_ns:
        raise ValueError(f"stale artifact from before this attempt: {path.name}")


def _date(data: dict, date: str) -> None:
    if str(data.get("trade_date", "")).replace("-", "") != date:
        raise ValueError(f"trade_date mismatch: {data.get('trade_date')!r}, expected {date}")


def _has_primary(unit: str, data: dict) -> bool:
    return any(k in data and isinstance(data[k], (list, dict, str, int, float)) for k in PRIMARY_FIELDS[unit])


def legal_r5_skip(root: Path, date: str, data: dict) -> bool:
    if data.get("profiles") != [] or not (data.get("reason") or data.get("skip_reason")):
        return False
    try:
        r2 = read_object(root / "data/research" / date / UNIT_FILES["R2"])
        _date(r2, date)
        if r2.get("status") not in USABLE_STATUSES or not isinstance(r2.get("main_lines"), list):
            return False
        lines = r2["main_lines"] + (r2.get("secondary_lines") or [])
        return not any(line.get("leaders") for line in lines if isinstance(line, dict))
    except (OSError, ValueError, TypeError):
        return False


def research_artifact(root: Path, date: str, unit: str, *, since_ns: int | None = None) -> tuple[Path, dict]:
    """Resolve ONLY same-day R7 aliases; no glob over evidence/validation files.

    A primary canonical file wins. A pointer/absent canonical may resolve to the
    exact dated R7 filename, never yesterday or an arbitrary traversal target.
    Both the target's content/date AND its own mtime are checked.
    """
    canonical = root / "data/research" / date / UNIT_FILES[unit]
    path = canonical
    data = read_object(path) if path.is_file() else {}
    if unit == "R7" and not _has_primary(unit, data):
        dated = canonical.with_name(f"R7_capital_flow_{date}.json")
        pointer = next((data[k] for k in ("canonical_path", "artifact_path", "target", "alias_of", "path", "pointer", "ref")
                        if isinstance(data.get(k), str)), None)
        if pointer:
            target = Path(pointer)
            target = (root / target) if str(target).startswith("data/") else (canonical.parent / target)
            if target.resolve() != dated.resolve():
                raise ValueError("R7 alias must target the same-day dated primary artifact")
        path = dated
        data = read_object(path)
    _fresh(path, since_ns)
    _date(data, date)
    status = str(data.get("status") or ("degraded" if data.get("degraded") else "complete"))
    if status == "skipped":
        if unit != "R5" or not legal_r5_skip(root, date, data):
            raise ValueError(f"{unit}: unexplained/unsupported skip")
    elif status not in USABLE_STATUSES:
        raise ValueError(f"{unit}: unusable status={status}")
    if not _has_primary(unit, data):
        raise ValueError(f"{unit}: primary research fields missing (pointer/skeleton is not research)")
    return path, data


def plan_reassessment_reasons(data: dict) -> list[str]:
    """Explicit incompleteness survives safe publication; absence is legacy.

    Delivery, research readiness and execution consent are separate contracts.
    Do not infer completion from LLM provenance or a safe no-trade decision.
    """
    reasons = []
    for label, section in (("plan", data), ("meta", data.get("meta") or {})):
        if not isinstance(section, dict):
            continue
        for key in ("production_ready", "research_completion_passed"):
            if key in section and section[key] is not True:
                reasons.append(f"{label}.{key} is not true")
        if section.get("reassessment_required") is True:
            reasons.append(f"{label}.reassessment_required")
    return reasons


def plan_artifact(root: Path, date: str, *, since_ns: int | None = None) -> tuple[Path, dict]:
    path = root / "data/plans" / date / "watchlist_plan.json"
    data = read_object(path)
    _fresh(path, since_ns)
    _date(data, date)
    meta = data.get("meta") or {}
    source = data.get("decision_source") or meta.get("decision_source")
    if (data.get("is_fallback") or meta.get("python_fallback") or
            "rule" in str(data.get("agent_name", "")).lower() or
            data.get("mode") in {"fallback", "python_fallback"}):
        raise ValueError("D1 is a fallback/rule artifact, not LLM delivery")
    if source != "llm":
        raise ValueError("D1 must explicitly declare decision_source=llm")
    if not data.get("generated_at") or not isinstance(data.get("execution_pool"), list):
        raise ValueError("D1 missing generated_at/execution_pool")
    from trading.load_plan import validate_plan_for_date
    validate_plan_for_date(data, date)
    # An empty execution pool is a valid no-trade decision, not a model failure.
    return path, data


def md_artifact(root: Path, date: str, unit: str, *, since_ns: int | None = None) -> Path:
    path = root / "chzl_kg/投研交易" / MD_DIRS[unit] / f"{date}.md"
    _fresh(path, since_ns)
    if len(path.read_text(encoding="utf-8").splitlines()) < 5:
        raise ValueError(f"{unit}: missing/substantially empty human report")
    return path


def publish_runtime_plan(root: Path, date: str, *, since_ns: int | None = None) -> Path:
    """Trusted implementation handoff: canonical -> runtime ONLY, atomically.

    The LLM profile need not (and must not) gain runtime write permission.
    No loaded/execution artifacts or trading gates are changed here.
    """
    _, data = plan_artifact(root, date, since_ns=since_ns)
    md_artifact(root, date, "D1", since_ns=since_ns)
    # Reuse execution's schema/authorization staging boundary rather than
    # introducing a second copy path that could bypass its no-promotion checks.
    from trading import load_plan
    if Path(load_plan.DATA_DIR).resolve() != (root / "data").resolve():
        raise ValueError("execution staging root mismatch; refusing cross-root handoff")
    runtime = load_plan.stage_plan(date)
    if read_object(runtime) != data:
        raise OSError("runtime handoff read-back mismatch")
    return runtime


def confidence(data: dict) -> float | None:
    """Unknown/unrated is null, not a measured zero (bool is not a score)."""
    value = data.get("confidence")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if 0 <= value <= 1 and math.isfinite(value) else None
