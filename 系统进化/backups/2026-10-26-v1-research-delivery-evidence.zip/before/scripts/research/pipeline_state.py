#!/usr/bin/env python3
"""Atomic business state at the EXISTING research_pipeline_YYYYMMDD.json path.

status is business state, never the scheduler/nohup result. All updates lock the
existing health directory inode (no new durable lock path). An older run cannot
finish over a newer run. Readers always see one complete JSON document.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import fcntl
import json
import os
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from scripts.research.pipeline_artifacts import (
    MD_DIRS, UNIT_FILES, atomic_json, md_artifact, plan_artifact,
    publish_runtime_plan, read_object, research_artifact,
)

ROOT = Path(__file__).resolve().parents[2]


def now() -> str:
    return datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="microseconds")


def state_path(root: Path, date: str) -> Path:
    return root / "data/health" / f"research_pipeline_{date}.json"


def alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return pid > 1
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


@contextmanager
def locked_state(root: Path, date: str):
    path = state_path(root, date)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        try:
            state = read_object(path)
        except (OSError, ValueError):
            state = {}
        yield state
        atomic_json(path, state)
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def start(root: Path, date: str, run_id: str, pid: int, status: str) -> None:
    with locked_state(root, date) as state:
        same = state.get("run_id") == run_id
        if not same and state.get("status") in {"started", "running"}:
            if alive(int(state.get("pid") or 0)):
                raise ValueError(f"pipeline already active: run_id={state.get('run_id')}, pid={state.get('pid')}")
        if same and state.get("status") in {"completed", "failed"}:
            raise ValueError("terminal run cannot be restarted; allocate a new run_id")
        if not same:
            state.clear()
            state.update({"schema_version": "research_pipeline_v2", "pipeline": "research_shell",
                          "trade_date": date, "run_id": run_id, "started_at": now(),
                          "started_ns": time.time_ns(), "finished_at": None,
                          "missing_json": [], "missing_md": [], "missing_count": 0,
                          "total_expected": 15, "stages": {}, "contract_results": {}, "error": None})
        state.update(status=status, pid=pid, updated_at=now())


def update(root: Path, date: str, run_id: str, fn) -> None:
    with locked_state(root, date) as state:
        if state.get("run_id") != run_id:
            raise ValueError("refusing update from superseded run")
        if state.get("status") in {"completed", "failed"}:
            raise ValueError("refusing update to terminal business state")
        fn(state)
        state["updated_at"] = now()


def stage(root: Path, date: str, run_id: str, name: str, status: str, error: str = "", attempt: int = 0) -> None:
    def apply(state):
        previous = state["stages"].get(name, {})
        entry = {**previous, "status": status, "error": error or None}
        entry.setdefault("started_at", now())
        if attempt:
            entry["attempt"] = attempt
        if status == "running" and name in {*UNIT_FILES, "D1"}:
            # Last attempt's JSON/MD evidence cannot validate this attempt.
            state["contract_results"].pop(name, None)
            entry["attempt_started_ns"] = time.time_ns()
        if status in {"completed", "failed", "skipped"}:
            entry["finished_at"] = now()
        state["stages"][name] = entry
    update(root, date, run_id, apply)


def attempt_start(root: Path, date: str, run_id: str, unit: str) -> int:
    state = read_object(state_path(root, date))
    if state.get("run_id") != run_id:
        raise ValueError("attempt belongs to superseded run")
    return state["stages"][unit]["attempt_started_ns"]


def check(root: Path, date: str, run_id: str, unit: str, since: Path | None = None) -> bool:
    since_ns = since.stat().st_mtime_ns if since else attempt_start(root, date, run_id, unit)
    results = {}
    for kind in ("json", "md"):
        try:
            if kind == "md":
                path = md_artifact(root, date, unit, since_ns=since_ns)
            elif unit == "D1":
                path, _ = plan_artifact(root, date, since_ns=since_ns)
            else:
                path, _ = research_artifact(root, date, unit, since_ns=since_ns)
            results[kind] = {"passed": True, "path": str(path.relative_to(root))}
        except (OSError, ValueError, TypeError) as exc:
            results[kind] = {"passed": False, "error": str(exc)}
            if kind == "md" and unit in UNIT_FILES:
                try:
                    _, payload = research_artifact(root, date, unit, since_ns=since_ns)
                    if payload.get("md_delivery"):
                        results[kind]["delivery_blocker"] = payload["md_delivery"]
                except (OSError, ValueError, TypeError):
                    pass
    update(root, date, run_id, lambda s: s["contract_results"].update({unit: results}))
    return all(r["passed"] for r in results.values())


def finish(root: Path, date: str, run_id: str, rc: int, error: str = "", *, skipped: bool = False) -> bool:
    def apply(state):
        if not skipped:
            since_ns = state["started_ns"]
            missing_json, missing_md = [], []
            for unit, filename in UNIT_FILES.items():
                try:
                    research_artifact(root, date, unit, since_ns=since_ns)
                except (OSError, ValueError, TypeError):
                    missing_json.append(Path(filename).stem)
            for unit, dirname in MD_DIRS.items():
                try:
                    md_artifact(root, date, unit, since_ns=since_ns)
                except (OSError, ValueError):
                    missing_md.append(f"{unit}:{dirname}")
            # Keep legacy total_expected=15 (7 research JSON + 8 MD). D1 JSON,
            # summary and runtime handoff are additional named contract results.
            state.update(missing_json=missing_json, missing_md=missing_md,
                         missing_count=len(missing_json) + len(missing_md))
            for name, fn in {
                "D1_json": lambda: plan_artifact(root, date, since_ns=since_ns),
                "summary": lambda: summary_contract(root, date, run_id, since_ns),
                "runtime_handoff": lambda: runtime_contract(root, date),
            }.items():
                try:
                    fn()
                    state["contract_results"][name] = {"passed": True}
                except (OSError, ValueError, TypeError) as exc:
                    state["contract_results"][name] = {"passed": False, "error": str(exc)}
        failures = [k for k, v in state["stages"].items() if v["status"] in {"failed", "running"}]
        bad_contracts = [k for k in ("D1_json", "summary", "runtime_handoff")
                         if state["contract_results"].get(k, {}).get("passed") is False]
        failed = bool(rc or failures or bad_contracts or state["missing_count"])
        state.update(status="failed" if failed else "completed", finished_at=now(),
                     process_exit_code=rc, exit_code=(rc or 1) if failed else 0,
                     error=(error or f"failed stages={failures}; contracts={bad_contracts}; missing={state['missing_count']}") if failed else None)
        if skipped:
            state["skipped"] = True
    update(root, date, run_id, apply)
    return read_object(state_path(root, date))["status"] == "completed"


def summary_contract(root: Path, date: str, run_id: str, since_ns: int) -> None:
    path = root / "data/research" / date / "research_summary.json"
    data = read_object(path)
    if path.stat().st_mtime_ns < since_ns or data.get("run_id") != run_id:
        raise ValueError("stale/mismatched research_summary run")
    if data.get("orchestrator_status") not in {"complete", "partial"}:
        raise ValueError("summary has no usable primary research")
    if not isinstance(data.get("contract_checks_passed"), bool):
        raise ValueError("summary contract check result missing")
    # Partial/explicit degrade is deliverable, NOT an assertion that all checks
    # passed. Missing primary units and checker crashes remain business failures.
    missing = set(UNIT_FILES) - set(data.get("artifacts", {}))
    if missing or "_error" in data.get("contract_failures", {}):
        raise ValueError(f"summary missing usable units={sorted(missing)} or checker failed")


def runtime_contract(root: Path, date: str) -> None:
    _, canonical = plan_artifact(root, date)
    runtime = read_object(root / "data/runtime" / f"watchlist_plan_{date}.json")
    if runtime != canonical:
        raise ValueError("runtime does not match authoritative canonical D1 plan")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command", choices=("start", "stage", "check", "finish", "handoff", "reap"))
    ap.add_argument("--root", type=Path, default=ROOT)
    ap.add_argument("--date", required=True)
    ap.add_argument("--run-id", default=os.environ.get("CHZL_RESEARCH_RUN_ID", ""))
    ap.add_argument("--pid", type=int, default=os.getppid())
    ap.add_argument("--status", default="running")
    ap.add_argument("--stage", default="startup")
    ap.add_argument("--error", default="")
    ap.add_argument("--attempt", type=int, default=0)
    ap.add_argument("--rc", type=int, default=0)
    ap.add_argument("--since", type=Path)
    ap.add_argument("--skipped", action="store_true")
    args = ap.parse_args()
    try:
        if args.command == "start":
            start(args.root, args.date, args.run_id, args.pid, args.status)
        elif args.command == "stage":
            stage(args.root, args.date, args.run_id, args.stage, args.status, args.error, args.attempt)
        elif args.command == "check":
            return 0 if check(args.root, args.date, args.run_id, args.stage, args.since) else 1
        elif args.command == "finish":
            return 0 if finish(args.root, args.date, args.run_id, args.rc, args.error, skipped=args.skipped) else 1
        elif args.command == "handoff":
            since_ns = args.since.stat().st_mtime_ns if args.since else attempt_start(args.root, args.date, args.run_id, "D1")
            publish_runtime_plan(args.root, args.date, since_ns=since_ns)
        elif args.command == "reap":
            state = read_object(state_path(args.root, args.date))
            if state.get("status") in {"started", "running"} and not alive(int(state.get("pid") or 0)):
                finish(args.root, args.date, state["run_id"], 1, "pipeline process disappeared before terminal delivery")
        return 0
    except (OSError, ValueError, TypeError) as exc:
        print(f"pipeline_state: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
