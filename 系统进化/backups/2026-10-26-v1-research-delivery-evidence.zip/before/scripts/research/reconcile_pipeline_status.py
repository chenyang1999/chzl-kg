#!/usr/bin/env python3
"""reconcile_pipeline_status.py · 流水线收尾核查器 (2026-09-29)

问题背景:
  并行 agent 在报告里审计兄弟节点/数据源时, 会把"我这次调用失败"或"当时还没落盘"
  直接定性成 source unavailable, 且没有最终复核环节 → 用户看到假红点, 决策依据失真。

职责:
  1. 以磁盘事实核查 R1-R7/D1 全部 artifact 的真实状态
  2. 对报告中点名"不可用"但可实测的源做探针复核 (hithink/两融等)
  3. 产出 data/health/pipeline_reconciliation_<date>.json (权威地面真相)
  4. 就地修正 chzl_kg 消息面/预案 md 审计表中的过时定性 (保留修正痕迹)

用法: python3 scripts/research/reconcile_pipeline_status.py --date YYYYMMDD [--patch-md]
"""
from __future__ import annotations

import argparse
import io
import json
import secrets
import sys
import urllib.request
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.research.pipeline_artifacts import (  # noqa: E402
    UNIT_FILES, atomic_json, plan_artifact, read_object, research_artifact,
)

TZ = timezone(timedelta(hours=8))
R_ARTIFACTS = ["R1_style", "R2_main_sectors", "R3_sentiment", "R4_news",
               "R5_stock_profiles", "R6_devil_advocate", "R7_capital_flow"]


def now_iso() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def probe_hithink() -> dict:
    """实测 hithink (问财 OpenAPI) 是否可用 — 区分 call_failed vs source_down。"""
    from scripts.fetch.run_auction_snapshot import _load_env_value
    key = _load_env_value("IWENCAI_API_KEY")
    if not key:
        return {"verdict": "no_api_key", "available": False}
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "X-Claw-Call-Type": "normal",
        "X-Claw-Skill-Id": "hithink-business-query",
        "X-Claw-Skill-Version": "1.0.0",
        "X-Claw-Plugin-Id": "none",
        "X-Claw-Plugin-Version": "none",
        "X-Claw-Trace-Id": secrets.token_hex(32),
    }
    payload = {"query": "三六零主营业务构成", "page": "1", "limit": "1",
               "is_cache": "1", "expand_index": "true"}
    req = urllib.request.Request(
        "https://openapi.iwencai.com/v1/query2data",
        data=json.dumps(payload).encode(), headers=headers, method="POST")
    try:
        r = json.loads(urllib.request.urlopen(req, timeout=20).read())
        ok = bool(r.get("datas"))
        return {"verdict": "available" if ok else "empty_response",
                "available": ok, "code_count": r.get("code_count")}
    except Exception as exc:  # noqa: BLE001
        return {"verdict": "source_down", "available": False,
                "error": f"{type(exc).__name__}: {exc}"}


def probe_margin(prev_date: str) -> dict:
    """核查 T-1 两融明细是否已可用 (agent 常误报停在更早日期)。"""
    try:
        from scripts.fetch.run_auction_snapshot import _load_env_value
        import tushare as ts
        ts.set_token(_load_env_value("TUSHARE_TOKEN"))
        df = ts.pro_api().margin(trade_date=prev_date)
        return {"verdict": "available" if len(df) else "empty",
                "available": bool(len(df)), "rows": int(len(df)),
                "date": prev_date}
    except Exception as exc:  # noqa: BLE001
        return {"verdict": "error", "available": False,
                "error": f"{type(exc).__name__}: {exc}"}


def artifact_status(date: str) -> dict:
    out = {}
    for unit, filename in UNIT_FILES.items():
        name = Path(filename).stem
        p = ROOT / "data/research" / date / filename
        try:
            p, j = research_artifact(ROOT, date, unit)
            out[name] = {"exists": True, "valid": True, "path": str(p.relative_to(ROOT)),
                         "mtime": datetime.fromtimestamp(p.stat().st_mtime, TZ).isoformat(timespec="seconds"),
                         "status_field": j.get("status"), "degraded": j.get("degraded"), "size": p.stat().st_size}
        except (OSError, ValueError, TypeError) as exc:
            out[name] = {"exists": p.is_file(), "valid": False, "error": str(exc)}
    for rel in (f"data/plans/{date}/watchlist_plan.json", f"data/runtime/watchlist_plan_{date}.json"):
        p = ROOT / rel
        try:
            j = read_object(p)
            _, canonical = plan_artifact(ROOT, date)
            out[rel] = {"exists": True, "valid": j == canonical,
                        "authoritative": rel.startswith("data/plans/"),
                        "matches_canonical": j == canonical, "size": p.stat().st_size}
        except (OSError, ValueError, TypeError) as exc:
            out[rel] = {"exists": p.is_file(), "valid": False, "error": str(exc)}
    return out


def patch_news_md(date: str, corrections: dict) -> list[str]:
    """修正消息面 md 审计表里的过时定性, 返回改动描述。"""
    md = ROOT / "chzl_kg" / "投研交易" / "消息面" / f"{date}.md"
    if not md.is_file():
        return []
    txt = md.read_text(encoding="utf-8")
    changes = []

    if corrections.get("hithink", {}).get("available"):
        target = "| hithink_business_query"
        repl = "| hithink_business_query     | 2026-09-29 | 🟡  | R4会话内调用失败(call_failed)；核查器实测接口可用→非源故障 |"
        lines = txt.split("\n")
        hit = any(l.startswith(target) and "🔴" in l for l in lines)
        lines = [repl if l.startswith(target) and "🔴" in l else l for l in lines]
        txt = "\n".join(lines)
        if hit:
            changes.append("hithink: 🔴不可用 → 🟡call_failed(接口实测可用)")

    r7 = corrections.get("artifacts", {}).get("R7_capital_flow", {})
    if r7.get("valid") and r7.get("status_field") == "complete" and not r7.get("degraded"):
        old = "| r7_capital_flow            | 2026-09-29 | 🔴  | 未落盘→r7_status=unavailable      |"
        new = f"| r7_capital_flow            | 2026-09-29 | 🟢  | R4生成时(07:14)未落盘；实际{r7['mtime'][11:19]}complete |"
        if old in txt:
            txt = txt.replace(old, new)
            changes.append("r7: 🔴未落盘 → 🟢complete(时序错位)")

    # frontmatter 数据源行同步修正
    txt = txt.replace(
        '    status: error\n    error: 本会话不可用, business_relevance=null 降级',
        '    status: call_failed\n    error: R4会话内调用失败；核查器事后实测接口可用')

    md.write_text(txt, encoding="utf-8")
    return changes


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", default=datetime.now(TZ).strftime("%Y%m%d"))
    ap.add_argument("--prev-date", default=None, help="T-1 YYYYMMDD (两融核查用)")
    ap.add_argument("--patch-md", action="store_true")
    ap.add_argument("--offline", action="store_true", help="artifact-only; no external probes or model calls")
    args = ap.parse_args()
    date = args.date
    prev_date = args.prev_date or (datetime.strptime(date, "%Y%m%d") - timedelta(days=1)).strftime("%Y%m%d")

    result = {
        "schema_version": "pipeline_reconciliation_v1",
        "trade_date": date,
        "checked_at": now_iso(),
        "artifacts": artifact_status(date),
        "probes": {"hithink_business_query": {"verdict": "not_probed"},
                   "margin_detail": {"verdict": "not_probed"}} if args.offline else {
            "hithink_business_query": probe_hithink(),
            "margin_detail": probe_margin(prev_date),
        },
    }

    real_missing = [k for k, v in result["artifacts"].items() if not v.get("exists") or not v.get("valid")]
    result["real_missing_artifacts"] = real_missing
    health = ROOT / "data/health" / f"research_pipeline_{date}.json"
    if health.is_file():
        from scripts.research.pipeline_state import alive, finish
        state = read_object(health)
        if state.get("status") in {"started", "running"} and not alive(int(state.get("pid") or 0)):
            finish(ROOT, date, state["run_id"], 1, "pipeline owner disappeared before terminal delivery")
            state = read_object(health)
        result["business_state"] = state
    result["summary"] = (
        f"artifact缺失{len(real_missing)}; "
        f"hithink={result['probes']['hithink_business_query']['verdict']}; "
        f"margin({prev_date})={result['probes']['margin_detail']['verdict']}")

    if args.patch_md:
        result["md_changes"] = patch_news_md(date, result)

    out = ROOT / "data" / "health" / f"pipeline_reconciliation_{date}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    atomic_json(out, result)
    print(json.dumps({"path": str(out.relative_to(ROOT)),
                      "summary": result["summary"],
                      "md_changes": result.get("md_changes", [])},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
