#!/usr/bin/env python3
"""Read-only, version-bound research handoff; never builds research or a plan.

The embedded manifest records delivery and transmission, NOT a model tool-read
or decision. Auxiliary materials remain outside the active D1 input permission.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from scripts.research.pipeline_artifacts import (  # noqa: E402
    MD_DIRS, UNIT_FILES, atomic_json, confidence, file_version, md_artifact, read_object,
    research_artifact, safe_artifact_path, validate_candidate_shape, validate_date, verified_delivery, verify_binding,
)
from src.research.orchestrator import build_research_summary, load_fetch_manifest  # noqa: E402

MANIFEST_VERSION = "plan_input_manifest_v1"
FINGERPRINT_FIELDS = ("sha256", "bytes", "mtime_ns")
SUMMARY_PROJECTION = ("schema_version", "trade_date", "run_id", "artifacts", "confidence", "hard_rejects",
                      "orchestrator_status", "contract_checks_passed", "contract_failures", "missing_md")
AUXILIARY_CANDIDATES = {
    "corrections": "data/corrections/20*/error_case_*.md",
    "stock_character": "data/cache/stock_character.json",
    "theme_anchors": "data/rules/theme_anchors/latest.json",
    "macro": "data/runtime/hermes_macro_{date}.json",
    "prediction": "data/research/{date}/node_prediction.json",
    "emotion_cycle": "data/research/{date}/emotion_cycle.json",
    "attention": "data/research/{date}/attention_signals.json",
}


def _date(date: str) -> None:
    validate_date(date)


def _inside(root: Path, path: Path) -> Path:
    return safe_artifact_path(root, path)


def _snapshot(root: Path, path: Path) -> tuple[dict, bytes]:
    before = file_version(root, path)
    blob = path.read_bytes()
    after = file_version(root, path)
    if before != after or hashlib.sha256(blob).hexdigest() != after["sha256"]:
        raise ValueError("input changed during inspection")
    return after, blob


def _binding(root: Path, state: dict, unit: str, kind: str, fingerprint: dict, run_id: str, date: str) -> dict:
    if not run_id:
        return {"status": "not_run_bound", "run_id": None, "attempt": None,
                "reason": "standalone inspection; no delivery receipt asserted"}
    stage = state.get("stages", {}).get(unit, {})
    receipt = state.get("contract_results", {}).get(unit, {}).get(kind, {})
    errors = []
    try:
        if state.get("run_id") != run_id or state.get("trade_date") != date:
            raise ValueError("pipeline run/date mismatch")
        path, _ = verified_delivery(root, date, unit, kind, state)
        if file_version(root, path) != fingerprint:
            raise ValueError("delivery changed after summary inspection")
    except (OSError, ValueError, TypeError) as exc:
        errors.append(str(exc))
    return {"status": "mismatch" if errors else "verified", "run_id": run_id, "attempt": stage.get("attempt"),
            "receipt": receipt, "errors": errors}


def _source_timing(payload: dict) -> dict:
    # Preserve declared source times verbatim. Filesystem delivery time is not
    # source observation time; generated_at is not an agent start/finish time.
    keys = ("generated_at", "captured_at", "observed_at", "source_observed_at", "resolved_trade_date",
            "data_from_trade_date", "input_freshness", "input_freshness_note", "data_sources")
    return {key: payload[key] for key in keys if key in payload}


def auxiliary_input_manifest(trade_date: str, *, root: Path | None = None,
                             approved_paths: dict[str, list[str]] | None = None) -> dict:
    """Exact-path adapter, opt-in only; no caller in the active pipeline opts in.

    Approval is a caller-owned reviewed allowlist, never a model artifact flag.
    No wildcard expansion or broad directory read is performed here.
    """
    _date(trade_date)
    root = root or ROOT
    result = {}
    for name, pattern in AUXILIARY_CANDIDATES.items():
        entry = {"candidate": pattern.format(date=trade_date), "authorized": False,
                 "status": "pending_approval", "availability": "not_inspected", "inputs": []}
        for rel in (approved_paths or {}).get(name, []):
            import fnmatch
            path = Path(rel)
            if path.is_absolute() or ".." in path.parts or not fnmatch.fnmatchcase(rel, entry["candidate"]):
                raise ValueError(f"{name}: path outside candidate allowlist")
            try:
                fingerprint, _ = _snapshot(root, root / rel)
                entry["inputs"].append({**fingerprint, "status": "available"})
            except (OSError, ValueError) as exc:
                entry["inputs"].append({"path": rel, "status": "missing_or_invalid", "error": str(exc)})
            entry.update(authorized=True, status="approved_adapter_only", availability="inspected")
        result[name] = entry
    if set(approved_paths or {}) - set(result):
        raise ValueError("unknown auxiliary category")
    return result


def _collect(trade_date: str, *, since_ns: int | None = None, run_id: str = "") -> tuple[dict, dict, list, dict]:
    _date(trade_date)
    artifacts, unit_meta, missing, payloads = {}, {}, [], {}
    state = {}
    if run_id:
        try:
            state = read_object(ROOT / "data/health" / f"research_pipeline_{trade_date}.json")
        except (OSError, ValueError):
            pass
    for unit, filename in UNIT_FILES.items():
        evidence = {"json": {"path": f"data/research/{trade_date}/{filename}", "readable": False,
                             "usable": False},
                    "md": {"path": f"chzl_kg/投研交易/{MD_DIRS[unit]}/{trade_date}.md", "delivered": False},
                    "transmission": "not_in_artifacts", "actual_tool_read": "not_independently_verified",
                    "decision_adoption": "not_independently_verified"}
        try:
            # Record readability separately from business usability/date/run.
            canonical = ROOT / evidence["json"]["path"]
            # Only the shared research resolver may authorize R7's canonical
            # symlink. Snapshotting the reference is best-effort metadata, not
            # primary evidence; the resolved regular file is validated/bound below.
            try:
                fingerprint, blob = _snapshot(ROOT, canonical)
                evidence["json"].update(fingerprint)
                evidence["json"]["readable"] = isinstance(json.loads(blob), dict)
            except (OSError, ValueError):
                pass
            path, payload = research_artifact(ROOT, trade_date, unit, since_ns=since_ns)
            if path != canonical:
                evidence["json"]["canonical_reference"] = {k: evidence["json"][k] for k in ("path", *FINGERPRINT_FIELDS) if k in evidence["json"]}
            fingerprint, blob = _snapshot(ROOT, path)
            if json.loads(blob) != payload:
                raise ValueError("primary changed between validation and fingerprint")
            binding = _binding(ROOT, state, unit, "json", fingerprint, run_id, trade_date)
            evidence["json"].update(**fingerprint, readable=True, source_timing=_source_timing(payload),
                                    receipt_binding=binding, research_status=payload.get("status"))
            if run_id and binding["status"] != "verified":
                raise ValueError("current-version JSON delivery unverified: " + "; ".join(binding["errors"]))
            status = payload.get("status") or ("degraded" if payload.get("degraded") else "complete")
            if status in {"completed", "ok"}:
                status = "complete"
            if payload.get("degraded") and status == "complete":
                status = "degraded"
            stage = state.get("stages", {}).get(unit, {})
            artifacts[unit] = fingerprint["path"]
            payloads[unit] = payload
            evidence["json"]["usable"] = True
            evidence["transmission"] = "listed_in_summary_artifacts"
            unit_meta[unit] = {
                "status": status, "started_at": stage.get("started_at"),
                "finished_at": stage.get("finished_at"),
                "notes": str(payload.get("reason") or payload.get("skip_reason") or payload.get("notes") or "LLM primary artifact"),
                "confidence": confidence(payload), "input_evidence": evidence,
            }
        except (OSError, ValueError, TypeError) as exc:
            missing.append(unit)
            evidence["json"]["error"] = str(exc)
            unit_meta[unit] = {"status": "failed", "started_at": None, "finished_at": None,
                               "notes": str(exc), "confidence": None, "input_evidence": evidence}
        # JSON usability and promised human delivery are independent obligations.
        try:
            _inside(ROOT, ROOT / evidence["md"]["path"])
            path = md_artifact(ROOT, trade_date, unit, since_ns=since_ns)
            fingerprint, _ = _snapshot(ROOT, path)
            binding = _binding(ROOT, state, unit, "md", fingerprint, run_id, trade_date)
            evidence["md"].update(**fingerprint, receipt_binding=binding,
                                   delivered=not run_id or binding["status"] == "verified")
        except (OSError, ValueError, TypeError) as exc:
            evidence["md"]["error"] = str(exc)
        if not evidence["md"]["delivered"]:
            evidence["md"]["status"] = "missing_or_unverified_delivery"
        else:
            evidence["md"]["status"] = "delivered"
    return artifacts, unit_meta, missing, payloads


def collect_artifacts(trade_date: str, *, since_ns: int | None = None, run_id: str = "") -> tuple[dict, dict, list]:
    artifacts, unit_meta, missing, _ = _collect(trade_date, since_ns=since_ns, run_id=run_id)
    return artifacts, unit_meta, missing


def _invalid_chart_coverage(exc: Exception) -> dict:
    return {"status": "invalid_candidate_shape", "authorized_for_d1": False, "coverage": None,
            "error": f"{type(exc).__name__}: {exc}",
            "evidence_kind": "snapshot_records_only_not_tool_read_or_model_adoption"}


def chart_coverage(trade_date: str, unit_data: dict) -> dict:
    """Audit current candidate set, not snapshot existence; grants no D1 reads."""
    try:
        for unit in ("R2", "R5"):
            validate_candidate_shape(unit, unit_data.get(unit, {}))
    except (TypeError, ValueError, AttributeError) as exc:
        return _invalid_chart_coverage(exc)
    codes = set()
    for line in (unit_data.get("R2", {}).get("main_lines") or []) + (unit_data.get("R2", {}).get("secondary_lines") or []):
        for leader in line.get("leaders") or []:
            if isinstance(leader, dict) and isinstance(leader.get("ts_code"), str):
                codes.add(leader["ts_code"])
    codes.update(p["ts_code"] for p in unit_data.get("R5", {}).get("profiles", [])
                 if isinstance(p, dict) and isinstance(p.get("ts_code"), str))
    out = {"needed": sorted(codes), "covered": [], "missing": sorted(codes), "coverage": None,
           "status": "missing", "authorized_for_d1": False,
           "evidence_kind": "snapshot_records_only_not_tool_read_or_model_adoption"}
    for rel in (f"data/raw/{trade_date}/chart_vision_snapshot.json", "data/cache/chart_vision_latest.json"):
        try:
            fingerprint, blob = _snapshot(ROOT, ROOT / rel)
            snapshot = json.loads(blob)
            if not isinstance(snapshot, dict):
                raise ValueError("snapshot object required")
            out.update(snapshot=fingerprint, generated_at=snapshot.get("generated_at"), snapshot_date=snapshot.get("date"))
            if snapshot.get("date") != trade_date:
                out["status"] = "wrong_date"
                continue
            records = snapshot.get("results") or {}
            if not isinstance(records, dict):
                raise ValueError("snapshot results must be an object")
            covered = sorted(c for c in codes if isinstance(records.get(c), dict) and records[c]
                             and not records[c].get("error") and records[c].get("ts_code", c) == c)
            out.update(covered=covered, missing=sorted(codes - set(covered)),
                       coverage=len(covered) / len(codes) if codes else None,
                       status="complete" if codes and len(covered) == len(codes) else "partial" if codes else "not_applicable")
            break
        except (OSError, ValueError, TypeError) as exc:
            out.setdefault("errors", []).append(f"{rel}: {exc}")
    return out


def _digest(value: dict) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def consume_authorized_inputs(summary: dict, *, root: Path | None = None) -> dict:
    """Read exact current main inputs. Does not certify a D1/model read event.

    Used by shell preflight and isolated consumers. No auxiliary auto-discovery,
    model self-report ingestion, permission elevation or decision logging.
    """
    root = root or ROOT
    date = summary["trade_date"]
    _date(date)
    manifest = summary.get("input_manifest", {})
    if manifest.get("schema_version") != MANIFEST_VERSION:
        raise ValueError("versioned input manifest missing")
    if _digest({k: v for k, v in manifest.items() if k != "sha256"}) != manifest.get("sha256"):
        raise ValueError("input manifest digest mismatch")
    if manifest.get("run_id") != summary.get("run_id") or manifest.get("trade_date") != date:
        raise ValueError("input manifest identity mismatch")
    if manifest.get("authorized_main_inputs") != summary.get("artifacts"):
        raise ValueError("authorized main inputs differ from summary.artifacts")
    if manifest.get("summary_projection_sha256") != _digest({key: summary.get(key) for key in SUMMARY_PROJECTION}):
        raise ValueError("summary decision-input projection changed")
    run_id = summary.get("run_id") or ""
    state = read_object(root / f"data/health/research_pipeline_{date}.json") if run_id else {}
    payloads = {}
    for unit, rel in summary["artifacts"].items():
        if unit not in UNIT_FILES:
            raise ValueError("non-primary unit in authorized inputs")
        expected = {f"data/research/{date}/{UNIT_FILES[unit]}"}
        if unit == "R7":
            expected.add(f"data/research/{date}/R7_capital_flow_{date}.json")
        if rel not in expected:
            raise ValueError("unauthorized main input path")
        record = manifest["units"][unit]["json"]
        fingerprint, blob = _snapshot(root, root / rel)
        if any(record.get(key) != fingerprint[key] for key in ("path", *FINGERPRINT_FIELDS)):
            raise ValueError(f"{unit}: primary input version changed")
        if run_id:
            binding = _binding(root, state, unit, "json", fingerprint, run_id, date)
            if binding["status"] != "verified" or binding["attempt"] != record["receipt_binding"]["attempt"]:
                raise ValueError(f"{unit}: run/attempt receipt changed")
        payload = json.loads(blob)
        if str(payload.get("trade_date", "")).replace("-", "") != date:
            raise ValueError("primary input date mismatch")
        payloads[unit] = payload
    return payloads


def make_summary(trade_date: str, *, since_ns: int | None = None, run_id: str = "") -> tuple[dict, list]:
    artifacts, unit_meta, missing, unit_data = _collect(trade_date, since_ns=since_ns, run_id=run_id)
    try:
        manifest = load_fetch_manifest(trade_date)
        manifest_error = None
    except (OSError, ValueError, TypeError) as exc:
        manifest, manifest_error = {}, str(exc)
    summary = build_research_summary(trade_date, manifest, artifacts, unit_meta)
    usable = [m for m in unit_meta.values() if m["status"] in {"complete", "partial", "degraded", "skipped"}]
    missing_md = [u for u, m in unit_meta.items() if not m["input_evidence"]["md"]["delivered"]]
    summary["orchestrator_status"] = (
        "failed" if not usable else "complete" if all(m["status"] == "complete" for m in unit_meta.values()) and not missing_md else "partial"
    )
    summary["timeouts"] = missing
    summary["run_id"] = run_id or None
    summary["missing_md"] = missing_md
    if manifest_error:
        summary["fetch_global_severity"] = None
        summary["manifest_error"] = manifest_error
        if usable:
            summary["orchestrator_status"] = "partial"
    try:
        from src.research import contract_checks
        failures = {k: v for k, v in contract_checks.run_research_checks(unit_data, trade_date).items() if v}
        results = {}
        r2 = unit_data.get("R2", {})
        if (r2.get("main_lines") == [] and r2.get("empty_pool_reason") and
                "consensus_themes" in r2):
            failures.pop("R2", None)
            results["R2"] = {"status": "not_applicable", "reason": r2["empty_pool_reason"]}
        for unit in missing:
            failures.setdefault(unit, []).append(unit_meta[unit]["notes"])
        for unit in UNIT_FILES:
            if unit in results:
                continue
            status = unit_meta[unit]["status"]
            results[unit] = {"status": "failed" if unit in failures else "skipped" if status == "skipped" else "degraded" if status in {"partial", "degraded"} else "passed",
                             "research_status": status}
        summary["contract_results"] = results
        summary["contract_failures"] = failures
        summary["contract_checks_passed"] = not failures
        if failures and usable:
            summary["orchestrator_status"] = "partial"
    except Exception as exc:
        summary["contract_failures"] = {"_error": [f"{type(exc).__name__}: {exc}"]}
        summary["contract_checks_passed"] = False
        summary["orchestrator_status"] = "partial" if usable else "failed"
    # Preserve R6 vetoes even from degraded research. No veto is relaxed here.
    r6 = unit_data.get("R6", {})
    vetoes = list(r6.get("hard_rejects") or [])
    for item in r6.get("counter_arguments") or []:
        if isinstance(item, dict) and item.get("severity") == "hard_reject" and item not in vetoes:
            vetoes.append(item)
    summary["hard_rejects"] = vetoes
    try:
        for unit in ("R2", "R5"):
            error = unit_meta[unit]["input_evidence"]["json"].get("error", "")
            if "invalid candidate shape" in error:
                raise ValueError(error)
        chart = chart_coverage(trade_date, unit_data)
    except (TypeError, ValueError, AttributeError) as exc:
        # Coverage is an optional audit, never a reason to lose good research.
        chart = _invalid_chart_coverage(exc)
    inputs = {"schema_version": MANIFEST_VERSION, "trade_date": trade_date, "run_id": run_id or None,
              "summary_projection_sha256": _digest({key: summary.get(key) for key in SUMMARY_PROJECTION}),
              "authorized_main_inputs": dict(artifacts),
              "units": {u: m["input_evidence"] for u, m in unit_meta.items()},
              "auxiliary_candidates": auxiliary_input_manifest(trade_date),
              "chart_coverage": chart,
              "actual_tool_read": "not_independently_verified",
              "decision_adoption": "not_independently_verified"}
    inputs["sha256"] = _digest(inputs)
    summary["input_manifest"] = inputs
    summary["decision_source"] = "llm"
    summary["summary_builder"] = "scripts/research/build_research_summary.py (read-only primary artifacts)"
    return summary, missing


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--date", default=datetime.now().strftime("%Y%m%d"))
    parser.add_argument("--force", action="store_true", help="compatibility flag; inputs are always re-inspected")
    parser.add_argument("--since-ns", type=int)
    parser.add_argument("--run-id", default=os.environ.get("CHZL_RESEARCH_RUN_ID", ""))
    parser.add_argument("--verify-inputs", action="store_true", help="read-only preflight of the saved summary's authorized primary versions")
    args = parser.parse_args()
    path = ROOT / "data/research" / args.date / "research_summary.json"
    _date(args.date)
    if args.verify_inputs:
        fingerprint, blob = _snapshot(ROOT, path)
        saved = json.loads(blob)
        if saved.get("trade_date") != args.date or saved.get("run_id") != (args.run_id or None):
            raise ValueError("summary date/run mismatch")
        if args.run_id:
            state = read_object(ROOT / f"data/health/research_pipeline_{args.date}.json")
            if state.get("run_id") != args.run_id:
                raise ValueError("summary belongs to superseded run")
            attempt = state.get("stages", {}).get("summary", {}).get("attempt")
            checked = verify_binding(ROOT, path, state.get("contract_results", {}).get("summary", {}), args.run_id, attempt)
            if checked != fingerprint:
                raise ValueError("summary changed during preflight")
        consume_authorized_inputs(saved)
        print("research_summary: authorized primary versions verified; model consumption not independently verified")
        return 0 if saved.get("artifacts") else 1
    since_ns = args.since_ns
    if args.run_id and since_ns is None:
        state = read_object(ROOT / "data/health" / f"research_pipeline_{args.date}.json")
        since_ns = state["started_ns"]
    summary, missing = make_summary(args.date, since_ns=since_ns, run_id=args.run_id)
    atomic_json(path, summary)
    print(f"research_summary: status={summary['orchestrator_status']}, units={len(summary['artifacts'])}, missing={missing}, missing_md={summary['missing_md']}, contracts_passed={summary['contract_checks_passed']}")
    # Missing MD remains an explicit unit/business delivery failure. The summary
    # itself is still a usable partial handoff; do not erase its JSON research.
    return 1 if missing or "_error" in summary["contract_failures"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
