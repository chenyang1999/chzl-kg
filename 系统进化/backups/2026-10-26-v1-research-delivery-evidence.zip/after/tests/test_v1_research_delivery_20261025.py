"""A2 offline delivery regressions; run only from a guarded scratch snapshot."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys

import pytest

from scripts.research import pipeline_artifacts as a
from scripts.research import pipeline_state as s
from scripts.research import reconcile_pipeline_status as r

DATE = "20261022"
RUN = "delivery-current"
FIELDS = {
    "R1": {"style": "fixture", "position_cap_suggestion": 0},
    "R2": {"main_lines": [], "consensus_themes": [], "empty_pool_reason": "no eligible leaders"},
    "R3": {"resonance_top_themes": []}, "R4": {"top_events": []},
    "R5": {"profiles": [], "r2_expand_shortfall": 5},
    "R6": {"counter_arguments": [], "hard_rejects": []},
    "R7": {"main_force": {}, "northbound": {}, "staleness_status": "unavailable", "unavailable_reason": "fixture", "resolved_trade_date": "20261021"},
}


def payload(unit, **changes):
    return {"trade_date": DATE, "status": "complete", "confidence": 0, **FIELDS[unit], **changes}


def deliver(root, unit, *, md=True, **changes):
    path = root / "data/research" / DATE / a.UNIT_FILES[unit]
    a.atomic_json(path, payload(unit, **changes))
    if md:
        human = root / "chzl_kg/投研交易" / a.MD_DIRS[unit] / (DATE + ".md")
        human.parent.mkdir(parents=True, exist_ok=True)
        human.write_text("# synthetic research\n" + "fixture only\n" * 6)
    return path


@pytest.fixture
def env(tmp_path, monkeypatch):
    assert tmp_path.resolve().is_relative_to(Path.home() / ".hermes/cache/scratch")
    s.start(tmp_path, DATE, RUN, os.getpid(), "running")
    monkeypatch.setattr(r, "ROOT", tmp_path)
    return tmp_path


def begin(root, unit="R1", attempt=1):
    s.stage(root, DATE, RUN, unit, "running", attempt=attempt)


def state(root):
    return a.read_object(s.state_path(root, DATE))


@pytest.mark.parametrize("changes", [{"run_id": "old-run"}, {"attempt": 0}, {"attempt": 2}])
def test_declared_wrong_run_or_attempt_cannot_pass(env, changes):
    begin(env)
    deliver(env, "R1", **changes)
    assert not s.check(env, DATE, RUN, "R1")
    assert state(env)["contract_results"]["R1"]["json"]["passed"] is False


def test_check_is_bound_to_run_attempt_and_bytes(env):
    begin(env)
    path = deliver(env, "R1", run_id=RUN, attempt=1)
    assert s.check(env, DATE, RUN, "R1")
    record = state(env)["contract_results"]["R1"]["json"]
    assert record["run_id"] == RUN and record["attempt"] == 1
    assert record["bytes"] == path.stat().st_size and len(record["sha256"]) == 64
    assert record["mtime_ns"] == path.stat().st_mtime_ns


def test_previous_attempt_check_cannot_be_committed_during_new_attempt(env, monkeypatch):
    begin(env)
    deliver(env, "R1")
    original = s.md_artifact
    def replaced(*args, **kwargs):
        path = original(*args, **kwargs)
        begin(env, attempt=2)
        return path
    monkeypatch.setattr(s, "md_artifact", replaced)
    with pytest.raises(ValueError, match="attempt"):
        s.check(env, DATE, RUN, "R1")
    assert "R1" not in state(env)["contract_results"]


def test_since_marker_never_bypasses_current_attempt(env):
    marker = env / "marker"
    marker.write_text("old")
    os.utime(marker, ns=(1, 1))
    path = deliver(env, "R1")
    old = path.stat().st_mtime_ns
    begin(env)
    assert not s.check(env, DATE, RUN, "R1", marker)
    assert path.stat().st_mtime_ns == old


def _finishable(root):
    for unit in a.UNIT_FILES:
        begin(root, unit)
        deliver(root, unit)
        assert s.check(root, DATE, RUN, unit)
        s.stage(root, DATE, RUN, unit, "completed", attempt=1)
    begin(root, "D1")
    plan = {"trade_date": DATE, "schema_version": "1.0", "generated_at": "2026-10-22T08:00:00+08:00",
            "decision_source": "llm", "execution_pool": [], "watch_pool": [{"ts_code": "000001.SZ", "name": "fixture"}],
            "mode": "dry_run", "autonomous_trading_enabled": False, "requires_user_confirmation": True,
            "risk_limits": {"target_total_position_pct": 0}, "no_trade_conditions": []}
    a.atomic_json(root / "data/plans" / DATE / "watchlist_plan.json", plan)
    md = root / "chzl_kg/投研交易/盘前预案" / (DATE + ".md")
    md.parent.mkdir(parents=True, exist_ok=True)
    md.write_text("# fixture\n" + "fixture only\n" * 6)
    from trading import load_plan
    load_plan.DATA_DIR, load_plan.RUNTIME_DIR = root / "data", root / "data/runtime"
    assert s.check(root, DATE, RUN, "D1")
    s.stage(root, DATE, RUN, "D1", "completed", attempt=1)
    a.publish_runtime_plan(root, DATE)
    s.stage(root, DATE, RUN, "runtime_handoff", "completed")
    s.stage(root, DATE, RUN, "summary", "running")
    a.atomic_json(root / "data/research" / DATE / "research_summary.json", {
        "trade_date": DATE, "run_id": RUN, "orchestrator_status": "partial", "contract_checks_passed": True,
        "artifacts": {u: f"data/research/{DATE}/{f}" for u, f in a.UNIT_FILES.items()}, "contract_failures": {}})
    s.stage(root, DATE, RUN, "summary", "completed")


def test_positive_delivery_zero_budget_preserves_research_and_watch(env):
    _finishable(env)
    assert s.finish(env, DATE, RUN, 0)
    health = state(env)
    assert health["status"] == "completed" and health["missing_count"] == 0 and health["total_expected"] == 15
    assert len(health["contract_results"]) >= 10
    assert a.read_object(env / "data/runtime" / ("watchlist_plan_" + DATE + ".json"))["watch_pool"]
    assert a.read_object(env / "data/research" / DATE / "R1_style.json")["position_cap_suggestion"] == 0


@pytest.mark.parametrize("fault", ["hash", "old_attempt", "wrong_run_record", "missing_binding", "missing_md", "summary_replaced", "summary_wrong_path"])
def test_finish_requires_checked_current_attempt_version(env, fault):
    _finishable(env)
    path = env / "data/research" / DATE / "R1_style.json"
    if fault == "hash":
        before = path.stat()
        data = a.read_object(path)
        data["style"] = "changed"
        a.atomic_json(path, data)
        os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
    elif fault in {"old_attempt", "wrong_run_record", "missing_binding"}:
        with s.locked_state(env, DATE) as health:
            if fault == "old_attempt":
                health["stages"]["R1"]["attempt"] = 2
            elif fault == "wrong_run_record":
                health["contract_results"]["R1"]["json"]["run_id"] = "old-run"
            else:
                health["contract_results"]["R1"]["json"].pop("sha256", None)
    elif fault == "missing_md":
        (env / "chzl_kg/投研交易/风格研判" / (DATE + ".md")).unlink()
    else:
        summary = env / "data/research" / DATE / "research_summary.json"
        data = a.read_object(summary)
        data["artifacts"]["R1"] = "data/research/20261021/R1_style.json" if fault == "summary_wrong_path" else data["artifacts"]["R1"]
        data["generated_at"] = "changed"
        a.atomic_json(summary, data)
    assert not s.finish(env, DATE, RUN, 0)
    assert state(env)["status"] == "failed" and state(env)["error"]
    if fault == "hash":
        assert state(env)["contract_results"]["R1"]["json"]["passed"] is False


def test_json_survives_missing_md_and_reconcile_is_not_delivery_green(env):
    begin(env)
    path = deliver(env, "R1", md=False)
    assert not s.check(env, DATE, RUN, "R1")
    health = state(env)
    assert health["contract_results"]["R1"]["json"]["passed"] is True
    assert path.exists()
    observation = r.artifact_status(DATE)["R1_style"]
    assert observation["valid"] is True
    assert observation["delivery_complete"] is False
    assert observation["md"]["passed"] is False


@pytest.mark.parametrize("reason,leaders,expected", [("no eligible leaders", [], True), ("", [], False), ("no leaders", [{"ts_code": "000001.SZ"}], False)])
def test_r5_skip_requires_actual_empty_r2(env, reason, leaders, expected):
    begin(env, "R2")
    deliver(env, "R2", main_lines=[{"leaders": leaders}])
    assert s.check(env, DATE, RUN, "R2")
    s.stage(env, DATE, RUN, "R2", "completed", attempt=1)
    begin(env, "R5")
    deliver(env, "R5", status="skipped", reason=reason)
    assert s.check(env, DATE, RUN, "R5") is expected
    assert state(env)["contract_results"]["R5"]["json"]["passed"] is expected


@pytest.mark.parametrize("mode", ["valid", "traversal", "symlink", "conflicting", "absolute"])
def test_r7_alias_is_exact_same_day_inside_root(env, mode):
    begin(env, "R7")
    canonical = deliver(env, "R7")
    dated = canonical.with_name("R7_capital_flow_" + DATE + ".json")
    a.atomic_json(dated, payload("R7"))
    pointer = dated.name
    if mode == "traversal":
        pointer = "../" + DATE + "/" + dated.name
    elif mode == "symlink":
        outside = env / "outside.json"
        a.atomic_json(outside, payload("R7"))
        dated.unlink()
        dated.symlink_to(outside)
    elif mode == "absolute":
        pointer = str(dated)
    alias = {"trade_date": DATE, "alias_of": pointer}
    if mode == "conflicting":
        alias["target"] = "R7_capital_flow_20261021.json"
    a.atomic_json(canonical, alias)
    assert s.check(env, DATE, RUN, "R7") is (mode == "valid")


def test_old_run_cannot_cover_new_terminal(env):
    assert not s.finish(env, DATE, RUN, 17, "fixture failure")
    s.start(env, DATE, "new-run", os.getpid(), "running")
    assert not s.finish(env, DATE, "new-run", 19, "new failure")
    before = s.state_path(env, DATE).read_bytes()
    with pytest.raises(ValueError, match="superseded"):
        s.finish(env, DATE, RUN, 0)
    assert s.state_path(env, DATE).read_bytes() == before


@pytest.mark.parametrize("value,expected", [(0, 0.0), (None, None), (False, None), ("unknown", None)])
def test_confidence_zero_unknown_are_distinct(value, expected):
    assert a.confidence({"confidence": value}) == expected


@pytest.mark.parametrize("date", ["../20261022", "20261322", "202610220"])
def test_requested_path_escape_rejected(env, date):
    with pytest.raises(ValueError):
        a.research_artifact(env, date, "R1")


def test_new_attempt_invalidates_success_even_when_old_files_are_touched(env):
    begin(env)
    path = deliver(env, "R1")
    assert s.check(env, DATE, RUN, "R1")
    begin(env, attempt=2)
    os.utime(path, None)
    health = state(env)
    assert "R1" not in health["contract_results"]
    observation = r.artifact_status(DATE)["R1_style"]
    assert observation["delivery_complete"] is False


def test_terminal_reconciliation_does_not_rewrite_business_history(env, monkeypatch):
    _finishable(env)
    assert s.finish(env, DATE, RUN, 0)
    before = s.state_path(env, DATE).read_bytes()
    path = env / "data/research" / DATE / "R1_style.json"
    a.atomic_json(path, payload("R1", style="edited later"))
    def denied(*args, **kwargs):
        raise AssertionError("offline observation must not probe or patch reports")
    monkeypatch.setattr(r, "probe_hithink", denied)
    monkeypatch.setattr(r, "probe_margin", denied)
    monkeypatch.setattr(r, "patch_news_md", denied)
    monkeypatch.setattr(sys, "argv", ["reconcile", "--date", DATE, "--offline"])
    assert r.main() == 0
    observed = a.read_object(env / "data/health" / ("pipeline_reconciliation_" + DATE + ".json"))
    assert "R1_style" in observed["real_missing_artifacts"]
    assert observed["artifacts"]["R1_style"]["delivery_complete"] is False
    assert s.state_path(env, DATE).read_bytes() == before


def test_r5_skip_cannot_use_unbound_old_r2(env):
    deliver(env, "R2")
    begin(env, "R5")
    deliver(env, "R5", status="skipped", reason="no eligible leaders")
    assert not s.check(env, DATE, RUN, "R5")
    assert state(env)["contract_results"]["R5"]["json"]["passed"] is False


def test_summary_receipt_cannot_certify_a_later_rechecked_attempt(env):
    _finishable(env)
    begin(env, "R1", attempt=2)
    deliver(env, "R1", style="new current-attempt research")
    assert s.check(env, DATE, RUN, "R1")
    s.stage(env, DATE, RUN, "R1", "completed", attempt=2)
    assert not s.finish(env, DATE, RUN, 0)
    assert state(env)["contract_results"]["R1"]["json"]["passed"] is True
    assert state(env)["contract_results"]["summary"]["passed"] is False


def test_replacement_during_final_contract_inspection_cannot_leave_pass(env, monkeypatch):
    _finishable(env)
    original = s.runtime_contract
    def replaced(*args, **kwargs):
        original(*args, **kwargs)
        path = env / "chzl_kg/投研交易/风格研判" / (DATE + ".md")
        path.write_text("# changed after first finish validation\n" + "changed\n" * 6)
    monkeypatch.setattr(s, "runtime_contract", replaced)
    assert not s.finish(env, DATE, RUN, 0)
    assert state(env)["contract_results"]["R1"]["md"]["passed"] is False
    assert "R1:风格研判" in state(env)["missing_md"]


@pytest.mark.parametrize("value", [[], {"R1": []}, {"R1": None}])
def test_malformed_health_stages_remain_visible_not_green(env, value):
    deliver(env, "R1")
    with s.locked_state(env, DATE) as health:
        health["stages"] = value
    observed = r.artifact_status(DATE)["R1_style"]
    assert observed["valid"] is True and observed["delivery_complete"] is False


@pytest.mark.parametrize("mode", ["valid", "wrong_day", "escape", "absolute", "traversal", "noncanonical", "chain", "directory", "wrong_content_date", "skeleton", "wrong_attempt", "stale_target"])
def test_r7_canonical_symlink_checks_exact_dated_primary(env, mode):
    begin(env, "R7")
    canonical = deliver(env, "R7")
    dated = canonical.with_name(f"R7_capital_flow_{DATE}.json")
    a.atomic_json(dated, payload("R7", run_id=RUN, attempt=1))
    canonical.unlink()
    target = dated.name
    if mode == "wrong_day":
        target = "R7_capital_flow_20261021.json"
        a.atomic_json(dated.with_name(target), payload("R7"))
    elif mode == "escape":
        outside = env / "outside.json"
        a.atomic_json(outside, payload("R7"))
        target = "../../../outside.json"
    elif mode == "absolute":
        target = str(dated)
    elif mode == "traversal":
        target = "../" + DATE + "/" + dated.name
    elif mode == "noncanonical":
        target = "./" + dated.name
    elif mode == "chain":
        other = dated.with_name("other.json")
        a.atomic_json(other, payload("R7"))
        dated.unlink()
        dated.symlink_to(other.name)
    elif mode == "directory":
        dated.unlink()
        dated.mkdir()
    elif mode == "wrong_content_date":
        a.atomic_json(dated, payload("R7", trade_date="20261021"))
    elif mode == "skeleton":
        a.atomic_json(dated, {"trade_date": DATE, "status": "complete"})
    elif mode == "wrong_attempt":
        a.atomic_json(dated, payload("R7", run_id=RUN, attempt=2))
    elif mode == "stale_target":
        os.utime(dated, ns=(1, 1))
    canonical.symlink_to(target)
    # The generic resolver must stay closed even for the approved R7 alias.
    with pytest.raises(ValueError, match="symlink"):
        a.safe_artifact_path(env, canonical)
    assert s.check(env, DATE, RUN, "R7") is (mode == "valid")
    if mode == "valid":
        resolved, data = a.research_artifact(env, DATE, "R7")
        assert resolved == dated and data["main_force"] == {}
        receipt = state(env)["contract_results"]["R7"]["json"]
        assert receipt["path"] == str(dated.relative_to(env))
        assert receipt == {**receipt, **a.file_version(env, dated)}
        assert a.verified_delivery(env, DATE, "R7", "json", state(env))[0] == dated
    else:
        assert state(env)["contract_results"]["R7"]["json"]["passed"] is False


@pytest.mark.parametrize("unit", ["R1", "R2", "R3", "R4", "R5", "R6"])
def test_non_r7_canonical_symlinks_stay_rejected(env, unit):
    begin(env, unit)
    canonical = deliver(env, unit)
    target = canonical.with_name(canonical.stem + "_" + DATE + ".json")
    a.atomic_json(target, payload(unit))
    canonical.unlink()
    canonical.symlink_to(target.name)
    assert not s.check(env, DATE, RUN, unit)
    assert state(env)["contract_results"][unit]["json"]["passed"] is False


@pytest.mark.parametrize("unit,changes", [
    ("R2", {"main_lines": "synthetic-wrong-shape"}),
    ("R2", {"main_lines": {}}), ("R2", {"main_lines": ["bad-line"]}),
    ("R2", {"secondary_lines": None}), ("R2", {"secondary_lines": "bad"}),
    ("R2", {"main_lines": [{"leaders": "bad"}]}),
    ("R2", {"main_lines": [{"leaders": ["bad-leader"]}]}),
    ("R2", {"secondary_lines": [{"leaders": [{"ts_code": []}]}]}),
    ("R5", {"profiles": "bad"}), ("R5", {"profiles": {}}),
    ("R5", {"profiles": ["bad-profile"]}), ("R5", {"profiles": [{"ts_code": []}]}),
])
def test_invalid_candidate_shapes_never_get_successful_receipts(env, unit, changes):
    begin(env, unit)
    deliver(env, unit, **changes)
    assert not s.check(env, DATE, RUN, unit)
    record = state(env)["contract_results"][unit]["json"]
    assert record["passed"] is False and "invalid candidate shape" in record["error"]


@pytest.mark.parametrize("unit,changes", [
    ("R2", {"main_lines": [], "secondary_lines": []}),
    ("R2", {"main_lines": [{"leaders": []}, {}], "secondary_lines": [{"leaders": [{}]}]}),
    ("R5", {"profiles": []}), ("R5", {"profiles": [{}, {"ts_code": "000001.SZ"}]}),
])
def test_candidate_shape_validation_adds_no_nonempty_or_trading_threshold(env, unit, changes):
    begin(env, unit)
    deliver(env, unit, **changes)
    assert s.check(env, DATE, RUN, unit)

