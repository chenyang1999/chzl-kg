"""Legacy reader binding regressions; synthetic scratch fixtures, -B/plugins off.

The real state/manifest consumer, algorithm, renderer, fallback hook and CLI run
unchanged. Only broker/quote boundaries and unused legacy research imports are
isolated. The F4 runner installs read/write/network/DB/process guards before
collection; no production data, configuration or account is read.
"""
from __future__ import annotations

import ast
import importlib
import json
import os
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace

import pytest

REPO = Path(__file__).resolve().parents[1]
SCRATCH = Path('/Users/chenyang/.hermes/cache/scratch')
DATE = '20261025'
RUN = 'F4-synthetic-run'
SOURCE_FILES = (
    'scripts/research/pipeline_artifacts.py', 'scripts/research/pipeline_state.py',
    'scripts/research/build_research_summary.py', 'src/research/orchestrator.py',
    'src/research/contract_checks.py', 'src/research/stock_character.py',
    'src/plan/main_decision.py', 'src/plan/d1_algorithm.py', 'src/plan/render_markdown.py',
    'src/execute/fallback.py', 'scripts/plan/run_main_decision.py',
)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')


@pytest.fixture(scope='module')
def modules(tmp_path_factory):
    root = tmp_path_factory.mktemp('f4-code')
    assert root.resolve().is_relative_to(SCRATCH)
    for rel in SOURCE_FILES:
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((REPO / rel).read_bytes())
    saved = {k: v for k, v in sys.modules.items() if k.split('.')[0] in {'src', 'scripts'}}
    for k in saved:
        del sys.modules[k]
    original_path = sys.path[:]
    sys.path.insert(0, str(root))
    def package(name, rel):
        m = ModuleType(name)
        m.__path__ = [str(root / rel)]
        sys.modules[name] = m
    for name, rel in [('scripts', 'scripts'), ('scripts.research', 'scripts/research'),
                      ('scripts.plan', 'scripts/plan'), ('src', 'src'),
                      ('src.research', 'src/research'), ('src.plan', 'src/plan'),
                      ('src.execute', 'src/execute'), ('src.collectors', 'src/collectors')]:
        package(name, rel)
    # Exact helper AST closure: do not import unused legacy builders/settings.
    p = root / 'src/research/orchestrator.py'
    names = {'_now_iso', '_rel', 'load_fetch_manifest', '_read_r6_hard_rejects', 'build_research_summary'}
    nodes = []
    for n in ast.parse(p.read_text(), filename=str(p)).body:
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            if not (isinstance(n, ast.ImportFrom) and n.module == 'src.research'):
                nodes.append(n)
        elif isinstance(n, (ast.Assign, ast.AnnAssign)) or isinstance(n, ast.FunctionDef) and n.name in names:
            nodes.append(n)
    o = ModuleType('src.research.orchestrator')
    o.__file__ = str(p)
    sys.modules[o.__name__] = o
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(p), 'exec'), o.__dict__)
    q = ModuleType('src.plan.qmt_holdings')
    q.fetch_holdings_map = lambda: {}
    q.holdings_qty = lambda holdings, code: 0
    sys.modules[q.__name__] = q
    xt = ModuleType('src.collectors.xtick_collector')
    xt.XTickCollector = lambda: SimpleNamespace(latest_close=lambda code: None)
    sys.modules[xt.__name__] = xt
    try:
        yield SimpleNamespace(
            a=importlib.import_module('scripts.research.pipeline_artifacts'),
            s=importlib.import_module('scripts.research.pipeline_state'),
            b=importlib.import_module('scripts.research.build_research_summary'), o=o,
            algorithm=importlib.import_module('src.plan.d1_algorithm'),
            main=importlib.import_module('src.plan.main_decision'),
            hook=importlib.import_module('src.execute.fallback'),
            cli=importlib.import_module('scripts.plan.run_main_decision'))
    finally:
        sys.path[:] = original_path
        for k in list(sys.modules):
            if k.split('.')[0] in {'src', 'scripts'}:
                del sys.modules[k]
        sys.modules.update(saved)


@pytest.fixture
def env(modules, tmp_path, monkeypatch):
    assert tmp_path.resolve().is_relative_to(SCRATCH)
    for m in (modules.b, modules.s, modules.o, modules.algorithm, modules.main):
        monkeypatch.setattr(m, 'ROOT', tmp_path)
    fields = {
        'R1': {'style': 'synthetic', 'position_cap_suggestion': 0.0},
        'R2': {'main_lines': [{'name': 'synthetic', 'leaders': [
            {'ts_code': '000001.SZ'}, {'ts_code': '000002.SZ'}],
            'cross_validation': {'r3_resonance_match': False, 'r4_catalyst_match': False,
                                 'r7_capital_match': False, 'cross_validation_score': 0}}], 'consensus_themes': []},
        'R3': {'resonance_top_themes': []}, 'R4': {'top_events': []},
        'R5': {'profiles': [{'ts_code': '000001.SZ'}], 'r2_expand_shortfall': 4},
        'R6': {'counter_arguments': [{'ts_code': '000002.SZ', 'severity': 'hard_reject', 'reason': 'synthetic veto'}],
               'hard_rejects': [{'ts_code': '000001.SZ', 'severity': 'hard_reject'}]},
        'R7': {'main_force': {}, 'northbound': {}, 'staleness_status': 'ok', 'resolved_trade_date': '20261023'},
    }
    modules.s.start(tmp_path, DATE, RUN, os.getpid(), 'running')
    paths = {}
    for unit, filename in modules.a.UNIT_FILES.items():
        modules.s.stage(tmp_path, DATE, RUN, unit, 'running', attempt=1)
        p = tmp_path / f'data/research/{DATE}/{filename}'
        write(p, {'trade_date': DATE, 'status': 'complete', 'confidence': 0 if unit == 'R1' else None, **fields[unit]})
        md = tmp_path / f'chzl_kg/投研交易/{modules.a.MD_DIRS[unit]}/{DATE}.md'
        md.parent.mkdir(parents=True, exist_ok=True)
        md.write_text('# synthetic\n' + 'current attempt\n' * 6)
        assert modules.s.check(tmp_path, DATE, RUN, unit)
        modules.s.stage(tmp_path, DATE, RUN, unit, 'completed', attempt=1)
        paths[unit] = p
    write(tmp_path / f'data/raw/{DATE}/manifest.json', {'date': DATE, 'global_severity': 0, 'sources': {}})
    summary, missing = modules.b.make_summary(DATE, run_id=RUN)
    assert not missing
    path = tmp_path / f'data/research/{DATE}/research_summary.json'
    write(path, summary)
    return SimpleNamespace(**vars(modules), root=tmp_path, paths=paths, summary=summary, summary_path=path)


def invoke(env, entry, monkeypatch):
    if entry == 'loader':
        return env.main.load_research_summary(DATE)
    if entry == 'minimal':
        return env.main._minimal_summary(DATE)
    if entry == 'run':
        return env.main.run_main_decision(DATE, fallback=True)
    if entry == 'hook':
        return env.hook.run_plan_fallback(DATE)
    monkeypatch.setattr(sys, 'argv', ['run_main_decision.py', '--date', DATE, '--fallback'])
    return env.cli.main()


def assert_no_plan(env):
    assert not (env.root / 'data/plans').exists()
    assert not (env.root / 'chzl_kg/投研交易/盘前预案').exists()


def test_valid_new_summary_uses_shared_consumer_and_preserves_projection(env, monkeypatch):
    calls = []
    original = env.b.consume_authorized_inputs
    def tracked(summary, *, root=None):
        calls.append(root)
        return original(summary, root=root)
    monkeypatch.setattr(env.b, 'consume_authorized_inputs', tracked)
    assert env.main.load_research_summary(DATE) == env.summary
    assert env.main._minimal_summary(DATE) == env.summary
    assert calls == [env.root, env.root]
    assert len(env.summary['hard_rejects']) == 2
    assert env.summary['confidence']['R1'] == 0
    assert env.summary['confidence']['R2'] is None
    assert all(not x['authorized'] for x in env.summary['input_manifest']['auxiliary_candidates'].values())


def test_real_fallback_zero_budget_retains_observation_json_and_md(env):
    plan = env.hook.run_plan_fallback(DATE)
    assert plan['risk_limits']['target_total_position_pct'] == 0
    assert plan['execution_pool'] == [] and not plan['autonomous_trading_enabled']
    assert plan['requires_user_confirmation'] is True
    assert plan['mode'] == 'fallback' and plan['decision_source'] == 'python_fallback'
    assert {p['ts_code'] for p in plan['watch_pool']} == {'000001.SZ', '000002.SZ'}
    assert all(not p['auto_trade_enabled'] and p['entry_rules'] == [] for p in plan['watch_pool'])
    saved = env.a.read_object(env.root / f'data/plans/{DATE}/watchlist_plan.json')
    assert saved['risk_limits']['target_total_position_pct'] == 0
    assert saved['watch_pool'] == plan['watch_pool']
    assert saved['meta']['r6_devil_advocate']['hard_rejects_applied']
    local = (env.root / f'data/plans/{DATE}/watchlist_plan.md').read_text()
    assert local == (env.root / f'chzl_kg/投研交易/盘前预案/{DATE}.md').read_text()
    assert 'mode: fallback' in local and 'decision_source: python_fallback' in local


@pytest.mark.parametrize('entry', ['loader', 'minimal', 'run', 'hook', 'cli'])
@pytest.mark.parametrize('fault', ['replacement', 'wrong_run', 'attempt', 'missing_receipt', 'missing_state', 'missing_input'])
def test_existing_rejected_summary_never_rediscovered(env, monkeypatch, entry, fault):
    state_path = env.s.state_path(env.root, DATE)
    state = env.a.read_object(state_path)
    if fault == 'replacement':
        write(env.paths['R2'], {**env.a.read_object(env.paths['R2']), 'notes': 'changed after summary'})
    elif fault == 'missing_input':
        env.paths['R2'].unlink()
    elif fault == 'missing_state':
        state_path.unlink()
    else:
        if fault == 'wrong_run':
            state['run_id'] = 'later-run'
        elif fault == 'attempt':
            state['stages']['R2']['attempt'] = 2
        else:
            state['contract_results'].pop('R2')
        write(state_path, state)
    if entry == 'cli':
        assert invoke(env, entry, monkeypatch) == 1
    else:
        with pytest.raises((ValueError, FileNotFoundError)):
            invoke(env, entry, monkeypatch)
    assert_no_plan(env)


@pytest.mark.parametrize('fault', ['null_manifest', 'unknown_manifest', 'malformed_json', 'wrong_date', 'legacy_invalid', 'broken_link', 'directory'])
@pytest.mark.parametrize('entry', ['minimal', 'hook'])
def test_present_invalid_is_not_missing(env, monkeypatch, fault, entry):
    summary = dict(env.summary)
    if fault == 'null_manifest':
        summary['input_manifest'] = None
    elif fault == 'unknown_manifest':
        summary['input_manifest'] = {'schema_version': 'not_supported'}
    elif fault == 'wrong_date':
        summary['trade_date'] = '20261024'
    elif fault == 'legacy_invalid':
        summary.pop('input_manifest')
        summary.pop('confidence')
    if fault == 'malformed_json':
        env.summary_path.write_text('{')
    elif fault in {'broken_link', 'directory'}:
        env.summary_path.unlink()
        if fault == 'broken_link':
            env.summary_path.symlink_to('absent-summary.json')
        else:
            env.summary_path.mkdir()
    else:
        write(env.summary_path, summary)
    with pytest.raises((ValueError, OSError)):
        invoke(env, entry, monkeypatch)
    assert_no_plan(env)


def test_genuinely_missing_summary_retains_legal_fallback(env):
    env.summary_path.unlink()
    with pytest.raises(FileNotFoundError):
        env.main.run_main_decision(DATE, fallback=False)
    summary = env.main._minimal_summary(DATE)
    assert summary['orchestrator_status'] == 'degraded'
    assert set(summary['artifacts']) == set(env.a.UNIT_FILES)
    plan = env.hook.run_plan_fallback(DATE)
    assert plan['execution_pool'] == []
    assert plan['risk_limits']['target_total_position_pct'] == 0
    assert len(plan['watch_pool']) == 2 and not plan['autonomous_trading_enabled']


def test_absent_manifest_legacy_format_remains_compatible(env):
    legacy = dict(env.summary)
    legacy.pop('input_manifest')
    write(env.summary_path, legacy)
    assert env.main.load_research_summary(DATE) == legacy
    assert env.main._minimal_summary(DATE) == legacy
    plan = env.hook.run_plan_fallback(DATE)
    assert plan['risk_limits']['target_total_position_pct'] == 0
    assert len(plan['watch_pool']) == 2


@pytest.mark.parametrize('alias', ['symlink', 'pointer', 'absent'])
def test_r7_legal_same_day_dated_alias_survives_real_loader_and_fallback(env, alias):
    env.s.stage(env.root, DATE, RUN, 'R7', 'running', attempt=2)
    canonical = env.paths['R7']
    dated = canonical.with_name(f'R7_capital_flow_{DATE}.json')
    write(dated, {**env.a.read_object(canonical), 'run_id': RUN, 'attempt': 2})
    canonical.unlink()
    if alias == 'symlink':
        canonical.symlink_to(dated.name)
    elif alias == 'pointer':
        write(canonical, {'trade_date': DATE, 'alias_of': dated.name})
    human = env.root / f'chzl_kg/投研交易/资金面/{DATE}.md'
    human.write_text('# synthetic R7\n' + 'refreshed attempt\n' * 6)
    assert env.s.check(env.root, DATE, RUN, 'R7')
    env.s.stage(env.root, DATE, RUN, 'R7', 'completed', attempt=2)
    summary, missing = env.b.make_summary(DATE, run_id=RUN)
    assert not missing
    write(env.summary_path, summary)
    loaded = env.main.load_research_summary(DATE)
    assert loaded['artifacts']['R7'] == str(dated.relative_to(env.root))
    assert env.main._minimal_summary(DATE) == loaded
    assert env.b.consume_authorized_inputs(loaded, root=env.root)['R7']['attempt'] == 2
    plan = env.hook.run_plan_fallback(DATE)
    assert plan['risk_limits']['target_total_position_pct'] == 0
    assert len(plan['watch_pool']) == 2 and not plan['execution_pool']
