"""B2 handoff regressions. Run with -B, fixed collection, scratch basetemp.

No model/market/broker call. Native producer files, real state/check/summary and
exact-input consumer run against synthetic fixtures. Self-reported model reads
are intentionally not evidence. No auxiliary permission is activated.
"""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace

import pytest

REPO = Path(__file__).resolve().parents[1]
DATE = "20261025"
RUN = "b2-synthetic-run"
SCRATCH = Path.home() / ".hermes/cache/scratch"


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


@pytest.fixture(scope="module")
def modules(tmp_path_factory):
    root = tmp_path_factory.mktemp("b2-code")
    assert root.resolve().is_relative_to(SCRATCH)
    # Reviewed import closure only; never copy whole source/credential trees.
    source_files = (
        "src/__init__.py", "src/settings.py", "src/execute/amygdala.py",
        "src/plan/buy_eligibility.py", "src/plan/d1_algorithm.py", "src/plan/main_decision.py",
        "src/plan/qmt_holdings.py", "src/plan/render_markdown.py",
        "src/research/__init__.py", "src/research/contract_checks.py", "src/research/data_sources.py",
        "src/research/orchestrator.py", "src/research/r1_style.py", "src/research/r2_main_sectors.py",
        "src/research/r3_sentiment.py", "src/research/r4_news.py", "src/research/r5_stock_profiles.py",
        "src/research/r6_devil_advocate.py", "src/research/r7_capital_flow.py", "src/research/stock_character.py",
        "src/trading_agent/journal.py", "src/trading_agent/models.py", "src/trading_agent/qmt_client.py",
        "trading/account_config.py", "trading/execution_authorization.py", "trading/load_plan.py",
        "trading/order/qmt_context.py", "trading/positions_state.py", "trading/schema/normalize.py",
        "trading/schema/watchlist_plan.py", "trading/watcher/dispatch.py",
        "trading/executors/__init__.py", "trading/executors/_buy_common.py", "trading/executors/_sell_common.py",
        "trading/executors/base.py", "trading/executors/registry.py",
        "trading/executors/execute_daban_confirm.py", "trading/executors/execute_exit_at_open.py",
        "trading/executors/execute_exit_if_no_new_high.py", "trading/executors/execute_intraday_break_exit.py",
        "trading/executors/execute_leader_breakout.py", "trading/executors/execute_low_absorption_intraday.py",
        "trading/executors/execute_sector_switch_exit.py", "trading/executors/execute_stop_loss_break.py",
        "trading/executors/execute_t_add_pullback.py", "trading/executors/execute_t_reduce_resistance.py",
        "trading/executors/execute_take_profit_hit.py", "trading/executors/execute_trend_pullback_buy.py",
        "trading/executors/execute_volume_price_divergence.py",
    )
    for rel in source_files:
        q = root / rel
        q.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO / rel, q)
    for name in ("pipeline_artifacts.py", "pipeline_state.py", "build_research_summary.py"):
        q = root / "scripts/research" / name
        q.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO / "scripts/research" / name, q)
    for name in ("scripts", "scripts/research"):
        (root / name / "__init__.py").write_text("")
    saved = {k: v for k, v in sys.modules.items() if k.split(".")[0] in {"src", "trading", "scripts"}}
    for k in saved:
        del sys.modules[k]
    sys.path.insert(0, str(root))
    try:
        yield SimpleNamespace(
            b=importlib.import_module("scripts.research.build_research_summary"),
            a=importlib.import_module("scripts.research.pipeline_artifacts"),
            s=importlib.import_module("scripts.research.pipeline_state"),
            o=importlib.import_module("src.research.orchestrator"))
    finally:
        sys.path.remove(str(root))
        for k in list(sys.modules):
            if k.split(".")[0] in {"src", "trading", "scripts"}:
                del sys.modules[k]
        sys.modules.update(saved)


@pytest.fixture
def env(modules, tmp_path, monkeypatch):
    assert tmp_path.resolve().is_relative_to(SCRATCH)
    for m in (modules.b, modules.o, modules.s):
        monkeypatch.setattr(m, "ROOT", tmp_path)
    fields = {
        "R1": {"style": "synthetic", "position_cap_suggestion": 0.0},
        "R2": {"main_lines": [{"name": "synthetic", "leaders": [{"ts_code": "000001.SZ"}, {"ts_code": "000002.SZ"}],
                                "cross_validation": {"r3_resonance_match": False, "r4_catalyst_match": False,
                                                     "r7_capital_match": False, "cross_validation_score": 0}}], "consensus_themes": []},
        "R3": {"resonance_top_themes": []}, "R4": {"top_events": []},
        "R5": {"profiles": [{"ts_code": "000001.SZ"}], "r2_expand_shortfall": 4},
        "R6": {"counter_arguments": [{"ts_code": "000002.SZ", "severity": "hard_reject", "reason": "synthetic veto"}],
               "hard_rejects": [{"ts_code": "000001.SZ", "severity": "hard_reject"}]},
        "R7": {"main_force": {}, "northbound": {}, "staleness_status": "ok", "resolved_trade_date": "20261023"},
    }
    modules.s.start(tmp_path, DATE, RUN, os.getpid(), "running")
    paths = {}
    for unit, filename in modules.a.UNIT_FILES.items():
        modules.s.stage(tmp_path, DATE, RUN, unit, "running", attempt=1)
        path = tmp_path / f"data/research/{DATE}/{filename}"
        write(path, {"trade_date": DATE, "status": "degraded" if unit == "R6" else "complete",
                     "confidence": 0 if unit == "R1" else None,
                     "generated_at": "2026-10-25T07:40:00+08:00", **fields[unit]})
        md = tmp_path / f"chzl_kg/投研交易/{modules.a.MD_DIRS[unit]}/{DATE}.md"
        md.parent.mkdir(parents=True, exist_ok=True)
        md.write_text("---\ndate: 2026-10-25\n---\n# synthetic\ntext\ntext\n")
        modules.s.check(tmp_path, DATE, RUN, unit)
        modules.s.stage(tmp_path, DATE, RUN, unit, "completed", attempt=1)
        paths[unit] = path
    write(tmp_path / f"data/raw/{DATE}/manifest.json", {"date": DATE, "global_severity": 0, "sources": {}})
    return SimpleNamespace(**vars(modules), root=tmp_path, paths=paths)


def build(env, run_id=RUN):
    return env.b.make_summary(DATE, run_id=run_id)


def test_native_receipts_to_summary_to_authorized_input_consumer(env):
    summary, missing = build(env)
    assert not missing, "Native A2 check must provide version-bound receipts: " + repr(missing)
    assert set(summary["artifacts"]) == set(env.a.UNIT_FILES)
    consumed = env.b.consume_authorized_inputs(json.loads(json.dumps(summary)))
    assert consumed["R1"]["position_cap_suggestion"] == 0.0
    assert summary["confidence"]["R1"] == 0.0 and summary["confidence"]["R2"] is None
    assert summary["input_manifest"]["units"]["R1"]["json"]["receipt_binding"]["status"] == "verified"
    assert {v["ts_code"] for v in summary["hard_rejects"]} == {"000001.SZ", "000002.SZ"}
    assert summary["input_manifest"]["actual_tool_read"] == "not_independently_verified"


def test_standalone_main_inputs_are_real_reads_not_model_read_evidence(env):
    summary, missing = build(env, "")
    assert not missing
    assert env.b.consume_authorized_inputs(summary)["R2"]["main_lines"][0]["leaders"]
    item = summary["input_manifest"]["units"]["R1"]
    assert item["json"]["receipt_binding"]["status"] == "not_run_bound"
    assert item["actual_tool_read"] == item["decision_adoption"] == "not_independently_verified"


@pytest.mark.parametrize("fault", ["missing", "wrong_date", "replaced_hash", "wrong_run", "new_attempt", "unversioned_receipt"])
def test_bad_primary_versions_cannot_enter_authorized_handoff(env, fault):
    state_path = env.s.state_path(env.root, DATE)
    if fault == "missing":
        env.paths["R2"].unlink()
    elif fault in {"wrong_date", "replaced_hash"}:
        p = env.paths["R2"]
        payload = env.a.read_object(p)
        payload["trade_date" if fault == "wrong_date" else "notes"] = "20261024" if fault == "wrong_date" else "replacement"
        write(p, payload)
    else:
        state = env.a.read_object(state_path)
        if fault == "wrong_run":
            state["run_id"] = "other-run"
        elif fault == "new_attempt":
            state["stages"]["R2"]["attempt"] = 2
        else:
            state["contract_results"]["R2"]["json"].pop("sha256")
        write(state_path, state)
    summary, missing = build(env)
    assert "R2" in missing and "R2" not in summary["artifacts"]
    assert summary["input_manifest"]["units"]["R2"]["json"]["usable"] is False


def test_missing_md_preserves_json_and_explicit_delivery_gap(env):
    (env.root / f"chzl_kg/投研交易/主线研判/{DATE}.md").unlink()
    summary, missing = build(env)
    assert "R2" not in missing and "R2" in summary["artifacts"]
    assert "R2" in summary["missing_md"] and summary["orchestrator_status"] == "partial"
    assert summary["input_manifest"]["units"]["R2"]["md"]["delivered"] is False
    assert "R2" in env.b.consume_authorized_inputs(summary)


@pytest.mark.parametrize("kind", ["replacement", "retry", "run", "mapping", "digest", "veto_projection"])
def test_saved_summary_consumer_detects_changed_version_or_identity(env, kind):
    summary, _ = build(env)
    if kind == "replacement":
        p = env.paths["R1"]
        write(p, {**env.a.read_object(p), "new": True})
    elif kind in {"retry", "run"}:
        state = env.a.read_object(env.s.state_path(env.root, DATE))
        if kind == "retry":
            state["stages"]["R1"]["attempt"] = 2
        else:
            state["run_id"] = "next-run"
        write(env.s.state_path(env.root, DATE), state)
    elif kind == "mapping":
        summary["artifacts"]["R1"] = "data/research/20261024/R1_style.json"
    elif kind == "veto_projection":
        summary["hard_rejects"] = []
    else:
        summary["input_manifest"]["sha256"] = "0" * 64
    with pytest.raises(ValueError):
        env.b.consume_authorized_inputs(summary)


def test_forged_model_read_and_adoption_claims_never_become_evidence(env):
    p = env.paths["R5"]
    write(p, {**env.a.read_object(p), "read_files": ["data/corrections/private.md"],
              "actual_tool_read": True, "corrections_applied": [{"case_id": "invented", "adopted": True}]})
    summary, _ = build(env, "")
    evidence = summary["input_manifest"]["units"]["R5"]
    assert evidence["actual_tool_read"] == evidence["decision_adoption"] == "not_independently_verified"
    assert all(not item["authorized"] and item["status"] == "pending_approval"
               for item in summary["input_manifest"]["auxiliary_candidates"].values())
    assert set(env.b.consume_authorized_inputs(summary)) == set(env.a.UNIT_FILES)


@pytest.mark.parametrize("snapshot_date,expected", [(DATE, ["000002.SZ"]), ("20261024", ["000001.SZ", "000002.SZ"])])
def test_chart_coverage_uses_current_candidate_set_not_file_presence(env, snapshot_date, expected):
    write(env.root / f"data/raw/{DATE}/chart_vision_snapshot.json",
          {"date": snapshot_date, "generated_at": "declared time", "results": {
              "000001.SZ": {"ts_code": "000001.SZ", "trend": "synthetic"},
              "000099.SZ": {"ts_code": "000099.SZ", "trend": "unrelated"}}})
    summary, _ = build(env, "")
    chart = summary["input_manifest"]["chart_coverage"]
    assert chart["needed"] == ["000001.SZ", "000002.SZ"]
    assert chart["missing"] == expected
    assert chart["authorized_for_d1"] is False


def test_zero_budget_keeps_observation_inputs_and_r6_vetoes(env):
    summary, _ = build(env, "")
    consumed = env.b.consume_authorized_inputs(summary)
    assert consumed["R1"]["position_cap_suggestion"] == 0
    assert [x["ts_code"] for x in consumed["R2"]["main_lines"][0]["leaders"]] == ["000001.SZ", "000002.SZ"]
    assert len(summary["hard_rejects"]) == 2
    assert "execution_pool" not in summary  # summary is not execution permission


def test_legal_r5_skip_is_retained_not_skeleton(env):
    write(env.paths["R2"], {"trade_date": DATE, "status": "degraded", "main_lines": [],
                           "consensus_themes": [], "empty_pool_reason": "no eligible leaders"})
    write(env.paths["R5"], {"trade_date": DATE, "status": "skipped", "profiles": [],
                           "skip_reason": "R2 no eligible leaders", "r2_expand_shortfall": 5})
    summary, missing = build(env, "")
    assert not missing and summary["units"]["R5"]["status"] == "skipped"
    assert summary["contract_results"]["R5"]["status"] == "skipped"


def test_auxiliary_adapter_is_exact_opt_in_and_default_does_not_read(env, monkeypatch):
    rel = "data/rules/theme_anchors/latest.json"
    write(env.root / rel, {"theme": "synthetic"})
    original = env.b._snapshot
    reads = []
    def tracked(root, path):
        reads.append(str(path.relative_to(root)))
        return original(root, path)
    monkeypatch.setattr(env.b, "_snapshot", tracked)
    default = env.b.auxiliary_input_manifest(DATE)
    assert reads == [] and default["theme_anchors"]["status"] == "pending_approval"
    explicit = env.b.auxiliary_input_manifest(DATE, approved_paths={"theme_anchors": [rel]})
    assert reads == [rel] and explicit["theme_anchors"]["inputs"][0]["sha256"]
    with pytest.raises(ValueError):
        env.b.auxiliary_input_manifest(DATE, approved_paths={"theme_anchors": ["../.env"]})
    assert not default["theme_anchors"]["authorized"]


def test_native_cli_saved_summary_preflight_and_replacement_rejection(env, monkeypatch):
    env.s.stage(env.root, DATE, RUN, "summary", "running")
    monkeypatch.setattr(sys, "argv", ["build_research_summary.py", "--date", DATE, "--run-id", RUN])
    assert env.b.main() == 0
    env.s.stage(env.root, DATE, RUN, "summary", "completed")
    monkeypatch.setattr(sys, "argv", ["build_research_summary.py", "--date", DATE, "--run-id", RUN, "--verify-inputs"])
    assert env.b.main() == 0
    p = env.paths["R1"]
    write(p, {**env.a.read_object(p), "replacement": True})
    with pytest.raises(ValueError):
        env.b.main()


def test_real_rule_comparison_consumer_keeps_zero_budget_observation(env, monkeypatch):
    # This is the existing rule comparison consumer, NOT a substitute LLM run.
    algorithm = importlib.import_module("src.plan.d1_algorithm")
    main = importlib.import_module("src.plan.main_decision")
    for module in (algorithm, main):
        monkeypatch.setattr(module, "ROOT", env.root)
    monkeypatch.setattr(algorithm, "fetch_holdings_map", lambda: {})
    monkeypatch.setitem(sys.modules, "src.collectors.xtick_collector",
                        SimpleNamespace(XTickCollector=lambda: SimpleNamespace(latest_close=lambda code: None)))
    summary, missing = build(env, "")
    assert not missing
    env.b.consume_authorized_inputs(summary)
    plan = main.build_watchlist_plan(DATE, json.loads(json.dumps(summary)), {}, fallback=True)
    assert plan["risk_limits"]["target_total_position_pct"] == 0.0
    assert plan["execution_pool"] == []
    assert {p["ts_code"] for p in plan["watch_pool"]} == {"000001.SZ", "000002.SZ"}
    assert all(p["auto_trade_enabled"] is False and p["entry_rules"] == [] for p in plan["watch_pool"])
    assert plan["autonomous_trading_enabled"] is False
    assert plan["meta"]["research_confidence"]["R1"] == 0.0
    assert plan["meta"]["research_confidence"]["R2"] is None


def test_manifest_digest_is_deterministic_for_unchanged_inputs(env):
    a, _ = build(env, "")
    b, _ = build(env, "")
    assert a["input_manifest"]["sha256"] == b["input_manifest"]["sha256"]


def r7_alias(env, kind="symlink"):
    env.s.stage(env.root, DATE, RUN, "R7", "running", attempt=2)
    canonical = env.paths["R7"]
    value = {**env.a.read_object(canonical), "run_id": RUN, "attempt": 2}
    dated = canonical.with_name(f"R7_capital_flow_{DATE}.json")
    write(dated, value)
    canonical.unlink()
    if kind == "symlink":
        canonical.symlink_to(dated.name)
    elif kind == "pointer":
        write(canonical, {"trade_date": DATE, "alias_of": dated.name})
    elif kind != "absent":
        raise AssertionError("unsupported fixture alias")
    human = env.root / f"chzl_kg/投研交易/资金面/{DATE}.md"
    human.write_text("# synthetic R7\n" + "current attempt\n" * 6)
    return canonical, dated


def complete_handoff(env, monkeypatch):
    env.s.stage(env.root, DATE, RUN, "summary", "running")
    monkeypatch.setattr(sys, "argv", ["build_research_summary.py", "--date", DATE, "--run-id", RUN])
    assert env.b.main() == 0
    env.s.stage(env.root, DATE, RUN, "summary", "completed")
    env.s.stage(env.root, DATE, RUN, "D1", "running", attempt=1)
    plan = {"trade_date": DATE, "schema_version": "1.0", "generated_at": "2026-10-25T08:00:00+08:00",
            "decision_source": "llm", "execution_pool": [],
            "watch_pool": [{"ts_code": "000001.SZ", "name": "synthetic"}],
            "mode": "dry_run", "autonomous_trading_enabled": False, "requires_user_confirmation": True,
            "risk_limits": {"target_total_position_pct": 0}, "no_trade_conditions": []}
    write(env.root / f"data/plans/{DATE}/watchlist_plan.json", plan)
    human = env.root / f"chzl_kg/投研交易/盘前预案/{DATE}.md"
    human.parent.mkdir(parents=True, exist_ok=True)
    human.write_text("# synthetic plan\n" + "no trade\n" * 6)
    load_plan = importlib.import_module("trading.load_plan")
    monkeypatch.setattr(load_plan, "DATA_DIR", env.root / "data")
    monkeypatch.setattr(load_plan, "RUNTIME_DIR", env.root / "data/runtime")
    assert env.s.check(env.root, DATE, RUN, "D1")
    env.s.stage(env.root, DATE, RUN, "D1", "completed", attempt=1)
    env.a.publish_runtime_plan(env.root, DATE)
    env.s.stage(env.root, DATE, RUN, "runtime_handoff", "completed")
    return env.a.read_object(env.root / f"data/research/{DATE}/research_summary.json")


@pytest.mark.parametrize("kind", ["symlink", "pointer", "absent"])
def test_r7_alias_real_check_summary_finish_and_consume(env, monkeypatch, kind):
    canonical, dated = r7_alias(env, kind)
    path, payload = env.a.research_artifact(env.root, DATE, "R7")
    assert path == dated and payload["attempt"] == 2
    assert env.s.check(env.root, DATE, RUN, "R7")
    env.s.stage(env.root, DATE, RUN, "R7", "completed", attempt=2)
    summary = complete_handoff(env, monkeypatch)
    receipt = env.a.read_object(env.s.state_path(env.root, DATE))["contract_results"]["R7"]["json"]
    evidence = summary["input_manifest"]["units"]["R7"]["json"]
    assert receipt["path"] == summary["artifacts"]["R7"] == str(dated.relative_to(env.root))
    assert evidence["sha256"] == receipt["sha256"] == env.a.file_version(env.root, dated)["sha256"]
    assert evidence["usable"] is True and evidence["receipt_binding"]["status"] == "verified"
    assert env.s.finish(env.root, DATE, RUN, 0)
    health = env.a.read_object(env.s.state_path(env.root, DATE))
    assert health["status"] == "completed" and health["total_expected"] == 15 and health["missing_count"] == 0
    assert health["contract_results"]["summary"]["inputs"]["R7"]["path"] == receipt["path"]
    consumed = env.b.consume_authorized_inputs(summary)
    assert consumed["R7"] == payload and consumed["R1"]["position_cap_suggestion"] == 0.0
    assert summary["confidence"]["R1"] == 0 and summary["confidence"]["R7"] is None
    assert len(summary["hard_rejects"]) == 2 and summary["missing_md"] == []


@pytest.mark.parametrize("fault", ["target_replaced", "attempt_switched"])
def test_r7_symlink_saved_handoff_and_finish_reject_changed_target_or_attempt(env, monkeypatch, fault):
    _, dated = r7_alias(env)
    assert env.s.check(env.root, DATE, RUN, "R7")
    env.s.stage(env.root, DATE, RUN, "R7", "completed", attempt=2)
    summary = complete_handoff(env, monkeypatch)
    if fault == "target_replaced":
        before = dated.stat()
        write(dated, {**env.a.read_object(dated), "generated_at": "2026-10-25T07:41:00+08:00"})
        os.utime(dated, ns=(before.st_atime_ns, before.st_mtime_ns))
        assert dated.stat().st_size == before.st_size and dated.stat().st_mtime_ns == before.st_mtime_ns
    else:
        env.s.stage(env.root, DATE, RUN, "R7", "running", attempt=3)
    with pytest.raises(ValueError):
        env.b.consume_authorized_inputs(summary)
    refreshed, missing = build(env)
    assert "R7" in missing and "R7" not in refreshed["artifacts"]
    assert not env.s.finish(env.root, DATE, RUN, 0)
    assert env.a.read_object(env.s.state_path(env.root, DATE))["contract_results"]["R7"]["json"]["passed"] is False


@pytest.mark.parametrize("fault", ["wrong_day", "escape", "absolute", "traversal", "chain", "noncanonical", "non_r7"])
def test_summary_cannot_bypass_rejected_canonical_symlink_with_valid_dated_file(env, fault):
    canonical, dated = r7_alias(env)
    unit = "R7"
    canonical.unlink()
    target = dated.name
    if fault == "wrong_day":
        target = "R7_capital_flow_20261024.json"
        write(dated.with_name(target), env.a.read_object(dated))
    elif fault == "escape":
        write(env.root / "escape.json", env.a.read_object(dated))
        target = "../../../escape.json"
    elif fault == "absolute":
        target = str(dated)
    elif fault == "traversal":
        target = "../" + DATE + "/" + dated.name
    elif fault == "chain":
        other = dated.with_name("other.json")
        write(other, env.a.read_object(dated))
        dated.unlink()
        dated.symlink_to(other.name)
    elif fault == "noncanonical":
        target = "./" + dated.name
    else:
        unit = "R1"
        canonical = env.paths[unit]
        target = canonical.with_name("R1_style_" + DATE + ".json")
        write(target, env.a.read_object(canonical))
        canonical.unlink()
        target = target.name
    canonical.symlink_to(target)
    summary, missing = build(env)
    assert unit in missing and unit not in summary["artifacts"]
    assert summary["input_manifest"]["units"][unit]["json"]["usable"] is False
    assert unit not in env.b.consume_authorized_inputs(summary)


@pytest.mark.parametrize("unit,changes", [
    ("R2", {"main_lines": "synthetic-wrong-shape"}),
    ("R2", {"main_lines": [{"leaders": ["bad"]}]}),
    ("R2", {"secondary_lines": [{"leaders": {}}]}),
    ("R5", {"profiles": "bad"}), ("R5", {"profiles": ["bad"]}),
    ("R5", {"profiles": [{"ts_code": []}]}),
])
def test_bad_candidate_unit_is_localized_and_other_research_remains_consumable(env, unit, changes):
    env.s.stage(env.root, DATE, RUN, unit, "running", attempt=2)
    write(env.paths[unit], {**env.a.read_object(env.paths[unit]), **changes})
    checked = env.s.check(env.root, DATE, RUN, unit)
    summary, missing = build(env)
    assert checked is False and unit in missing and unit not in summary["artifacts"]
    assert "R1" in env.b.consume_authorized_inputs(summary)
    assert summary["orchestrator_status"] == "partial" and summary["hard_rejects"]
    chart = summary["input_manifest"]["chart_coverage"]
    assert chart["status"] == "invalid_candidate_shape" and chart["coverage"] is None
    assert chart["authorized_for_d1"] is False


@pytest.mark.parametrize("bad", [
    {"R2": {"main_lines": "bad"}}, {"R2": {"main_lines": ["bad"]}},
    {"R2": {"secondary_lines": [{"leaders": "bad"}]}},
    {"R5": {"profiles": "bad"}}, {"R5": {"profiles": ["bad"]}},
])
def test_optional_chart_audit_reports_invalid_shape_without_inventing_coverage(env, bad):
    chart = env.b.chart_coverage(DATE, bad)
    assert chart["status"] == "invalid_candidate_shape" and chart["coverage"] is None
    assert chart["authorized_for_d1"] is False and chart["error"]


@pytest.mark.parametrize("error", [TypeError, ValueError, AttributeError])
def test_optional_chart_local_failure_does_not_erase_usable_summary(env, monkeypatch, error):
    def broken(*args, **kwargs):
        raise error("synthetic candidate shape audit failure")
    monkeypatch.setattr(env.b, "chart_coverage", broken)
    summary, missing = build(env)
    assert not missing and set(env.b.consume_authorized_inputs(summary)) == set(env.a.UNIT_FILES)
    assert len(summary["hard_rejects"]) == 2
    chart = summary["input_manifest"]["chart_coverage"]
    assert chart["status"] == "invalid_candidate_shape" and chart["coverage"] is None

