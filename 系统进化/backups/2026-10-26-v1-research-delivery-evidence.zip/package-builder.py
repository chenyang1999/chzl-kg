"""Package only reviewed second-batch evidence; never run business tasks."""
from pathlib import Path
from urllib.parse import unquote, urlsplit
from datetime import datetime
import ast
import csv
import difflib
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
import zipfile

ROOT = Path('/Users/chenyang/Downloads/demo/沧海巨浪')
BASE = Path('/Users/chenyang/.hermes/cache/scratch/v1-research-20261025')
KIT = BASE / 'FINAL'
RUN = KIT / 'parent-after-F4-20261026'
OLD_RUN = BASE / 'F3/parent-final-20261026T0018'
KG = ROOT / 'chzl_kg'
BACKUPS = KG / '系统进化/backups'
REPORT = KG / '系统进化/2026-10-26 第二批研究交付修复与主控验收.md'
TARGET = BACKUPS / '2026-10-26-v1-research-delivery-evidence.zip'
STAGE = BASE / 'PARENT/final-delivery'
STAGE.mkdir(mode=0o700)
assert not TARGET.exists(), 'Never overwrite an existing evidence archive'


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def load(path):
    return json.loads(path.read_text())


def emit(rel, blob):
    dest = STAGE / rel
    assert not dest.exists(), rel
    assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(blob)
    dest.chmod(0o600)


def jsout(rel, value):
    emit(rel, json.dumps(value, ensure_ascii=False, indent=2).encode())


def copy(path, rel):
    assert path.is_file() and not path.is_symlink(), str(path)
    emit(rel, path.read_bytes())


result = load(RUN / 'F3-result.json')
manifest = load(RUN / 'source-manifest.json')
old_manifest = load(OLD_RUN / 'source-manifest.json')
baseline = load(BASE / 'baseline.json')
assert result['exit_code'] == 0
assert result['totals'] == {'unique_cases': 1114, 'passed': 1114, 'failure': 0, 'error': 0, 'skipped': 0}
assert result['prior_fixed_cases'] == 790
assert result['subtests_by_group'] == {'old-profiles': 16, 'paper': 65}
assert result['known_C2_F1_boundary']['fixed_by_original_test']
for key in ['coverage_errors', 'current_source_drift', 'frozen_drift', 'app_copy_drift', 'guard_violations', 'harness_errors']:
    assert not result[key], key
changed_since_last_gate = {rel for rel, entry in old_manifest.items() if manifest[rel]['sha256'] != entry['sha256']}
assert changed_since_last_gate == {'src/plan/main_decision.py'}
for rel, entry in manifest.items():
    p = ROOT / rel
    assert not p.is_symlink() and sha(p.read_bytes()) == entry['sha256'], rel
assert (ROOT / '.git/index').read_bytes() == (BASE / 'index.before').read_bytes()
assert subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT) == (BASE / 'index-records.before').read_bytes()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == baseline['head']
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT).decode().strip() == baseline['branch']
assert (KIT / 'c2_assets/test_c2_boundaries.py').read_bytes() == (BASE / 'C2/test_c2_boundaries.py').read_bytes()

# Human-only documentation is outside the tested source closure.
readme = KG / 'README.md'
links = []
for token in re.findall(r'\[[^\]]+\]\(([^)]+)\)', readme.read_text()):
    url = urlsplit(token)
    if url.scheme:
        continue
    resolved = (readme.parent / unquote(url.path)).resolve()
    links.append({'target': token, 'exists': resolved.exists()})
assert all(row['exists'] for row in links)
assert not (KG / 'chzl_kg').exists()
finders = []
for parent, dirs, files in os.walk(KG, followlinks=False):
    if '.DS_Store' in files:
        finders.append(str((Path(parent) / '.DS_Store').relative_to(KG)))

names = ['00-CANONICAL-ARCHITECTURE-v1.md', '07-重构进度表.md', '09-架构审阅图-T1prime.md', '10-系统架构全景-v1.md']
migrations = []
with tarfile.open(BACKUPS / '2026-10-25-kg-four-docs-before.tar.gz', 'r:gz') as tf:
    members = tf.getmembers()
    for name in names:
        matches = [x for x in members if Path(x.name).name == name and x.isfile()]
        assert len(matches) == 1, name
        original = tf.extractfile(matches[0]).read()
        current = KG / '系统进化' / name
        assert sha(current.read_bytes()) == sha(original), name
        assert not (KG / name).exists(), name
        migrations.append({'target': str(current.relative_to(KG)), 'sha256': sha(original), 'unchanged_from_approved_backup': True})
kg_check = {'observed_at': datetime.now().astimezone().isoformat(), 'local_link_count': len(links), 'missing_links': [x for x in links if not x['exists']], 'README_sha256': sha(readme.read_bytes()), 'nested_chzl_kg_exists': False, 'finder_metadata_present': finders, 'approved_migrations': migrations, 'scope': 'README links, exact four approved document bytes, directory metadata only; no private trading material or editor state body read'}
jsout('knowledge/kg-final-verification.json', kg_check)
copy(readme, 'knowledge/README.md')
copy(BASE / 'PARENT/README.before-navigation-20261026.md', 'knowledge/README.before-recent-navigation.md')
nav_before = (BASE / 'PARENT/README.before-navigation-20261026.md').read_text()
nav_patch = ''.join(difflib.unified_diff(nav_before.splitlines(True), readme.read_text().splitlines(True), fromfile='a/chzl_kg/README.md', tofile='b/chzl_kg/README.md'))
emit('knowledge/recent-navigation.patch', nav_patch.encode())
copy(REPORT, 'report.md')
copy(ROOT / 'data/evolution/2026-W44/sign_off_log.md', 'sign-off-log.md')
copy(BASE / 'PARENT/final-acceptance-receipt.json', 'native-final/parent-verification.json')

implementations = ['scripts/research/pipeline_artifacts.py', 'scripts/research/pipeline_state.py', 'scripts/research/reconcile_pipeline_status.py', 'scripts/research/build_research_summary.py', 'scripts/research/run_research_shell.sh', 'src/plan/main_decision.py']
new_tests = ['tests/test_v1_research_delivery_20261025.py', 'tests/test_v1_research_handoff_20261025.py', 'tests/test_v1_legacy_summary_binding_20261026.py']
changes = []
patches = []
for rel in implementations + new_tests:
    after = (RUN / 'frozen' / rel).read_bytes()
    before_path = BASE / 'before' / rel
    if rel in implementations:
        before = before_path.read_bytes()
        assert sha(before) == baseline['sources'][rel]['sha256'], rel
        copy(before_path, 'before/' + rel)
    else:
        assert not before_path.exists(), rel
        before = b''
    emit('after/' + rel, after)
    patches.append(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + rel if rel in implementations else '/dev/null', tofile='b/' + rel)))
    changes.append({'path': rel, 'kind': 'implementation' if rel in implementations else 'new_test', 'before_sha256': sha(before) if rel in implementations else None, 'after_sha256': sha(after), 'after_bytes': len(after)})
emit('repair-only.patch', ''.join(patches).encode())
jsout('changes.json', changes)

# Preserve native results and only explicitly selected command evidence.
for source, prefix in [(RUN, 'native-final'), (OLD_RUN, 'native-before-F4')]:
    for filename in ['F3-result.json', 'source-manifest.json', 'junit.xml', 'native-case-index.json', 'subtest-index.json', 'harness-hashes.json', 'guard-receipts.json']:
        copy(source / filename, prefix + '/' + filename)
    r = load(source / 'F3-result.json')
    for receipt in r['runs']:
        if source == OLD_RUN and receipt['group'] != 'c2-known-F1':
            continue
        evidence = Path(receipt['evidence'])
        assert evidence.is_relative_to(source)
        for filename in ['command.json', 'stdout.txt', 'stderr.txt', 'exit.json']:
            p = evidence / filename
            if p.is_file():
                copy(p, prefix + '/commands/' + str(p.relative_to(source)))
for filename in ['F4-result.md', 'F4-result.json', 'F4-incremental.patch', 'before-hashes.json', 'after-hashes.json', 'before-after-hashes.json']:
    copy(BASE / 'F4' / filename, 'F4/' + filename)
# Failed local guard rounds remain visible, not counted as final product failures.
failed_round = BASE / 'F4/contracts-repaired1'
failed_files = []
if failed_round.is_dir():
    for filename in ['F3-result.json', 'source-manifest.json', 'junit.xml', 'guard-receipts.json']:
        p = failed_round / filename
        if p.is_file():
            copy(p, 'F4/guard-first-round/' + filename)
            failed_files.append(str(p.relative_to(BASE / 'F4')))
    failed_result_path = failed_round / 'F3-result.json'
    if failed_result_path.exists():
        for receipt in load(failed_result_path)['runs']:
            if receipt['returncode'] == 0:
                continue
            evidence = Path(receipt['evidence'])
            assert evidence.is_relative_to(failed_round)
            for filename in ['command.json', 'stdout.txt', 'stderr.txt', 'exit.json']:
                p = evidence / filename
                if p.is_file():
                    copy(p, 'F4/guard-first-round/commands/' + str(p.relative_to(failed_round)))
jsout('F4/failed-round-retention.json', {'selected_evidence': failed_files, 'final_acceptance_is_separate': True})

kit_files = ['run_joint.py', 'audit_worker.py', 'case-identity-contract.json', 'additional-identity-contract.json', 'research_worker.py', 'research_guard.py', 'scope.json', 'legacy_bootstrap.py', 'inherited-harness-hashes.json']
kit_files += ['support/' + n for n in ['legacy_s2_before_ledger.py', 'test_s3_ast_diagnostics.py', 'test_audit_d_diagnostics.py']]
kit_files += ['c2_assets/' + n for n in ['guard.py', 'real_modules.py', 'test_c2_boundaries.py', 'pytest.ini', 'run_checks.py', 'shell_probe.py', 'shell_child.py']]
for rel in kit_files:
    copy(KIT / rel, 'runner/' + rel)

pending = '''--- a/agent-cron-pipeline-ops/SKILL.md
+++ b/agent-cron-pipeline-ops/SKILL.md
@@
 ### 4. Repair the contract, not the symptom
 
+- Distinguish an absent summary from an existing rejected handoff. Only absence of the summary itself may enter an existing missing-summary fallback; missing inputs, receipts, state, invalid JSON and verifier rejection must not trigger rediscovery. Reuse the shared verifier in direct minimal-summary and legacy readers.
@@
 ### 3. Make regression safe before discovery
 
+- Interpret a relative symlink target from the new link's parent, not the worker cwd. Guard the link location and resolved destination independently, preserve escape negatives, and retain failed guard evidence separately from product regression results.
'''
emit('pending-skills.patch', pending.encode())
readme_text = '''# 本批工程证据包

本包不是完整系统、干净Git提交、生产数据备份或实盘许可。

- report.md：授权、实际测试、修复边界、未尽事项。
- native-final/：主控当前冻结树原生JUnit与机器回执；native-before-F4/：前一轮真实红测。
- before/、after/、repair-only.patch：仅本批六个实现及三个新增测试的字节与增量。基底是修前脏工作树，不是HEAD；不要盲目向不同工作树应用。
- runner/：实跑入口的同字节副本，依赖原项目工作树、现有.venv、macOS隔离工具；不是独立安装包。
- pending-skills.patch：未批准的语义差异建议，不可当作已经应用；不包含角色权限放宽。
- knowledge/：最终导航与四项精确迁移的摘要核验；不含私人交易材料、Wiki正文或模型配置私有备份。

复跑：将本包解到本机授权scratch中的新目录；先对照 native-final/source-manifest.json 核验当前项目字节。用项目 .venv/bin/python -B <解包目录>/runner/run_joint.py --mode final --label <未用过的简单名称>。

每次实际冻结／回归都会生成新证据，不能拿之前的绿测认证后来改过的源码。禁止把这个入口改为生产账户、业务模型、行情或调度任务运行器。
'''
emit('README.md', readme_text.encode())

# Refuse suspicious secret literals without displaying their values.
pattern = re.compile(r'''(?im)\b(?:api_key|api_secret|access_token|auth_token|password|client_secret|authorization)\b["']?\s*[:=]\s*["']([^"'\r\n]{16,})["']''')
key_pattern = re.compile(r'\b(?:sk-[A-Za-z0-9_-]{24,}|AKIA[A-Z0-9]{16})\b')
suspects = []
synthetic_count = 0
for p in sorted(STAGE.rglob('*')):
    if not p.is_file():
        continue
    assert not p.is_symlink()
    text = p.read_text(encoding='utf-8')
    for value in [m.group(1) for m in pattern.finditer(text)] + [m.group(0) for m in key_pattern.finditer(text)]:
        if any(marker in value.lower() for marker in ['redacted', 'synthetic', 'canary', 'dummy', 'fake', 'placeholder', 'test']):
            synthetic_count += 1
        else:
            suspects.append(str(p.relative_to(STAGE)))
assert not suspects, 'Review possible secret literals in selected files only: ' + repr(sorted(set(suspects)))
jsout('payload-scan.json', {'selected_payload_only': True, 'unresolved_suspicious_literals': 0, 'synthetic_markers_excluded': synthetic_count, 'not_a_whole_repository_secret_audit': True, 'excluded': ['.env and credentials', 'profile model configurations/backups', 'private trade material', 'live data/DB/ledgers', 'whole Wiki snapshots']})
copy(Path(__file__), 'package-builder.py')
entries = {str(p.relative_to(STAGE)): {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in sorted(STAGE.rglob('*')) if p.is_file()}
jsout('archive-manifest.json', entries)
with zipfile.ZipFile(TARGET, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(STAGE.rglob('*')):
        if p.is_file():
            z.write(p, str(p.relative_to(STAGE)))
TARGET.chmod(0o600)
with zipfile.ZipFile(TARGET) as z:
    assert z.testzip() is None
    archived = json.loads(z.read('archive-manifest.json'))
    assert len(z.namelist()) == len(set(z.namelist())) == len(archived) + 1
    assert set(z.namelist()) == set(archived) | {'archive-manifest.json'}
    for rel, record in archived.items():
        blob = z.read(rel)
        assert len(blob) == record['bytes'] and sha(blob) == record['sha256'], rel
        assert blob == (STAGE / rel).read_bytes(), rel
    assert z.read('report.md') == REPORT.read_bytes()
for rel, record in manifest.items():
    assert sha((ROOT / rel).read_bytes()) == record['sha256'], rel
assert (ROOT / '.git/index').read_bytes() == (BASE / 'index.before').read_bytes()
assert subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT) == (BASE / 'index-records.before').read_bytes()
receipt = {'verified_at': datetime.now().astimezone().isoformat(), 'archive': str(TARGET), 'archive_sha256': sha(TARGET.read_bytes()), 'archive_bytes': TARGET.stat().st_size, 'members_verified': len(entries) + 1, 'all_member_bytes_and_hashes_verified': True, 'source_manifest_still_matches': True, 'index_and_records_unchanged': True, 'native_totals': result['totals'], 'subtests_by_group': result['subtests_by_group'], 'kg_final': kg_check, 'archive_is_evidence_not_git_commit_or_production_approval': True}
(BASE / 'PARENT/final-delivery-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
TARGET.with_suffix('.zip.sha256').write_text(receipt['archive_sha256'] + '  ' + TARGET.name + '\n')
TARGET.with_suffix('.zip.sha256').chmod(0o600)
print(json.dumps(receipt, ensure_ascii=False, indent=2))
