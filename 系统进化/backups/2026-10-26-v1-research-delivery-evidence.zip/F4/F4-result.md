# F4 旧规则/备用读取器版本绑定修复

## 结果
- 唯一项目写范围：`src/plan/main_decision.py`、新增 `tests/test_v1_legacy_summary_binding_20261026.py`；无其他生产文件修改、无 Git 写/提交、无配置/技能/cron/SOUL 修改。
- 原 C2 F1 严格测试原名原断言：修前 **1 fail / exit 1** → 修后 **1 pass / exit 0**。未通过 skip/xfail/删例隐藏失败。
- 最终原生唯一 **320 pass / 0 fail / 0 error / 0 skip**；其中新增 **51**、既有 **269**；另有 **16** profiles 子例，不计入原生数。
- 最终源码/冻结/复制漂移 0、覆盖错误 0、意外守卫违规 0；7 项边界探针均被阻断；NUL-safe Git index records 前后相同。

## 根因与最小修复
1. 旧 loader 仅看键、日期与文件存在；新 manifest 路径懒加载真实 `consume_authorized_inputs(summary, root=ROOT)`，不复制其校验。字段存在但 null/未知/坏 digest 不是旧格式。
2. 新增私有 `_ResearchSummaryMissing(FileNotFoundError)` 仅用于打开 summary 本身时不存在；缺 primary/state/receipt 或其他验证失败不可能命中这条 fallback。
3. `run_main_decision` 不再捕获宽泛 ValueError/FileNotFoundError；只捕获上述真正缺 summary 的异常。存在但坏 JSON、目录、断链或已拒绝 handoff 均向上拒绝，写 plan 前停止。
4. 直接 `_minimal_summary` 先经 loader 消费现有 summary；保留原版本绑定、R6 否决与 R7 dated 路径，不以自动发现重建绕过。确实无 summary 才用既有降级发现。
5. manifest 字段真正缺失的合法旧格式仍兼容；未改预算、R6、研究就绪判定、执行许可或 auxiliary scope。

## 已读定义与调用链
- `build_research_summary.consume_authorized_inputs`、`main_decision.load_research_summary/_minimal_summary/run_main_decision/build_watchlist_plan`。
- `scripts/plan/run_main_decision.main` → `src.execute.fallback.run_plan_fallback` → `run_main_decision`；`ensure_watchlist_plan.ensure_plan` 同样调用该 hook。直接 `_minimal_summary` 唯一项目外部调用为既有 `tests/pipeline/test_d1_decision_source.py`，已用合成根目录原样跑。
- 所有 Python 调用点经精确符号搜索核对；没有修改这些调用方或扩大生产写范围。

## 原生队列
| group | cases | exit |
|---|---:|---:|
| repaired2-strict-F1 | 1 | 0 |
| repaired2-c2-other-functions | 37 | 0 |
| repaired2-new | 60 | 0 |
| delivery | 73 | 0 |
| handoff | 50 | 0 |
| old-reliability | 34 | 0 |
| old-profiles | 3 | 0 |
| old-contracts | 62 | 0 |

## 覆盖与兼容
- 合法新 loader/直接 minimal 共用真实 consumer；run-bound 当前 receipts 正向。
- 实际 fallback hook/真实 run 与 CLI 对 summary 后改稿、错 run、切 attempt、缺 receipt、缺 state、缺 primary 全部拒绝且无输出 plan。
- 零预算保留观察池/禁自动交易/空 entry_rules，R6 veto 不丢，JSON 与两份 MD 一致。
- 真缺 summary 合法 fallback；旧 manifest 字段缺失兼容；字段存在但坏值不降级。
- R7 同日相对 symlink/pointer/canonical absent → dated 三种合法 alias，经真实 state/check → summary → loader/minimal → fallback 正向；既有逃逸负例仍原样通过。

## 真实命令与证据
```sh
# 最终完整有限队列；每个 label 必须新值，脚本拒绝复用旧目录
/Users/chenyang/Downloads/demo/沧海巨浪/.venv/bin/python -B /Users/chenyang/.hermes/cache/scratch/v1-research-20261025/F4/run_f4.py --label repaired2 --contracts
```
- 上述真实命令已返回 exit 0。重跑请换未用 label；汇总脚本 `finalize.py` 默认读取本次 repaired2，不会伪造新运行。
- 每个 child 的真实 argv、清理后环境、stdout/stderr、exit：`commands/`；测试原生结果：`junit.xml` 与 `native-case-index.json`；逐组原生 JUnit 与守卫路径见 `F4-result.json.runs`。
- 修前：`c2/before-F1/junit.xml`、`audit.json`；修后：`c2/repaired2-strict-F1/junit.xml`。修前真实 argv：`.venv/bin/python -B F4/c2/run_checks.py F4/c2/snapshot-before before-F1`，选择环境 `C2_SELECTION=test_C2_F1_existing_plan_reader_must_reject_replaced_bound_input`，禁插件/禁字节码。
- 源码原字节：`before/`；修前/后 hash：`before-hashes.json`、`after-hashes.json`、`before-after-hashes.json`；修复增量：`F4-incremental.patch`（相对修前脏工作树，不是 HEAD diff）。
- 明确依赖白名单：`write-scope.json`、`c2/snapshot-repaired2/snapshot.json`、`contracts-repaired2/source-manifest.json`；按文件复制，不 copytree 整 src/trading/scripts。旧队列导入必需 settings/QMT 源码仅在已审查闭包，永不读 .env/账户/持仓/生产账本。
- 没有真实业务产物写入；所有合成 data/plans、JSON、MD、状态与 fixture 均在 scratch。

## 隔离问题（透明保留）
第一轮 `repaired1` 的 delivery/handoff 各 1 例被 F4 复用 guard 误拦，exit 96：守卫将相对 symlink target 按 cwd 而非 link.parent 解析，虚构了越界位置。未修改旧测试或生产契约。仅修本次 F4-local guard 的目标解析后第二轮全绿；第一轮 JUnit、日志、违规记录全部保留，不能描述第一轮全过。

## 剩余边界
- Not a new full 1054-case F3 run; only these finite native cohorts rerun. F3 known-exit1 statistical flag now becomes false because original strict F1 passes, not because assertions changed.
- Orchestrator summary helpers use exact AST closure to exclude unused legacy builders/settings in C2/F4; state/manifest/reader/algorithm/renderer/hook/CLI execute actual unchanged modules.
- No real model, market, QMT/IB, production task, resident reload, push or production business artifacts. External holdings/quote boundaries are synthetic.
- Python audit hooks are not an OS-general sandbox; reviewed legacy shell cases use existing seatbelt + exact relocated shell/fake-Hermes boundaries.
- Legacy summaries without input_manifest retain existing existence/date/completeness checks; this does not retrofit historical version receipts. Genuine absent summary still permits previously legal raw-artifact fallback.
- The shared consumer verifies the saved manifest and authorized primary versions/receipts; it does not prove model tool-read/adoption or eliminate mutation races after validation before later algorithm reads. No parallel validator, extra permissions or threshold changes added.

## 技能差异建议（仅建议，未应用）
```diff
# main_decision_v1 · Inputs/降级路径
+ 带 input_manifest 的旧规则/备用读取器复用 consume_authorized_inputs，失败立即拒绝；不得按文件存在重发现。
+ 区分 summary 本身不存在与输入/状态/receipt 缺失。只有前者允许既有缺文件 fallback。
+ 直接 minimal-summary 消费者也必须保留现有 handoff 的 R6/版本/R7 dated 引用。
# agent-cron-pipeline-ops · Regression guard
+ 验证 symlink 目标相对于 link.parent 而非 cwd；拒绝目标不得误读/误写，保留原逃逸负例。
```
