"""Offline only. Default recomputes and compares frozen tables, never writes. --freeze writes only beside this script."""
from pathlib import Path
from collections import Counter,defaultdict
import json,re,csv,io,hashlib,sys
ROOT=Path('/Users/chenyang/Downloads/demo/沧海巨浪'); OUT=Path(__file__).resolve().parent
assert ROOT not in OUT.parents and OUT!=ROOT
L=ROOT/'chzl_kg/投研交易/数据源台账'; H=ROOT/'data/health'; D='20261127'; S=['ok','degraded','failed','pending','skipped'];rank={s:i for i,s in enumerate(['skipped','ok','pending','degraded','failed'])}; h=lambda b:hashlib.sha256(b).hexdigest()
files={};tables={};groups=defaultdict(list); families=defaultdict(dict);trends=[];dates=[]; tally=Counter(); bad=[]
def read(p):
 assert p.resolve().is_relative_to(ROOT) and not p.is_symlink();b=p.read_bytes();files[str(p.relative_to(ROOT))]=h(b);return b.decode('utf-8')
def get(p):return json.loads(read(p)) if p.is_file() else {}
def store(n,head,rows):
 o=io.StringIO();w=csv.writer(o,lineterminator='\n');w.writerow(head);w.writerows(rows);tables[n]=o.getvalue()
def group(key,layer):
 k=re.sub('20[0-9]{6}','DATE',key).lower(); t=k.rsplit(':',1)[-1];
 if layer=='L4':return k
 if layer=='L5':return k.split('/')[-1].replace('artifact:','').replace('_date','')+(':runtime' if 'runtime/watchlist' in k or 'watchlist_plan_date' in k else '')
 if layer=='L3' and re.fullmatch('research:r[1-7]',k):return '角色交付:'+t.upper()
 if 'datapro' in k:return 'DataPro/'+('业务' if layer=='L3' or 'business' in k else '连通')
 for pat,tag in [('qmt','QMT'),('weflow','WeFlow'),('sanji|三刀','sanji'),('mptext','mptext'),('ocr|图片','图片文字覆盖'),('rss|wechat_official|公众号','公众号/RSS'),('wechat|weixin|群聊|微信群|群[0-9]|chat.group','匿名文本覆盖'),('overseas|外盘|海外快照','海外快照'),('attention|人气信号','人气信号'),('hotlist|ths_hot|dc_hot','热榜'),('xtick|x-tick','XTick'),('vibe','Vibe'),('hithink|iwencai|问财','问财'),('eastmoney_earnings_predict|业绩预告','东财业绩预告'),('news_major','要闻'),('news_cls','财联社'),('news_extras','新闻补足'),('announcement|公告','公告'),('factor_snapshot','因子快照'),('northbound|北向|moneyflow_hsgt','北向参考'),('theme_anchor','题材锚'),('chart_vision','图表'),('tushare','Tushare'),('status_counts','状态计数'),('mcp_health','健康元数据'),('source:llm|ds:llm','模型探针')]:
  if re.search(pat,k):return tag
 if re.fullmatch(r'(research:r\d:|source:|ds:|mcp:)?[a-z0-9_.:/-]{1,80}',k):return t
 return '未归并键#'+h(key.encode())[:12]
md={p.stem:p for p in L.rglob('[0-9]*.md')};js={p.stem[-8:]:p for p in H.glob('datasource_ledger_????????.json')};assert set(md)==set(js)
for p in sorted(L.rglob('*.md')):
 text=read(p)
 if p.stem.startswith('_trend'):trends.append((p.name,re.findall(r'^\| (20\d{6}) \|',text,re.M)))
bak=ROOT/'chzl_kg/系统进化/backups/2026-10-23-production-recovery-before/files/chzl_kg/投研交易/数据源台账/20261023.md';same=read(bak)==read(md['20261023']); detail=[]
for dt in sorted(js):
 d=get(js[dt]);s=d['summary'];m=read(md[dt]);v=d.get('schema_version','legacy');assert d['trade_date']==dt and d['generated_at'] in m; line=next(x for x in m.splitlines() if '总览：' in x); nums=list(map(int,re.findall('[0-9]+',line))); wanted=[s[k] for k in (['ok','total','degraded','failed','pending','skipped'] if v!='legacy' else ['ok','failed','critical_failed'])];
 if nums!=wanted:bad.append((dt,'MD头',nums,wanted))
 daygroups=defaultdict(list);raw=Counter();
 for i,r in enumerate(d['rows']):
  l=r['layer'][:2];k=r['key'];state=r.get('state') or dict(zip(['✅','🔴','🟡','⏸','⏳'],['ok','failed','degraded','skipped','pending']))[r['status'][0]];raw[state]+=1;g=group(k,l);daygroups[l,g].append((state,i,k));
  if l=='L3' and '4013' in (str(r.get('note'))+' '+str(r.get('error'))) and 'datapro' in k.lower():tally['4013_'+dt]=1
 if v!='legacy' and any(raw[k]!=s[k] for k in S):bad.append((dt,'JSON行计数'))
 for (l,g),rr in sorted(daygroups.items()):
  st=max((x[0] for x in rr),key=rank.get); c=Counter(x[0] for x in rr);families[l,g][dt]=st;groups[dt,l,g]=[x[1] for x in rr];detail.append([dt,l,g,st,*[c[t] for t in S],';'.join(str(x[1]) for x in rr)])
 j=get(H/f'research_pipeline_{dt}.json');p=ROOT/'data/plans'/dt;au=get(p/'auction_amendment.json');mid=get(p/'midday_amendment.json');ps='-' if not j else j.get('status','legacy');dates.append([dt,d['generated_at'],d['is_trading_day'],v,len(d['rows']),*[raw[t] for t in S],ps,j.get('missing_count',''),(p/'watchlist_plan.json').is_file(),(ROOT/f'data/runtime/watchlist_plan_{dt}.json').is_file(),au.get('status','-'),mid.get('status','-')]);tally['rows']+=len(d['rows'])
store('dates.csv',['date','ledger_generated','trading_as_ledger','schema','row_n',*S,'pipeline_latest','missing_count','plan_exists_now','runtime_plan_exists_now','P1_latest','P2_latest'],dates);store('date-source.csv',['date','layer','source_family','worst_visible',*S,'rows_index_0based'],detail);store('sources.csv',['layer','family','observed_days',*S,'failed_dates','degraded_dates'],([l,g,len(a),*[list(a.values()).count(t) for t in S],*[','.join(d for d,v in a.items() if v==t) for t in ['failed','degraded']]] for (l,g),a in sorted(families.items())));
# Human tables may have been reclassified without rewriting the paired legacy JSON.
mdrows=[]; trendsums=[]
for dt,p in sorted(md.items()):
 layer=None; d=get(js[dt]); namekeys={(r['layer'][:2],r['name']):r['key'] for r in d['rows']}
 for lineno,line in enumerate(read(p).splitlines(),1):
  if line.startswith('#'): layer=(re.match(r'### (L[1-5])',line).group(1) if re.match(r'### (L[1-5])',line) else None)
  if not layer or not line.startswith('|'):continue
  cells=line.strip('|').split('|'); mark=cells[0].strip()[:1];marks={'✅':'ok','🔴':'failed','🟡':'degraded','⏳':'pending','⏸':'skipped','⚠':'degraded','❌':'failed'}
  if mark not in marks or len(cells)<2:continue
  label=cells[1].strip(); mkey=re.search(r'\(`([^`]+)`\)',label);key=mkey.group(1) if mkey else namekeys.get((layer,label),label);family=group(key,layer) if layer!='L4' or key.startswith('cron:') else '未绑定任务#'+h(key.encode())[:12];mdrows.append([dt,layer,family,marks[mark],lineno])
for n,ds in trends:
 for ln,line in enumerate(read(L/n).splitlines(),1):
  match=re.match(r'\| (20\d{6}) \| (\d+) \| (\d+) \| (\d+) \|',line)
  if match:trendsums.append([n,ln,*match.groups()])
store('md-detail.csv',['date','layer','family','visible_state','md_line'],mdrows);store('trend-detail.csv',['file','line','date','reported_ok','reported_abnormal','reported_critical'],trendsums)
# Explicit allowlist; only selected status scalars printed, no article, message, account or model prompt bodies exported.
rootRaw=ROOT/'data/raw'/D;pl=ROOT/'data/plans'/D;logs=ROOT/'data/logs/research_shell'/D;summary=get(ROOT/'data/research'/D/'research_summary.json');j=get(H/f'research_pipeline_{D}.json');a=get(rootRaw/'auction_snapshot.json');pa=get(pl/'auction_amendment.json');pm=get(pl/'midday_amendment.json');e=get(ROOT/'data/reports'/D/'E1_data.json');ert=get(ROOT/'data/runtime/E1_data.json');ov=get(rootRaw/'overseas_snapshot.json');rss=get(rootRaw/'rss_fetch_status.json');
for n in ['manifest.json','mcp_health.json','intraday_snapshot_1130.json','intraday_analysis_1130.json']:get(rootRaw/n)
for n in ['R7_capital_flow_20261126.json','R2_main_sectors.json','R4_news.json','R3_sentiment.json']:get(ROOT/'data/research/20261126'/n)
quota=[x for x in ['R1','R2','R3','R4','R6','R7'] if '429' in read(logs/(x+'.log'))];f=next(logs.glob('*.delivery.json'));r5=get(f);stream=f.with_name(f.name.replace('.delivery.json','.stream.jsonl'));q5='429' in read(stream) and r5['stage']=='R5';binding='no consumer attempt bound' in read(logs/'D1.log');
store('inputs.csv',['repo_relative_path','sha256'],sorted(files.items()));print('md/daily, trend, json, extra backup/same:',len(md),len(trends),len(js),same,'rows:',tally['rows'],'days trading:',sum(x[2] for x in dates),'date/layer/family:',len(detail),'families:',len(families),'MD or JSON summary discrepancies:',bad);print('trends:',[(n,a[0],a[-1]) for n,a in trends]);print('DataPro-key 4013 L3 dates:',sum(n for k,n in tally.items() if k.startswith('4013_')));print('latest pipeline:',j['started_at'],j['finished_at'],j['status'],j['missing_count'],'R summary',summary['orchestrator_status'],'429:',quota,'R5 native:',q5,'D1 bind error:',binding);print('P1 inputs/outcomes:',a['captured_at'],a['status'],pa['generated_at'],pa['status'],'P2:',pm['generated_at'],pm['status'],'midday primary exists:',(rootRaw/'midday_snapshot.json').exists());print('E1 dated:',e['trade_date'],e['generated_at'],e['status'],'runtime slot:',ert['trade_date'],ert['generated_at']);print('coverage RSS',rss['feeds_ok'],rss['feeds_total'],rss['core_ok'],rss['core_feeds'],'overseas requested/returned/fresh:',{k:[v.get('quality',{}).get(i) for i in ('requested_count','returned_count','fresh_count')] for k,v in ov['categories'].items()});
if sys.argv[1:]==['--freeze']:
 for n,t in tables.items():(OUT/n).write_bytes(t.encode())
else:
 changes=[n for n,t in tables.items() if not (OUT/n).exists() or (OUT/n).read_bytes()!=t.encode()];print('frozen table changes:',changes);sys.exit(bool(changes))
