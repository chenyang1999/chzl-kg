"""REVIEW-01 synthetic render-entry regressions; no production artifacts."""
from copy import deepcopy
from typing import Any
import pytest
from src.plan import render_markdown, quick_reference
from scripts.plan import render_plan_tables

@pytest.fixture(params=[render_markdown, render_plan_tables], ids=["prose", "tables"])
def renderer(request, monkeypatch, tmp_path):
    module = request.param
    monkeypatch.setattr(render_markdown, "ROOT", tmp_path)
    function = (module.render_watchlist_plan_md if module is render_markdown
                else module.render_plan_tables_md)
    return module, function

def sample() -> dict[str, Any]:
    def stock(code, **kw):
        result = dict(ts_code=code, name="合成票", entry_rules=[dict(type="leader_breakout",
            trigger_price=10.2, buy_zone=[10,10.3], position_pct=0)],
            exit_rules=[dict(type="stop_loss_break",trigger_price=9,quantity_pct=.5,
                effective_from="T+1",reason="合法卖出仍保留",trigger_condition="破位")],
            auto_trade_enabled=False,requires_user_confirmation=True,max_position_pct=0)
        result.update(kw)
        return result
    return dict(trade_date="20990106", mode="dry_run", no_trade=True,
        autonomous_trading_enabled=False, requires_user_confirmation=True,
        risk_limits=dict(target_total_position_pct=0,max_buy_orders_per_day=0,max_positions=5),
        execution_pool=[stock("000001.SZ",plan_status="execution_pool_hold")],
        watch_pool=[stock("000002.SZ",buy_eligibility={"status":"unknown"}),
            stock("000003.SZ",buy_eligibility={"status":"blocked"}),
            stock("000004.SZ",research_anchor_only=True,buy_eligibility={"status":"unknown"})],
        seesaw_plan=dict(seesaw_directions=[dict(direction="合成反向",candidates=[stock("000005.SZ")])]),
        rejected=[dict(ts_code="000006.SZ",reason="原有否决")])

def rows(md):
    return {line.split(" | ")[0][2:]:line for line in md.splitlines()
            if line.startswith("| ") and "（" in line and "） | " in line}

def render_unchanged(renderer,p):
    before=deepcopy(p)
    md=renderer[1](p)
    assert p==before
    return md

def test_incomplete_is_not_rejected_and_missing_counts_stay_unknown(renderer):
    p=sample()
    p.update(production_ready=False,research_completion_passed=False,reassessment_required=True)
    p["meta"]={"r6_devil_advocate":dict(formal_review_completed=False,review_passed=False,hard_rejects_applied=[])}
    md=render_unchanged(renderer,p)
    assert "研究与正式反证状态（仅展示）" in md
    r=rows(md)
    assert "未完成" in r["研究是否完成（research_completion_passed）"]
    assert "未完成" in r["正式反证是否完成（meta.r6_devil_advocate.formal_review_completed）"]
    assert "未知" in r["正式评估数（meta.r6_devil_advocate.candidates_evaluated）"]
    assert "未知" in r["已阅读研究对象数（meta.r6_devil_advocate.research_objects_inspected）"]
    assert r["硬否决数（meta.r6_devil_advocate.hard_rejects_applied）"].endswith(" | 0 |")
    assert "未完成不等于已审否决" in md

@pytest.mark.parametrize("complete,passed,evaluated,inspected,rejects",[
    (False,False,0,6,[]),(True,True,6,8,[]),
    (True,False,4,7,["000006.SZ","000007.SZ"]),
    (False,True,0,6,["000006.SZ"]),
])
def test_independent_explicit_states_and_zero(renderer,complete,passed,evaluated,inspected,rejects):
    p=sample(); p["research_completion_passed"]=complete
    p["meta"]={"r6_devil_advocate":dict(formal_review_completed=complete,
        review_passed=passed,candidates_evaluated=evaluated,research_objects_inspected=inspected,
        hard_rejects_applied=rejects)}
    r=rows(render_unchanged(renderer,p))
    assert ("已完成" if complete else "未完成") in r["正式反证是否完成（meta.r6_devil_advocate.formal_review_completed）"]
    assert ("通过" if passed else "未通过") in r["正式反证是否通过（meta.r6_devil_advocate.review_passed）"]
    for label,field,value in [("正式评估数","candidates_evaluated",evaluated),
            ("已阅读研究对象数","research_objects_inspected",inspected),
            ("硬否决数","hard_rejects_applied",len(rejects))]:
        assert r[f"{label}（meta.r6_devil_advocate.{field}）"].endswith(f" | {value} |")

@pytest.mark.parametrize("bad",[None,False,"6",-1,{},[]])
def test_absent_or_invalid_is_unknown_not_pool_inferred(renderer,bad):
    p=sample(); p["meta"]={"r6_devil_advocate":dict(candidates_evaluated=bad,
        research_objects_inspected=bad,hard_rejects_applied=None,formal_review_completed="true")}
    r=rows(render_unchanged(renderer,p))
    for label in ["研究是否完成（research_completion_passed）",
        "正式反证是否完成（meta.r6_devil_advocate.formal_review_completed）",
        "正式评估数（meta.r6_devil_advocate.candidates_evaluated）",
        "已阅读研究对象数（meta.r6_devil_advocate.research_objects_inspected）",
        "硬否决数（meta.r6_devil_advocate.hard_rejects_applied）"]:
        assert "未知" in r[label]

def test_only_added_display_input_anchors_sell_and_existing_groups_unchanged(renderer,monkeypatch):
    p=sample()
    md=render_unchanged(renderer,p)
    with monkeypatch.context() as m:
        m.setattr(quick_reference, "_review_overview", lambda _plan: [])
        old=render_unchanged(renderer,p)
    addition="\n".join(quick_reference._review_overview(p))+"\n"
    assert md.count(addition)==1
    assert md.replace(addition, "", 1)==old
    assert "当前禁止新买（非永久否决）" in md
    assert "买入资格未知／待复核（非已审否决）" in md
    assert "仅观察／禁买（不建议开仓）" in md
    assert "合法卖出仍保留" in md and "50%" in md and "T+1" in md
    assert "全局禁止开仓（no_trade）" in md
    assert "总仓上限：0%" in md and "每日买单上限：0" in md
