"""D1 盘前预案 Markdown 渲染。

2026-09-30 修：原实现是计数桩（只输出 "entry_rules: N 条"），即使执行池非空，
人读预案里也看不到任何买点/买区/逻辑——用户看到的"什么预案都没有"有一部分
由此造成。现在把每票的通道、触发价、买区、止损止盈、执行逻辑完整渲染出来。
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from src.plan.quick_reference import (
    render_constraints, render_sector_overview, render_pool_reference,
    render_seesaw_reference, decision_origin,
)

ROOT = Path(__file__).resolve().parents[2]


def _fmt(x: Any) -> str:
    if x is None:
        return "—"
    if isinstance(x, float):
        return f"{x:.2f}"
    return str(x)


def _zone(r: dict[str, Any]) -> str:
    z = r.get("buy_zone") or r.get("pullback_zone")
    if isinstance(z, (list, tuple)) and len(z) == 2:
        return f"{_fmt(z[0])} ~ {_fmt(z[1])}"
    return _fmt(r.get("trigger_price"))


_CHANNEL_LABEL = {
    "trend_pullback_buy": "低吸·决策线回踩",
    "leader_breakout": "打板·突破跟随",
    "low_absorption_intraday": "盘中低吸",
}


def _render_entry_rule(r: dict[str, Any]) -> list[str]:
    t = r.get("type") or "?"
    label = _CHANNEL_LABEL.get(t, t)
    out = [f"  - **{label}** (`{t}`)"]
    out.append(f"    - 买区: `{_zone(r)}`")
    if r.get("trigger_price") is not None:
        out.append(f"    - 触发价: `{_fmt(r.get('trigger_price'))}`")
    if r.get("position_pct") is not None:
        try:
            out.append(f"    - 建议仓位: `{float(r['position_pct']) * 100:.0f}%`")
        except (TypeError, ValueError):
            out.append(f"    - 建议仓位: `{r['position_pct']}`")
    if r.get("max_premium_pct") is not None:
        try:
            out.append(f"    - 最高可接受溢价: `{float(r['max_premium_pct']) * 100:.0f}%`")
        except (TypeError, ValueError):
            pass
    if r.get("execution_logic"):
        out.append(f"    - 执行逻辑: {r['execution_logic']}")
    if r.get("derivation_reason"):
        out.append(f"    - 推导依据: {r['derivation_reason']}")
    if r.get("one_word_no_chase"):
        out.append("    - ⚠️ **一字板：禁止追高，只等开板后分歧承接**")
    if r.get("requires_intraday_confirm"):
        out.append("    - 需盘中确认（放量/承接）后才可下手")
    return out


def render_watchlist_plan_md(plan: dict[str, Any]) -> str:
    trade_date = plan.get("trade_date", "")
    meta = plan.get("meta") or {}
    position_cap = meta.get("position_cap_pct", plan.get("risk_limits", {}).get("target_total_position_pct"))
    exec_pool = plan.get("execution_pool") or []
    watch_pool = plan.get("watch_pool") or []
    mc = plan.get("market_context") or {}
    ds = plan.get("data_sources") or {}
    ec = ds.get("entry_channels") or meta.get("entry_channels") or {}

    # ── 决策来源显眼标注（2026-09-30）：人读预案必须一眼看出今天是谁在决策 ──
    decision_source, is_fallback = decision_origin(plan)

    lines = [
        "---",
        f"date: {trade_date[:4]}-{trade_date[4:6]}-{trade_date[6:8]}" if len(trade_date) == 8 else f"date: {trade_date}",
        "agent: D1-main-decision",
        f"decision_source: {decision_source}",
        f"generated_at: {plan.get('generated_at', '')}",
        f"position_cap: {position_cap}",
        f"execution_count: {len(exec_pool)}",
        f"watch_count: {len(watch_pool)}",
        f"mode: {plan.get('mode')}",
        "---",
        "",
        f"# {trade_date} 盘前预案",
        "",
    ]

    if is_fallback:
        lines.extend([
            "> ## 🚨 本预案由 **Python 量价规则兜底** 生成，**不是大模型决策**",
            ">",
            "> 大模型 D1（`main_decision_v1` fresh context）今晨**未能产出**预案，安全网用",
            "> `src/plan/d1_algorithm.py`（纯量价规则）补位。规则只看得到量价与档位，",
            "> **看不到题材、消息、情绪与博弈**——不可据此下单，务必等大模型重跑或人工重出。",
            ">",
            "> 触发时机：provider 超时 / 404 / 上游 artifact 缺失。排障先看 `data/logs/research_shell/<date>/D1.log`。",
            "",
        ])

    lines.extend([
        "## 一句话结论",
        mc.get("structure") or meta.get("note") or "",
        "",
    ])

    # ── 明日情绪节点预测（马尔科夫两跳 · 2026-10-17 补全）──
    # 读 data/research/YYYYMMDD/node_prediction.json，把「今日→明日→后日」概率分布渲染进预案。
    # 用户钦定：买票是 T+1，今天买的票明天卖，必须知道明天情绪节点。只吐温度，不选票。
    np_path = ROOT / "data" / "research" / trade_date / "node_prediction.json"
    if np_path.is_file():
        try:
            np_data = json.loads(np_path.read_text(encoding="utf-8"))
            tmr_dist = np_data.get("tomorrow_dist") or {}
            two_step = np_data.get("two_step_dist") or {}
            tmr_top = np_data.get("most_likely_tomorrow") or "—"
            tmr_prob = np_data.get("most_likely_tomorrow_prob") or 0
            two_top = max(two_step.items(), key=lambda kv: kv[1])[0] if two_step else "—"
            lines.extend(["", "## 明日情绪节点预测（马尔科夫）", ""])
            lines.append(f"- 今日阶段: **{np_data.get('today_phase_name') or '—'}**")
            lines.append(f"- 明日最可能: **{tmr_top}** ({tmr_prob:.0%})")
            if tmr_dist:
                rank = sorted(tmr_dist.items(), key=lambda x: -x[1])
                lines.append("- 明日分布: " + " ｜ ".join(f"{k} {v:.0%}" for k, v in rank))
            if two_step:
                lines.append(f"- 后日最可能: **{two_top}**")
                lines.append("- 两跳分布: " + " ｜ ".join(f"{k} {v:.0%}" for k, v in sorted(two_step.items(), key=lambda x: -x[1])))
            if np_data.get("reversal_adjustment"):
                lines.append(f"- ⚠️ 反转校正: {np_data['reversal_adjustment']}")
            if np_data.get("risk_note"):
                lines.append(f"- ⚠️ 风险: {np_data['risk_note']}")
            lines.append("- 用法: 只吐温度不选票；明日若高概率主跌 → 今日执行池只留强逻辑票/轻仓；明日若修复 → 冰点日可尾盘试错")
        except (json.JSONDecodeError, OSError):
            pass

    # ── 入口通道（regime 决策留痕）──
    if ec:
        lines.append("## 入口通道（regime 决策）")
        lines.append("")
        lines.append(f"- 市场风格: **{ec.get('style') or '—'}**")
        chans = ec.get("channels") or []
        lines.append(
            "- 今日启用通道: "
            + ("、".join(f"{_CHANNEL_LABEL.get(c, c)}(`{c}`)" for c in chans) if chans else "—")
        )
        lines.append(f"- 点火 regime: `{ec.get('ignition')}` ｜ 候选数: `{ec.get('raw_candidates')}`")
        if ec.get("reason"):
            lines.append(f"- 判据: {ec['reason']}")
        lines.append("")

    lines.extend(render_sector_overview(plan))
    lines.extend(render_constraints(plan))
    lines.extend([f"## 执行池({len(exec_pool)} 只)", ""])

    # Per-stock explanation and both tables are rendered together below; avoid
    # a second prose implementation mixing stock-wide prices across scenarios.

    # Both human-readable paths share the same scenario-safe deterministic view.
    lines.extend(render_pool_reference(plan, exec_pool, "执行池"))
    lines.extend([f"## 观察池({len(watch_pool)} 只)", ""])
    lines.extend(render_pool_reference(plan, watch_pool, "观察池"))
    lines.extend(render_seesaw_reference(plan))

    lines.extend(["", "## R6 反证采纳", ""])
    r6m = meta.get("r6_devil_advocate") or {}
    d1_recorded = len(r6m.get("strong_suggests_overridden") or [])  # D1 算的 subset
    r6_raw_strong = 0  # R6 落盘原始
    r6_raw_hard = 0
    # P2 补全：按 mode 分类列出 strong_suggest 详情 + 个股级 ts_code，方便 D1 review
    trade_date = (plan.get("trade_date") or "")
    if trade_date:
        r6_path = ROOT / "data" / "research" / trade_date / "R6_devil_advocate.json"
        if r6_path.is_file():
            try:
                r6 = json.loads(r6_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                r6 = {}
            ca = r6.get("counter_arguments") or []
            r6_raw_hard = len(r6.get("hard_rejects") or [])
            r6_raw_strong = sum(1 for c in ca if c.get("severity") == "strong_suggest")
            lines.append(f"- hard_rejects: {r6_raw_hard} (D1 采纳) / 落盘原始: {r6_raw_hard}")
            lines.append(f"- strong_suggest: D1 v1 记录 {d1_recorded} 条 / R6 落盘原始 {r6_raw_strong} 条（差值= D1 未自动接的强 suggest）")
            # 按 mode_name 分组
            by_mode: dict[str, list[dict[str, Any]]] = {}
            for c in ca:
                if c.get("severity") != "strong_suggest":
                    continue
                m = c.get("mode_name", "未分类")
                by_mode.setdefault(m, []).append(c)
            # 优先显示：含 ts_code 个股级的强 suggest（最有行动价值）
            # v1.8 优先：D1 算法已抽好的 meta_r6.strong_suggests_accepted[] 含 ts_code / id / suggestion
            # v1.7 回退：从 R6 ca 里抽 target_ts_code（兼容 LLM 落盘但没跑 D1 算法的场景）
            stock_hits: list[tuple[str, str, str]] = []  # (ts_code, name, suggestion)
            r5_index: dict[str, str] = {}  # ts_code -> name
            r5_path = ROOT / "data" / "research" / trade_date / "R5_stock_profiles.json"
            if r5_path.is_file():
                try:
                    r5 = json.loads(r5_path.read_text(encoding="utf-8"))
                    for p in (r5.get("profiles") or []):
                        ts = p.get("ts_code") or ""
                        if ts:
                            r5_index[ts] = p.get("name", "")
                        code = p.get("code") or ""
                        if code:
                            r5_index[code] = p.get("name", "")
                except (json.JSONDecodeError, OSError):
                    r5_index = {}
            accepted = (r6m.get("strong_suggests_accepted") or []) if isinstance(r6m, dict) else []
            if accepted:
                for item in accepted:
                    ts = item.get("ts_code", "")
                    sug = (item.get("suggestion") or "")[:80]
                    name = r5_index.get(ts, "") or r5_index.get(ts.split(".")[0] if ts else "", "")
                    stock_hits.append((ts, name, sug))
            else:
                for c in ca:
                    if c.get("severity") != "strong_suggest":
                        continue
                    ts = c.get("target_ts_code") or ""
                    if not ts:
                        m2 = re.search(r"\b(\d{6}\.(SH|SZ|BJ))", (c.get("target") or "").upper())
                        if m2:
                            ts = m2.group(1)
                    if ts:
                        name = r5_index.get(ts, "") or r5_index.get(ts.split(".")[0], "")
                        stock_hits.append((ts, name, (c.get("suggestion") or "")[:80]))
            if stock_hits:
                lines.append("")
                lines.append("**个股级 strong_suggest（已进 watch_pool，方向=down）**：")
                for ts, name, sug in stock_hits:
                    lines.append(f"- {ts} {name} — {sug}")
            # 显示按 mode 分类的所有 strong_suggest
            if by_mode:
                lines.append("")
                lines.append("**按反证模式分类**：")
                for mode, items in by_mode.items():
                    lines.append(f"- {mode}（{len(items)} 条）")
                    for c in items[:3]:  # 每模式至多列 3 条
                        rid = c.get("reject_id", "?")
                        target = c.get("target", "")
                        if len(target) > 60:
                            target = target[:60] + "..."
                        lines.append(f"  - {rid}: {target}")
            # 模式 5 命中时单独显眼提示（top1 预测偏差 → 提示降仓）
            m5_hits = [c for c in ca if c.get("reject_id", "").startswith("R6_M5") and c.get("severity") == "strong_suggest"]
            if m5_hits:
                lines.append("")
                lines.append("⚠️ **R6.M5 命中：马尔科夫 top1 预测偏差。说明 D1 v1 未自动降仓（需 review），但建议在仓位档位上限主动降一档（base_mobile_ratio × 0.85）**")
            # P2 补全：显示 D1 算法实际算出的 market_wide_factor 与每只降仓票
            mw_factor = (r6m.get("market_wide_factor") or 1.0) if isinstance(r6m, dict) else 1.0
            mw_signals = (r6m.get("market_wide_signals") or {}) if isinstance(r6m, dict) else {}
            if mw_factor != 1.0 or mw_signals:
                lines.append("")
                lines.append(f"**全市场级降仓信号（D1 v1.8 实算）**：market_wide_factor = **{mw_factor}**")
                if mw_signals:
                    lines.append(f"- rule: {mw_signals.get('rule', '')}")
                    lines.append(f"- M5_hit: {mw_signals.get('M5_hit', False)}")
                    lines.append(f"- M1_strong_hit: {mw_signals.get('M1_strong_hit', False)}")

    # P2 补全：R3 群聊情绪 + R4 消息面整合段（2026-10-17）
    r34 = meta.get("r3_r4_integration") or {}
    if r34 and r34.get("schema_version") == "r3_r4_integration_v1":
        lines.extend(["", "## R3 群聊情绪 + R4 消息面整合", ""])
        # R3 群聊
        r3 = r34.get("r3_sentiment") or {}
        r3_dq = r3.get("data_quality", "missing")
        r3_verdict = (r3.get("next_day_signal") or {}).get("verdict") or "无"
        r3_score = r3.get("sentiment_score", "N/A")
        lines.append(f"**R3 群聊情绪**：data_quality={r3_dq} | sentiment_score={r3_score} | verdict={r3_verdict}")
        themes = r3.get("resonance_top_themes") or []
        if themes:
            lines.append("- 共振主题（top5）：")
            for t in themes[:5]:
                lines.append(
                    f"  - {t.get('theme_name','?')} | {t.get('resonance_level','?')} | "
                    f"sectors={t.get('suggested_sectors',[])[:3]} | {t.get('early_or_late','?')}"
                )
        kol = r3.get("kol_summary") or []
        if kol:
            lines.append(f"- KOL 群聊观点（{len(kol)} 条）：")
            for k in kol[:3]:
                lines.append(
                    f"  - [{k.get('source','?')}] {k.get('view','')[:80]}"
                )
        # R4 消息面
        r4 = r34.get("r4_news") or {}
        r4_dq = r4.get("data_quality", "missing")
        r4_events = r4.get("top_events") or []
        r4_fb = r4.get("first_board_candidates_high") or []
        lines.append("")
        lines.append(f"**R4 消息面**：data_quality={r4_dq} | top_events={len(r4_events)} 条 | 首板候选高质量={len(r4_fb)} 条")
        if r4_events:
            lines.append("- 重大事件（top5）：")
            for e in r4_events[:5]:
                polarity = e.get("polarity", "?")
                strength = e.get("strength", "?")
                title = (e.get("title") or "")[:60]
                lines.append(f"  - [{polarity}/{strength}] {title}")
        if r4_fb:
            lines.append("- 首板高质量候选（top5）：")
            for c in r4_fb:
                lines.append(
                    f"  - {c.get('code','?')} {c.get('name','?')} | {c.get('industry','?')} | hit={c.get('hit_count',0)}"
                )
        # LLM 整合提示
        prompts = r34.get("llm_integration_prompts") or {}
        if prompts:
            lines.append("")
            lines.append("**LLM 整合任务（程序不算，留给 LLM 端）**：")
            for k, v in prompts.items():
                lines.append(f"- {k}: {v}")

    rejected = plan.get("rejected") or []
    if rejected:
        lines.extend(["", "## 否决清单", ""])
        for r in rejected:
            lines.append(f"- {r.get('ts_code')} {r.get('name')} — {r.get('reason')}（源: {r.get('source_agent')}）")

    return "\n".join(lines) + "\n"
