"""Install audit boundaries before pytest import / collection."""
import sys, os, json, types, hashlib
from pathlib import Path
ROOT=Path("/Users/chenyang/Downloads/demo/沧海巨浪")
S=Path(__file__).resolve().parent
violations=[]
selftesting=False

def deny(event,detail):
    if not selftesting:
        violations.append({"event":event,"detail":str(detail)})
    raise PermissionError("offline guard: "+event+" "+str(detail))

def check_path(value,write=False):
    if not isinstance(value,(str,bytes,os.PathLike)): return
    p=Path(os.fsdecode(value)).absolute()
    protected=(p.name==".env" or p.suffix in {".db",".sqlite",".sqlite3"} or
        any(p.is_relative_to(ROOT/sub) for sub in ["data","kb","chzl_kg"]))
    if protected: deny("protected_file",p)
    if write and not p.is_relative_to(S): deny("write_outside_scratch",p)

def audit(event,args):
    if event=="open":
        mode=args[1]; flags=args[2] if len(args)>2 else 0
        writing=(isinstance(mode,str) and any(c in mode for c in "wax+")) or (isinstance(flags,int) and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
        check_path(args[0],writing)
    elif event in {"os.remove","os.rmdir","os.mkdir","os.chmod","os.truncate"}:
        check_path(args[0],True)
    elif event in {"os.rename","os.link"}:
        check_path(args[0],True);check_path(args[1],True)
    elif event=="os.symlink": check_path(args[1],True)
    elif event.startswith("socket.") or event in {"sqlite3.connect","subprocess.Popen","os.system"}:
        deny(event,"blocked")

sys.addaudithook(audit)
selftesting=True
for path in [ROOT/".env",ROOT/"data/research/synthetic.json",ROOT/"kb/research.db"]:
    try: path.read_bytes()
    except PermissionError: pass
    else: raise AssertionError("guard selftest failed")
(S/"guard-selftest.txt").write_text("scratch writes permitted; protected reads blocked before open")
selftesting=False
settings=types.ModuleType("src.settings");settings.ROOT=S;settings.PROJECT_ROOT=S
settings.__file__=str(S/"synthetic-settings.py")
sys.modules["src.settings"]=settings
sys.path.insert(0,str(ROOT))
import pytest
source_paths=[ROOT/"src/plan/quick_reference.py",ROOT/"src/plan/render_markdown.py",ROOT/"scripts/plan/render_plan_tables.py"]
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
phase=sys.argv[1]
code=pytest.main([str(S/"test_review01_display.py"),"--noconftest","-c","/dev/null","--confcutdir",str(S),"-p","no:cacheprovider","-p","no:logging","--basetemp",str(S/(phase+"-tmp")),"--tb=short","-q","--junitxml",str(S/(phase+".xml"))])
after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
receipt=dict(phase=phase,exit_code=int(code),guard_installed_before_pytest=True,
    violations=violations,source_before=before,source_after=after,source_stable=before==after)
(S/(phase+".receipt.json")).write_text(json.dumps(receipt,indent=2,ensure_ascii=False))
assert not violations,violations
assert before==after,"source drift"
sys.exit(code)
