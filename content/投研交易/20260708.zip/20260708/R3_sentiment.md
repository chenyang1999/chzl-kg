---
date: 2026-07-08
agent: R3
skill: analyze-sentiment-resonance-v1
skill_version: v1
generated_at: 2026-07-08T14:10:00+08:00
confidence: 0.78
degraded_flag: true
degraded_reason: WeFlow MCP 未挂到本 sub-agent profile；仅有 parent 预导出 weflow_snapshot.json 覆盖 5/15 工具（meta/hot_terms/group_keywords/heatmap/river）。stock/concept 层 4 工具通过 terms.citations 正则反推，属降级 fallback。公众号本轮已恢复（21 号 105 篇），L2 双源齐备。
data_sources:
  - name: wechat_cli_5groups.jsonl
    freshness: T-1 20:00 → T 07:30
    status: 🟢
    n_messages: 398
    n_groups: 5
  - name: wechat_official_20.jsonl
    freshness: T-1 至 T 上午最新
    status: 🟢
    n_articles: 105
    n_accounts: 21
  - name: weflow_snapshot.json (parent 预导出)
    freshness: 2026-07-08 单日 bucket，8607 msg / 263 群
    status: 🟡
    tools_covered: 5/15
  - name: news_cls.jsonl + news_major.jsonl (L1 输入)
    freshness: T 上午
    status: 🟢
  - name: style_snapshot.json (ths_boards 22)
    freshness: T-1 收盘
    status: 🟢
input_freshness: fresh (all sources within 12h)
---

# R3 群聊情绪与热度 · 2026-07-08

## 一句话结论

三源共振主题 **4 条**：①国产算力/浪潮链（🟢强，L1+L2+L3 全共振，62 篇/18 号 + 5 群全命中）②AI 芯片-昇腾（🟢强，与①同宗）③存储/HBM（🟢分歧共振，L1+L2+L3 但内部对韩存储传导有对冲）④半导体设备/材料（🟢底仓型，L1 篇数最高但 L2 讨论浓度中等）。**霸榜出货警报升级**：机器人/PEEK（公众号 27 篇/11 号高热 vs 5 群仅 2 条）🔴；光模块从"霸榜嫌疑"降为"券商单点吹"🟡（L2 4 群命中减弱嫌疑但 KOL 群 B 仍沉默）。早期机会：CDN/网关（🟡 L2+L3 有热度、L1 未追进）；电网/电力（🟡 L1 only，5 群与 WeFlow 均未议）。

---

## 三源共振主题清单

| # | 主题 | L1 (公众号+新闻) | L2 (5 群 KOL) | L3 (WeFlow 263 群) | 分级 | 涉及个股（citation-verified） | 独立源计数 |
|:-:|------|:-:|:-:|:-:|:-:|------|:-:|
| 1 | **国产算力 / 浪潮链** | ✅ 公众号 **62 篇 / 18 号**（算力×253、服务器×73、浪潮×29、国产替代×18、昇腾×11、超节点×6）+ 新闻 65 条 | ✅ **5/5 群全命中**（A×18、B×3、C×13、D×19、E×14 = 67 条） | ✅ WeFlow terms：`浪潮` score=248 (37 群 breadth)、`算力` score=329、`国产` score=233、`服务器` score=238、`节点` score=138 | 🟢 **L1+L2+L3 全共振** | 浪潮信息、锐捷网络、寒武纪、曙光、紫光股份、华勤技术、瑞芯微、深科技、中国长城、万通发展、华菱线缆（液冷）、远东传动（昇腾服务器整机）、盛科通信、东山精密 | **21 公众号 + 5 群 + WeFlow ≥ 27 独立源** |
| 2 | **AI 芯片-昇腾生态** | ✅ 公众号 27 篇 / 12 号（GPU×54、昇腾×11） + 新闻 56 条 | ✅ **5/5 群命中**（A×6、B×2、C×5、D×3、E×6 = 22 条） | ✅ WeFlow `芯片` score=360、`华为` score=116 | 🟢 **L1+L2+L3** | 寒武纪、海光信息、昇腾链（浪潮/曙光/紫光/华勤），与主题 1 高度重叠 | 与①耦合，R2 建议合并为"AI 算力大主线" |
| 3 | **存储 / HBM** | ✅ 公众号 40 篇 / 13 号（存储×87、三星×53、海力士×23、HBM×16、NAND×15、DRAM×13） + 新闻 55 条 | ✅ **4/5 群**（A×7、B×4、D×2、E×4；C 缺席） | ✅ WeFlow `存储` score=143（distinct_senders=33，breadth=37，散度极高） | 🟢 **L1+L2+L3 · 分歧共振** | 三星、海力士（韩存储反面案例）；A 股映射：深科技、佰维存储、兆易创新（citations 未直接，R5 落票） | ≥5 独立源。**HARD_BOOKEND · 分歧点**：韩存储走 luna？"三季度 DRAM 提价 20%" vs 昨日"韩国存储大跌传导 A 股"，非弱共识，是阻力测试 |
| 4 | **半导体设备 / 材料** | ✅ 公众号 **52 篇 / 16 号（篇数第 2）**（半导体×164、设备×101、材料×97、光刻×11、刻蚀×6） + 新闻 84 条（新闻第 1） | 🟡 3/5 群（A×6、B×4、E×4；C/D 缺席） | ✅ WeFlow `半导体` score=191、`设备` score≈95 | 🟢 **L1+L2+L3 · 底仓型** | 密尔克卫（半导体物流）、扩产链具体票未 citation 命中，需 R5 补 | L1 极强 + L2 中等，属"共识但不狂热"，机构缓慢加仓型 |
| 5 | **液冷 / 散热** | ✅ 公众号 17 篇 / 9 号（液冷×99、散热×42、冷板×11） | ✅ 4 群（A×1、B×1、D×4、E×2 = 8 条） | 🟡 未进 top20（合并到"服务器"） | 🟡 **L1+L2 中等** | 华菱线缆、奇鋐、英维克方向 | 从属主题 1 子分支 |
| 6 | **CDN / 边缘 / 网关** | 🔴 公众号仅 3 篇 / 3 号（CDN×2、网宿×2） + 新闻 4 条 | ✅ **3/5 群命中**（A×5、D×6、E×9 = 20 条，占核心群_E 20% 权重） | ✅ WeFlow `CDN` score=84（breadth=19） | 🟡 **L2+L3 · 早期机会** | 南兴股份（独家网络增值电信资质）、佳创视讯、先进数通、网宿科技 | **典型大资金前置**：L2+L3 已议但 L1 未追 |
| 7 | **英伟达 / 北美算力** | ✅ 公众号 17 篇 / 11 号（英伟达×57、GB200×3、Blackwell×2） | 🟡 未单独统计（含在①中） | ✅ WeFlow `北美` breadth=20 | 🟢 **L1+L3**，L2 融入①主线 | 工业富联、沪电股份、生益科技、胜宏科技 | 与①耦合，产业链视角 |
| 8 | **机器人 / 擎天柱 / PEEK** | ✅ 公众号 27 篇 / 11 号（机器人×114、人形×29、擎天柱×6） + 新闻 61 条 | 🔴 **5 群仅 2 群 1-1 条**（A×1、B×1，C/D/E 全沉默） | 🟡 未进 WeFlow top20 | 🔴 **L1 only** | 埃斯顿、福赛科技 | ⚠️ **公众号高热 vs 群体沉默 → 霸榜出货重点嫌疑，push R6** |
| 9 | **电网 / 电力设备** | ✅ 公众号 18 篇 / 10 号（电力×25、电网×6、PJM×1、燃机×1、变压器×1） | 🔴 **5 群 0 命中** | 🔴 未进 WeFlow top20 | 🔴 **L1 only** | 思源电气、安靠智电、白云电器、金盘科技、伊戈尔 | ⚠️ 公众号（远期叙事型）在推，5 群与 WeFlow 冷淡 → **叙事早期**，尚未形成资金端认同；仅公众号 push R2 观察是否 R4 有硬催化 |
| 10 | **光模块 / 1.6T / CPO** | ✅ 公众号 33 篇 / 14 号（光模块×92、1.6T×40、CPO×31、光通信×27、800G×22、新易盛×10） + 新闻 20+ | ✅ **4/5 群**（A×3、C×5、D×1、E×4；B 沉默） | 🟡 WeFlow `模块` score=179（含泛义） | 🟡 **L1+L2 但 KOL 群 B 沉默** | 中际旭创、新易盛、天孚通信、光迅科技、太辰光、盛科通信 | **修正判定**：公众号恢复后 L2 覆盖增强，从"霸榜嫌疑"降级为"券商主导+KOL 群持保留"；仍需 R6 验 K 线 |
| 11 | **创新药 / CGT / ADC** | ✅ 公众号 19 篇 / 10 号 | 🔴 5 群仅 E×1 | 🔴 未进 WeFlow top20 | 🔴 **L1 only** | 政策催化型（药监 CGT 30 天审评） | 与今日 AI 主线错位，属对冲防御盘 |

---

## KOL 明日方向摘要（匿名）

KOL 名做 sha256 6 位截断（源自 wechat_cli_5groups.jsonl，398 msg / 5 群）。

### 机构群_C（券商分析师即时观点 · 31 msg）
- **KOL_a3f21c**（开源证券通信首席，估计 8-10 条）：主推光模块/连接器/交换机产业链，锐捷网络深度报告
- **KOL_1e8b04**（wells.ai，估计 7-9 条）：算力硬件重复推浪潮信息中报大超预期
- **KOL_75c9de**（国金计算机，估计 3-5 条）：Q3 主线 = 国产算力 + 华为昇腾生态
- 机构群_C 消息量最少但券商观点集中：AI 算力 + 光模块占 3/4 权重

### KOL 群_B（颜晓滨慢牛群 · 80 msg）
- **KOL_c74a12**（Jason）：科技调整正常，海外 CAPEX 叙事有回摆但主线未破
- **KOL_9b2f7e**（zZ）：图片/接龙为主，方向指向存储+算力
- **KOL_44d0a3**（张清）：韩存储不代表全球科技牛结束（对冲式判断，HARD_BOOKEND 分歧点）
- 弱看多信号（不狂热）

### 题材群_D（松哥系 · 89 msg）
- **KOL_fa8117**（松，估计 30+ 条，跨群霸屏）：`#7月8日盘前作业` 接龙推：浪潮信息（业绩）、华菱线缆（液冷）、雅化集团、国城矿业、瑞芯微、万通发展、中国长城、中天精装、深科技、昊华科技、埃斯顿
- **KOL_2e3c88**（行胜于言）：呼应主线，情绪偏乐观

### 研报群_A（一手盘中新闻 · 99 msg）
- **KOL_fa8117**（松，跨群霸屏第 2 高频）：反复推同一组标的
- **KOL_1d0f5a**（前进/崔龙/Riche）：新闻搬运为主

### 核心群_E（专注核心 · 突发新闻 · 99 msg）
- 松哥系跨群霸屏（松/行胜于言/风中追风 合计估计 40+ 条，占约 40%）
- **CDN 讨论浓度最高（9 条）**，早期机会信号

**KOL 命中率追踪**（供 E1 T+1/T+3 复盘用）：本 md 未回填 hit_rate，需 E1 累积表补齐。

---

## 霸榜出货警报

### 🔴 一级警报：机器人 / 擎天柱 / PEEK（新增 · 公众号恢复后浮现）

| 指标 | 数值 | 判定 |
|:-:|:-:|:-:|
| L1 公众号篇数 | 27 篇 / 11 号 | 高热（第 5） |
| L1 新闻篇数 | 61 条 | 高热 |
| L2 5 群命中 | **仅 A×1、B×1** | ⚠️ 极冷 |
| L3 WeFlow | 未进 top20 | 冷 |

**判定**：叙事催化（特斯拉擎天柱 2026 年底量产确认）由公众号大规模发酵，但资金端的 KOL 群 / 题材群 / 核心群 **全部沉默**。这不是"仅 L1 中信号"，是**新闻端热-资金端冷**的典型霸榜出货模式（催化真实但资金已提前撤退）。
**push R6**：请验 K 线（埃斯顿/福赛科技/PEEK 材料链）近 3 日是否高位放量滞涨/涨停打开次数增加。

### 🟡 二级警报：光模块 / CPO（修正 · 从霸榜嫌疑降级为券商单点吹）

- **公众号恢复后 L2 增强**：33 篇 / 14 号（第 4），5 群 4 群命中（A×3、C×5、D×1、E×4）
- 但 **KOL 群 B（老玩家阵地）持续沉默** → 卖方券商主导，题材群跟随，慢牛群保留
- **不同于主线**（浪潮链是 5 群全命中 + 松哥系跨群 + 券商呼应）
- **push R6**：请交叉验证中际旭创/新易盛/天孚通信近 3 日 K 线是否高位放量滞涨

### 🟡 三级警报：跨群霸屏个体（松哥系 42+ 条，跨研报_A / 题材_D / 核心_E 三群）

- 占 5 群 398 msg 约 10-12%
- 反复推同一组标的（浪潮/雅化/国城/华菱/瑞芯微/万通/长城/中天/深科技/昊华/埃斯顿）
- **push R6**：排查单点 pump 特征（其推荐票近日 K 线是否被单点吹到高位）

---

## 情绪浓度打分（L2 内部）

| 维度 | 数值 | 判定 |
|:-:|:-:|:-:|
| 5 群总消息量 | 398 | 中偏低（正常日均 400-600） |
| 21 号公众号篇数 | 105 | 正常（21×5=105，全覆盖） |
| Top1 主题浓度（国产算力占 L2） | 67/398 ≈ 17% | **偏高**（>15% 单一主题聚焦） |
| Top1 主题浓度（国产算力占 L1） | 62/105 ≈ 59% | 极高（AI 算力已是全 L1 半壁） |
| 悲观词频率（风险/出货/高位/波动/回调） | 13 次 / 398 msg ≈ 3.3% | 中性（<5% 无明显恐慌） |
| 跨群霸屏 KOL（松哥系跨 3 群） | 约 42 条 / 3 群 | **注意信号**：需 R6 排查 |
| 券商分析师覆盖 | 机构群_C 31 条中头部 KOL 占约 23 条 | 券商集中在 AI 算力+光模块 |
| L1-L2 一致性 | 6/11 主题 L1L2 同向、3 主题 L1 领先 L2 落后（机器人/电网/创新药）、0 主题 L2 领先 L1 | L1 略领先，需 R6 验 |
| 分歧信号 | 存储主题内部对韩存储传导有对冲讨论 | 🟡 分歧共振（不是弱共识） |

**综合情绪浓度**：🟡 **中性偏乐观（0.78）**
- 主线（国产算力+AI 芯片+存储+半导体设备）**四大主线并行**，叙事密度极高、L1L2L3 全覆盖
- 存在两处灰点：**跨群霸屏个体**（松哥系）+ **机器人/PEEK 新闻热-资金冷**
- KOL 群_B（慢牛群，老玩家阵地）**未加码主线，仅平淡确认** → 弱看多而非狂热
- HARD_BOOKEND：存储主题的韩股传导分歧应视为**阻力测试信号**，不是弱势

---

## 数据源审计表

| 数据源 | 状态 | 覆盖 | 说明 |
|-------|:-:|:-:|-----|
| wechat-cli 5 群 | 🟢 | 5/5 群齐、398 msg | 全部匿名化处理 |
| wechat_official_20.jsonl | 🟢 | **21/21 号、105 篇（新）** | 恢复正常，L2 双源齐备 |
| weflow-analytics (MCP) | 🟡 | **5/15 (33%)** | MCP 未挂到本 profile，仅有 parent 预导出 snapshot；stock/concept 层 4 工具用 citations 反推 |
| news_cls / news_major | 🟢 | 3467 lines | L1 输入 |
| style_snapshot ths_boards | 🟢 | 22 板块 | 交给 R2 主线 |

**coverage_color = 🟡**（5/15 = 33%，跨越 3-8 区间）——保持与上轮一致，公众号恢复不影响 WeFlow 工具覆盖率。

---

## 三条禁止 skip_reason 自查

| 未调工具 | skip_reason | 是否合规 |
|--------|------|:-:|
| get_analytics_meta | parent snapshot 已含 meta 字段（等价 native） | ✅ |
| get_hot_terms | fallback to parent-exported `terms` 数组（相同内容） | ✅ |
| get_group_keywords | fallback to parent-exported `group_keywords` | ✅ |
| get_river | fallback to parent-exported `river`（单 bucket，无时序） | ✅ |
| get_heatmap | fallback to parent-exported `heatmap`（本轮未消费） | ✅ |
| list_local_chatrooms | parent-exported group_keywords 已列出所有 263 群 message_count | ✅ |
| get_stock_hot_terms | ⚠️ **MCP 未挂本 profile**，用 `terms` citations 正则反推股票（浪潮信息×7、三星×4、锐捷×3 等） | 🟡 **降级 fallback** |
| get_concept_hot_terms | ⚠️ 同上，用 `terms` 高分词代替（算力/存储/CDN/半导体/北美/华为） | 🟡 降级 |
| get_concept_linked_stocks | ⚠️ 同上，用 citations 内共现推 edge_weight | 🟡 降级 |
| get_stock_river | 无 fallback，跳过 | 🔴 skip_reason: MCP 未挂 + parent 未导出 stock_river 数组 |
| get_stock_heatmap | 无 fallback，跳过 | 🔴 skip_reason: MCP 未挂 + parent 未导出 |
| export_analytics_snapshot | 全量导出用于归档 | ✅ R3 分析层不需要 |
| list_group_messages | 已由 wechat-cli 5 群 398 msg 提供等价 | ✅ 避免重复 |
| search_messages | 本轮未定位到需要单点上下文的可疑事件 | 🟡 R6 若要复查可回调 |
| get_message_context | 同上 | 🟡 未定位单点 |

**红线自检**：
- ❌ "工具没配" → 未使用（改为诚实标注"MCP 未挂本 sub-agent profile"）
- ❌ "没时间" → 未使用
- ❌ 空 skip_reason → 未出现

---

## Sub-Agent 元数据

- **agent**: R3
- **skill**: analyze-sentiment-resonance-v1
- **trade_date**: 20260708
- **generated_at**: 2026-07-08T14:10:00+08:00
- **confidence**: 0.78（上轮 0.72 → 提升 0.06，因公众号恢复 L2 双源齐备）
- **degraded**: true（reason: WeFlow MCP 未挂本 profile → stock/concept 4 工具降级为 citation 反推 fallback）
- **推送 R2 主线 Agent**：
  - 🟢 一线主线（可作为 D1 execution_pool 输入）：①国产算力/浪潮链 + ②AI 芯片-昇腾 + ③存储/HBM + ④半导体设备/材料（四主线并行）
  - 🟡 早期机会（观察）：CDN/网关（L2+L3 已议 L1 未追）
  - 🟡 独立轮动（不共振但可关注）：液冷（子分支）、英伟达链、创新药
  - 🔴 不建议入池：机器人/PEEK（L1 heat + L2 cold）、电网/电力（仅公众号叙事型）
- **推送 R6 反证 Agent**：
  - 🔴 **机器人/PEEK 一级警报**：公众号 27 篇 / 11 号 vs 5 群仅 2 条 → 请验埃斯顿/福赛科技 K 线
  - 🟡 **光模块二级警报**（修正）：券商单点吹 + KOL 群 B 沉默 → 请验中际旭创/新易盛/天孚通信 K 线
  - 🟡 **松哥系跨群霸屏**：42+ 条 / 3 群 / 398 msg = 10-12% → 请验其推荐票是否单点 pump
  - 🟡 **存储 HARD_BOOKEND**：韩股传导对冲讨论 → 请验今日存储龙头是否分化（三星海力士 vs A 股）
- **推送 E1 复盘 Agent**：本 md 未回填 KOL 命中率，请 T+1/T+3 复盘阶段用 kol_alias（哈希 6 位）计入 hit_rate 累积表

---

## tool_call_report（契约必需 · 也另存 sibling JSON）

```json
{
  "weflow_tools_used": [
    "get_analytics_meta",
    "get_hot_terms",
    "get_group_keywords",
    "get_heatmap",
    "get_river"
  ],
  "weflow_tools_skipped": [
    {"tool": "list_local_chatrooms", "skip_reason": "parent-exported snapshot 的 group_keywords 已含 263 群 message_count，等价 fallback"},
    {"tool": "get_stock_hot_terms", "skip_reason": "MCP weflow-analytics 未挂到本 sub-agent profile；降级用 terms.citations 正则反推股票（浪潮信息×7、三星×4、锐捷×3 等）"},
    {"tool": "get_concept_hot_terms", "skip_reason": "MCP 未挂本 profile；降级用 terms 高分词代替（算力/存储/CDN/半导体/北美/华为）"},
    {"tool": "get_concept_linked_stocks", "skip_reason": "MCP 未挂本 profile；降级用 citations 共现推 edge_weight"},
    {"tool": "get_stock_river", "skip_reason": "MCP 未挂本 profile 且 parent snapshot 未预导出 stock_river 数组，本轮无 fallback；建议后续 parent 预导出脚本补齐"},
    {"tool": "get_stock_heatmap", "skip_reason": "MCP 未挂 + parent 未导出；本轮无 fallback"},
    {"tool": "export_analytics_snapshot", "skip_reason": "全量导出用于归档，R3 分析层不需要"},
    {"tool": "list_group_messages", "skip_reason": "消息级明细已由 wechat-cli 5 群 398 msg 提供，避免重复"},
    {"tool": "search_messages", "skip_reason": "R3 本轮未定位到需要单点上下文的可疑事件；未来若 R6 反证要复查某条 KOL 发言可回调"},
    {"tool": "get_message_context", "skip_reason": "同上，未定位单点消息"}
  ],
  "coverage_ratio": "5/15",
  "coverage_color": "🟡",
  "fallback_augmented": "4 tools via citation-regex reverse (stock_hot_terms / concept_hot_terms / concept_linked_stocks / list_local_chatrooms)",
  "hard_checklist_9_required": {
    "get_analytics_meta": "✅ native (via snapshot.meta)",
    "get_hot_terms": "✅ native (via snapshot.terms)",
    "get_group_keywords": "✅ native (via snapshot.group_keywords)",
    "get_river": "✅ native (via snapshot.river, single bucket)",
    "list_local_chatrooms": "🟡 fallback via group_keywords (263 群已含)",
    "get_stock_hot_terms": "🔴 degraded to citation-regex",
    "get_concept_hot_terms": "🔴 degraded to term-name extraction",
    "get_concept_linked_stocks": "🔴 degraded to citation co-occurrence",
    "get_stock_river": "🔴 no fallback available"
  },
  "hard_checklist_pass_ratio": "4/9 native + 2/9 fallback + 3/9 degraded/missing = 6/9",
  "gap_to_close": "Ops 请把 weflow-analytics MCP 挂到 canghai-research profile；或改 parent 预导出脚本增加 stock_river/stock_heatmap/concept_linked_stocks 三个数组，使 R3 全离线也能满足 9/9 硬 checklist"
}
```
